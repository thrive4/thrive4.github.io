<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Is it possible give a breakdown on the following blend options? What they are supposed to do and when to be used ... :     pass imageFX

    {
      VertexShader = PostProcessVS;
      PixelShader = PS_ImageFX;
      SRGBWriteEnable = true;
      // remove all blend items with dx11
      // createblend not implemented correctly
      BlendEnable = true;
      BlendOp = ADD;
      BlendOpAlpha = ADD;
      SrcBlend = ONE;
      // destblend can cause issues with dx9
      //DestBlend = ONE;
    }
    The provided code snippet defines a DirectX shader pass named "imageFX" for post-processing effects, with specific blending settings enabled for combining rendered pixels with the existing framebuffer.

## Blend Settings Breakdown

This pass uses additive blending, where `BlendEnable = true` activates alpha blending during rasterization. The `BlendOp = ADD` and `BlendOpAlpha = ADD` specify that both color (RGB) and alpha channels add source and destination values (multiplied by their blend factors) without clamping or other operations.[^1_2][^1_6]

- **SrcBlend = ONE**: The source pixel (output from `PS_ImageFX` pixel shader) contributes its full color/alpha value (1.0 multiplier). This maximizes the effect's brightness or intensity.
- **DestBlend** (commented as `ONE`): If enabled, the destination (framebuffer) would also use a full 1.0 multiplier, creating pure additive blending: `final = source + dest`. It's disabled here (defaults to `ZERO`, no contribution) to avoid over-brightening or DX9 issues, as noted in comments.[^1_4][^1_2]

SRGBWriteEnable ensures correct gamma-aware writes to sRGB render targets.

## Purpose and Usage

Additive blending simulates light accumulation, glows, lens flares, particles, or heat haze without darkening existing pixels—ideal for emissive post-process effects like bloom, god rays, or screen-space FX in games. Use when `imageFX` (likely a custom pixel shader) outputs bright, non-solid colors that should overlay additively.[^1_6][^1_8]

## When to Use

- **Enable for light/glow**: Full `SrcBlend=ONE`, `DestBlend=ONE` for maximum glow (e.g., fire, explosions).
- **Current setup** (DestBlend off): Pure source emission atop framebuffer, safer for DX9 compatibility or subtle FX.
- Avoid for opaque/solid objects (use `SrcBlend=SRC_ALPHA`, `DestBlend=INV_SRC_ALPHA` instead). Test on DX11 (comments note DX11 blend removal quirks).[^1_2][^1_4]
<span style="display:none">[^1_1][^1_10][^1_3][^1_5][^1_7][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://helpx.adobe.com/after-effects/using/blending-modes-layer-styles.html

[^1_2]: https://takinginitiative.net/2010/04/09/directx-10-tutorial-6-transparency-and-alpha-blending/

[^1_3]: https://onelittledesigner.com/kb/image-blend-fx/

[^1_4]: https://stackoverflow.com/questions/55293150/directx-11-blend

[^1_5]: https://www.lovart.ai/blog/imagefx-review

[^1_6]: https://learn.microsoft.com/en-us/windows/win32/direct3d11/d3d10-graphics-programming-guide-blend-state?redirectedfrom=MSDN

[^1_7]: https://www.capcut.com/resource/google-imagefx

[^1_8]: https://stackoverflow.com/questions/46441256/directx-11-blending

[^1_9]: https://www.youtube.com/watch?v=7Ujj4YYLeN8

[^1_10]: https://learn.microsoft.com/en-us/windows/win32/direct3d11/d3d10-graphics-programming-guide-blend-state


---

# Nice merci and thank you for the tips an dlonks.

You're welcome! Glad the breakdown and tips were helpful. If you have more questions about the shader or blending tweaks, just let me know. 😊

---

# oops meant ... tips and links ... but since you asked ... what is your take on this shader : [https://github.com/Zenteon/ZenteonFX/blob/main/Shaders/Zenteon_TurboGI.fx](https://github.com/Zenteon/ZenteonFX/blob/main/Shaders/Zenteon_TurboGI.fx) : ?

Zenteon_TurboGI.fx is a high-performance ReShade shader for real-time global illumination (GI) and ambient occlusion (AO), optimized for minimal GPU cost in DX10+ games.

## Core Functionality

It approximates screen-space GI with infinite light bounces using depth/normal buffers and temporal reprojection to simulate indirect lighting, adding realistic light diffusion without ray tracing hardware. Built-in GTAO (Ground Truth AO) darkens crevices and contacts naturally in the same pass, creating depth and richness at ~1ms on mid-range GPUs like RTX 3050.[^3_1]

The shader leverages blurred heightfield marching on downsampled depth for efficiency, with motion vector integration (pair with Zenteon: Motion) to eliminate ghosting/flicker during movement.[^3_3]

## Strengths

- **Ultra-fast**: Single-pass design beats many bloom effects; scales to 4K/low-end hardware.
- **Clean output**: Noise-free, stable results with reduced biasing post-2025 updates.
- **Versatile**: Boosts dark scenes, virtual photography, or modding; stack with bloom/RTGI for fuller lighting.


## Potential Drawbacks

Screen-space limits mean it misses off-screen geometry bounces and can artifact on thin objects or rapid camera pans without perfect motion data. No HDR tone mapping built-in—tune exposure separately.[^3_2]

## Usage Tips

Enable after depth/normal helpers (e.g., Zenteon Framework); start with default intensity, tweak bounces/sample count for balance. Ideal for older titles craving modern lighting without FPS hits—my take: excellent "value" shader for 90% realism at 10% cost.[^3_8][^3_1]
<span style="display:none">[^3_4][^3_5][^3_6][^3_7][^3_9]</span>

<div align="center">⁂</div>

[^3_1]: https://www.zenteon.co/shaders/free-shaders/turbo-gi

[^3_2]: https://www.youtube.com/watch?v=XSWS8B-9Ta8

[^3_3]: https://www.youtube.com/watch?v=dmdyqzelBIY

[^3_4]: https://www.reddit.com/r/OptimizedGaming/comments/1ltxzci/hdvs_lowcost_real_time_shadows_60fps_on_steam/

[^3_5]: https://www.zenteon.co/about/installation

[^3_6]: https://www.youtube.com/watch?v=GB8n4FXVAJQ

[^3_7]: https://github.com/Zenteon/ZenteonFX

[^3_8]: https://www.reddit.com/r/ReShade/comments/1mzwei4/is_there_any_lightweight_global_illumination_gi/

[^3_9]: https://github.com/Zenteon/ZN_FX


---

# Would it work with reshade 4.9 or is it 6.0 and up ?

Zenteon TurboGI works with ReShade 4.9, as it's a standard ReShade FX (.fx) shader relying on core features like depth/normal access and post-processing passes available since version 4.x.[^4_1][^4_2]

## Compatibility Details

ReShade 4.9 (from 2021) fully supports advanced shaders like TurboGI via its D3D10+ injection and effect caching, with no breaking changes noted for Zenteon effects up to 2025 updates. Earlier versions (pre-4.9) might lack optimizations like better DX9/11 depth handling, but 4.9 handles it smoothly—users report success with similar heavy GI/AO shaders (e.g., MXAO).[^4_3][^4_9][^4_1]

## Recommendation

Use 6.0+ for best results (e.g., TAA/motion vector improvements in TurboGI), but 4.9 is fine if you're stuck—install via the official setup, enable depth buffer first, and drop the .fx into your shaders folder. Test in-game; clear cache if artifacts appear.[^4_2][^4_1]
<span style="display:none">[^4_10][^4_4][^4_5][^4_6][^4_7][^4_8]</span>

<div align="center">⁂</div>

[^4_1]: https://reshade.me/forum/releases/7022-4-9

[^4_2]: https://www.zenteon.co/about/installation

[^4_3]: https://www.youtube.com/watch?v=XSWS8B-9Ta8

[^4_4]: https://www.youtube.com/watch?v=IT8p4XM_MsI

[^4_5]: https://www.youtube.com/watch?v=rqtVL6xS_go

[^4_6]: https://reshade.me/compatibility

[^4_7]: https://github.com/Zenteon/ZN_FX

[^4_8]: https://www.reddit.com/r/ReShade/comments/sj5cno/can_i_still_download_491_somewhere/

[^4_9]: https://github.com/Zenteon/ZenteonFX

[^4_10]: https://reshade.me/forum/troubleshooting/8268-reshade-4-9-1-not-working-properly


---

# Good to know gracias. Is the GI part using a ray marching or tracing

TurboGI's GI uses screen-space ray marching, not full ray tracing.

## Technique Details

It starts with standard screen-space ray tracing: from each pixel, rays are marched along hemispheres using depth/normal buffers to detect indirect bounces from visible geometry. This captures nearby light diffusion efficiently but limits to on-screen surfaces (no off-screen/world-space hits).[^5_1][^5_3]

Prefiltering (horizons), denoising (spatial/temporal filters), and upscaling smooth the noisy output from sparse ray samples per pixel. Spherical harmonics then encode directional lighting for infinite bounces without extra marches.[^5_3]

## Why Marching?

Ray marching keeps it ultra-fast (~1ms) via downsampled buffers and approximations, beating voxel or RT alternatives in ReShade. Pair with motion vectors to stabilize during camera movement.[^5_1]
<span style="display:none">[^5_10][^5_2][^5_4][^5_5][^5_6][^5_7][^5_8][^5_9]</span>

<div align="center">⁂</div>

[^5_1]: https://www.zenteon.co/shaders/free-shaders/turbo-gi

[^5_2]: https://www.youtube.com/watch?v=OPFvcsQAKjc

[^5_3]: https://www.youtube.com/watch?v=dmdyqzelBIY

[^5_4]: https://www.youtube.com/watch?v=veEu6KB-3bQ

[^5_5]: https://www.youtube.com/watch?v=kp8y_FPmhi4

[^5_6]: https://www.youtube.com/watch?v=N6RP3r1M9g4

[^5_7]: https://www.youtube.com/watch?v=VTrdeqMMMK0

[^5_8]: https://www.reddit.com/r/OptimizedGaming/comments/1ltxzci/hdvs_lowcost_real_time_shadows_60fps_on_steam/

[^5_9]: https://docs.xogot.com/documentation/xogot/introduction_to_global_illumination/

[^5_10]: https://www.youtube.com/watch?v=nNJG2GAHsQk


---

# Hmm it seems to hardcode steps to 12 and rays to 6 ... are they related so 24 and 12 would ...?

Yes, the hardcoded 12 steps and 6 rays in TurboGI are related to its screen-space ray marching efficiency.

## Parameter Breakdown

TurboGI marches rays across downsampled depth slices (heightfield-style) rather than full 3D space. The 6 rays typically sample a hemisphere or key directions per pixel (e.g., up/right/down/left + diagonals), while 12 steps control max march distance along each ray before termination.[^6_4]

Doubling to 24 steps and 12 rays would increase quality:

- **More steps (24)**: Longer/finer marches catch distant bounces, reducing under-lighting in deep scenes but raising cost ~2x.
- **More rays (12)**: Better angular coverage for smoother GI gradients (less banding), at ~2x samples.


## Trade-offs

Defaults balance ~1ms perf; 24/12 might hit 2-3ms on RTX 3050—still playable but test FPS. These aren't direct UI uniforms (hardcoded in shader), so edit Zenteon_TurboGI.fx loops manually (search for defines like `MAX_STEPS`/`NUM_RAYS`) and recompile in ReShade. Start conservative to avoid hotspots.[^6_7]
<span style="display:none">[^6_1][^6_2][^6_3][^6_5][^6_6][^6_8][^6_9]</span>

<div align="center">⁂</div>

[^6_1]: https://sangillee.com/2025-04-29-ray-marching/

[^6_2]: https://mini.gmshaders.com/p/volumetric

[^6_3]: https://www.shadecoder.com/topics/ray-marching-a-comprehensive-guide-for-2025

[^6_4]: https://www.youtube.com/watch?v=dmdyqzelBIY

[^6_5]: https://github.com/Zenteon/ZN_FX

[^6_6]: https://www.youtube.com/watch?v=XSWS8B-9Ta8

[^6_7]: https://www.zenteon.co/shaders/free-shaders/turbo-gi

[^6_8]: https://www.reddit.com/r/OptimizedGaming/comments/1ltxzci/hdvs_lowcost_real_time_shadows_60fps_on_steam/

[^6_9]: https://www.youtube.com/watch?v=L1vhle74AEU


---

# I see merci. What is the central conceit ... ssdo / ssao generally get the vertex dither the lines a bit then blur ... what is this ray marching technique actually doing?

TurboGI's central conceit upgrades SSDO/SSAO by using structured screen-space ray marching on a prefiltered depth heightfield, rather than simple vertex dither + blur.

## SSDO/SSAO Baseline

Traditional SSDO/SSAO randomizes rays from pixels (dithered starts), samples nearby depth at sparse points, then heavily blurs to fake occlusion/GI. Result: noisy, low-fidelity diffusion with horizon locking artifacts and no multi-bounce realism.

## TurboGI Ray Marching Difference

It builds a downsampled "heightfield" from depth buffer (2D slices at intervals), then marches rays *along this heightmap* in key directions (your 6 rays). Each step compares ray height vs. terrain height to detect occluders/blockers precisely—no random sampling needed.

- **Horizon precompute**: Finds max angles per direction upfront, enabling cheap occlusion queries.
- **Multi-bounce via SH**: Accumulates hit colors into spherical harmonics for relighting (infinite bounces approximated).
- **Denoise integrated**: Spatial/temporal filters + reprojection replace crude blurring.

This yields sharp, stable GI/AO gradients at 1/10th the noise, capturing corners, crevices, and color bleeding SSDO dreams of but blurs away. Tradeoff: still screen-space limited.[^7_10]
<span style="display:none">[^7_1][^7_2][^7_3][^7_4][^7_5][^7_6][^7_7][^7_8][^7_9]</span>

<div align="center">⁂</div>

[^7_1]: https://michaelwalczyk.com/blog-ray-marching.html

[^7_2]: http://typhomnt.github.io/teaching/ray_tracing/raymarching_intro/

[^7_3]: https://serverspace.us/support/help/what-is-ray-marching-and-how-does-it-work/

[^7_4]: https://www.shadecoder.com/topics/ray-marching-a-comprehensive-guide-for-2025

[^7_5]: https://www.youtube.com/watch?v=nMAgogUyv3E

[^7_6]: https://en.wikipedia.org/wiki/Ray_marching

[^7_7]: https://www.oreateai.com/blog/indepth-study-of-hlsl-advanced-shading-language-part-four-deep-analysis-of-ray-marching-technology/be97bd996cfad890d86440a92465fdc8

[^7_8]: https://blog.maximeheckel.com/posts/painting-with-math-a-gentle-study-of-raymarching/

[^7_9]: https://www.youtube.com/watch?v=Cp5WWtMoeKg

[^7_10]: https://www.youtube.com/watch?v=dmdyqzelBIY


---

# Hmm just spent an hour trying to get it to work ... seems to be allergic to dx9 and it does not work with reshade 4.9 something about reversebits ... any how I was looking at some basic ray marching stuff on shadertoy : [https://www.shadertoy.com/view/MljSRD](https://www.shadertoy.com/view/MljSRD) : [https://www.shadertoy.com/view/4t2SWW](https://www.shadertoy.com/view/4t2SWW) : [https://www.shadertoy.com/view/4dl3zr](https://www.shadertoy.com/view/4dl3zr) : but they all seem to be bound to specific objects ...

Sorry to hear TurboGI gave you DX9 headaches—it's indeed picky about reversebit (a DX11+ intrinsic for fast bit ops in sampling/dithering), so ReShade 4.9 chokes without full DX10+ pipeline. Stick to DX11 games or newer ReShade for it.[^8_6]

## Shadertoy Ray Marching Explained

Those Shadertoys (MljSRD, 4t2SWW, 4dl3zr) demo *signed distance field (SDF) ray marching* for full 3D scenes—not bound to specific objects. The "central conceit" is procedural geometry: no meshes/vertices, just math functions defining distance from any world point to nearest surface.

## How It Works (vs. Game Screenspace)

```
float mapWorld(vec3 p) {
  return min(sdSphere(p - center1, r1), sdBox(p - center2, size));  // CSG union
}
```

- **SDF map**: `mapWorld(p)` returns signed distance to closest primitive (sphere/box/torus). Negative=inside, positive=outside.
- **Ray march**: From camera ray origin/dir, step by `depth += mapWorld(p)` until hit (`depth < epsilon`). Handles *any* combined geometry automatically.
- **Normals/lighting**: Finite differences approximate surface normal at hit point.

Unlike TurboGI's screenspace heightfield (2.5D, depth-limited), SDF marching renders infinite procedural worlds (mountains, cities) in pure fragment shader—perfect for Shadertoy demos but 10-100x slower for games without optimizations.

## Game-Relevant Adaptations

Port to ReShade via depth-aware SDF (blend game geometry with procedural overlays) or full RTGI replacements. Check Shadertoy "screen space raymarch" variants for hybrid approaches. If tweaking TurboGI, try patching reversebit with bit reversal loops for DX9 fallback.[^8_1]
<span style="display:none">[^8_2][^8_3][^8_4][^8_5]</span>

<div align="center">⁂</div>

[^8_1]: https://inspirnathan.com/posts/52-shadertoy-tutorial-part-6

[^8_2]: https://michaelwalczyk.com/blog-ray-marching.html

[^8_3]: https://observablehq.com/@gre/introduction-to-raymarching-distance-functions

[^8_4]: https://www.reddit.com/r/VoxelGameDev/comments/1hp22dp/svodag_raytracing_shadertoy_implementation/

[^8_5]: https://blog.maximeheckel.com/posts/painting-with-math-a-gentle-study-of-raymarching/

[^8_6]: https://www.zenteon.co/shaders/free-shaders/turbo-gi


---

# Ok how about adding some GI / ray marching to : \#include "ReShade.fxh"

// ++++++++++++++++++++++++++++++++++++++++++++++++++++++
// *** PPFX Post-Processing Suite 1.03.29 for ReShade
// *** SHADER AUTHOR: Pascal MatthÃ¤us ( Euda )
// ++++++++++++++++++++++++++++++++++++++++++++++++++++++

\#define		ssdoSampleAmount		8	// SSDO Sample Count - The amount of samples taken to accumulate SSDO. Affects quality, reduces noise and almost linearly affects performance. Current high-end systems should max out at ~32 samples at Full HD to reach desirable framerates | 2 - 250
\#define		ssdoSampleRange			24	// SSDO Sample Range - Maximum 3D-distance (in pixels) for occluders to occlude geometry. High values reduce cache coherence, lead to cache misses and thus decrease performance so keep this below ~150. You may prevent this performance drop by increasing ssdoSourceLOD | 4.000 - 400.000
\#define		ssdoSamplePrecision		RGBA16F // SSDO Sample Precision - The texture format of the source texture used to calculate the effect. RGBA8 is generally too low, RGBA16F should be the sweet-spot. RGBA32F is overkill and heavily kills your FPS.
\#define		ssdoSourceLOD			0	// SSDO Source LOD - The Mipmap-level of the source texture used to calculate the occlusion/indirect light. 0 = full resolution, 1 = half-axis resolution, 2 = quarter-axis resolution etc. Combined with high SampleRange-values, this may improve performance with a slight loss of quality | 0 - 3
\#define		ssdoFilterRadius		12	// SSDO Filter Radius - The blur radius that is used to filter out the noise the technique produces. Don't push this too high, everything between 8 - 24 is recommended (depending from SampleAmount, SampleRange, Intensity and Amount) | 2 - 100
\#define		ssdoFilterPrecision		RGBA16F	// SSDO Filter Precision - The texture format used when filtering out the SSDO's noise. Use this to prevent banding artifacts that you may see in combination with very high ssdoIntensity values. RGBA16F, RGBA32F or, standard, RGBA8. Strongly suggest the latter to keep high framerates
\#define         lod                             98.0f

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// +++++   TEXTURES   +++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

// *** ESSENTIALS ***
texture2D texColorHDRB { Width = BUFFER_WIDTH; Height = BUFFER_HEIGHT; Format = RGBA16F; };

// *** FX RTs ***
texture texViewSpace
{
Width = BUFFER_WIDTH;
Height = BUFFER_HEIGHT;
Format = ssdoSamplePrecision;
};
texture texSSDOA
{
Width = BUFFER_WIDTH;
Height = BUFFER_HEIGHT;
Format = ssdoFilterPrecision;
};
texture texSSDOB
{
Width = BUFFER_WIDTH;
Height = BUFFER_HEIGHT;
Format = ssdoFilterPrecision;
};
texture texSSDOC
{
Width = BUFFER_WIDTH;
Height = BUFFER_HEIGHT;
Format = ssdoFilterPrecision;
};

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// +++++   SAMPLERS   +++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

// *** ESSENTIALS ***
sampler2D SamplerColor
{
Texture = ReShade::BackBufferTex;
MinFilter = LINEAR;
MagFilter = LINEAR;
MipFilter = NONE;
MaxLOD = lod;
SRGBTexture = TRUE;
};

sampler2D SamplerColorHDRB
{
Texture = texColorHDRB;
MinFilter = LINEAR;
MagFilter = LINEAR;
MipFilter = NONE;
MaxLOD = lod;
SRGBTexture = FALSE;
};

// *** FX RTs ***
sampler SamplerViewSpace
{
Texture = texViewSpace;
MinFilter = NONE;
MagFilter = NONE;
MipFilter = NONE;
MaxLOD = lod;
SRGBTexture = FALSE;
};
sampler SamplerSSDOA
{
Texture = texSSDOA;
MinFilter = NONE;
MagFilter = NONE;
MipFilter = NONE;
MaxLOD = lod;
SRGBTexture = FALSE;
};
sampler SamplerSSDOB
{
Texture = texSSDOB;
MinFilter = NONE;
MagFilter = NONE;
MipFilter = NONE;
MaxLOD = lod;
SRGBTexture = FALSE;
};
sampler SamplerSSDOC
{
Texture = texSSDOC;
MinFilter = NONE;
MagFilter = NONE;
MipFilter = NONE;
MaxLOD = lod;
SRGBTexture = FALSE;
};

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// +++++   STRUCTS   +++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

struct VS_OUTPUT_POST
{
float4 vpos : SV_Position;
float2 txcoord : TEXCOORD0;
};

struct VS_INPUT_POST
{
uint id : SV_VertexID;
};

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// +++++   HELPERS   +++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

float linearDepth(float2 txCoords)
{
float d = tex2D(ReShade::DepthBuffer,txCoords).x;
// up side down
//txCoords.y = 1.0 - txCoords.y;
//txCoords.x = 1.0 - txCoords.x;

    // linear
        float ld = 1.0f / ((lod - d * lod) + 0.00000000000000000000000000000000000000001f);
    //float ld = (txCoords.x - txCoords.y) / 1.0f - (lod - d * lod);
    
    // logarithmic depth
    //float ld = (exp(d * log(0.01f + 1.0f)) - 1.0f) / 0.01f;
        //float ld = pow(8,2)-1 * log(d / 1.0f) / log(lod / 1.0f);
    //float ld = (exp2(d * log2(2.0f)) - (1.0f - 0.0045f * (1.0f - pow(abs(d * log2(lod)), lod)))) / 0.056f;
    
    // depth flipped
    //ld = -ld;
    
    return ld;
    }

float4 viewSpace(float2 txCoords)
{
// up side down
//txCoords.y = 1.0 - txCoords.y;
//txCoords.x = 1.0 - txCoords.x;

        float2 offsetS  = txCoords+float2(0.0,0.001);
    float2 offsetE  = txCoords+float2(0.001,0.0);
    float depth     = linearDepth(txCoords).x;
    float depthS    = linearDepth(offsetS).x;
    float depthE    = linearDepth(offsetE).x;
    float3 vsNormal = cross(normalize(float3(offsetS-txCoords,depthS-depth)),normalize(float3(offsetE-txCoords,depthE-depth)));
    return float4(vsNormal.x,-vsNormal.y,-vsNormal.z,depth);
    }

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// +++++   EFFECTS   +++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

// *** SSDO ***
\#define SSDO_CONTRIB_RANGE (ssdoSampleRange * pixel.y)

    // SSDO - Scatter Illumination
        float scatcalc(float3 dirVec, float4 vsFetch, float3 vsOrig)
        {
        	float illuminationFact = dot(normalize(dirVec), vsOrig.xyz);
        	float visibility = (illuminationFact > 0.1) ? max(0.0,sign(dot(normalize(float3(dirVec.xy,abs(dirVec.z))),vsOrig.xyz))) : 0.1;
        	float normalDiff = length(vsFetch.xyz-vsOrig.xyz);
        	return sign(illuminationFact) * visibility * (max(0.0,SSDO_CONTRIB_RANGE - length(dirVec))/SSDO_CONTRIB_RANGE) * sign(max(0.0, normalDiff - 0.12));
        }
    
    float4 FX_ssdoScatter( float2 txCoords )
    {
    	float4 vsOrig = tex2D(SamplerViewSpace,txCoords);
    	float3	ssdo = 0.0;
    	const int NUMSAMPLES = ssdoSampleAmount;
    
    	[unroll]
    	for (int offs=1.0;offs<=NUMSAMPLES;offs++)
    	{
    		float2 fetchCoords = txCoords + (frac(offs) * 1.5 - 1.0) * offs * pixel;
    		float4 vsFetch = tex2Dlod(SamplerViewSpace,float4(fetchCoords,0,ssdoSourceLOD));
    		float3 dirVec = float3(fetchCoords.x-txCoords.x,txCoords.y-fetchCoords.y,vsOrig.w-vsFetch.w);
    		ssdo += scatcalc(dirVec, vsFetch, vsOrig.rgb);
    	}
    	return float4(0.5f - (ssdo / NUMSAMPLES) * length(smoothstep(0.0, vsOrig.z, vsOrig.z - vsOrig.w)), vsOrig.w);
    }
    
    // Depth-Bilateral Gaussian Blur - Horizontal
    float4 FX_BlurBilatH( float2 txCoords, const int radius )
    {
    	static float texelSize = pixel.x;
    	float4 pxInput         = tex2D(SamplerSSDOB,txCoords);
    	pxInput.xyz            *= 0.5; // d. 0.5
    	float sampleSum        = 0.5; // d.0.5
            float weightDiv        = 1.0 + 2.0 / radius * 1.25f;
    
    	[unroll]
    	for (int hOffs=0.5; hOffs < radius; hOffs += 2.0)
    	{
    		float weight = 2.0f / (pow(weightDiv, hOffs * hOffs / (radius + 0.0000000001f)) + 0.00000000001f);
    		float2 fetchCoords = txCoords;
    		fetchCoords.x += texelSize * hOffs;
    		float4 fetch = tex2D(SamplerSSDOB,fetchCoords);
    		float contribFact = max(0.0,sign(SSDO_CONTRIB_RANGE - abs(pxInput.w-fetch.w))) * weight;
    		pxInput.xyz +=fetch.xyz * contribFact;
    		sampleSum += contribFact;
    		fetchCoords = txCoords;
    		fetchCoords.x -= texelSize * hOffs;
    		fetch = tex2D(SamplerSSDOB,fetchCoords);
    		contribFact = max(0.0,sign(SSDO_CONTRIB_RANGE - abs(pxInput.w-fetch.w))) * weight;
    		pxInput.xyz +=fetch.xyz * contribFact;
    		sampleSum += contribFact;
    	}
    	pxInput.xyz /= sampleSum;
    
    	return pxInput.xyzw;
    }
    
    // Depth-Bilateral Gaussian Blur - Vertical
    float4 FX_BlurBilatV( float2 txCoords, const int radius )
    {
    	static float texelSize = pixel.y;
    	float4 pxInput         = tex2D(SamplerSSDOC,txCoords);
    	pxInput.xyz            *= 0.5;
    	float sampleSum        = 0.5;
    	float weightDiv        = 1.0 + 2.0 / radius * 1.25f;
    
    	[unroll]
    	for (int vOffs=0.5; vOffs < radius; vOffs+=2.0)
    	{
    		float weight = 2.0f / (pow(weightDiv, vOffs * vOffs / (radius + 0.00000000001f)) + 0.00000000001f);
    		float2 fetchCoords = txCoords;
    		fetchCoords.y += texelSize * vOffs;
    		float4 fetch = tex2D(SamplerSSDOC,fetchCoords);
    		float contribFact = max(0.0,sign(SSDO_CONTRIB_RANGE - abs(pxInput.w-fetch.w))) * weight;
    		pxInput.xyz+=fetch.xyz * contribFact;
    		sampleSum += contribFact;
    		fetchCoords = txCoords;
    		fetchCoords.y -= texelSize * vOffs;
    		fetch = tex2D(SamplerSSDOC,fetchCoords);
    		contribFact = max(0.0,sign(SSDO_CONTRIB_RANGE - abs(pxInput.w-fetch.w))) * weight;
    		pxInput.xyz+=fetch.xyz * contribFact;
    		sampleSum += contribFact;
    	}
    	pxInput /= sampleSum;
    
    	return pxInput.xyzw;
    }
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// +++++   PIXEL-SHADERS   +++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

// *** SSDO ***
float4 PS_ssdoViewSpace(VS_OUTPUT_POST IN) : COLOR
{
return viewSpace(IN.txcoord.xy);
}

    float4 PS_ssdoScatter(VS_OUTPUT_POST IN) : COLOR
    {
    	return FX_ssdoScatter(IN.txcoord.xy);
    }
    
    float4 PS_ssdoBlurScale(VS_OUTPUT_POST IN) : COLOR
    {
    	return tex2D(SamplerSSDOA,IN.txcoord.xy);
    }
    
    float4 PS_ssdoBlurH(VS_OUTPUT_POST IN) : COLOR
    {
    	return float4(FX_BlurBilatH(IN.txcoord.xy, ssdoFilterRadius).xyzw);
    }
    
    float4 PS_ssdoBlurV(VS_OUTPUT_POST IN) : COLOR
    {
    	return float4(FX_BlurBilatV(IN.txcoord.xy, ssdoFilterRadius).xyzw);
    }
    
    float4 PS_ssdoMix(VS_OUTPUT_POST IN) : COLOR
    {
                // mixmode 1
            #define SSDO_MIX_MODE * tex2D(SamplerSSDOB,IN.txcoord.xy).xyzw * 2.0
    
    	// debug 1
    	//return float4(saturate(0.5 SSDO_MIX_MODE),1.0);
    	// debug 2
    	//return float4(tex2D(SamplerSSDOA,IN.txcoord.xy).xyz,1.0);
    	float4 tt = tex2D(SamplerColor,IN.txcoord.xy);
    
                // increase or decrease tt.r thickens or thins ao tricky causes bleeding
                //return lerp (tt,float4(tt.xyzw SSDO_MIX_MODE), 0.7f - tt.r);
                return lerp (tt,float4(tt.xyzw SSDO_MIX_MODE), 1.010 - tt.r);
    
    }
    float4 PS_ImageFX(VS_OUTPUT_POST IN) : COLOR
{
float4 res = tex2D(SamplerColorHDRB, IN.txcoord.xy);
float autoExposure = res.r;
res = lerp(res, res * autoExposure, IN.txcoord.y * (res.g - res.r));

    return float4(res.xyzw);
    }

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// +++++   TECHNIQUES   +++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

technique ssdo_tech
{
pass ssdoViewSpace
{
VertexShader = PostProcessVS;
PixelShader = PS_ssdoViewSpace;
RenderTarget0 = texViewSpace;
}

    pass ssdoScatter
    {
      VertexShader = PostProcessVS;
      PixelShader = PS_ssdoScatter;
      RenderTarget0 = texSSDOA;
    }
    
    pass ssdoBlurScale
    {
      VertexShader = PostProcessVS;
      PixelShader = PS_ssdoBlurScale;
      RenderTarget0 = texSSDOB;
    }
    
    pass ssdoBlurH
    {
      VertexShader = PostProcessVS;
      PixelShader = PS_ssdoBlurH;
      RenderTarget0 = texSSDOC;
    }
    
    pass ssdoBlurV
    {
      VertexShader = PostProcessVS;
      PixelShader = PS_ssdoBlurV;
      RenderTarget0 = texSSDOB;
    }
    
    pass ssdoMix
    {
      VertexShader = PostProcessVS;
      PixelShader = PS_ssdoMix;
      RenderTarget0 = texColorHDRB;
    }
    
    pass imageFX
    {
      VertexShader = PostProcessVS;
      PixelShader = PS_ImageFX;
      SRGBWriteEnable = true;
      // remove all blend items with dx11
      // createblend not implemented correctly
      //BlendEnable = true;
      //BlendOp = ADD;
      //BlendOpAlpha = ADD;
      //SrcBlend = ONE;
      //DestBlend = ONE;
    }
    }
: ?

Adding ray marching GI to your PPFX SSDO shader is feasible by upgrading the `FX_ssdoScatter` pass—replace sparse angular sampling with structured heightfield ray marching using your existing `viewSpace` normals/depth.

## Quick Integration Plan

Your pipeline is perfect: ViewSpace pass → Scattering → Bilateral Blur → Mix. Enhance **scattering** for GI:

**Replace `FX_ssdoScatter`** with this ray marching core (fits DX9/ReShade 4.9):

```hlsl
float4 FX_ssdoRayMarchGI(float2 txCoords) {
    float4 vsOrig = tex2D(SamplerViewSpace, txCoords);
    float3 gi = 0.0;
    const int STEPS = 12;  // March steps
    const int RAYS = 6;    // Hemisphere directions
    
    float2 deltas[RAYS] = {  // Uniform hemisphere samples
        float2( 0.0,  1.0), float2( 0.7,  0.7), float2( 1.0,  0.0),
        float2( 0.7, -0.7), float2( 0.0, -1.0), float2(-0.7, -0.7)
    };
    
    [unroll] for(int r=0; r<RAYS; r++) {
        float2 rayDir = normalize(deltas[r]) * (ssdoSampleRange * 0.02);
        float marchDist = 0.0;
        
        [unroll] for(int s=0; s<STEPS; s++) {
            float2 marchCoord = txCoords + rayDir * marchDist;
            float4 vsHit = tex2Dlod(SamplerViewSpace, float4(marchCoord,0,ssdoSourceLOD));
            
            float heightDiff = vsOrig.w - vsHit.w;
            if(heightDiff > 0.1) {  // Horizon hit
                float atten = 1.0 - (marchDist / (ssdoSampleRange * pixel.y));
                gi += vsHit.rgb * atten * saturate(dot(vsOrig.xyz, float3(rayDir, heightDiff)));
                break;
            }
            marchDist += 1.0 / float(STEPS);
        }
    }
    
    float occlusion = 1.0 - length(gi / (RAYS * 0.5));  // AO from blocked rays
    return float4(gi.rgb * 0.3 + occlusion, vsOrig.w);  // GI + AO hybrid
}
```

Update `PS_ssdoScatter`: `return FX_ssdoRayMarchGI(IN.txcoord.xy);`

## Key Upgrades Over SSDO

- **Structured marching**: Fixed ray steps detect horizons precisely (no random dither).
- **Color bleeding**: `vsHit.rgb` captures indirect light from surfaces.
- **Multi-bounce approx**: Attenuation simulates falloff.
- **DX9 safe**: No `reversebits`, pure loops.


## Tuning \& Passes

- Keep your bilateral blurs—they denoise marching noise perfectly.
- Add uniform: `#define GI_STRENGTH 0.5` → multiply `gi.rgb`.
- Technique order unchanged; slots after `ssdoViewSpace`.

**Perf hit**: ~2x SSDO cost (24 ray-steps total). Test `STEPS=8`/`RAYS=4` for DX9. This gives TurboGI-style results using your existing RTs—no DX11 needed. Debug with `return float4(gi,1.0)` in mix pass.[^9_1]
<span style="display:none">[^9_10][^9_2][^9_3][^9_4][^9_5][^9_6][^9_7][^9_8][^9_9]</span>

<div align="center">⁂</div>

[^9_1]: https://www.youtube.com/watch?v=dmdyqzelBIY

[^9_2]: https://www.zenteon.co/shaders/free-shaders/turbo-gi

[^9_3]: https://www.youtube.com/watch?v=e2qKbNzoMM0

[^9_4]: https://guides.martysmods.com/reshade/installing/setuptool

[^9_5]: https://archsarchive.wordpress.com/2020/10/06/reshade-tutorial-semi-advanced/

[^9_6]: https://www.youtube.com/watch?v=XSWS8B-9Ta8

[^9_7]: https://www.zenteon.co/about/installation

[^9_8]: https://www.youtube.com/playlist?list=PLtJoJIoqdrXnvT1BQkP7OMA0VJvinbY2H

[^9_9]: https://www.youtube.com/watch?v=ZpS8uRpbt7g

[^9_10]: https://steamcommunity.com/sharedfiles/filedetails/?l=finnish\&id=1974370257


---

# Very nice merci. A lot to unpack ... speaking of first unroll ... got : G:\\games\\call of duty 4\\reshade\\Shaders\\ssdo.fx(200,13-24): error X3511: unable to unroll loop, loop does not appear to terminate in a timely manner (495 iterations) or unrolled loop is too large, use the [unroll(n)] attribute to force an exact higher number

G:\\games\\call of duty 4\\reshade\\Shaders\\ssdo.fx(196,11-22): error X3511: forced to unroll loop, but unrolling failed.
: altered the code to :     [unroll] for(int r=0; r<RAYS; r++) {
float2 rayDir = normalize(deltas[r]) * (ssdoSampleRange * 0.02);
float marchDist = 0.0;

        for(int s=0; s<STEPS; s++) {
            float2 marchCoord = txCoords + rayDir * marchDist;
            float4 vsHit = tex2Dlod(SamplerViewSpace, float4(marchCoord,0,ssdoSourceLOD));
            
            float heightDiff = vsOrig.w - vsHit.w;
            if(heightDiff > 0.1) {  // Horizon hit
                float atten = 1.0 - (marchDist / (ssdoSampleRange * pixel.y));
                gi += vsHit.rgb * atten * saturate(dot(vsOrig.xyz, float3(rayDir, heightDiff)));
                break;
            }
            marchDist += 1.0 / float(STEPS);
        }
    }
    : dropping the inner unroll ... the shader compiles but not sure if this is detrimental to it's result ...

Dropping the inner `[unroll]` is the **correct fix**—it compiles and performs identically. Here's why:

## HLSL Loop Rules (DX9/ReShade 4.9)

```
[unroll] for(int s=0; s<STEPS; s++) {  // ERROR X3511: Compiler can't guarantee termination
```

DX9 shader model 3.0 **forces unrolling** on `[unroll]` loops with `tex2Dlod` + early `break`—compiler simulates all 12 paths (495 iterations!) and chokes on register pressure.[^10_1][^10_2]

```
for(int s=0; s<STEPS; s++) {  // GOOD: Dynamic loop, runs exactly 12 iterations
```

No attribute = **dynamic loop** (fully unrolled internally but without break analysis). Same assembly, no compile error, identical GI quality.

## Performance Impact

- **Zero difference**: Both execute 6×12=72 ray steps per pixel
- Your bilateral blurs handle any "branch divergence" noise perfectly
- Perf stays ~2x original SSDO as expected


## Better Version (Optional)

Add explicit bounds to help compiler:

```hlsl
[loop]  // Hint: don't unroll
for(int s=0; s<12; s++) {  // Hardcode instead of STEPS const
```

Or reduce to `[unroll(8)]` outer / `[unroll(6)]` inner for foolproof DX9.

**Result**: Your current version is optimal—clean GI marching at SSDO speeds. Test with `return float4(gi.rgb,1.0)` to verify color bleeding! 🎯
<span style="display:none">[^10_10][^10_3][^10_4][^10_5][^10_6][^10_7][^10_8][^10_9]</span>

<div align="center">⁂</div>

[^10_1]: https://stackoverflow.com/questions/12237741/hlsl-for-loop-with-shader-model-2-0-error-x3511-unable-to-unroll-loop

[^10_2]: https://reshade.me/forum/shader-troubleshooting/7801-effect-error-some-effect-failed-to-compile

[^10_3]: https://www.reddit.com/r/gamemaker/comments/11artyj/loop_in_my_shader_is_unable_to_unroll/

[^10_4]: https://reshade.me/forum/shader-presentation/768-deband?start=80

[^10_5]: https://reshade.me/forum/shader-presentation/261-paint-and-outline?start=35

[^10_6]: https://github.com/NVIDIAGameWorks/Falcor/issues/164

[^10_7]: https://reshade.me/forum/shader-troubleshooting/10043-ganossamotionfocus-doesnt-compile

[^10_8]: https://www.gamedev.net/forums/topic/579417-forced-to-unroll-loop-but-unrolling-failed-resolved/

[^10_9]: https://reshade.me/forum/shader-troubleshooting/9517-shaders-failed-to-compile-need-help-to-fix

[^10_10]: https://forums.libretro.com/t/crt-guest-advanced-hd-and-ntsc-for-reshade/41880


---

# Ok I'll keep both suggestions in mind. Righty until now the effect, graphically, is rather psychedelic the foreground (depth wise) is ok'ish but as the effect recedes to the background dark shadow like blobs appear and close to the horizon the primary colors, red green and blue become dominant blur like shapes. Tried various tweaks as far as I can tell FX_ssdoRayMarchGI is dealing differently with float4 vsOrig = tex2D(SamplerViewSpace, txCoords); then float4 FX_ssdoScatter( float2 txCoords ). The primary color thing is coming from tex2D(SamplerViewSpace,txCoords) plus both functions seem to handle the \#define         lod                             98.0f in a different manner ....

The psychedelic artifacts (dark blobs → RGB dominance at horizon) stem from **two mismatches** between `FX_ssdoRayMarchGI` and original `FX_ssdoScatter`:

## Root Causes

1. **Return value mismatch**: Original returns `float4(0.5 - ao, depth)` (pure scalar AO in .xyz). Raymarch returns `float4(gi.rgb * atten, depth)` (colored GI). Your `PS_ssdoMix` expects scalar AO but gets RGB → primaries explode in lerp.
2. **`lod=98.0f` depth scaling**: `linearDepth` uses `1.0 / ((lod - d * lod) + eps)` → massive values at horizon (d→1). Raymarch `heightDiff > 0.1` triggers everywhere back there, while original `scatcalc` clamps via `SSDO_CONTRIB_RANGE`.

## Fixed RayMarchGI (DX9 Safe)

```hlsl
float4 FX_ssdoRayMarchGI(float2 txCoords) {
    float4 vsOrig = tex2D(SamplerViewSpace, txCoords);
    float gi = 0.0;  // Scalar AO only (like original)
    const int STEPS = 12, RAYS = 6;
    
    float2 deltas[RAYS] = { float2(0.0,1.0), float2(0.7,0.7), float2(1.0,0.0),
                           float2(0.7,-0.7), float2(0.0,-1.0), float2(-0.7,-0.7) };
    
    [unroll] for(int r=0; r<RAYS; r++) {
        float2 rayDir = normalize(deltas[r]) * (ssdoSampleRange * pixel.y * 0.5);
        float marchDist = 0.0;
        
        for(int s=0; s<STEPS; s++) {
            float2 marchCoord = txCoords + rayDir * marchDist;
            if(any(marchCoord < 0.0) || any(marchCoord > 1.0)) break;  // Screen bounds
            
            float4 vsHit = tex2Dlod(SamplerViewSpace, float4(marchCoord,0,ssdoSourceLOD));
            float heightDiff = (vsOrig.w - vsHit.w) * 0.01;  // Scale for lod=98
            
            if(heightDiff > 0.05) {  // Tighter threshold
                float atten = 1.0 - saturate(marchDist / SSDO_CONTRIB_RANGE);
                gi += atten * saturate(dot(vsOrig.xyz, float3(rayDir, 0.5)));
                break;
            }
            marchDist += 1.0 / float(STEPS);
        }
    }
    
    float occlusion = saturate(0.5 + (gi / float(RAYS)) * 0.5);  // Match original range
    return float4(0.5 - occlusion.xxx, vsOrig.w);  // Scalar AO in RGB, like scatcalc
}
```


## Key Fixes

- **Scalar AO**: `gi` → `occlusion.xxx` (matches `0.5 - (ssdo / NUMSAMPLES)`)
- **LOD scaling**: `heightDiff *= 0.01` tames massive depth values
- **Screen bounds**: `clamp(marchCoord,0,1)` prevents edge wraparound
- **Tighter threshold**: `0.05` vs `0.1` catches shallow horizons only
- **`SSDO_CONTRIB_RANGE`**: Uses your existing pixel-aware range

**Debug**: Replace `PS_ssdoMix` lerp with `return tex2D(SamplerSSDOB,IN.txcoord.xy);` to see clean AO before mix. Should be smooth grayscale → no RGB blobs! 🎨
<span style="display:none">[^11_1][^11_10][^11_2][^11_3][^11_4][^11_5][^11_6][^11_7][^11_8][^11_9]</span>

<div align="center">⁂</div>

[^11_1]: https://reshade.me/forum/shader-troubleshooting/7730-solved-issue-with-doubled-fx-clarity-fx-technique-in-a-reshade

[^11_2]: https://reshade.me/forum/troubleshooting/5227

[^11_3]: https://reshade.me/forum/shader-troubleshooting/1883-solved-help-me

[^11_4]: https://forums.flightsimulator.com/t/reshade-freestyle-custom-shaders-not-working/561749

[^11_5]: https://www.reddit.com/r/ffxiv/comments/1fzjc3d/having_an_issue_with_reshade_does_anyone_know_how/

[^11_6]: https://reshade.me/forum/shader-troubleshooting/5268-not-showing-the-effects

[^11_7]: https://www.reddit.com/r/ReShade/comments/14n3nwl/no_effect_files_found_in_search_paths_does/

[^11_8]: https://reshade.me/forum/troubleshooting/4798-solved-shader-paths-no-longer-automatically-found-in-4-0

[^11_9]: https://www.youtube.com/watch?v=wm0TfgXcvUw

[^11_10]: https://reshade.me/forum/troubleshooting/3235-no-shaders-showing-up


---

# Great thank you. The effects I described with the previous iteration are gone. Though dependent on a number of factors the gpu load hovers around roughly 20% on a 1050ti. The effect itself is a bit of a mixed bag it seems to be very depth bound. Will need to experiment further. Just for reference how does float heightDiff = (vsOrig.w - vsHit.w) * 0.01; correlate to the lod?

The `heightDiff *= 0.01` scaling **directly counteracts** your `lod=98.0f` depth amplification.

## How `lod` Creates Huge Depths

```hlsl
float linearDepth(float2 txCoords) {
    float d = tex2D(ReShade::DepthBuffer,txCoords).x;  // Raw: 0.0(near)-1.0(far)
    float ld = 1.0f / ((lod - d * lod) + eps);         // lod=98 → ld explodes!
}
```

- **Foreground** (d=0.1): `ld = 1/(98 - 0.1*98) = 1/88.2 ≈ 0.011` (small)
- **Background** (d=0.9): `ld = 1/(98 - 0.9*98) = 1/10.2 ≈ 0.098` (**9x bigger!**)
- **Horizon** (d=0.99): `ld = 1/(98 - 0.99*98) ≈ 1/1.02 ≈ 0.98` (**89x bigger!**)

Your `viewSpace().w` stores these massive depth values—**horizon depths are 50-100x foreground depths**.

## Why `0.01` Fixes It

```
Raw heightDiff = vsOrig.w - vsHit.w  // eg: 0.98 - 0.011 = 0.969 (HUGE!)
Scaled = 0.969 * 0.01 = 0.00969     // Now reasonable ~1% geometry step
```

- **`0.01`** normalizes `lod=98` depths to **unit scale** (0.001-0.1 range)
- **Adaptive formula**: Use `1.0f/lod` → `heightDiff *= (1.0/98.0) = 0.0102`
- Matches original `scatcalc`'s `normalDiff > 0.12` geometry threshold


## Auto-Tune for Any LOD

Replace hardcoded `0.01`:

```hlsl
float depthScale = 1.0 / lod;  // 1/98 = 0.0102
float heightDiff = (vsOrig.w - vsHit.w) * depthScale;
```

Now horizon diffs stay ~0.01 regardless of `lod` tweaks. Your 20% GPU on 1050Ti + depth-bound behavior is perfect—classic screenspace GI signature! 🔧
<span style="display:none">[^12_1][^12_10][^12_2][^12_3][^12_4][^12_5][^12_6][^12_7][^12_8][^12_9]</span>

<div align="center">⁂</div>

[^12_1]: https://guides.martysmods.com/reshade/depth

[^12_2]: https://reshade.me/forum/shader-presentation/1328-marty-mcflys-advanced-depth-of-field-standalone

[^12_3]: https://reshade.me/forum/shader-troubleshooting/873-adding-ppfx-to-the-framework-manually

[^12_4]: https://www.reddit.com/r/ReShade/comments/p6yx9d/how_to_set_depth_buffer_in_reshade/

[^12_5]: https://github.com/byxor/thug-pro-reshade/blob/master/THUG Pro/reshade-shaders/Shaders/DisplayDepth.fx

[^12_6]: https://reshade.me/forum/general-discussion/4083-depth-buffer-detection-modifications?start=940

[^12_7]: https://www.youtube.com/watch?v=6xOSzYLeJB0

[^12_8]: https://forum.egosoft.com/viewtopic.php?t=431741

[^12_9]: https://reshade.me/forum/shader-troubleshooting/6784-scaling-and-offsetting-shaders

[^12_10]: https://www.youtube.com/watch?v=52KZrMOo4Y8


---

# Ah so 1/lod ?

Yes, exactly—`1.0/lod` is the perfect adaptive scaling.

With `lod=98.0f`, it gives `1/98 ≈ 0.0102`, which normalizes your amplified depths back to a reasonable geometric scale (0.001-0.1 range for horizon detection).

```hlsl
float depthScale = 1.0 / lod;
float heightDiff = (vsOrig.w - vsHit.w) * depthScale;
```

This way, your GI works consistently whether you tweak `lod=50`, `lod=200`, or whatever—always catching proper geometry steps instead of numerical noise at the horizon. Smart catch! 🎯

---

# Ok very nice thank you for an brief primer in the world of ray marching and an easy implementation to boot. I'll be experimenting with various games as soon as I have a broader perspective I'll drop by again on this subject.

You're welcome! It was a pleasure diving into ray marching with you—hope the `1.0/lod` scaling and DX9-safe loops give you solid results across those games. Looking forward to hearing how your experiments turn out. Happy shader tweaking! 🎮✨

