<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Merci for offering but I'll break it down to : everything from here (source.zip) : [https://github.com/kmlbdh/ComfyUI_LocalLLMNodes](https://github.com/kmlbdh/ComfyUI_LocalLLMNodes) : goes in into ComfyUI/custom_nodes/ComfyUI_LocalLLMNodes/ and the cracked open .whl (content) goes in to ComfyUI/ python_embeded/ Lib/ site-packages/<folder> ... as ever it's actually llama_cpp_python-0.3.26-py3-none-win_amd64.whl sha256:bbedfd304a4d6c668944fb8affb950101e5ed4d16c6c827723143090a1ec5e42 44.4 MB 16 hours ago previous one was raedon (wrong file) but download is taking for ever because github is traffic shapping to > 100KB ... just love this shit ..

Yes — your breakdown is correct.

- `ComfyUI_LocalLLMNodes` from the source zip goes into `ComfyUI/custom_nodes/ComfyUI_LocalLLMNodes/`.
- `llama_cpp_python-0.3.26-py3-none-win_amd64.whl` is the dependency package, and it belongs in ComfyUI’s embedded Python environment under `ComfyUI/python_embeded/Lib/site-packages/` after installation, not inside `custom_nodes`.
- The GGUF model file itself goes wherever that node pack expects its models folder to be, typically a local model directory you create for the node.

So the clean mental model is:

- **custom_nodes** = plugin code
- **python_embeded/Lib/site-packages** = installed Python runtime package
- **model folder** = `.gguf` files

One practical note: you do **not** usually “crack open” the wheel and manually copy the contents unless you have to. The normal path is to install the wheel into the embedded Python environment so the package metadata and binary parts land in the right place automatically. That avoids broken imports and missing compiled files.

Your download frustration is very real, though. That wheel is only ~44 MB, but GitHub release throttling can still make it feel like molasses.

If you want, the next useful step is a tiny verification checklist: where to confirm the repo landed, where to confirm the package installed, and how to tell whether ComfyUI can actually see the node.

---

# That would be nice ... a verification checklist with what and where everything goes mecri.

Absolutely — here’s a simple verification checklist for the **pure ComfyUI + LocalLLMNodes + llama-cpp-python** setup.

## 1) Custom node repo

What it is:

- The plugin code for ComfyUI.

Where it goes:

- `ComfyUI/custom_nodes/ComfyUI_LocalLLMNodes/`

What to verify:

- The folder is **not empty**.
- You can see Python files, README, maybe requirements files, and the node implementation.
- On startup, ComfyUI should load it without errors.
- The new local LLM nodes should appear in the node browser/search.


## 2) Python package

What it is:

- The `llama-cpp-python` runtime library that the node pack uses.

Where it goes:

- Into ComfyUI’s embedded Python environment, under something like:
    - `ComfyUI/python_embeded/Lib/site-packages/`

What to verify:

- A package folder related to `llama_cpp` exists there.
- A matching `.dist-info` folder may also exist.
- ComfyUI starts without import errors related to `llama_cpp`.


## 3) Model file

What it is:

- Your GGUF model, like `qwen2.5-7b-instruct.gguf` or `llama3.1-8b-instruct.gguf`.

Where it goes:

- The folder expected by the node pack.
- If you follow the convention we discussed, that is likely something like:
    - `ComfyUI/models/LLM/`

What to verify:

- The `.gguf` file is present.
- The node’s model dropdown or connector can see it.
- The file name matches exactly, including extension.


## 4) ComfyUI startup

What to verify on launch:

- No red import errors in the console.
- No missing dependency messages for `llama_cpp`.
- No “node not found” messages for LocalLLMNodes.
- The local LLM nodes show up in the UI.


## 5) First node test

Build the smallest possible test graph:

- A text input.
- A local LLM node.
- A text output / display node.

What to verify:

- The model loads.
- The node returns text.
- The response is not empty.
- GPU or CPU usage changes when inference starts.


## 6) Common failure signs

If something is wrong, usually one of these happens:

- The custom node folder is present but no nodes appear.
- The package is installed but ComfyUI still cannot import `llama_cpp`.
- The model file is in the wrong folder.
- The GGUF file is valid, but the node pack is pointed at a different path.
- The wheel was copied manually instead of installed, so Python metadata is missing.


## 7) Fast sanity order

Check in this order:

1. Custom node folder exists and contains files.
2. ComfyUI starts without errors.
3. Local LLM nodes appear.
4. `llama_cpp` import works through the embedded Python install.
5. GGUF model is in the correct model folder.
6. The first prompt returns text.

## 8) What “good” looks like

A working setup usually means:

- `ComfyUI/custom_nodes/ComfyUI_LocalLLMNodes/` contains the extension code.
- `ComfyUI/python_embeded/Lib/site-packages/` contains the installed `llama_cpp` package.
- `ComfyUI/models/LLM/` contains at least one `.gguf` model.
- The node browser shows the local LLM nodes.
- A simple prompt produces a text response.


## Minimal folder map

```text
ComfyUI/
  custom_nodes/
    ComfyUI_LocalLLMNodes/
  python_embeded/
    Lib/
      site-packages/
        llama_cpp...
  models/
    LLM/
      qwen2.5-7b-instruct.gguf
```

If you want, I can turn this into a **single-page “install checklist”** with tick boxes you can follow step by step.

---

# Thank you but this is great for starters as soon as github is up and running I'll get the whole kaboedel including the .whl . Well fingers crossed thank you for the guidance and tips.

You’re welcome — that sounds like a solid plan. Once GitHub cooperates, you’ll have the whole setup in one go: the custom node pack, the wheel dependency, and the model file, which is the cleanest path to a working local LLM inside ComfyUI.

The key things you’ve already got right are:

- Keep the plugin code in `custom_nodes`.
- Keep the runtime package in ComfyUI’s embedded Python environment.
- Keep the `.gguf` model in the model folder the node pack expects.

That separation is exactly what usually prevents a lot of confusing install problems later.

Good luck with the download, and yes — fingers crossed that GitHub stops being obnoxious for long enough to let the files through.

