<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# After some trial runs with pop os I'm beginning to get some cold feet with regard to the way the os deals with ntfs partitions. So for instance putting the pop os swap file on a ntfs partiton do or don't ?

Do not put a Pop!_OS swap file on an NTFS partition; use a native Linux filesystem (ext4, btrfs, etc.) on a local disk instead.

### Why NTFS is a bad idea for swap

- NTFS support on Linux is provided by a driver layer, not the native kernel swap subsystem, so reliability and performance are worse than with ext4 or other Linux filesystems.
- Swap I/O is extremely frequent and low‑level; any extra translation layer (like NTFS) adds latency and more chances for weird bugs or corruption if something goes wrong.
- If the disk is also used by Windows, hibernation/fast‑startup or an unclean shutdown on either OS can leave NTFS in an inconsistent state, which is exactly what you do *not* want for swap.
- The standard and well‑tested setup on Pop!_OS is either a dedicated swap partition or a swap file on the root ext4 filesystem; that’s what the distro tools and defaults are designed and tuned for.


### Practical recommendation

- Leave your NTFS partitions strictly for shared **data** between Windows and Linux (documents, media, etc.), not for system components like swap or `/home`.
- On the disk where Pop!_OS is installed, create either:
    - a small swap partition (e.g. 4–8 GB for typical desktop use), or
    - a swap file on the Pop!_OS ext4 root (Pop can manage this automatically in many install setups).

If you describe your current partition layout (drives, sizes, which ones are NTFS/ext4, dual‑boot or not), I can suggest an exact scheme for where to put swap without risking your data.
<span style="display:none">[^1_1][^1_10][^1_2][^1_3][^1_4][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://www.reddit.com/r/pop_os/comments/ukdxvf/correct_way_to_mount_an_ntfs_drive_in_pop_os_2110/

[^1_2]: https://www.reddit.com/r/pop_os/comments/1ff3jd4/popos_and_been_a_sod_with_ntfs/

[^1_3]: https://www.reddit.com/r/pop_os/comments/qigyh4/using_pop_os_with_ntfs_partition/

[^1_4]: https://www.youtube.com/watch?v=N_TgL_uRTNU

[^1_5]: https://www.reddit.com/r/pop_os/comments/sl6o11/can_i_open_ntfs_drives_in_pop_os/

[^1_6]: https://www.reddit.com/r/pop_os/comments/bw59zn/ntfs_in_pop_os/

[^1_7]: https://www.reddit.com/r/pop_os/comments/qihq7k/native_ntfs_write_and_read/

[^1_8]: https://www.facebook.com/groups/poposlinux/posts/7890022634443356/

[^1_9]: https://www.reddit.com/r/pop_os/comments/pl8u9s/do_i_need_to_create_a_swap_partition/

[^1_10]: https://tildes.net/~tech/1np1/i_dont_want_windows_11_how_easy_is_it_to_use_linux


---

# My feet are getting colder I was afraid of this ... I already had issues with just one ntfs partition on the same drive as pop os itself (whole thing with the mountpoint and the \) now there is this ...

You’re running into very normal pain points; nothing here is your fault or unusual.

### 1. The core issue with NTFS on the same drive

- NTFS on Linux is “good enough for data,” but it is still a second‑class citizen compared to ext4, especially for anything system‑critical.
- As soon as you put Pop!_OS and an NTFS partition on the same physical drive, you increase the chances of: permission weirdness, mount failures after crashes, and boot‑time delays if that NTFS partition is listed in `/etc/fstab` but can’t be mounted cleanly.
- The backslash `\` and mount‑point confusion you saw is a symptom of “Linux world vs Windows world” colliding: Linux expects paths like `/mnt/data`, Windows expects drive letters and backslashes; NTFS inherits a lot of Windows assumptions.


### 2. What you *should* use NTFS for

Safe use cases for NTFS in your setup:

- A separate **data** partition to share files with Windows (documents, media, maybe game libraries).
- Mounted only *after* the system is up (e.g., via the file manager or a non‑critical entry in `/etc/fstab` with `nofail` so a mount failure doesn’t block boot).

Things you should **not** use NTFS for on Pop!_OS:

- Swap files or swap partitions.
- `/home`, `/var`, or any directory with lots of small, constantly changing files.
- Anything that must always be mounted for Pop!_OS to boot or behave normally.


### 3. How to “un‑spook” your current setup

If you tell me:

- How many drives you have (e.g. “one NVMe, one HDD”),
- Which partitions are Windows, which are Pop!_OS, which are NTFS,
- Whether you actually *need* Windows‑sharing on that NTFS partition,

then I can propose a concrete plan like:

- “Leave partition X as NTFS data, remove it from `/etc/fstab`,”
- “Resize Y, make a small ext4 partition for swap,” or
- “Reformat this problem NTFS partition to ext4 and use it purely for Pop.”

That way you can keep dual‑boot and shared storage, but Pop!_OS itself lives entirely on ext4 and stops tripping over NTFS.
<span style="display:none">[^2_1][^2_2][^2_3][^2_4][^2_5][^2_6][^2_7][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://www.reddit.com/r/pop_os/comments/ukdxvf/correct_way_to_mount_an_ntfs_drive_in_pop_os_2110/

[^2_2]: https://www.reddit.com/r/linuxquestions/comments/1bl09rw/how_can_pop_os_mount_ntfs_drives_but_arch_cant/

[^2_3]: https://github.com/pop-os/pop/issues/623

[^2_4]: https://www.reddit.com/r/pop_os/comments/1dntnj4/urgently_need_help_with_ntfs_drives_no_longer/

[^2_5]: https://www.reddit.com/r/pop_os/comments/17do376/errors_mounting_hdd_ntfs_partition/

[^2_6]: https://www.reddit.com/r/pop_os/comments/1rb568r/ntfs_error_mounting/

[^2_7]: https://bbs.archlinux.org/viewtopic.php?id=271650

[^2_8]: https://www.reddit.com/r/pop_os/comments/y99ynb/cant_readwrite_ntfs_drive/

[^2_9]: https://www.facebook.com/groups/poposlinux/posts/25394041833614832/


---

# The dual boot paradigm ... I already anticipated that by having windows on one drive and pop os on an other what I had not anticipated is that having an ntfs partition (data purposes only) on the same drive as pop os was going to create such issues ... since I want to keep the os partiton small for pop os I thought I'll use the ntfs partition for the pop os swap (AI apps go 16GB easy) and everything would be ticktey boo (using the swap partition is a bad idea from the start by the way ... )

Your instinct is right: using an NTFS partition for swap is where things go from “slightly janky” to “please don’t.”[^3_2][^3_7]

### Why NTFS swap is a hard no

- The Linux swap subsystem expects a block device or a file on a native filesystem (ext4, xfs, btrfs); NTFS adds a translation layer and is not designed for this kind of constant random I/O.[^3_7]
- NTFS on Linux can flip to read‑only or fail to mount if Windows leaves it “dirty” (fast startup, crashes, hibernation), which would suddenly remove your swap and potentially destabilize the system under load.[^3_2]
- Performance will be worse and less predictable than a swap file/partition on ext4, especially when you’re already pushing 16+ GB with AI workloads.[^3_5][^3_7]


### The “small Pop!_OS partition + big data partition” idea

The good part of your plan:

- Keeping Pop!_OS itself on a relatively small ext4 partition is fine.
- Having a separate NTFS *data* partition on the same drive is also fine as long as it’s for documents/media/projects and is not required for the system to boot.[^3_1][^3_5]

The part to change:

- Do **not** put swap on that NTFS data partition.
- Treat NTFS strictly as shared/user data, not as infrastructure for Pop!_OS.


### A workable layout for your case

Given your constraints (Pop!_OS on its own drive, Windows on another, wanting a small OS partition but big RAM‑hungry apps):

1. On the Pop!_OS drive, ensure there is:
    - An ext4 root partition (Pop!_OS).
    - Either:
        - A dedicated **ext4 swap partition**, or
        - Extra free space on root to hold a **large swap file**.
2. Size guidance for your use case:
    - If you routinely see 16 GB used and want headroom, aim for 24–32 GB swap.
    - That can be a swap file on ext4; you don’t *have* to carve another partition if you’d rather keep things flexible.[^3_3][^3_6]
3. Keep the NTFS partition:
    - For shared data (projects, media, maybe model weights if you accept slightly slower I/O).
    - Mounted with options that don’t break boot if it fails (`nofail` in fstab, or just auto‑mount via the GUI).[^3_1][^3_2]

### About “using a swap partition is a bad idea”

- For most desktop users today a swap *file* is more convenient and flexible than a swap partition, but a properly sized swap partition on ext4 is still perfectly valid and often simpler for things like hibernation.[^3_6][^3_3]
- What’s really “bad” is swap on the wrong filesystem (NTFS) or on a flaky/externally‑managed disk.

If you can list your Pop!_OS drive’s partitions (sizes and types), I can suggest a concrete “do this next” plan to convert what you have into: small ext4 root, big ext4‑backed swap, plus your NTFS data partition left for pure storage.
<span style="display:none">[^3_4][^3_8]</span>

<div align="center">⁂</div>

[^3_1]: https://www.reddit.com/r/pop_os/comments/qigyh4/using_pop_os_with_ntfs_partition/

[^3_2]: https://www.reddit.com/r/pop_os/comments/x0z30w/nfts_disk_wont_write_on_pop_os_2204/

[^3_3]: https://www.reddit.com/r/pop_os/comments/pl8u9s/do_i_need_to_create_a_swap_partition/

[^3_4]: https://www.reddit.com/r/pop_os/comments/ukdxvf/correct_way_to_mount_an_ntfs_drive_in_pop_os_2110/

[^3_5]: https://www.reddit.com/r/pop_os/comments/sl6o11/can_i_open_ntfs_drives_in_pop_os/

[^3_6]: https://github.com/pop-os/distinst/issues/171

[^3_7]: https://www.facebook.com/groups/poposlinux/posts/5666677466777895/

[^3_8]: https://www.reddit.com/r/pop_os/comments/bw59zn/ntfs_in_pop_os/


---

# Well what I am doing now is taking an other run on getting pop os to boot from usb where it will have it's own little drive with no ntfs to worry about I've trimmed the partitioning to a minimal 1GB efi and the remaining 63GB or so for the root aka the os itself will the create swap files on the go with script (mkswap, swapon, etc) not to happy that I have to swap on the usb but the other drives are ntfs so ....

That setup will work, and given your constraints it’s a reasonable plan, but there are a few things to be aware of.

### 1. Your partition idea (EFI + root)

- A 1 GB EFI and ~63 GB ext4 root on the USB is perfectly fine for Pop!_OS plus apps.
- Let Pop!_OS live entirely on that ext4 root; don’t touch the internal NTFS partitions except as optional data mounts.


### 2. Swap on the USB: pros and cons

**Pros**

- Keeps Pop!_OS completely independent from the NTFS drives.
- You avoid all the NTFS swap problems we discussed (instability, dirty‑bit issues, permissions).

**Cons**

- USB sticks are much slower than internal SSDs; heavy swap (AI workloads) will feel *very* laggy.
- USB flash has limited write endurance, and swap hammers the drive; a lot of swapping can wear it out relatively quickly.

If you must run RAM‑hungry stuff, try to minimize swap usage (close other apps, run smaller models, use batch sizes that fit in RAM) so the USB isn’t thrashed constantly.

### 3. Making swap “on the go”

What you’re planning (scripts with `fallocate`/`dd` + `mkswap` + `swapon`) is fine:

1. Create a swapfile on the USB’s ext4 root, e.g. `/swapfile-32G`.
2. `chmod 600 /swapfile-32G`
3. `mkswap /swapfile-32G`
4. `swapon /swapfile-32G`

If it turns out you always need that swap, you can add it to `/etc/fstab` later so it activates automatically; if it’s only occasional, keep it as a manual script.

### 4. A slightly nicer variant (if possible)

If your machine has *any* internal space you can reformat to ext4 (even 32–64 GB), a better hierarchy would be:

- Internal SSD/HDD: small ext4 partition just for swap (and maybe a bit of cache).
- USB: Pop!_OS root + EFI as you designed.

That keeps the OS separate from NTFS *and* puts swap on a faster, more durable device than a USB stick.

If you tell me the exact USB size/type and what internal disks/partitions you have (rough sizes and which ones must stay NTFS), I can suggest concrete swap size(s) and a simple script layout.
<span style="display:none">[^4_1][^4_10][^4_2][^4_3][^4_4][^4_5][^4_6][^4_7][^4_8][^4_9]</span>

<div align="center">⁂</div>

[^4_1]: https://www.youtube.com/watch?v=oz6TjmCEAik

[^4_2]: https://www.youtube.com/watch?v=10VDptdVLf0

[^4_3]: https://pop-os.github.io/docs/getting-started/create-bootable-media/bootable-usb-using-linux.html

[^4_4]: https://www.fosslinux.com/112708/the-ultimate-guide-to-creating-a-pop_os-bootable-usb-drive.htm

[^4_5]: https://www.youtube.com/watch?v=42zUASJ7tR8

[^4_6]: https://support.system76.com/articles/install-pop/

[^4_7]: https://support.system76.com/articles/live-disk/

[^4_8]: https://www.reddit.com/r/pop_os/comments/1kuyo52/new_to_linux_how_do_i_install_pop_os_for/

[^4_9]: https://www.youtube.com/watch?v=mnNNo74dSdk

[^4_10]: https://www.youtube.com/watch?v=zJk2OH3gi5M


---

# Well while I was typing my previous remark it did occur to me that I could 'sacrifice' some space on the ssd's (I have two) for a dedicated swap space for pop os so option 4 is well an option ... it's still pending *if* I get pop os running on the usb previous attempts went bad so I ended up putting pop os on one of the ssd's and then started becoming aware of all the issues with mixed partition formats ...

You’re on the right track: isolating Pop!_OS from NTFS and using a dedicated swap area on an SSD is exactly what you want.

### 1. Strategy sanity‑check

- Pop!_OS on its **own ext4 root** (whether on USB or SSD) with no NTFS on that same OS disk is the cleanest way to avoid the “mixed filesystems” headaches you’ve just seen.
- Sacrificing some space on one of the SSDs for a native Linux swap partition or ext4 swapfile is **much** better than swapping on USB, both for speed and drive longevity.


### 2. About the USB install problems

Since previous attempts to run Pop!_OS from USB failed, I’d treat the USB step as:

- A convenience / testing step: if you get it working, great, you can experiment safely.
- Not a hard requirement: if it keeps being flaky, it’s perfectly fine to install Pop!_OS directly to one SSD, as long as that SSD is fully Linux‑native (EFI + ext4, no NTFS on that drive).

If you do go USB‑only for a while, keep swap on an SSD, not the stick:

- Create a small Linux partition on one SSD (e.g. 32–64 GB, type “Linux swap” or ext4).
- Use it purely for swap for the USB‑booted Pop!_OS.


### 3. A concrete layout that avoids the mess

Given your goals, here’s a robust layout that will keep things sane:

- SSD 1: Windows + NTFS data (no Pop!_OS here).
- SSD 2:
    - 1–2 GB EFI (FAT32) for Pop!_OS (and optionally shared with other Linux installs).
    - X GB ext4 root for Pop!_OS (no NTFS partitions on *this* drive).
    - Optional: separate ext4 `/home` if you ever want that.
    - Y GB swap (either as its own partition or as a swapfile on the ext4 root).

Or, if you *really* want Pop!_OS on USB:

- USB: EFI + ext4 root for Pop!_OS.
- SSD 2: a single Linux swap partition (or small ext4 just to host a swapfile).
- All other partitions on both SSDs remain NTFS data/Windows and are mounted only as needed inside Pop!_OS.


### 4. Minimizing future friction with NTFS

Once Pop!_OS is installed cleanly:

- Do not put any NTFS partitions in `/etc/fstab` as “required” mounts; if you add them, use options like `nofail` so a dirty NTFS volume doesn’t block boot.
- Treat NTFS as “nice‑to‑have external storage,” not part of the OS’s bones.

If you want, you can list your two SSDs and how they’re currently partitioned (rough sizes and what’s on them), and I can sketch an exact “delete/resize/create these partitions” plan so you don’t have to guess anymore.
<span style="display:none">[^5_1][^5_10][^5_2][^5_3][^5_4][^5_5][^5_6][^5_7][^5_8][^5_9]</span>

<div align="center">⁂</div>

[^5_1]: https://github.com/pop-os/pop/issues/730

[^5_2]: https://www.reddit.com/r/pop_os/comments/15if4e2/cannot_boot_into_live_usb_error_you_need_to_load/

[^5_3]: https://www.reddit.com/r/pop_os/comments/or9x5d/pop_os_doesnt_boot_from_usb/

[^5_4]: https://support.system76.com/articles/bootloader/

[^5_5]: https://www.reddit.com/r/pop_os/comments/bde92n/cant_boot_from_live_usb/

[^5_6]: https://support.system76.com/articles/install-pop/

[^5_7]: https://forum.level1techs.com/t/pop-os-installation-black-screen/189011

[^5_8]: https://www.facebook.com/groups/poposlinux/posts/23953438044341892/

[^5_9]: https://support.system76.com/articles/live-disk/

[^5_10]: https://forum.level1techs.com/t/pop-os-boot-up-problems/145040


---

# Thank you for offering assistance. I'm in the fortunate position that both ssd's only have the os's on them (no data yet) so the data partition's can be shifted around rather easy os on drive a can have a swap on drive b and visa versa still... why does pop os do stuff like 2MB unallocated at the begin and end of it's drive and the recovery thing seemingly in the end is not necessary ...

Pop!_OS's default partitioning leaves small unallocated gaps and includes a recovery partition to optimize for SSD alignment, recovery tools, and future flexibility.

### Why the 2MB unallocated spaces

These gaps at the drive's beginning and end ensure proper **4K sector alignment** on modern SSDs/HDDs.[^6_1][^6_2]

- SSDs perform best when partitions start at multiples of 4KB or 1MiB boundaries; misalignment causes extra internal "padding writes" that wear out the drive faster.
- The installer automatically adds these gaps (typically 1-2MB) to hit those boundaries without forcing you to manually calculate offsets in tools like GParted.
- They're harmless and can't be used anyway; you can safely ignore or delete them later if you resize partitions.


### The recovery partition (usually ~4GB at the end)

This is **optional but recommended** for Pop!_OS-specific recovery tools.[^6_3][^6_6][^6_1]

- It contains a minimal bootable environment with the Pop!_OS installer, recovery utilities, and System76 firmware tools—think "one-click repair" for bootloaders, drivers, or encryption issues.
- Placed at the end for easy access during boot (GRUB can chainload it) and because recovery rarely needs to resize.
- You *can* skip it if you're comfortable with a standard live USB for repairs, but it's handy for non-experts or when your USB is misplaced.


### Your clean-slate SSD opportunity

Since both SSDs are OS-only right now:

- **SSD A (Windows)**: Leave as-is; optionally shrink it later for NTFS data.
- **SSD B (Pop!_OS)**: During install, use **Custom partitioning** in the Pop!_OS installer:


| Partition | Size | Type | Mountpoint | Purpose |
| :-- | :-- | :-- | :-- | :-- |
| EFI | 1GB | FAT32 | /boot/efi | UEFI boot |
| Root | 60-100GB | ext4 | / | OS + apps |
| Swap | 16-32GB | linux-swap | (none) | AI workloads |
| (Optional) Data | Rest | NTFS or ext4 | /mnt/data | Shared storage |

- Skip the recovery partition if you want to maximize space (the installer allows this).
- Cross-swap idea: Put Pop!_OS swap on SSD A (shrink Windows slightly, add a linux-swap partition). Pop!_OS will detect and use it automatically via `swapon --show`.

This keeps everything aligned, avoids NTFS drama on the Pop!_OS drive, and gives you swap where it's fast and durable. If the USB boot still flakes out, just install directly to SSD B with this scheme—the installer's partition editor makes it straightforward.
<span style="display:none">[^6_10][^6_4][^6_5][^6_7][^6_8][^6_9]</span>

<div align="center">⁂</div>

[^6_1]: https://www.reddit.com/r/pop_os/comments/bqq2en/what_is_the_default_partitioning_for_pop_os_1804/

[^6_2]: https://dev.to/fabiosleal/how-to-create-separate-partitions-for-boot-home-and-swap-on-popos-10lg

[^6_3]: https://www.reddit.com/r/pop_os/comments/uqsppq/what_is_your_pop_os_2204_lts_partitioning_scheme/

[^6_4]: https://www.youtube.com/watch?v=7xeIkAGEvG0

[^6_5]: https://samarthrawat1.hashnode.dev/dual-boot-pop-os-the-right-way

[^6_6]: https://www.reddit.com/r/pop_os/comments/smlxth/pop_os_partitions_what_are_the_things_to_keep_in/

[^6_7]: https://mutschler.dev/linux/pop-os-btrfs-24-04/

[^6_8]: https://support.system76.com/articles/install-pop/

[^6_9]: https://forum.level1techs.com/t/ssd-partition-on-popos/195636

[^6_10]: https://www.reddit.com/r/pop_os/comments/1nthnp3/fresh_pop_os_2404_install_partitioning_advice/


---

# A ext4 swap on the same drive as the os ... I thought having swaps on the same drive is not such an hot idea ...

Swap on the same drive as your OS is perfectly fine and standard for most Linux setups, including Pop!_OS.

### Why same-drive swap works well

Modern SSDs handle simultaneous reads/writes to root and swap efficiently thanks to parallel NAND channels and caching—there's no significant contention like on old mechanical HDDs.[^7_4]

- Pop!_OS (and Ubuntu derivatives) default to this layout: ext4 root + swapfile/partition on the same SSD.
- The only time "separate drive swap" matters is for servers with heavy I/O or multi-user workloads, not desktops/AI apps.


### When separate drives *do* help (your case)

Your cross-SSD swap idea (Pop!_OS root on SSD B, swap on SSD A) adds minor redundancy:

- If SSD B fails, swap on SSD A might still let you recover data.
- Slightly better parallelism under extreme load (AI thrashing both root and swap).

But it's optional—same-drive is simpler and performs identically for your needs.

### Recommended layout (pick one)

| Option | SSD A (Windows) | SSD B (Pop!_OS) | Pros |
| :-- | :-- | :-- | :-- |
| **Simple** | Windows + NTFS | 1GB EFI + 60GB ext4 root + 32GB swap | Standard, no cross-drive hassle [^7_2] |
| **Your cross idea** | Windows + NTFS + 32GB linux-swap | 1GB EFI + 60GB ext4 root | Extra resilience |

Both avoid NTFS issues entirely. Use the Pop!_OS installer's custom partitioning to set this up—select "Something else," create partitions aligned (it handles the 2MB gaps), skip recovery if you want. Once installed, swap activates automatically if on the same drive or via `swapon /dev/sdX` for the cross-drive one.[^7_4]
<span style="display:none">[^7_1][^7_3][^7_5][^7_6]</span>

<div align="center">⁂</div>

[^7_1]: https://stackoverflow.com/questions/34101993/increase-ext4-partition-size-by-decreasing-swap-memory-size-in-linux

[^7_2]: https://docs.redhat.com/en/documentation/red_hat_enterprise_linux/6/html/installation_guide/s2-diskpartrecommend-x86

[^7_3]: https://docs.redhat.com/en/documentation/red_hat_enterprise_linux/6/html/installation_guide/s2-diskpartrecommend-ppc

[^7_4]: https://docs.redhat.com/en/documentation/red_hat_enterprise_linux/8/html/managing_storage_devices/getting-started-with-swap_managing-storage-devices

[^7_5]: https://www.reddit.com/r/linuxquestions/comments/zqwyeu/what_should_my_swap_partition_size_be/

[^7_6]: https://bbs.archlinux.org/viewtopic.php?id=305323


---

# More or less the plan now with the benefit of hindsight or if the usb pop os actually installs and runs SSD A will get a dedicated ext4 partition of 64GB for pop os and well SSB will be wiped might put windows on it and put windows swap on the ntfs remainder of SSD A ... Windows by the way does not do this : 'Why the 2MB unallocated spaces

These gaps at the drive's beginning and end ensure proper 4K sector alignment on modern SSDs/HDDs.' ...

Your plan to dedicate a clean 64GB ext4 partition on SSD A for Pop!_OS (with SSD B potentially for a fresh Windows) is solid and sidesteps all the NTFS headaches cleanly.

### Why this works perfectly

- Pop!_OS lives entirely on its own ext4 partition—no shared drive, no mount drama, no swap compatibility issues.
- You can add swap either as part of that 64GB (e.g., 50GB root + 14GB swap partition) or as a swapfile on the ext4 root.
- Windows on SSD B stays isolated on NTFS, with its own pagefile handling.


### Windows and the 2MB gaps (you're right)

Windows installers **don't** add those alignment gaps by default:

- Windows typically starts its first partition right at sector 63 (old MBR standard) or LBA 34 (UEFI), which can be misaligned on modern 4K-native SSDs.
- This causes write amplification (extra internal SSD overhead), but Microsoft deemed it "acceptable" since SSD wear-leveling hides most of the penalty from casual users.
- Linux distros like Pop!_OS are more SSD-obsessed and explicitly align to 1MiB/2048 sectors for optimal performance. Windows users rarely notice or care.


### Executing your layout cleanly

**SSD A:**


| Partition | Size | Type | Purpose |
| :-- | :-- | :-- | :-- |
| Windows EFI | ~500MB | FAT32 | Windows boot |
| Windows NTFS | Remainder minus 64GB | NTFS | Windows OS + pagefile |
| Pop!_OS ext4 | 64GB | ext4 | Pop!_OS root (+ optional swap) |

**SSD B:** Fresh Windows install (EFI + NTFS), or whatever.

During Pop!_OS USB install:

1. Choose "Something else" → select your 64GB space on SSD A.
2. Create: 1GB FAT32 EFI (if needed, reuse Windows EFI), rest ext4 mounted at `/`.
3. Install bootloader to SSD A EFI partition.

This gives you dual-boot isolation with maximum SSD health across both OSes. Once Pop!_OS is running stably from USB, you'll know the hardware compatibility is good before committing the SSD partition.

---

# Yeah or in the worst case scenario pop os refuses to install or run well from usb I'll chip of 64GB from the SSD A (windows)  data partition and ext4 it for pop os in that case still on SSD B ... good options merci. Let's talk trim how is this going to pan out for the ssd's ...

TRIM works great on your SSDs with Pop!_OS, but needs minor tweaks depending on encryption and periodic vs continuous modes.

### Pop!_OS TRIM defaults

Pop!_OS enables **periodic TRIM** out of the box via `fstrim.timer` (runs weekly), which is the recommended, low-impact approach for SSD health.[^9_1][^9_2]

- No defragmentation ever happens on ext4 (Linux filesystems self-optimize; defrag is a Windows thing).
- Continuous TRIM (`discard` mount option) is **not** enabled by default to avoid performance hiccups on some SSDs.


### For your layout (ext4 Pop!_OS partition)

**Unencrypted (your likely case):**

- Already works automatically: `sudo systemctl status fstrim.timer` shows it's active.
- Verify with `sudo fstrim -av` (trims all mounted filesystems).

**If you later enable full-disk encryption:**

- Add `discard` (unencrypted) or `allow-discards` (LUKS in `/etc/crypttab`) for TRIM to pass through.[^9_3][^9_4]
- Avoid `discard` in `/etc/fstab`—it can cause lag or rare corruption; stick to weekly `fstrim`.


### Windows side (NTFS)

- Windows handles TRIM automatically on NTFS; no config needed.
- Just ensure "Fast Startup" is off (it can leave NTFS "dirty" and block Linux mounts anyway).


### SSD health monitoring

Install `smartmontools`: `sudo apt install smartmontools`, then `sudo smartctl -a /dev/nvme0` (adjust device).

- Look for "Percentage Used" or "Wear_Leveling_Count"—your SSDs will last 5-10+ years even with heavy AI swapping.

Your 64GB ext4 plan + weekly TRIM keeps both SSDs happy long-term. Run `sudo fstrim -av` manually post-install to kick it off.
<span style="display:none">[^9_5][^9_6][^9_7][^9_8][^9_9]</span>

<div align="center">⁂</div>

[^9_1]: https://www.reddit.com/r/pop_os/comments/m25ram/pop_os_and_storage_drives/

[^9_2]: https://www.reddit.com/r/pop_os/comments/10a17fo/ssd_is_fstrim_running_popos_2204/

[^9_3]: https://www.reddit.com/r/pop_os/comments/1igzzmn/is_this_the_correct_way_to_enable_trim_on/

[^9_4]: https://www.reddit.com/r/linux4noobs/comments/j4jdjv/trim_on_encrypted_nvme_pop_os_2004/

[^9_5]: https://forum.manjaro.org/t/solved-support-of-trim-on-my-ssd-hardware/38699

[^9_6]: https://www.reddit.com/r/pop_os/comments/ckz1ec/does_pop_os_have_ssd_periodic_trimming_enabled_by/

[^9_7]: https://www.reddit.com/r/pop_os/comments/yrtbxy/psa_with_full_disk_encryption_trim_is_disabled_by/

[^9_8]: https://www.facebook.com/groups/GNUAndLinux/posts/10164983418295019/

[^9_9]: https://www.linux.org/threads/can-you-trim-a-portable-ssd.49471/


---

# Just to be clear both os's trim the whole drive regardless of the partitioning or formats present right ?

No, neither OS trims the *whole* drive automatically—TRIM only targets **mounted filesystems** of supported types on that OS, ignoring unmounted partitions and foreign formats.[^10_1][^10_7]

### Pop!_OS (ext4 partitions)

- `fstrim` (weekly via timer) scans **only** actively mounted ext4 filesystems (your Pop!_OS root, any data ext4).
- NTFS partitions on the same SSD are untouched by Pop!_OS TRIM—they need Windows to mount and trim them.
- Unallocated space or unmounted partitions? No TRIM reaches them.


### Windows (NTFS partitions)

- Windows TRIM runs on **mounted NTFS** volumes only (your Windows OS partition).
- It ignores ext4 partitions entirely, even if on the same physical SSD.
- Windows doesn't "see" ext4, so no accidental trimming there.


### What this means for your SSDs

TRIM coverage is **per-OS, per-filesystem**—your SSDs stay healthy as long as:

- Pop!_OS boots → trims its ext4 partitions weekly.
- Windows boots → trims its NTFS automatically.

**No gaps:** Every partition gets trimmed when its OS is running. The SSD firmware handles the low-level cleanup across all areas over time.

### Verify it yourself (once Pop!_OS is installed)

```
sudo fstrim -av
```

Shows only trimmed ext4 mounts. Boot Windows, check Disk Management → Properties → Tools → Optimize (shows NTFS TRIM status).

Your mixed layout works fine—each OS maintains its own partitions independently.
<span style="display:none">[^10_2][^10_3][^10_4][^10_5][^10_6][^10_8]</span>

<div align="center">⁂</div>

[^10_1]: https://www.reddit.com/r/pop_os/comments/m25ram/pop_os_and_storage_drives/

[^10_2]: https://www.reddit.com/r/pop_os/comments/smlxth/pop_os_partitions_what_are_the_things_to_keep_in/

[^10_3]: https://www.reddit.com/r/pop_os/comments/1lldsg8/setting_up_multiple_ssd_partitions/

[^10_4]: https://mutschler.dev/linux/pop-os-btrfs-24-04/

[^10_5]: https://www.reddit.com/r/pop_os/comments/ckz1ec/does_pop_os_have_ssd_periodic_trimming_enabled_by/

[^10_6]: https://www.reddit.com/r/System76/comments/x2i4pj/does_trim_work_properly_on_a_fully_encrypted/

[^10_7]: https://www.reddit.com/r/pop_os/comments/10a17fo/ssd_is_fstrim_running_popos_2204/

[^10_8]: https://www.facebook.com/groups/GNUAndLinux/posts/10164983418295019/


---

# That's an eye opener I thought trim was very low level complete drive indeed seems to be format type bound : https://en.wikipedia.org/wiki/Trim_(computing) : wow 'Windows does not support TRIM on [exFAT](https://en.wikipedia.org/wiki/ExFAT) or the older FAT/FAT32 filesystems.' ..

Yes, TRIM is filesystem-specific and works at the block device level through the filesystem driver—it's not a whole-drive operation like a full garbage collection.

### TRIM scope clarified

Each OS's TRIM command (Linux `fstrim`, Windows Optimize) only notifies the SSD controller about **free blocks within mounted, supported filesystems** on that OS. Unmounted partitions, foreign formats, or unsupported filesystems get skipped entirely.[^11_1]

- Your ext4 Pop!_OS partition: Trimmed weekly by Pop!_OS `fstrim`.
- NTFS Windows partitions: Trimmed automatically when Windows runs.
- No overlap or conflict—each OS handles its own turf independently.


### The exFAT/FAT revelation

You're spot on with the Wikipedia note: Windows skips TRIM on exFAT and FAT32 entirely, even when mounted. Those ancient filesystems lack the infrastructure to issue proper TRIM commands.

- Modern Linux (Pop!_OS included) **does** TRIM exFAT/FAT32 via `fstrim`, but you'd rarely use them anyway.
- Moral: Stick to ext4 (Linux) and NTFS (Windows) for your partitions—both get full TRIM love from their native OSes.


### Your SSDs are covered

With your planned layout (ext4 Pop!_OS + NTFS Windows on mixed SSDs), every active partition gets trimmed regularly when its OS boots. The SSD firmware handles any low-level housekeeping across the physical drive. No manual intervention needed beyond the default timers.

<div align="center">⁂</div>

[^11_1]: https://www.reddit.com/r/pop_os/comments/m25ram/pop_os_and_storage_drives/

