<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Would it be possible to run this with comfyui on windows / 5060 rtx 8GB : [https://huggingface.co/Lightricks/LTX-2.3/blob/main/ltx-2.3-22b-dev.safetensors](https://huggingface.co/Lightricks/LTX-2.3/blob/main/ltx-2.3-22b-dev.safetensors) : ?

No, running the full LTX-2.3-22b-dev.safetensors model (42GB) directly in ComfyUI on a Windows system with an RTX 5060 8GB GPU is not feasible due to severe VRAM limitations.[^1_2][^1_6]

## Hardware Constraints

The RTX 5060's 8GB VRAM falls far short of the 32GB+ required for the unoptimized 22B dev model, causing out-of-memory (OOM) errors during loading or inference. ComfyUI on Windows offers some RAM offloading, but it's insufficient for this checkpoint size.[^1_1][^1_3][^1_9][^1_2]

## Viable Alternatives

Use quantized or distilled variants instead:

- **FP8 versions** (e.g., ltx-2.3-22b-dev-fp8.safetensors, ~23-29GB): Still too large for 8GB without heavy offloading, but possible at low resolutions (≤1024x1024) with tiled VAE.[^1_6][^1_8]
- **GGUF Q4 models** (from Kijai on Hugging Face): Optimized for 8GB VRAM, enabling short video generation (e.g., 2-5s clips) via ComfyUI-GGUF nodes.[^1_4][^1_7][^1_8]
- Install ComfyUI-LTXVideo custom nodes and example workflows for low-VRAM setups.[^1_10]


## Setup Tips for Success

- Update ComfyUI, PyTorch (CUDA 12.8+ for RTX 50-series), and GGUF nodes.[^1_3][^1_8]
- Enable `--lowvram` flag and use short sequences with upscaling.[^1_1]
- Expect slower renders (minutes per short clip) compared to high-end GPUs.[^1_5][^1_9]

<div align="center">⁂</div>

[^1_1]: https://www.reddit.com/r/comfyui/comments/1m07yq7/rtx_5060_8gb/

[^1_2]: https://docs.ltx.video/open-source-model/integration-tools/comfy-ui

[^1_3]: https://github.com/comfyanonymous/ComfyUI/discussions/6643

[^1_4]: https://zimage.run/zh/blog/how-to-install-ltx-2-gguf-models-comfyui

[^1_5]: https://discuss.huggingface.co/t/nvidia-geforce-rtx-5060-ti-and-wan2-2-model/170645

[^1_6]: https://aistudynow.com/ltx-2-3-in-comfyui-workflow/

[^1_7]: https://discuss.huggingface.co/t/a-model-for-converting-photos-to-videos-with-8gb-of-vram/170034

[^1_8]: https://www.youtube.com/watch?v=_6ff9yhhqFA

[^1_9]: https://www.youtube.com/watch?v=n4vEshC9EO4

[^1_10]: https://www.youtube.com/watch?v=G2JBqUHUbfQ


---

# 'tiled VAE' ?

Tiled VAE is a technique that processes large images in smaller overlapping tiles during encoding (image to latent) and decoding (latent to image) steps in diffusion models like those in ComfyUI.[^2_1][^2_3]

## Key Benefits

It drastically reduces VRAM usage, enabling high-resolution outputs (e.g., 4K+) on GPUs with limited memory like your RTX 5060 8GB. Tiles overlap slightly to blend seams seamlessly, avoiding visible artifacts.[^2_2][^2_4][^2_6][^2_9]

## ComfyUI Usage

Nodes like **VAEEncodeTiled** and **VAEDecodeTiled** handle this—set `tile_size` to 512 and `overlap` to 64 for optimal results on low VRAM. Pair with tiled diffusion for full low-memory workflows, as in LTX-2.3 setups.[^2_3][^2_5][^2_7][^2_10]
<span style="display:none">[^2_8]</span>

<div align="center">⁂</div>

[^2_1]: https://wiki.shakker.ai/en/tiled-diffusion-tiled-vae-plugins

[^2_2]: https://www.reddit.com/r/StableDiffusion/comments/11tuzov/for_anyone_who_isnt_already_aware_of_it_tiled_vae/

[^2_3]: https://docs.getsalt.ai/md/Comfy/Nodes/VAEDecodeTiled/

[^2_4]: https://github.com/KawakamiReiAI/TiledVAE

[^2_5]: https://comfyai.run/documentation/VAEEncodeTiled

[^2_6]: https://comfyai.run/documentation/VAEDecodeTiled

[^2_7]: https://www.reddit.com/r/StableDiffusion/comments/15urdmq/tiled_vae_vs_tiled_diffusion/

[^2_8]: https://www.youtube.com/watch?v=44waH3sDYOM

[^2_9]: https://www.runcomfy.com/comfyui-nodes/ComfyUI/VAEDecodeTiled

[^2_10]: https://github.com/shiimizu/ComfyUI-TiledDiffusion


---

# Well still heavy but then 2.3 is pretty new ... is it lighter in it's 'full' mode then kling or wan wamu?

Yes, LTX-2.3 in its full mode is generally lighter on VRAM and faster than Kling or Wan/WAMU equivalents, though it's still demanding for 8GB GPUs without quantization.[^3_1][^3_2]

## VRAM Comparison

Full LTX-2.3 (unquantized dev) uses 18-22GB on RTX 4090 for 720p, versus Wan 2.2's 22-24GB and Kling's cloud-optimized but heavier inference (often 24GB+ equivalent). Benchmarks show LTX-2 generating 768x512 clips in ~47s on 4090 (18GB peak), while Wan 2.2 takes 3m+ at 22GB.[^3_2][^3_1]

## Performance Edge

LTX-2.3 prioritizes efficiency with DiT architecture and NVFP8 quantization (~30% size reduction), enabling viable runs on 16GB+ GPUs where Wan often hits OOM. Kling lags in local setups due to proprietary scaling; Wan/WAMU excels in quality but at 2-5x longer renders and higher memory.[^3_3][^3_5][^3_1][^3_2]

## Practical Takeaway

On your RTX 5060 8GB, stick to LTX-2.3 GGUF-Q4 (~8-12GB effective) over Wan—it's newer, lighter, and better suited for ComfyUI low-VRAM workflows like tiled VAE.[^3_1][^3_3]
<span style="display:none">[^3_10][^3_4][^3_6][^3_7][^3_8][^3_9]</span>

<div align="center">⁂</div>

[^3_1]: https://apatero.com/blog/ai-video-generation-speed-benchmarks-2025

[^3_2]: https://slashdot.org/software/comparison/LTX-2.3-vs-Wan2.2/

[^3_3]: https://www.globenewswire.com/news-release/2026/01/06/3213304/0/en/Lightricks-Open-Sources-LTX-2-the-First-Production-Ready-Audio-and-Video-Generation-Model-With-Truly-Open-Weights.html

[^3_4]: https://artificialanalysis.ai/video/models/ltx-2-3-pro

[^3_5]: https://www.reddit.com/r/StableDiffusion/comments/1j5k9k5/ltxv_vs_wan21_vs_hunyuan_insane_speed_differences/

[^3_6]: https://wavespeed.ai/blog/posts/introducing-wavespeed-ai-ltx-2-3-text-to-video-on-wavespeedai/

[^3_7]: https://gigazine.net/gsc_news/en/20260306-ltx-2-3-video-generation-ai

[^3_8]: https://aicreators.tools/creative-ai-suites/ai-suite/freepik

[^3_9]: https://skywork.ai/blog/ai-video/ltx-2-performance-analysis/

[^3_10]: https://artificialanalysis.ai/video/models/ltx-2-3-fast


---

# Ok ltx is becoming more and more promising in comparison to the other two. All right on the menu are : [https://civitai.com/models/2443478/rebels-ltx-23-dev-gguf](https://civitai.com/models/2443478/rebels-ltx-23-dev-gguf) : and : [https://huggingface.co/unsloth/LTX-2.3-GGUF](https://huggingface.co/unsloth/LTX-2.3-GGUF) : (why of why do people do 'Download the mp4 in the repo and open it with ComfyUI. The workflow to reproduce the video is embedded in the file.' it's brutally unpractical) anyway spoilt for choice there (has quite a lot of variants no idea which is best for 8GB...) ....

LTX-2.3 GGUF variants from Rebels (CivitAI) and unsloth (Hugging Face) are both solid for your RTX 5060 8GB setup, with unsloth's being more widely benchmarked for ComfyUI low-VRAM workflows.[^4_5][^4_8]

## Best Pick for 8GB VRAM

Go with **Q2_K** or **Q3_K_S/M** from unsloth/LTX-2.3-GGUF (~8-11GB file size). These fit 8-10GB VRAM budgets, enabling short 720p/1080p clips (2-10s) using tiled VAE, system RAM offloading (needs 32GB+ RAM), and ComfyUI-GGUF nodes. Q2_K prioritizes speed/stability on tight VRAM; Q3_K_M adds slight quality at similar memory.[^4_1][^4_4][^4_5]

## Repo Comparison

| Repo | Key Variants | Strengths | Notes |
| :-- | :-- | :-- | :-- |
| Rebels (CivitAI) [^4_5] | Q3_K_S (~8GB), Q4_0 (~10GB) | Rebel-tuned for ComfyUI, fast inference | Less community validation than unsloth; good for extreme low-VRAM |
| unsloth (HF) [^4_8] | Q2_K (8.3GB), Q3_K_M (10.8GB), up to Q8 | Broad quant levels, official-like quality | Preferred in tutorials; pair with Kijai VAEs/text encoders [^4_4] |

## Workflow Practicality Fix

Embedded MP4 workflows are impractical—drag-and-drop the .json or .png workflow file directly into ComfyUI instead (extract via FFprobe if needed). Start with unsloth Q3_K_M + LTXV2_comfy nodes for plug-and-play success on 8GB.[^4_2][^4_1]
<span style="display:none">[^4_10][^4_3][^4_6][^4_7][^4_9]</span>

<div align="center">⁂</div>

[^4_1]: https://www.youtube.com/watch?v=NKjerydGXYY

[^4_2]: https://www.youtube.com/watch?v=lWwpTXfVsBE

[^4_3]: https://www.stablediffusiontutorials.com/2026/03/ltx-2.3-video-audio-gen.html

[^4_4]: https://www.youtube.com/watch?v=qBtNIWDHCOQ

[^4_5]: https://zimage.run/zh/blog/how-to-install-ltx-2-gguf-models-comfyui

[^4_6]: https://www.youtube.com/watch?v=Kyn-RG3uTYQ

[^4_7]: https://www.reddit.com/r/StableDiffusion/comments/1qwyp6k/comment/o3ssm1x/

[^4_8]: https://huggingface.co/unsloth/LTX-2.3-GGUF/tree/main

[^4_9]: https://huggingface.co/QuantStack/LTX-2.3-GGUF

[^4_10]: https://www.youtube.com/watch?v=_6ff9yhhqFA


---

# Ok merci for the tips and info will give it a go.

You're welcome! Bonne chance with the LTX-2.3 GGUF setup on your RTX 5060—start with unsloth's Q3_K_M for the best balance, and let me know how it goes or if you hit any snags.

