<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# I'm having a bit of an issue with installing pop os. I want to install it to an unused 32GB partition using 'custom install' I can select the partition enable it and use most of the drop down items but the button 'erase and install' does not become electable ...

Pop!_OS won’t let you continue until a few conditions are met on the partition layout, so that’s almost always why “Erase and install” stays greyed out or unclickable.[^1_2][^1_5][^1_7]

### What the installer requires

Make sure **all** of these are true:

- You have a root partition:
    - Filesystem: ext4.
    - Mount point: `/` (root).
    - “Format” enabled for that partition.[^1_5][^1_7]
- You have a boot/EFI partition:
    - If your system boots in UEFI mode (most modern systems):
        - Filesystem: FAT32.
        - Size: at least 512 MB, but Pop!_OS 22.04+ effectively requires about 1 GB for the EFI System Partition (ESP), otherwise the button can stay disabled.[^1_4][^1_9][^1_2]
        - Mount point: `/boot/efi`.
        - “Use” enabled (you usually don’t need to reformat it if Windows is using it already).
    - If you boot the installer in legacy/BIOS mode but the disk is partitioned for UEFI, the installer can also behave oddly; make sure you boot the USB in UEFI mode (the entry often says “UEFI: <USB name>”).[^1_1][^1_4]
- Root size is large enough:
    - A 32 GB root partition is generally acceptable, but some users have reported “Erase and install” not working when root was very small (under 20 GB). Your 32 GB partition should be OK, as long as it is properly set as `/`.[^1_9][^1_4]


### Step‑by‑step checklist for your case (32 GB free partition)

Assuming you already shrank your disk and have ~32 GB unallocated or a dedicated partition:

1. Boot the Pop!_OS USB in **UEFI mode** from your firmware/boot menu.[^1_1][^1_4]
2. In the installer, choose **Custom (Advanced)**.
3. On your existing EFI partition (often 100–500 MB FAT32 at the start of the disk, used by Windows):
    - Select it.
    - Set “Use as” → `/boot/efi`.
    - Do **not** check format (keep Windows boot files).[^1_2][^1_4]
4. On your 32 GB partition:
    - Select it.
    - Set filesystem to `ext4`.
    - Check “Format”.
    - Set mount point to `/`.[^1_7][^1_5]
5. Make sure no required field at the bottom of the installer window is complaining (there’s usually a line of instructions/hints telling you what’s missing).[^1_5][^1_7]

At this point, “Erase and install” should be clickable. If it is still not:

- Check if the EFI partition is smaller than 1 GB; if it is only 100–500 MB, Pop!_OS 22.04+ may refuse and you might need to resize it to at least ~1 GB using a tool like GParted from the live session (this is risky: always back up important data first).[^1_4][^1_9]
- Confirm that you didn’t accidentally set the 32 GB partition as `/home` or some other mount point; the installer requires at least a root and boot/EFI.[^1_2][^1_5]


### If you share more details

If you can, reply with:

- A list of your partitions (sizes, filesystems, and which one has Windows).
- Whether your EFI partition exists and its size.
- A description of what you selected for “Use as” and mount point for each.

With that, I can tell you exactly what to change so the button becomes active.
<span style="display:none">[^1_10][^1_3][^1_6][^1_8]</span>

<div align="center">⁂</div>

[^1_1]: https://www.reddit.com/r/pop_os/comments/mlnzqy/erase_and_install_button_greyed_out/

[^1_2]: https://www.reddit.com/r/pop_os/comments/ptepa2/cant_install_pop_os_on_separate_partition/

[^1_3]: https://www.reddit.com/r/pop_os/comments/s54ok4/stuck_with_the_erase_and_install_button_greyed/

[^1_4]: https://www.reddit.com/r/pop_os/comments/bl6bei/i_cant_move_forward_while_trying_to_install_pop/

[^1_5]: https://www.reddit.com/r/pop_os/comments/kilxsf/cant_seem_to_click_the_erase_and_install_button_i/

[^1_6]: https://www.reddit.com/r/pop_os/comments/e9tzye/cannot_install_with_custom_partitioning_error/

[^1_7]: https://www.reddit.com/r/pop_os/comments/aej4ns/erase_and_install_button_not_working/

[^1_8]: https://github.com/pop-os/pop/issues/205

[^1_9]: https://www.reddit.com/r/pop_os/comments/yjejxy/cannot_install_erase_and_install_button_grayed_out/

[^1_10]: https://www.youtube.com/watch?v=7xeIkAGEvG0


---

# Hmm I'm getting efi partition to small (100MB) ...

Pop!_OS is complaining because its installer now enforces a much larger EFI System Partition (ESP) than the 100 MB that Windows typically creates.

### What Pop!_OS expects

- Older Pop!_OS versions: effectively required an ESP of about 500–512 MB or larger for custom installs.[^2_1][^2_3][^2_5]
- Newer Pop!_OS (22.04+ and especially current ISOs): the underlying installer (distinst / systemd‑boot setup) has moved toward treating ~1 GB as the practical minimum, because Pop!_OS stores:
    - Multiple kernels (current + old),
    - A recovery kernel,
    - Boot manager files, often alongside Windows entries.[^2_2][^2_4][^2_6]

Your 100 MB ESP is therefore rejected, and the “EFI partition too small” error keeps the install button disabled.[^2_1][^2_2]

### Your practical options

All of these involve some risk to existing data, so make backups first.

1. **Resize the existing EFI partition to ≥ 512 MB (preferably 1 GB)**
    - From a live USB (GParted on any Linux live environment), you would:
        - Shrink the partition immediately following the 100 MB ESP to free, say, 900 MB of space.
        - Expand the EFI partition into that free space so it becomes ~1 GB.[^2_9][^2_2][^2_1]
    - This keeps a **single shared ESP** for Windows and Pop!_OS, which is the cleanest design, but resizing system partitions can go wrong if there’s a power loss or disk errors.
2. **Create a second EFI partition just for Pop!_OS (if you have unallocated space before your Linux root)**
    - Technically allowed on GPT: you can have more than one ESP, and Pop!_OS will happily use a dedicated 1 GB FAT32 partition as `/boot/efi`.[^2_4][^2_2]
    - Downsides:
        - It’s non‑standard (multiple ESPs).
        - Some tools expect only one ESP, so troubleshooting later can be confusing.
3. **Install Pop!_OS on another drive with a fresh, larger EFI partition**
    - If you have a second SSD/HDD, you can let Pop!_OS create its own 1 GB ESP on that drive and keep the Windows 100 MB ESP untouched on the first drive.[^2_4][^2_9]
    - This is the safest in terms of not touching the Windows layout at all, but requires extra hardware.

### What I’d recommend step‑by‑step

If you only have one drive and want a clean dual boot:

1. Boot any Linux live USB that includes GParted (Ubuntu, Pop!_OS live, etc.).
2. In GParted, locate the 100 MB FAT32 partition marked “EFI System” or with the `esp` flag.
3. Shrink the next partition on the disk (usually Windows C: or a reserved partition) by about 900 MB.
4. Extend the EFI partition to fill that new space so it’s around 1 GB total.
5. Apply changes, reboot back into Windows twice (let it run disk checks if it wants to).
6. Boot the Pop!_OS installer again, choose Custom Install, select this now‑1 GB EFI partition as `/boot/efi` (do **not** format it), and set your 32 GB partition as `ext4` mounted at `/` with format checked.[^2_6][^2_2][^2_1][^2_4]

After that, the “EFI partition too small” error should disappear, and the install button should become active.

If you’re unsure, tell me:

- Your disk layout (sizes and order of partitions, especially what sits right after the 100 MB EFI),
- Pop!_OS version you’re installing,

and I can suggest an exact “resize this, then that” sequence.
<span style="display:none">[^2_10][^2_7][^2_8]</span>

<div align="center">⁂</div>

[^2_1]: https://www.reddit.com/r/pop_os/comments/l33nur/minimum_efi_system_partition_size_and_dual/

[^2_2]: https://github.com/pop-os/distinst/issues/239

[^2_3]: https://www.reddit.com/r/linux4noobs/comments/jjkrtq/what_sizes_should_the_popos_partitions_be/

[^2_4]: https://www.reddit.com/r/linuxquestions/comments/1818h9x/why_does_popos_need_1gb_of_efi/

[^2_5]: https://github.com/pop-os/iso/issues/236

[^2_6]: https://www.reddit.com/r/linux4noobs/comments/1hxqefb/pop_os_the_system_efi_partition_is_too_small/

[^2_7]: https://www.reddit.com/r/pop_os/comments/yzbv6k/efi_partition_too_small_for_install/

[^2_8]: https://github.com/pop-os/pop/issues/1431

[^2_9]: https://www.youtube.com/watch?v=dA4l8nZ3TJ0

[^2_10]: https://www.reddit.com/r/pop_os/comments/ehmcdw/partitions/


---

# Sigh .... I have a 65Gig partition prepped for pop OS why does it need a boot efi partition of one gig ...

Yeah, it feels excessive, especially when you’ve already carved out a decent‑sized 65 GB partition for Pop!_OS itself.

### Why Pop!_OS wants ~1 GB EFI

Pop!_OS uses **systemd‑boot** and stores much more in the EFI System Partition (ESP) than many other distros:

- It places:
    - The current kernel,
    - At least one old kernel,
    - A recovery kernel,
    - Initrds and bootloader files,
all directly on the ESP instead of under `/boot` on your root partition.[^3_2][^3_4]
- On systems that also have Windows, its boot manager entries live there too, which eats further space.[^3_5][^3_2]

Developers have seen lots of users run out of space on 256–512 MB ESPs during kernel updates, leaving systems unbootable or unable to update kernels safely.[^3_2][^3_5]
Because of that, they deliberately raised the enforced minimum to about 1 GB and marked smaller ESPs as “too small”, even if they *technically* work initially.[^3_6][^3_9][^3_2]

So it’s not that your 65 GB root isn’t enough; it’s that Pop!_OS insists on a “future‑proof” EFI area where it can juggle multiple kernels and a recovery environment without running out of room.[^3_4][^3_2]

### What that means for you

- Your 65 GB partition for `/` is totally reasonable; you don’t need to change that.
- The annoying part is expanding or creating a ~1 GB FAT32 ESP so Pop!_OS will actually proceed with the install.
- Once that’s done, the installer will happily use your 65 GB partition as root and leave the rest of your layout alone.

If you tell me roughly how your disk is laid out (which partitions in order, sizes, which one is Windows, which is the 65 GB Pop!_OS partition), I can suggest the least painful way to grow or add that 1 GB ESP.
<span style="display:none">[^3_1][^3_10][^3_3][^3_7][^3_8]</span>

<div align="center">⁂</div>

[^3_1]: https://www.reddit.com/r/pop_os/comments/l33nur/minimum_efi_system_partition_size_and_dual/

[^3_2]: https://github.com/pop-os/distinst/issues/239

[^3_3]: https://www.reddit.com/r/linux4noobs/comments/jjkrtq/what_sizes_should_the_popos_partitions_be/

[^3_4]: https://www.reddit.com/r/linuxquestions/comments/1818h9x/why_does_popos_need_1gb_of_efi/

[^3_5]: https://github.com/pop-os/iso/issues/236

[^3_6]: https://www.reddit.com/r/linux4noobs/comments/1hxqefb/pop_os_the_system_efi_partition_is_too_small/

[^3_7]: https://www.reddit.com/r/pop_os/comments/yzbv6k/efi_partition_too_small_for_install/

[^3_8]: https://github.com/pop-os/pop/issues/1431

[^3_9]: https://www.youtube.com/watch?v=dA4l8nZ3TJ0

[^3_10]: https://www.reddit.com/r/pop_os/comments/ehmcdw/partitions/


---

# Hmm does cachyOS come with same curve ball ...

CachyOS can have a **similar** (and in some cases even stricter) “curve ball” around EFI size, depending on how you install it.

### What CachyOS tends to expect

- Their recommended / enforced size in some installer modes is around **2 GB** for the EFI/boot partition, especially when:
    - Using systemd‑boot or rEFInd.
    - Storing kernels and initramfs directly in the EFI/boot partition (same idea as Pop!_OS’s “put everything in ESP” approach).
- The idea is the same: multiple kernels, different bootloaders, snapshots, etc., can fill a small ESP and break updates, so they err on the side of “big and safe”.


### But it depends on how you set it up

- If you **manually** partition and use a more traditional setup (GRUB, kernels on `/boot` on your root filesystem), a 512 MB–1 GB EFI partition is usually fine in practice.
- Where people run into a hard requirement (like “must be 2 GB”) is:
    - Using the “replace partition” / automatic options.
    - Using CachyOS’s default scheme where kernels and initramfs live in the EFI/boot partition.


### What this means for you

If your main frustration is “I don’t want to resize my existing tiny 100 MB Windows ESP again”:

- Pop!_OS: strongly pushes you toward a ~1 GB ESP and won’t use the 100 MB one.
- CachyOS:
    - With defaults: may want a large (up to 2 GB) EFI/boot partition.
    - With careful **manual** setup: you *might* be able to keep your small Windows ESP for Windows only and:
        - Create a separate, modest‑sized EFI (e.g. 512 MB–1 GB) for CachyOS, or
        - Use GRUB with a non‑EFI `/boot` partition and only minimal EFI files on the ESP.

If you tell me what you’d prefer (stick to one shared EFI vs. separate ones, and whether you’re okay with manual partitioning), I can outline a concrete layout that avoids surprises for CachyOS while keeping your 65 GB Linux partition plan.
<span style="display:none">[^4_1][^4_10][^4_2][^4_3][^4_4][^4_5][^4_6][^4_7][^4_8][^4_9]</span>

<div align="center">⁂</div>

[^4_1]: https://discuss.cachyos.org/t/cachyos-proper-efi-partition-size-explanation-please/6517

[^4_2]: https://github.com/CachyOS/cachyos-calamares/issues/50

[^4_3]: https://discuss.cachyos.org/t/efi-or-boot-partition-install-requirement/11309

[^4_4]: https://www.reddit.com/r/cachyos/comments/1h9u7ky/suggested_partitioning_size/

[^4_5]: https://www.reddit.com/r/cachyos/comments/1ly1fhl/trying_to_understand_cachy_os_installation/

[^4_6]: https://www.youtube.com/watch?v=q53PHR2JQZE

[^4_7]: https://www.youtube.com/watch?v=lVVDrjgIOpg

[^4_8]: https://www.reddit.com/r/cachyos/comments/1o4cqif/need_help_installing_cachyos_ans_efi_on_separate/

[^4_9]: https://forums.opensuse.org/t/add-cachy-os-to-grub-on-100mb-efi-partition/188433

[^4_10]: https://www.youtube.com/watch?v=mVXONaHZvFU


---

# Sigh ... I thought the order was install windows (10) first prep the partitions and then do one of the nix OS's .... this sucks ... because I have no idea how to install windows 10 first and make sure the the efi partition is at least 1GB ...

You absolutely don’t need to reinstall Windows just to get a bigger EFI partition, and you’re right: the usual advice is “Windows first, then Linux.”[^5_1][^5_7]

### Why Windows gave you 100 MB

- Windows installers typically create a 100 MB EFI System Partition by default, because Microsoft’s *minimum* is small, even though many people now recommend 300–500 MB or more.[^5_2][^5_3][^5_6][^5_7]
- That’s fine for Windows alone, but it’s tight once a Linux distro also wants to put kernels and bootloader files there.[^5_5][^5_8][^5_1]


### You do NOT need to reinstall Windows

To get where you want to be (Windows + “nix” with a ≥1 GB EFI) you have two realistic paths, neither of which requires reinstalling Windows:

1. **Resize the existing 100 MB EFI to ~1 GB**

Conceptually:
    - Shrink the partition that sits immediately after the EFI by ~900 MB.
    - Grow the EFI partition into that freed space so it becomes ~1 GB.
    - Then install Pop!_OS (or another distro), telling it to use that EFI as `/boot/efi` without formatting it.

Tools you can use:
    - From Linux live media: a GUI partitioner like GParted can do “shrink next partition, then grow EFI”.
    - From Windows: it’s *possible* but much more awkward; third‑party tools are usually friendlier than Disk Management for EFI changes.

This is the most common way people fix the “100 MB ESP” issue after the fact, and it preserves your existing Windows install.[^5_7][^5_10][^5_1]
2. **Create a separate EFI partition for Linux**

If there is free space *before* or *near* your 65 GB Linux partition (or you can make some by shrinking a nearby partition), you can:
    - Create a new ~512 MB–1 GB FAT32 partition and mark it as an EFI System Partition.
    - In the Linux installer, set that new partition as `/boot/efi` and keep the Windows 100 MB ESP just for Windows.

Multiple ESPs are technically allowed; it’s just less “standard”. But it avoids touching the Windows ESP at all.[^5_8][^5_5]

### If you *ever* reinstall Windows later

If at some point you do a full reinstall and want to “do it right”:

- During Windows setup, instead of pointing it at unallocated space and letting it auto‑partition:
    - Delete any existing partitions on that drive.
    - Manually create a small placeholder partition layout so Windows is forced to use a larger EFI (for example, some people pre‑create a 500 MB–1 GB FAT32 partition and mark it as EFI using another tool beforehand).
- But that’s only worth thinking about **next time**; it’s overkill for your current situation.

***

If you tell me:

- The order and sizes of your partitions (EFI, MSR, C:, recovery, the 65 GB one, etc.),
I can describe **exactly** which partition to shrink and how much, and where to grow the EFI so you don’t have to guess.
<span style="display:none">[^5_4][^5_9]</span>

<div align="center">⁂</div>

[^5_1]: https://www.reddit.com/r/pop_os/comments/l33nur/minimum_efi_system_partition_size_and_dual/

[^5_2]: https://www.reddit.com/r/sysadmin/comments/13yeh3d/windows_11_new_efi_system_partition_requirement/

[^5_3]: https://www.tenforums.com/installation-upgrade/102777-recommended-size-efi-partition-v1709.html

[^5_4]: https://www.reddit.com/r/Dell/comments/14sangh/what_should_be_the_size_of_the_efi_partition_of/

[^5_5]: https://wiki.archlinux.org/title/EFI_system_partition

[^5_6]: https://garytown.com/low-space-on-efi-system-partition-clean-up

[^5_7]: https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/configure-uefigpt-based-hard-drive-partitions?view=windows-11

[^5_8]: https://www.reddit.com/r/archlinux/comments/1ivyt83/efi_system_partition_size_1gb_or_512mb/

[^5_9]: https://forum.manjaro.org/t/efi-system-partition-esp-size-and-commentary/158684

[^5_10]: https://learn.microsoft.com/en-us/answers/questions/4287192/how-to-increase-efi-and-recovery-partitions-size-u


---

# that partition is windows ... so 'Shrink the partition that sits immediately after the EFI by ~900 MB.

Grow the EFI partition into that freed space so it becomes ~1 GB.' using windows  ?

**No, Windows Disk Management cannot safely resize the EFI partition** when the Windows partition (C:) is right after it, which is the standard layout.

### Why Windows tools won't work here

Windows Disk Management *only* lets you extend a partition if unallocated space is **immediately adjacent** (right next to it). Since your 100 MB EFI partition is followed directly by the Windows C: partition, there's no adjacent free space to grab. Shrinking C: first creates unallocated space *after* C:, not before it where the EFI sits, so you can't extend EFI with native tools.[^6_1][^6_4]

Diskpart has similar limitations—it can't move partitions around or extend non-adjacent ones easily.

### What actually works (from Windows)

**Third-party partition tools** are the standard solution for this exact scenario:

**Recommended free option: MiniTool Partition Wizard Free**

1. Download/install **MiniTool Partition Wizard Free** (widely used for EFI resizing, safe for GPT/UEFI).
2. Launch it → Right-click your **Windows C: partition** → **Resize/Move**.
3. Shrink C: by ~900 MB (drag the left edge of C: rightward to create space *before* it, between EFI and C:).
4. Click **Apply** (this moves data safely).
5. Now right-click the **EFI partition** → **Extend** → Take all the new unallocated space next to it (to make EFI ~1 GB total).
6. **Apply** again.

This works because MiniTool can "borrow" space from non-adjacent partitions by moving boundaries.[^6_3][^6_5]

**Paid alternatives** like EaseUS Partition Master or AOMEI Partition Assistant do the same with nicer GUIs and video tutorials.[^6_7][^6_3]

### ⚠️ Critical precautions

- **Backup everything important** first (full disk image ideal, but at least your files).
- Run as Administrator.
- Don't interrupt the process (needs ~30-60 min; keep power stable).
- After resizing, reboot into Windows 2-3 times (it may run startup repair/checks).
- Verify Windows boots fine before touching Pop!_OS installer.


### Once EFI is ~1 GB

Boot Pop!_OS live USB → Custom install → Select the now-larger EFI as `/boot/efi` (**don't format**) + your 65 GB partition as `ext4` `/` (format it). Button should light up.

If you're nervous about third-party tools, boot any Linux live USB (Ubuntu/Pop!_OS) and use **GParted**—it does the exact same resize/move/extend sequence with a familiar GUI, zero cost, zero install needed.[^6_2][^6_11]

Your partition layout sounds standard (EFI → C: → ...), so this is a 20-minute fix either way. Let me know if it succeeds or you hit a specific error!
<span style="display:none">[^6_10][^6_6][^6_8][^6_9]</span>

<div align="center">⁂</div>

[^6_1]: https://www.reddit.com/r/WindowsHelp/comments/1j5yr62/how_can_resize_efi_partition_on_windows_11/?tl=es-419

[^6_2]: https://pleasework.robbievance.net/howto-move-efi-system-partition-so-you-can-increase-space-on-system-drive/

[^6_3]: https://www.easeus.com/partition-master/how-to-resize-efi-partition-windows-10.html

[^6_4]: https://learn.microsoft.com/en-us/answers/questions/3814445/how-can-i-resize-the-efi-partition

[^6_5]: https://learn.microsoft.com/en-us/answers/questions/4287192/how-to-increase-efi-and-recovery-partitions-size-u

[^6_6]: https://www.youtube.com/watch?v=RwMUunu_U6s

[^6_7]: https://www.youtube.com/watch?v=nXLcogrck3c

[^6_8]: https://www.elevenforum.com/t/how-to-increase-size-of-efi-systems-partition.37763/

[^6_9]: https://www.youtube.com/watch?v=YOqGWwpY5R0

[^6_10]: https://www.youtube.com/watch?v=KmIlfKYU5cQ

[^6_11]: https://www.reddit.com/r/pop_os/comments/l33nur/minimum_efi_system_partition_size_and_dual/


---

# Can I do that with popos 'modify partitions' oh hang on there is an other partition next to the efi  a 'microsoft reserved partiton' 16MB ...

Yes, the 16MB Microsoft Reserved Partition (MSR) between EFI and Windows C: is standard on GPT disks, but it complicates resizing EFI because GParted/Pop!_OS tools often struggle to shift it without issues.

### Pop!_OS "Modify Partitions" limitations

Pop!_OS's built-in partition editor (in the installer) can resize NTFS partitions like C:, but it **cannot** easily:

- Delete/move the MSR (Windows gets upset if you touch it).
- Extend EFI across the MSR gap.
So you'll likely hit the same "EFI too small" block even after shrinking C:.[^7_1]


### Skip it—use GParted from Pop!_OS live USB instead

1. Boot the **Pop!_OS live USB** (not installer yet).
2. Open terminal → type `gparted` (installs automatically if needed).
3. Your layout: `/dev/sda1 EFI (100MB)` → `/dev/sda2 MSR (16MB)` → `/dev/sda3 C: (big NTFS)`.
4. Right-click **C: partition** → **Resize/Move** → Shrink it by ~900MB from the *left edge* (this creates unallocated space between MSR and C:).
5. **Delete the MSR** (16MB)—it's safe; Windows recreates if needed and doesn't store data there.
6. Right-click **EFI** → **Resize/Move** → Extend it rightward into all freed space (~1GB total).
7. **Apply** changes → Reboot → Boot back to Pop!_OS installer.

Now Custom Install works: EFI (now 1GB) as `/boot/efi` (no format), your 65GB as `ext4 /` (format). Button activates.[^7_1]

### MSR safety note

The 16MB MSR is just a placeholder for dynamic disks/convertible volumes—pure Windows systems never use it. Deleting it during resize is a common workaround and won't break booting.[^7_1]

### Risk level: Medium

- **Backup first** anyway.
- If Windows won't boot after: boot Windows USB → Repair → Startup Repair fixes it.
- Takes ~20 mins total.

This bypasses Windows tools entirely. Want screenshots of the exact GParted clicks for your layout?
<span style="display:none">[^7_2][^7_3][^7_4][^7_5][^7_6][^7_7]</span>

<div align="center">⁂</div>

[^7_1]: https://www.reddit.com/r/pop_os/comments/d1a72g/unable_to_resize_efi_partition_for_pop_os/

[^7_2]: https://www.reddit.com/r/pop_os/comments/11d86xu/installing_popos_to_dual_boot_with_windows_efi_is/

[^7_3]: https://www.reddit.com/r/pop_os/comments/zaoiq5/pop_install_issue_after_resizing_efi_partition/

[^7_4]: https://www.reddit.com/r/linux4noobs/comments/1hxqefb/pop_os_the_system_efi_partition_is_too_small/

[^7_5]: https://www.reddit.com/r/pop_os/comments/yzbv6k/efi_partition_too_small_for_install/

[^7_6]: https://www.reddit.com/r/pop_os/comments/15ouhik/resizing_file_system_root/

[^7_7]: https://www.facebook.com/groups/poposlinux/posts/5326387997473512/


---

# Ok ... so why is it such a hot idea to do windows first ... why not install pop os and then windows?

Installing Windows first is the standard advice mainly because its installer blindly overwrites the bootloader area, breaking Linux access.

### Why "Windows first" became the rule

- **Bootloader behavior**: Windows setup always installs and configures its own UEFI bootloader (bootmgfw.efi) to the EFI partition. It ignores other OSes and doesn't detect Linux GRUB/systemd-boot entries. If you install Pop!_OS first, Windows later will wipe or reorder those entries, leaving you unable to boot Linux without repair tools.[^8_2][^8_4]
- **Partition habits**: Windows auto-creates its preferred layout (100MB EFI → 16MB MSR → NTFS C: → recovery). Linux installers play nice with this and just add their own entries. Reverse it, and you fight Windows assumptions.
- **Simplicity for beginners**: Fixing a broken GRUB (via live USB + `boot-repair` or `chroot`) is a common next step if Windows goes second. Doing Windows first avoids that 90% of the time.


### Can you install Pop!_OS first, then Windows?

Yes, on modern UEFI systems—it's doable and often easier for partition prep:

1. Install Pop!_OS → Shrink its root partition → Leave unallocated space for Windows.
2. Install Windows into that space (it creates its own NTFS but shares the EFI).
3. Boot Pop!_OS live USB → Run `sudo pop-shop install boot-repair` (or `sudo apt install boot-repair`) → Repair GRUB to detect and chainload Windows.
4. Set BIOS boot order to GRUB first.

**Tradeoffs**:


| Order | Pros | Cons |
| :-- | :-- | :-- |
| **Windows first** | No bootloader repair needed; Windows untouched after Linux add. | Partition resizing headaches (like your EFI issue); Windows controls boot order. |
| **Linux first** | Full control over partitions/EFI size upfront; easier to prep dual-boot space. | Requires GRUB repair after Windows; Windows may change boot priority. |

Your situation (small EFI already baked in) actually makes **Pop!_OS first** tempting: fix EFI size now via GParted, install Pop!_OS to your 65GB, shrink it for Windows space later. But if Windows data/setup is already there, stick to resizing EFI as discussed.

The "Windows first" mantra is partly legacy (from MBR days); UEFI made order less critical, but habit persists for reliability.
<span style="display:none">[^8_1][^8_3][^8_5]</span>

<div align="center">⁂</div>

[^8_1]: https://www.lenovo.com/us/en/glossary/what-is-dual-boot/

[^8_2]: https://www.reddit.com/r/linuxquestions/comments/1e21yuu/for_a_dual_boot_is_it_better_to_clean_install/

[^8_3]: https://www.youtube.com/watch?v=KPoM3LpMUcY

[^8_4]: https://www.youtube.com/watch?v=Ci1xSICUClc

[^8_5]: https://www.reddit.com/r/linuxquestions/comments/qcb2zk/dual_boot_installation_question_which_os_first/


---

# What a mess ... ok going for 'Create a separate EFI partition for Linux

If there is free space before or near your 65 GB Linux partition (or you can make some by shrinking a nearby partition), you can:
Create a new ~512 MB–1 GB FAT32 partition and mark it as an EFI System Partition.' with pop os ... well so much for the windows install ... an additonal efi partition for pop os broke it ... pop os how ever did install and works ... but then that wasn't quite what I wanted to end up with ...

Multiple EFI partitions work fine technically, but Pop!_OS's systemd-boot doesn't automatically detect or chainload Windows from a separate EFI, so your BIOS/firmware boot menu became the only way to switch OSes—which is clunky and broke seamless dual boot.

### Why the breakage happened

Pop!_OS installed systemd-boot only to *its own* EFI partition and ignored the Windows one. Windows was still bootable (via its EFI), but without a unified boot manager listing both, you now select OSes manually each time via F12/boot menu. That's functional but not what you wanted (a nice menu with both options).

### Fix it now (add Windows to Pop!_OS boot menu)

Since Pop!_OS is running, use it to detect and add Windows—no reinstalls needed:

1. Open **Terminal** in Pop!_OS.
2. Update: `sudo apt update && sudo apt install efibootmgr os-prober`
3. Mount your **Windows EFI partition** (the original 100MB one):

```
sudo mkdir /mnt/efi
sudo mount /dev/sdXY /mnt/efi  # Replace sdXY with Windows EFI (use `lsblk` or `fdisk -l` to ID it)
```

4. Regenerate bootloader configs:

```
sudo mount --bind /dev /mnt/efi/dev
sudo mount --bind /proc /mnt/efi/proc
sudo mount --bind /sys /mnt/efi/sys
sudo os-prober
sudo genefsb -i /boot/efi/loader/entries  # systemd-boot specific
sudo bootctl --path=/boot/efi update
```

5. Reboot. Hold **Spacebar** during boot (Pop!_OS trick) or check systemd-boot menu for Windows entry.

### Clean it up (optional: merge into one EFI later)

Once dual boot works:

- Boot Windows → Verify OK.
- Back in Pop!_OS, resize/delete the extra Pop!_OS EFI → Extend Windows EFI if needed → Recopy Pop!_OS bootloader files to the shared (Windows) EFI.

This gets you a proper dual boot menu from Pop!_OS without touching Windows data. If commands error, paste the output and your `lsblk` here. You're close!
<span style="display:none">[^9_1][^9_2][^9_3][^9_4][^9_5][^9_6][^9_7][^9_8]</span>

<div align="center">⁂</div>

[^9_1]: https://www.youtube.com/watch?v=MBPR4PAzDfs

[^9_2]: https://www.reddit.com/r/pop_os/comments/hndt9c/how_to_install_popos_on_a_system_with_a_efi/

[^9_3]: https://www.reddit.com/r/pop_os/comments/l33nur/minimum_efi_system_partition_size_and_dual/

[^9_4]: https://forum.level1techs.com/t/just-how-bad-would-it-be-to-have-multiple-efi-partitions-on-a-disk-for-dual-boot/178035

[^9_5]: https://www.reddit.com/r/pop_os/comments/zaa63q/dual_booting_with_win11_2_efi_boot_partitions/

[^9_6]: https://www.reddit.com/r/pop_os/comments/qomsx0/my_short_guide_on_how_do_i_install_pop_os_in_a/

[^9_7]: https://www.reddit.com/r/pop_os/comments/yzbv6k/efi_partition_too_small_for_install/

[^9_8]: https://www.facebook.com/groups/poposlinux/posts/4962496687195980/


---

# Hmm thanks for the tips but this is getting to iffy ... by the by I take it that a specific version of popos supports the 5060 rtx ?

No specific Pop!_OS version is *required* exclusively for the RTX 5060—any recent NVIDIA ISO works fine with the right driver series (570+ open kernel modules).[^10_1][^10_5]

### Pop!_OS NVIDIA support for RTX 5060

- **Current stable (24.04+ or latest 22.04 NVIDIA ISO)**: Download the **NVIDIA ISO** from pop.system76.com (not Intel/AMD version). It ships with NVIDIA driver 580, which fully supports RTX 50-series including 5060 for gaming, compute, and CUDA.[^10_4][^10_5][^10_1]
- Users report RTX 5060 running Dying Light at 174 FPS on Pop!_OS 22.04 NVIDIA ISO, so your install should handle it out of the box once booted.[^10_4]
- Early adopters had black screen issues on older Mint/Ubuntu due to driver mismatches, but Pop!_OS NVIDIA ISOs avoid this by pre-baking the exact 580-open drivers RTX 5060 needs.[^10_3][^10_1]


### Quick test before full commit

- Grab the **Pop!_OS NVIDIA ISO** (second download option on their site).
- Boot live USB → If desktop loads with hardware acceleration (check `nvidia-smi`), you're golden.
- No repartitioning needed—just recover your Windows later if desired.

Since Pop!_OS is already running on your system, run `nvidia-smi` in terminal to check if 5060 is detected. If not, Pop Shop → Search "system76-driver-nvidia" → Install latest (handles 50-series automatically). This sidesteps all the EFI/dual-boot mess for now.
<span style="display:none">[^10_10][^10_2][^10_6][^10_7][^10_8][^10_9]</span>

<div align="center">⁂</div>

[^10_1]: https://www.reddit.com/r/pop_os/comments/1pho1e4/will_pop_os_work_on_my_rtx_5060/

[^10_2]: https://forums.developer.nvidia.com/t/pop-os-22-04-unable-to-load-nvidia-drivers-550-560-or-565/319709

[^10_3]: https://www.reddit.com/r/pop_os/comments/15hdkaw/does_pop_os_have_rtx_4000_series_support_if_yes/

[^10_4]: https://www.youtube.com/watch?v=vjvCf-iH_zI

[^10_5]: https://system76.com/pop/download/

[^10_6]: https://www.reddit.com/r/Ubuntu/comments/1k7e7jq/rtx_5060/

[^10_7]: https://forum.level1techs.com/t/how-to-use-a-5060ti-on-linux-right-now/230071

[^10_8]: https://forums.developer.nvidia.com/t/rtx-5060-driver/334371

[^10_9]: https://linuxcommunity.io/t/problem-with-drivers-and-bootloader/5717

[^10_10]: https://www.reddit.com/r/pop_os/comments/yfic13/when_updating_to_60_with_nvidia_gpu/


---

# Ok getting the latest iso with nvidia from here : [https://system76.com/pop/download/](https://system76.com/pop/download/) : Pop!_OS 24.04 LTS ... going to install on a separate drive (usb stick) multi booting windows with a nix is still just a bad plan ... any idea how I can bypass the the password with popos ? windows allows just a username ...

Pop!_OS 24.04 LTS NVIDIA ISO on a USB stick is a solid plan—multi-booting can indeed get messy fast.

Pop!_OS requires a login password by default (unlike Windows' optional PIN-only setup), but you can enable automatic login to bypass the password screen entirely.

## Enable Auto-Login (no password prompt)

**During fresh install:**

1. Create your user → When it asks for password, enter a **blank** password (just hit Enter twice).
2. After install boots → **Settings** → **Users** → Toggle **"Automatic Login"** ON for your user.
3. Log out → It boots straight to desktop forever.

**If you already set a password:**

```
# Terminal (once logged in):
sudo nano /etc/gdm3/custom.conf
```

Uncomment/add these lines under `[daemon]`:

```
AutomaticLoginEnable=true
AutomaticLogin=yourusername
```

`sudo systemctl restart gdm`

## Handle Keyring/Sleep Prompts

Auto-login skips the login screen but you'll still get:

- **"Unlock Login Keyring"** popup → Set keyring password to blank: **Passwords \& Keys** app → Right-click "Login" → Change → Blank password.
- **Screen lock after idle** → **Settings** → **Privacy** → **Screen Lock** → OFF.

Now it boots like Windows (no passwords), but `sudo` still prompts for security. Matches your workflow perfectly. Install finishes in ~10 mins on USB.
<span style="display:none">[^11_1][^11_2][^11_3][^11_4][^11_5][^11_6][^11_7][^11_8]</span>

<div align="center">⁂</div>

[^11_1]: https://www.reddit.com/r/pop_os/comments/n4j475/disabling_password_on_pop/

[^11_2]: https://www.reddit.com/r/pop_os/comments/kz6nxd/remove_pop_os_login_password/

[^11_3]: https://www.reddit.com/r/pop_os/comments/w607jx/is_it_possible_to_remove_the_login_password/

[^11_4]: https://www.reddit.com/r/pop_os/comments/p6q7zo/how_do_i_disable_reenable_password_prompts_in_pop/

[^11_5]: https://www.reddit.com/r/pop_os/comments/i31mcw/login_without_password/

[^11_6]: https://www.reddit.com/r/pop_os/comments/rusioq/how_to_get_rid_of_password/

[^11_7]: https://support.system76.com/articles/password/

[^11_8]: https://www.facebook.com/groups/poposlinux/posts/5394467733998871/


---

# Ah ht enter twice ... ok gracias for the tips will do once I start, trying to get pop os, on a stick. By the by the new windows install is more or less finished you probably know this but the efi 100MB can not be resized in windows well ok windows only does shrink but that can not be done either ... seems windows is very picky about the size of the efi ... and as far as I can tell during the install of windows 10 there is no option to *set* the efi partition to a desired size ...

Yeah, Windows 10 setup stubbornly sticks to its 100MB EFI default with zero options to customize it during install—you can't pre-specify sizes in the GUI.[^12_7]

### Windows EFI behavior confirmed

- Always auto-creates exactly **100MB FAT32 EFI** (or 260MB on 4Kn drives) when given unallocated space.
- No sliders, no manual partitioning screen like Linux installers offer.
- Shrink in Windows Disk Management? Nope—EFI is marked "System" and unmovable; shrink only works on basic NTFS volumes with free space.[^12_11]
- That's why everyone hits your exact frustration: Windows bakes in the "too small for Linux" layout.


### Your Pop!_OS-on-USB plan sidesteps it perfectly

Fresh 24.04 NVIDIA ISO on USB stick → **Erase entire USB** → Standard install. Pop!_OS auto-creates its own properly-sized 500MB+ EFI + root on the USB. Boots flawlessly, RTX 5060 ready. No Windows partition conflicts.

**Blank password trick works great there too**—just Enter twice at user creation, then Settings → Users → Automatic Login. Boots to desktop instantly.

Multi-booting *is* a hassle; single-drive USB Pop!_OS gives you the best of both worlds without repartition roulette. Smart call.
<span style="display:none">[^12_1][^12_10][^12_2][^12_3][^12_4][^12_5][^12_6][^12_8][^12_9]</span>

<div align="center">⁂</div>

[^12_1]: https://www.reddit.com/r/pop_os/comments/l33nur/minimum_efi_system_partition_size_and_dual/

[^12_2]: https://www.reddit.com/r/sysadmin/comments/13yeh3d/windows_11_new_efi_system_partition_requirement/

[^12_3]: https://www.tenforums.com/installation-upgrade/102777-recommended-size-efi-partition-v1709.html

[^12_4]: https://www.reddit.com/r/Dell/comments/14sangh/what_should_be_the_size_of_the_efi_partition_of/

[^12_5]: https://wiki.archlinux.org/title/EFI_system_partition

[^12_6]: https://garytown.com/low-space-on-efi-system-partition-clean-up

[^12_7]: https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/configure-uefigpt-based-hard-drive-partitions?view=windows-11

[^12_8]: https://www.reddit.com/r/archlinux/comments/1ivyt83/efi_system_partition_size_1gb_or_512mb/

[^12_9]: https://learn.microsoft.com/en-us/answers/questions/4287192/how-to-increase-efi-and-recovery-partitions-size-u

[^12_10]: https://forum.manjaro.org/t/efi-system-partition-esp-size-and-commentary/158684

[^12_11]: https://learn.microsoft.com/en-us/answers/questions/3814445/how-can-i-resize-the-efi-partition


---

# Yes... it does just for the record if I had chosen the normal install of popos would it have erased the windows partition?

**No, "normal install" (Clean Install) would NOT have erased your Windows partition**—*if* you picked the right drive.

Pop!_OS's first screen shows all drives clearly labeled by size/model. "Clean Install" only wipes **the single drive/USB you select** and ignores others completely. Windows on your main drive stays 100% safe as long as you choose the USB stick.[^13_7]

### How it works exactly:

1. **Boot Pop!_OS USB** → Installer loads → **"Clean Install"** button.
2. **Drive selection screen**: Lists every drive (SSD/HDD/USB) separately:

```
Drive 1: 500GB Samsung SSD  [Windows detected here]
Drive 2: 128GB USB Stick    [← Pick THIS]
```

3. Click **128GB USB** → **Install** → Wipes *only* that USB, creates proper EFI + root automatically.
4. Your Windows SSD untouched, boots normally from BIOS menu.

**The danger is only mis-clicking**—installer doesn't merge drives or auto-detect "main OS". Always double-check the drive size/model shown above the Install button.

That's why **Custom (Advanced)** is safer for multi-drive: you manually pick exact partitions. But for USB-only Pop!_OS like you're doing now, Clean Install is fastest and foolproof. Windows lives on happily.
<span style="display:none">[^13_1][^13_2][^13_3][^13_4][^13_5][^13_6][^13_8]</span>

<div align="center">⁂</div>

[^13_1]: https://www.youtube.com/watch?v=rS7n9JuDKw8

[^13_2]: https://www.reddit.com/r/pop_os/comments/1njsn4w/removing_windows_from_dual_boot/

[^13_3]: https://www.youtube.com/watch?v=dA4l8nZ3TJ0

[^13_4]: https://www.reddit.com/r/pop_os/comments/1b1tgg1/clean_install_without_overwriting_home_partition/

[^13_5]: https://www.reddit.com/r/pop_os/comments/mlnzqy/erase_and_install_button_greyed_out/

[^13_6]: https://www.reddit.com/r/pop_os/comments/snlc0q/how_do_i_delete_pop_os_from_my_computer/

[^13_7]: https://support.system76.com/articles/install-pop/

[^13_8]: https://www.facebook.com/groups/poposlinux/posts/8938878969557712/


---

# No I'm probably confusing this a bit but I meant in the previous situation with two partitions on one drive that ultimately borked the windows install ... would selecting 'clean install' on that one drive have erased the windows partition and those belonging to it ?

**Yes, "Clean Install" on that single drive would have erased the entire Windows partition** (and all partitions on that drive).

Pop!_OS's "Clean Install" (or "Erase and Install") targets **only the selected drive** but wipes **every partition on it** completely—EFI, MSR, C:, recovery, everything becomes unallocated space for a fresh Pop!_OS layout.[^14_7][^14_9]

### In your previous scenario:

- One physical drive with: Windows EFI (100MB) + MSR (16MB) + Windows C: + your 65GB free partition.
- Installer shows: **"500GB Samsung SSD"** (the whole drive).
- Click **Clean Install** → **Confirm** → Entire SSD reformatted. Windows gone forever, Pop!_OS gets full disk with proper-sized EFI + root.

That's exactly why you wisely went **Custom Install** instead—it let you pick *just* the 65GB partition for `/` while leaving Windows partitions alone (until the separate EFI caused boot confusion).

**Custom = surgical** (pick exact partitions). **Clean = nuke entire drive**. Always double-check the drive size/model shown before confirming! Your USB stick plan avoids this entirely.
<span style="display:none">[^14_1][^14_10][^14_2][^14_3][^14_4][^14_5][^14_6][^14_8]</span>

<div align="center">⁂</div>

[^14_1]: https://support.system76.com/articles/pop-recovery/

[^14_2]: https://www.youtube.com/watch?v=rS7n9JuDKw8

[^14_3]: https://www.reddit.com/r/pop_os/comments/mm3s6z/i_wanted_to_try_popos_but_now_i_want_to_get_my/

[^14_4]: https://www.reddit.com/r/pop_os/comments/1njsn4w/removing_windows_from_dual_boot/

[^14_5]: https://www.youtube.com/watch?v=gNvPX_O5IJY

[^14_6]: https://www.reddit.com/r/pop_os/comments/1b1tgg1/clean_install_without_overwriting_home_partition/

[^14_7]: https://www.reddit.com/r/pop_os/comments/nojun9/will_installing_pop_os_wipe_all_my_disks_or_just/

[^14_8]: https://www.facebook.com/groups/poposlinux/posts/8938878969557712/

[^14_9]: https://support.system76.com/articles/install-pop/

[^14_10]: https://www.facebook.com/groups/poposlinux/posts/3463588290420168/


---

# Ok good to get that verified. So one last thing I'm using ventoy on a usb hard drive with a bunch of iso's which works nicely, boot > select iso > install ... as intended ... can ventoy deal with some extra folders in the root of the drive where I could put apps / drivers / etc or is it better to just stick with os iso's ?

**Yes, Ventoy handles extra folders perfectly fine** alongside your ISOs—no issues at all.

### Ventoy USB structure

Ventoy creates two fixed partitions on your USB drive:

- **Part1 (exFAT by default)**: Main data area where you drop ISOs. This acts like a normal USB drive.
- **Part2 (~32MB FAT)**: Hidden Ventoy bootloader (don't touch).

**You can freely add folders, apps, drivers, documents—anything** directly to Part1 alongside your ISOs. Ventoy only scans for `*.iso` files (and some IMG/WIM) and ignores everything else.[^15_1][^15_2]

### Example layout that works great:

```
USB Drive (Part1 exFAT):
├── pop_os_24.04_nvidia.iso
├── ubuntu.iso
├── windows10.iso
├── Tools/
│   ├── nvidia_drivers.run
│   ├── memtest86.iso
│   └── HirensBootCD.iso
├── Drivers/
│   ├── Realtek_Audio.zip
│   └── Intel_ME_FWUpd.exe
├── Docs/
│   └── partition_notes.txt
└── ventoy/          (optional Ventoy config folder)
```


### Key points:

- **Drag-and-drop ISOs anywhere** on Part1—even inside subfolders. Ventoy menu shows tree view with folders.
- **Non-ISO files 100% safe**—stored like normal USB files, accessible from Windows/Linux/Pop!_OS live sessions.
- **No reformatting needed** when adding/removing ISOs or folders.
- **Even works during OS installs**—boot Pop!_OS from Ventoy, access your `Drivers/` folder from live desktop.

**Perfect for your workflow**: ISOs for boot/install + organized apps/drivers/docs all on one USB HDD. Boot > pick ISO > install > grab drivers from adjacent folder. Way cleaner than separate USBs.
<span style="display:none">[^15_10][^15_3][^15_4][^15_5][^15_6][^15_7][^15_8][^15_9]</span>

<div align="center">⁂</div>

[^15_1]: https://www.ventoy.net/en/doc_disk_layout.html

[^15_2]: https://www.dotlinux.net/blog/how-to-create-a-multiboot-usb-with-ventoy/

[^15_3]: https://www.pctips.com/multiboot-usb-drives/

[^15_4]: https://github.com/ventoy/Ventoy

[^15_5]: https://www.youtube.com/watch?v=gAnA7X8fAGs

[^15_6]: https://itsfoss.community/t/tutorial-on-ventoy-to-create-a-multiboot-linux-installation-usb-tool/13539?page=3

[^15_7]: https://www.youtube.com/watch?v=_w4XcQA3vpA

[^15_8]: https://www.ventoy.net/en/doc_start.html

[^15_9]: https://www.youtube.com/watch?v=-7APoZzNPyU

[^15_10]: https://www.reddit.com/r/linux/comments/iekgrz/ventoy_a_new_bootable_usb_solution_with_ventoy/


---

# Lovely ... ok that's it thank you for the assistance even though not quite to plan I'm a bit wiser about the 'multi boot' thing specifically those pesky efi's.

You're welcome! Yeah, those EFI partitions are definitely the stealthiest multi-boot gotcha—glad you got Pop!_OS running smoothly on the USB stick with Ventoy regardless. Hit me up if you run into driver quirks with the RTX 5060 or anything else. Safe travels! 🚀

