<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# how about a .sh around wah@:/mnt/recycle/dev/audioplayer-bass\$ LD_LIBRARY_PATH=.:\$LD_LIBRARY_PATH ./audioplayer /media/wah/games/data/mp3/world

Yes — a tiny wrapper `.sh` is the simplest fix here. It sets `LD_LIBRARY_PATH` for just this launch, and wrapper scripts are a common way to avoid touching the system-wide linker config.[^1_1][^1_2]

## Wrapper script

Save this as `run-audioplayer.sh` in the same folder as `audioplayer` and `libbass.so`:

```bash
#!/bin/sh
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
export LD_LIBRARY_PATH="$DIR${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
exec "$DIR/audioplayer" "$@"
```

Then make it executable:

```bash
chmod +x run-audioplayer.sh
```

Run it like this:

```bash
./run-audioplayer.sh /media/wah/games/data/mp3/world
```


## Why this works

`LD_LIBRARY_PATH` is a colon-separated search path for shared libraries, and prepending the executable’s directory makes the loader look there first for `libbass.so`. The wrapper approach also keeps the setting local to this program instead of affecting your whole shell session.[^1_3][^1_2][^1_1]

## Small note

This uses the script’s own directory, not the current working directory, so it behaves more like Windows’ “look next to the executable” rule. That is usually better than `LD_LIBRARY_PATH=.` because `.` depends on where you launched the command from.[^1_4][^1_2][^1_3]
<span style="display:none">[^1_10][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://stackoverflow.com/questions/13428910/how-to-set-the-environment-variable-ld-library-path-in-linux

[^1_2]: https://www.hpc.dtu.dk/?page_id=1180

[^1_3]: https://www.datacadamia.com/os/linux/ld_library_path

[^1_4]: https://enchildfone.wordpress.com/2010/03/23/a-description-of-rpath-origin-ld_library_path-and-portable-linux-binaries/

[^1_5]: https://www.baeldung.com/linux/rpath-change-in-binary

[^1_6]: https://iq.opengenus.org/set-ld-library-path/

[^1_7]: https://www.reddit.com/r/linux4noobs/comments/1oycdgc/how_to_set_ld_library_path_for_a_specific/

[^1_8]: https://stackoverflow.com/questions/52098777/shell-script-that-sets-ld-library-path-pwd-does-not-work-from-java

[^1_9]: https://github.com/python/cpython/issues/111514

[^1_10]: https://discussion.fedoraproject.org/t/ld-library-path-is-not-set-by-bash-profile-anymore-after-upgrade-to-fedora-31/75171

