<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Alas no cigar ... all though not a fan I went for the 'magic' number in this case 1.333 (funny how .333 always kinda works) so for now : header.w = min(CLng((lst.index * 1.333 / lst.total) * backgroundplate.w), backgroundplate.w)

: used a min to limit the overshoot with a high number of indexes ... will have to do for now. Many thanks for sharing some scenarios and tips math like this is always a bit hard to crack.

That’s a perfectly reasonable pragmatic fix. Using `Min(..., backgroundplate.w)` to cap the overshoot is a sound safeguard, and the `.333` factor likely compensates for a mismatch between how your `lst.index` progresses and what you want the bar to visually represent.

## Why it probably helped

Your formula:

```basic
header.w = Min(CLng((lst.index * 1.333 / lst.total) * backgroundplate.w), backgroundplate.w)
```

works because it scales the indicator faster, then clamps it so it never exceeds the plate width. That’s a common way to tame imperfect real-world progress math when the underlying index doesn’t map cleanly to pixels.

## A small note

If you later want to refine it, the most useful thing to verify is whether `lst.index` is:

- item count,
- row count,
- scroll offset,
- or some other internal step value.

That determines whether the right mapping factor should be linear, proportional, or based on a visible-range formula.

## Cleaner version

If you want it a bit safer in FreeBASIC:

```basic
Dim As Integer w
w = CLng((lst.index * 1.333 / lst.total) * backgroundplate.w)
header.w = Min(w, backgroundplate.w)
```

If `lst.total` can ever be zero, protect that too.

Glad it’s usable for now. Math for UI indicators can be annoyingly slippery because the “right” formula often depends on the hidden behavior of the scrolling/indexing logic.

