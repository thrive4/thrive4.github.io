<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# I would like to slim down some apps and / or services on windows 10 maybe you can help or give some suggestions. First off searchapp.exe and startmenuexeprince.exe, are they tied to the exporer.exe (because I will be bypassing that via a shell) or if not can they be stopped from running at boot either via the registry or a policy setting?

On Windows 10, both processes are part of the modern shell stack, but they are not hard‑wired to explorer.exe itself. You can kill and prevent them even if you bypass Explorer with an alternate shell, but you must accept losing built‑in Start menu and Windows search functionality.

## What those processes are

- `SearchApp.exe`
This is the Windows Search UI process used by the taskbar/search box, Start menu search, and File Explorer search integration in newer Windows 10 builds.[^1_1][^1_3][^1_7]
- `StartMenuExperienceHost.exe`
This is the separate UWP host process for the “modern” Start menu experience introduced in 1903+; it runs as part of the desktop shell and communicates with Explorer but is not the same process as Explorer.[^1_2]

If you replace `explorer.exe` with another shell, these can still be launched by the system unless you explicitly block or remove them.[^1_5][^1_2]

## Stopping them at boot (conceptually)

If you are comfortable losing Start menu and integrated search, there are three broad approaches that people use:

1. **Software Restriction / AppLocker policy** (cleanest for managed systems)
    - Create a disallow rule targeting
        - `C:\Windows\SystemApps\Microsoft.Windows.Search_cw5n1h2txyewy\SearchApp.exe`
        - `C:\Windows\SystemApps\Microsoft.Windows.StartMenuExperienceHost_cw5n1h2txyewy\StartMenuExperienceHost.exe` (exact folder name varies by build).
    - Apply the rule to all users (or at least to those sessions where your custom shell runs).
This prevents the processes from ever starting, rather than killing them after launch.[^1_5]
2. **ACL / rename the SystemApps folder** (hard block, but update‑hostile)
Typical pattern for `SearchApp.exe` people use:
    - Boot into Safe Mode with Command Prompt.
    - Go to `%windir%\SystemApps`.
    - Stop `SearchApp.exe` if it is running (`taskkill /f /im SearchApp.exe`).
    - Rename the search system app folder, e.g.:
        - `move Microsoft.Windows.Search_cw5n1h2txyewy Microsoft.Windows.Search_cw5n1h2txyewy.old`.[^1_3][^1_4][^1_6]
You can do the equivalent for the Start menu host folder. This effectively prevents the OS from loading those components at all, but cumulative updates can revert or break this, and on some builds it can cause taskbar glitches if you still use the default shell.[^1_4]
3. **Kill them on session start** (works well with a custom shell)
Since you’ll be bypassing Explorer anyway, you can launch your shell via a startup script that first terminates all shell‑related UWP hosts:
    - Example batch sequence used by others to get a “clean” desktop environment:

```cmd
@echo off
taskkill /f /im explorer.exe
taskkill /f /im SearchApp.exe
taskkill /f /im ShellExperienceHost.exe
taskkill /f /im StartMenuExperienceHost.exe
```

Then start your own shell process.[^1_2]
In your scenario, you can set this script to run as the user shell via the `Shell` value under:
`HKCU\Software\Microsoft\Windows NT\CurrentVersion\Winlogon` or `HKLM` (depending on your design), so Explorer never comes up and these processes are killed immediately.

## Registry / policy angle

There is no single documented “off” switch in the registry for `SearchApp.exe` or `StartMenuExperienceHost.exe` while keeping the rest of the shell intact; they are treated as core system apps. The closest policy‑level mechanisms are:[^1_1][^1_3]

- **Disabling Windows Search service** – this stops indexing but does not alone prevent `SearchApp.exe` from launching when you open the Start menu or taskbar search.[^1_3][^1_1]
- **Software Restriction Policies / AppLocker** – recommended if you want a supported policy‑based way to keep those executables from running without hacking files.[^1_5]


## Practical suggestion for your use‑case

Since you plan to replace Explorer with a custom shell:

1. Configure your shell via the `Shell` registry value so `explorer.exe` does not start at logon.
2. Add a small startup script (or integrate into the shell’s bootstrapper) that:
    - Calls `taskkill /f /im SearchApp.exe`
    - Calls `taskkill /f /im StartMenuExperienceHost.exe`
    - Optionally kills `ShellExperienceHost.exe` as well if you do not want the modern shell surfaces.[^1_2]
3. (Optional but cleaner) Add SRP/AppLocker deny rules for those two executables so they are never re‑spawned by the system.[^1_5]

If you share which exact Windows 10 build you are on and how you plan to register your shell (HKCU vs HKLM, classic vs UWP), I can outline more precise steps tailored to that setup.
<span style="display:none">[^1_10][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://learn.microsoft.com/en-us/answers/questions/3936873/how-to-remove-searchapp-exe

[^1_2]: https://learn.microsoft.com/en-us/answers/questions/3728246/how-do-you-disable-searchapp-exe-from-running-so-t

[^1_3]: https://www.minitool.com/news/searchapp-exe.html

[^1_4]: https://www.tenforums.com/general-support/215831-how-disable-searchapp-exe.html

[^1_5]: https://www.reddit.com/r/sysadmin/comments/l1cb06/start_menu_application_searching_windows_10_20h2/

[^1_6]: https://www.bleepingcomputer.com/forums/t/734430/how-can-i-permanently-disable-or-just-delete-searchappexe/

[^1_7]: https://helpdeskgeek.com/what-is-searchapp-exe-and-is-it-safe/

[^1_8]: https://learn.microsoft.com/en-us/answers/questions/4170598/how-to-stop-explorer-exe-and-or-searchapp-exe-from

[^1_9]: https://learn.microsoft.com/en-us/answers/questions/4261963/fix-the-searchapp-exe-or-search-ui-exe-windows-10

[^1_10]: https://fpkm.tistory.com/208


---

# Some nice suggestions currently I will be doing something along the lines of : HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System

shell = cmd.exe /c start f:\\osd\\osd.exe : if memory serves me well starting up a .bat via the shell is a no go in the past I did use autoit (compiled a .au3 to an exe) because the .exe can be set to run as administrator ....

Your memory serves you right: using a `.bat` directly as the shell is unreliable on newer Windows 10 builds, and an `.exe` wrapper (like your old AutoIt approach) is the more robust way to go.[^2_3][^2_4]

## About your current shell line

You wrote:

`HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System`
`shell = cmd.exe /c start f:\osd\osd.exe`

A few points:

- The **usual** per‑user shell key is
`HKCU\Software\Microsoft\Windows NT\CurrentVersion\Winlogon\Shell` (string) rather than the Policies path.[^2_4]
- You *can* put a command line there (e.g. `cmd.exe /c ...`), but quoting and spaces get tricky, and if anything fails, you end up with a black screen and no shell.[^2_2][^2_6]
- `start` inside `cmd.exe /c` returns immediately, so Windows may think the shell has exited, depending on how it monitors it.

If you want something simple and robust, the safest pattern is:

- Point `Shell` directly at a single **.exe** (no `cmd`, no `start`).
- Have that exe do whatever you need: kill unwanted processes, start your real shell, handle restarts.


## Recommended pattern for your setup

1. **Keep using an .exe launcher**
    - You can stick with AutoIt, a small C/C++/C\# stub, or any tool that compiles to a plain .exe.
    - Give it something like:
        - Kill `SearchApp.exe`, `StartMenuExperienceHost.exe`, `explorer.exe` if running.
        - Start `f:\osd\osd.exe` (or whatever your main shell is).
        - Optionally wait on it and reboot or restart the shell on exit.
2. **Registry setting (per‑user)**
    - Set:
`HKCU\Software\Microsoft\Windows NT\CurrentVersion\Winlogon`
`Shell` = `"F:\osd\launcher.exe"` (your compiled exe).
    - This per‑user shell key is known to work fine on Windows 10 for single‑user custom shells.[^2_4]
3. **If you insist on using cmd.exe**
If you really want to keep the current style, use the Winlogon key and be careful with quoting, for example:

`Shell` = `cmd.exe /c "start ""F:\osd\osd.exe"""`

But this is still more fragile than a dedicated launcher exe, and Windows kiosk/custom‑shell guidance strongly prefers a direct exe path.[^2_5][^2_6][^2_2]

## Running as administrator

- The shell process runs in the context of the user who logs on; it won’t auto‑elevate just because it is in `Shell`.
- Your previous trick (AutoIt exe marked to “Run as administrator” in its manifest) is still a reasonable way to get an elevated shell on a local admin account, but you’ll get UAC prompts unless UAC is configured accordingly.
- If you want *no* UAC prompts and full admin rights, use an admin account and adjust UAC or use the embedded Shell Launcher / Assigned Access mechanisms designed for kiosk shells (Enterprise/IoT SKUs).[^2_5]

If you tell me which Windows 10 edition and build you’re on and whether this is a kiosk‑like scenario or just a personal build, I can suggest an exact launcher layout (AutoIt script or small PowerShell‑compiled exe) tailored for that.
<span style="display:none">[^2_1][^2_7]</span>

<div align="center">⁂</div>

[^2_1]: https://stackoverflow.com/questions/53369043/custom-shell-can-not-start-in-win10

[^2_2]: https://learn.microsoft.com/en-us/answers/questions/1158081/how-can-you-modify-the-shell-in-the-registry-resta

[^2_3]: https://www.tenforums.com/customization/162697-can-no-longer-change-default-shell-explorer-exe-custom.html

[^2_4]: https://stackoverflow.com/questions/33364908/how-to-run-an-application-as-shell-replacement-on-windows-10-enterprise

[^2_5]: https://learn.microsoft.com/en-us/windows/configuration/shell-launcher/configure

[^2_6]: https://learn.microsoft.com/en-us/answers/questions/249751/windows-10-kiosk-scripting-registry-change-for-she

[^2_7]: https://answers.microsoft.com/en-us/windows/forum/all/changing-shell-in-registry-has-no-effect/c53c8c2b-a206-4d0b-bdbc-099caa0ad631


---

# Ok something's never change ... funny if I do this taskkill /f /im SearchApp.exe less then a second later SearchApp.exe is relaunched by well something ... doing taskkill /f /im explorer.exe fortunately does make house of cards fall down so SearchApp, StartMenuExperienceHost and some textinputhost thing all go down in one swoop hope that at booting (without explorer.exe) the same occurs ...

What you are seeing is normal for a stock shell session: several components actively monitor and respawn `SearchApp.exe`, so a simple `taskkill` in a normal Explorer session will never “stick”. When you take `explorer.exe` out of the picture at logon (by using a custom shell), its usual orchestration chain is broken, so far fewer of these “self‑healing” restarts will happen automatically.[^3_3][^3_4]

A few concrete points that should match what you’re observing:

- In a normal desktop, `SearchApp.exe` is treated as a core shell component; when you kill it, the shell stack or background task infrastructure starts it again almost immediately, which is why it pops back less than a second later.[^3_5][^3_3]
- When you kill `explorer.exe`, several dependent shell UWP hosts go down with it in one go: `SearchApp.exe`, `StartMenuExperienceHost.exe`, and the text input host you mentioned all terminate because they’re tied to the Explorer‑driven shell session.[^3_4][^3_6]
- If you log on with your custom shell (so Explorer never starts), most of those processes should never appear, or, if something tries to bring them up, they’ll fail more quietly because the Start menu and taskbar aren’t present to call into them.[^3_4][^3_5]

For your plan:

- Relying on “no Explorer at boot” is exactly the right instinct; if Explorer is never launched, you’ve already removed the primary trigger that’s keeping those processes alive.
- I’d still let your launcher exe do a one‑time `taskkill /f` sweep for `SearchApp.exe`, `StartMenuExperienceHost.exe`, and `TextInputHost.exe` right after logon, just to clean up anything the system might have pre‑spawned before the shell hand‑off.
- If, after switching to the custom shell, you do still see `SearchApp.exe` relaunching on its own, then the next escalation step would be either:
    - an AppLocker / SRP deny rule on the Search system app exe, or
    - the “rename the SystemApps search folder” trick you already noticed works, which prevents the background task infrastructure from being able to start it at all.[^3_7][^3_3]

Once you flip the user shell to your own executable and confirm a clean boot, you should be able to check Task Manager and verify that Explorer, StartMenuExperienceHost, and SearchApp are all gone and stay gone unless you deliberately start them.
<span style="display:none">[^3_1][^3_2][^3_8][^3_9]</span>

<div align="center">⁂</div>

[^3_1]: https://learn.microsoft.com/en-us/answers/questions/3986082/searchapp-exe-caused-windows-to-shut-down

[^3_2]: https://www.reddit.com/r/techsupport/comments/1ko07q9/searchappexe_constant_crash/

[^3_3]: https://www.reddit.com/r/Windows10/comments/1fal8j8/search_app_reopens_itself_after_i_close_it_in/

[^3_4]: https://www.edtittel.com/blog/searchapp-exe-sets-windows-10-crash-record.html

[^3_5]: https://learn.microsoft.com/en-us/answers/questions/589640/microsoft-search-window-disapears-immediatly-after

[^3_6]: https://www.reddit.com/r/Windows10/comments/jxz2u6/issues_with_searchapp_crashing_since_latest_update/

[^3_7]: https://www.reddit.com/r/Windows10TechSupport/comments/lbv1ty/windows_10_search_bar_keeps_crashing/

[^3_8]: https://learn.microsoft.com/en-us/answers/questions/3833163/window-10-search-app-keeps-crashing

[^3_9]: https://www.youtube.com/watch?v=Oqmp-rBykGo


---

# Ok got it. Just for plan B will this fly? powershell.exe -ExecutionPolicy Bypass -File "C:\Scripts\MyScript.ps1"

Yes, that form is valid as a “plan B”, with a couple of nuances.

- The syntax
`powershell.exe -ExecutionPolicy Bypass -File "C:\Scripts\MyScript.ps1"`
will run that *one* script with the policy set to Bypass for that process only. It does not permanently change execution policy and it ignores the machine/user defaults for that run.[^4_2][^4_4][^4_10]
- This makes it suitable to use as:
    - A shell command line (e.g., in `Winlogon\Shell`) that just runs your PowerShell bootstrap script.
    - A launcher from a small stub exe, if you still prefer having a compiled front‑end.
- Things to keep in mind:
    - If a domain/local Group Policy enforces a stricter policy, it can override what you’re trying to do; in that case, you’d need policy changes or a different approach.[^4_3][^4_2]
    - Make sure the path is absolute and quoted exactly as you wrote, otherwise the shell startup is brittle.

If you want, I can suggest a minimal `MyScript.ps1` skeleton that kills the shell cruft and then starts your main `osd.exe`.
<span style="display:none">[^4_1][^4_5][^4_6][^4_7][^4_8][^4_9]</span>

<div align="center">⁂</div>

[^4_1]: https://www.reddit.com/r/PowerShell/comments/lnlpwl/setexecutionpolicy_bypass_for_windows_10_pcs_in/

[^4_2]: https://stackoverflow.com/questions/67270197/windows-powershell-policy-execution-bypass

[^4_3]: https://www.reddit.com/r/PowerShell/comments/60sflc/does_the_gpo_startup_powershell_script_bypass/

[^4_4]: https://sentry.io/answers/bypass-and-set-powershell-script-execution-policies/

[^4_5]: https://www.reddit.com/r/PowerShell/comments/6qwzk0/help_bypassing_executionpolicy/

[^4_6]: https://www.reddit.com/r/PowerShell/comments/fuew48/running_ps_script_as_admin_and_bypassing/

[^4_7]: https://www.netspi.com/blog/technical-blog/network-pentesting/15-ways-to-bypass-the-powershell-execution-policy/

[^4_8]: https://www.youtube.com/watch?v=MqsVydfjMQ8

[^4_9]: https://sanjaymenon.in/blog/bypass-powershell-execution-policy/

[^4_10]: https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_execution_policies?view=powershell-7.5


---

# That would be very nice thank you for offering...

Here’s a minimal, practical `MyScript.ps1` you can adapt. It does:

1. Kill the usual shell stuff.
2. Start your custom shell.
3. Optionally loop/restart if it exits.

### Example `C:\Scripts\MyScript.ps1`

```powershell
# --- config ---
$ShellPath  = "F:\osd\osd.exe"
$ShellArgs  = ""            # e.g. '-someSwitch "some value"'
$RestartOnExit = $false     # set $true if you want it to relaunch on exit

function Kill-Processes {
    $targets = @(
        "explorer.exe",
        "SearchApp.exe",
        "StartMenuExperienceHost.exe",
        "ShellExperienceHost.exe",
        "TextInputHost.exe"
    )

    foreach ($p in $targets) {
        try {
            Get-Process -Name ($p -replace ".exe","") -ErrorAction SilentlyContinue |
                Stop-Process -Force -ErrorAction SilentlyContinue
        } catch {}
    }
}

function Start-Shell {
    if (-not (Test-Path $ShellPath)) {
        Write-Host "Shell executable not found: $ShellPath"
        Start-Sleep -Seconds 5
        exit 1
    }

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName  = $ShellPath
    $psi.Arguments = $ShellArgs
    $psi.UseShellExecute = $true

    [void][System.Diagnostics.Process]::Start($psi)
}

# --- main loop ---
do {
    Kill-Processes
    Start-Shell

    if ($RestartOnExit) {
        # wait a bit, then try to re‑kill and restart
        Start-Sleep -Seconds 5
    }
} while ($RestartOnExit)
```


### Shell registry line

Then your shell entry can be:

```text
Shell = powershell.exe -ExecutionPolicy Bypass -File "C:\Scripts\MyScript.ps1"
```

in `HKCU\Software\Microsoft\Windows NT\CurrentVersion\Winlogon` (per‑user), or the equivalent per‑machine if you want it for all users.

If you tell me whether you want automatic restart (`$RestartOnExit = $true`) or strictly one‑shot, I can tweak the script further (e.g. add logging or a simple watchdog).

---

# This is great the use case is a solo machine (not in any 'managed' environment). Thank you for the script. Do you have any idea how the service sysmain works (pertains to improve the system over time)?

SysMain (formerly SuperFetch) is a Windows service designed to analyze your usage patterns and preload frequently used apps/files into RAM for faster launches over time.[^6_1][^6_2]

## Core function

It learns what you run most (e.g., your osd.exe shell, common tools) and prefetches those into standby memory, so they load near-instantly next time. On HDDs this helps a lot; on SSDs or high-RAM systems, the benefit shrinks while it can spike disk/CPU usage during its background work.[^6_4][^6_7][^6_1]

## Slimming impact

For your solo custom-shell machine:

- Safe to disable: it's non-essential and many power users kill it to cut background I/O and RAM churn (frees 100-500MB easily).[^6_1][^6_4]
- Especially useful here since your shell replaces Explorer/Start, so SysMain's predictions will be way off anyway.


## Disable methods

Add to your `MyScript.ps1` (right after `Kill-Processes`):

```powershell
Stop-Service -Name SysMain -Force -ErrorAction SilentlyContinue
Set-Service -Name SysMain -StartupType Disabled -ErrorAction SilentlyContinue
```

Or one-shot via `sc config SysMain start= disabled && sc stop SysMain` in a cmd snippet.[^6_9][^6_4]

On your setup, this should noticeably quiet disk activity at idle without downside.
<span style="display:none">[^6_10][^6_3][^6_5][^6_6][^6_8]</span>

<div align="center">⁂</div>

[^6_1]: https://www.coretechnologies.com/blog/windows-services/sysmain/

[^6_2]: https://devicebase.net/en/microsoft-windows-11-24h2/questions/what-is-sysmain-service-in-windows-11-and-how-to-disable-it/715

[^6_3]: https://www.reddit.com/r/Windows10/comments/v8an69/what_is_sysmain_and_why_was_it_ruining_my_computer/

[^6_4]: https://softwarekeep.com/blogs/troubleshooting/fixed-sysmain-high-cpu-and-memory-usage-in-windows-10

[^6_5]: https://www.softwarehubs.com/troubleshooting/sysmain-in-windows.html

[^6_6]: https://learn.microsoft.com/en-us/answers/questions/4134946/what-is-sysmain-and-why-does-it-sometimes-use-a-bu?forum=windows-all

[^6_7]: https://www.linkedin.com/posts/tom-amollo_sysmain-activity-7404520260147712000-mwaF

[^6_8]: https://blog.acer.com/en/discussion/2836/how-to-disable-superfetch-sysmain-in-windows-11

[^6_9]: https://www.ninjaone.com/blog/how-to-configure-superfetch-in-windows/

[^6_10]: https://www.tenforums.com/performance-maintenance/184542-sysmain-needed-not.html


---

# Nice one so superfetch 2.0 ok disbaled ... how about 'data sharing service'?

Data Sharing Service (DsSvc, `dssvc.exe`) handles data brokering between apps, like clipboard sync, app data exchange, and some telemetry sharing with Microsoft.[^7_1][^7_2][^7_7]

## Core function

It enables seamless data handoff between UWP/modern apps (e.g., sharing text/images between apps, clipboard history support) and coordinates with services like Data Usage or clipboard features. On a solo custom-shell machine, you'll rarely notice it since those modern app interactions aren't in play.[^7_4][^7_1]

## Slimming impact

Totally safe to disable here—no breakage on a stripped-down setup without Start menu or Explorer-driven apps. Frees minor CPU/disk cycles (some report it hogs I/O during telemetry bursts).[^7_8][^7_1]

## Disable via script

Add to your `MyScript.ps1` (after SysMain block):

```powershell
Stop-Service -Name DsSvc -Force -ErrorAction SilentlyContinue
Set-Service -Name DsSvc -StartupType Disabled -ErrorAction SilentlyContinue
```

Or cmd equivalent: `sc config DsSvc start= disabled && sc stop DsSvc`.[^7_1]

Perfect companion to your SysMain disable—keeps more background noise out.
<span style="display:none">[^7_3][^7_5][^7_6][^7_9]</span>

<div align="center">⁂</div>

[^7_1]: https://malwaretips.com/blogs/service-host-data-sharing-service/

[^7_2]: https://blackmagicdesign-creatorscom.jp/data-sharing-service-windows/

[^7_3]: https://learn.microsoft.com/en-us/windows-server/storage/file-server/file-server-smb-overview

[^7_4]: https://blackmagicdesign-creatorscom.jp/blog/data-sharing-service-windows/

[^7_5]: https://www.myworkdrive.com/file-sharing/windows

[^7_6]: https://whereisk0shl.top/post/a-simple-story-of-dssvc

[^7_7]: https://learn.microsoft.com/en-us/windows-server/security/windows-services/security-guidelines-for-disabling-system-services-in-windows-server

[^7_8]: https://www.reddit.com/r/Windows10/comments/3eg53w/datasharingservice_slows_the_pc_to_crawl_details/

[^7_9]: https://answers.microsoft.com/en-us/insider/forum/all/datasharingservice-slows-the-pc-to-crawl/d0dc99f6-770d-46e5-9a21-84ba7930113c


---

# Okidoki indeed a bit dodgy that one and also vague. Any way that will do for now thank you for assistance and scripts it will contribute nicely to a slimmed down version of windows 10 and just as a closing note tweaked : windows 7 40 services : windows 10 80 : still a away to go ...

You're welcome—glad the scripts and service tweaks help slim things down toward that Windows 7 vibe. 80 services vs 40 is quite the bloat creep, but knocking out the non-essentials like SysMain, DsSvc, and shell cruft gets you a solid chunk closer without breakage. If you hit any snags testing the custom shell, feel free to ping.

