﻿This conversation was generated with Duck.ai (https://duck.ai) using Anthropic's Claude Haiku 4.5 Model. AI chats may display inaccurate or offensive information (see https://duckduckgo.com/duckai/privacy-terms for more info).

====================

User prompt 1 of 6 - 4/26/2026, 1:01:42 PM:
pop os looses time setting is the following still corecct for pop os 24.04? :  The easiest solution for it is to fix it in Linux, forcing it to work the same way as Windows. You can do this through the terminal:

timedatectl set-local-rtc 1 --adjust-system-clock

You can verify if the change has been successful, by running this command:

timedatectl

You should see RTC in local TZ: yes. If you need to revert it, just set it to 0:

timedatectl set-local-rtc 0 --adjust-system

link: https://support.system76.com/articles/dual-booting/

For Windows OS, just find a software that can automatically sync your time after boot up, set it in startup. :

Claude Haiku 4.5:
I'll check if this information is still accurate for Pop!_OS 24.04.
Let me search for current information about this issue with Pop!_OS 24.04.
Based on my search results, **yes, the solution you're referencing is still correct and relevant for Pop!_OS 24.04**, though I should clarify a few important points:

## The Core Solution Is Still Valid

The command **`timedatectl set-local-rtc 1 --adjust-system-clock`** still works for fixing dual-boot time issues in Pop!_OS 24.04. This approach forces Linux to store time in the RTC (Real-Time Clock) as local time rather than UTC, matching how Windows handles system time. Verification with **`timedatectl`** and reverting with **`timedatectl set-local-rtc 0 --adjust-system-clock`** remain the same.

## Current Context (April 2026)

There's **active discussion** about this issue on Pop!_OS's GitHub repository. A January 2026 bug report confirms that users with Pop!_OS 24.04 and COSMIC Desktop still experience time synchronization problems when dual-booting with Windows 11, so this remains a known issue.

## Important Notes

1. **The revert command in your source may be incomplete** — you mentioned reverting with `timedatectl set-local-rtc 0 --adjust-system` but the full command should be **`timedatectl set-local-rtc 0 --adjust-system-clock`** (note the `-clock` suffix).

2. **Ubuntu 24.04 (Pop!_OS's base) uses different time sync services** depending on your setup — some systems use `systemd-timesyncd` while others use `chrony`. If `chrony` is installed, it takes priority.

3. **Alternative approach** — Instead of changing RTC settings, some users find it easier to configure Windows to automatically sync time from an internet source, which is what your note mentions.

The solution remains one of the most practical approaches for dual-boot setups, but System76 may eventually implement a more user-friendly GUI option for this in future COSMIC updates.

--------------------

User prompt 2 of 6 - 4/26/2026, 1:06:42 PM:
Thank you. Well some small deviations in my case I'm not 'dual booting' in the classical sense The windows 10 and pop os have separate partitions on separate drives but the symptoms are the same ... alas I have no intention to allow windows 10 online so syncing is not an option so what does 'timedatectl set-local-rtc 1 --adjust-system-clock' actually do? Or on the basis of what I have : wah@:~$ timedatectl
               Local time: Sun 2026-04-26 12:59:12 CEST
           Universal time: Sun 2026-04-26 10:59:12 UTC
                 RTC time: Sun 2026-04-26 10:59:12
                Time zone: Europe/Amsterdam (CEST, +0200)
System clock synchronized: yes
              NTP service: active
          RTC in local TZ: no : disable ntp and system clock synchronized ... just get the time form the bios ...

Claude Haiku 4.5:
Great question — let me break down what's actually happening here and what that command does.

## What `timedatectl set-local-rtc 1 --adjust-system-clock` Does

The command changes **how your system interprets the RTC (BIOS clock)**. Here's the key difference:

**Current situation (RTC in local TZ: no):**
- Your RTC stores time in **UTC** (10:59:12)
- Linux reads it as UTC, then adds your timezone offset (+0200) to display **CEST time** (12:59:12)
- Windows also reads the RTC as UTC, but **expects it to be local time**, so it adds another +0200 offset, resulting in the wrong time (14:59:12 or whatever)

**After running the command (RTC in local TZ: yes):**
- Your RTC would store time in **local time** (12:59:12 CEST)
- Both Linux and Windows read it as local time and display it correctly
- The `--adjust-system-clock` flag automatically adjusts your current system clock to prevent a sudden jump

## Your Specific Situation

Since you have **separate drives** with separate OSes and **no internet sync**, your approach makes sense: **disable NTP and rely on the BIOS clock**. Here's what I'd suggest:

1. **In Pop!_OS**, stop NTP from constantly "correcting" the time:
   ```
   sudo timedatectl set-ntp false
   ```
   This disables the NTP service, so your system won't try to sync with time servers.

2. **Then apply the RTC change** to align with your Windows 10 setup:
   ```
   sudo timedatectl set-local-rtc 1 --adjust-system-clock
   ```

3. **Verify** it worked:
   ```
   timedatectl
   ```
   You should see `RTC in local TZ: yes` and `System clock synchronized: no`.

4. **Set the correct time in the BIOS** (or from whichever OS boots first), and both systems should then read it identically.

This way, the BIOS becomes your "single source of truth" for time, and both OSes interpret it the same way.

--------------------

User prompt 3 of 6 - 4/26/2026, 1:09:17 PM:
sudo timedatectl set-ntp true : flips it back on again?

Claude Haiku 4.5:
**Yes, exactly.** Running **`sudo timedatectl set-ntp true`** will flip NTP back on and re-enable automatic time synchronization.

So if you want to keep NTP disabled and rely solely on your BIOS clock, just don't run that command. You only need to run it if you later decide you want automatic time syncing again.

To check the current state anytime, just run:
```
timedatectl
```

And look for the line `NTP service:` — it will show either **active** or **inactive**.

--------------------

User prompt 4 of 6 - 4/26/2026, 11:10:41 AM:
Always the curve balls ... : wah@:~$ sudo timedatectl set-ntp false
[sudo] password for wah:
wah@:~$ timedatectl
               Local time: Sun 2026-04-26 13:09:38 CEST
           Universal time: Sun 2026-04-26 11:09:38 UTC
                 RTC time: Sun 2026-04-26 11:09:38
                Time zone: Europe/Amsterdam (CEST, +0200)
System clock synchronized: yes
              NTP service: inactive
          RTC in local TZ: no
wah@:~$ sudo timedatectl set-local-rtc 1 --adjust-system-clock
wah@:~$ timedatectl
               Local time: Sun 2026-04-26 11:09:52 CEST
           Universal time: Sun 2026-04-26 09:09:52 UTC
                 RTC time: Sun 2026-04-26 11:09:52
                Time zone: Europe/Amsterdam (CEST, +0200)
System clock synchronized: no
              NTP service: inactive
          RTC in local TZ: yes

Warning: The system is configured to read the RTC time in the local time zone.
         This mode cannot be fully supported. It will create various problems
         with time zone changes and daylight saving time adjustments. The RTC
         time is never updated, it relies on external facilities to maintain it.
         If at all possible, use RTC in UTC by calling
         'timedatectl set-local-rtc 0'.

Claude Haiku 4.5:
Interesting! You've hit the **warning that systemd developers built in** — they really don't like this configuration. But here's the important thing to understand:

## What Actually Happened

Look at your time output carefully:

**Before:**
- RTC time: 11:09:38 (UTC)
- Local time: 13:09:38 CEST (UTC + 2 hours)

**After:**
- RTC time: 11:09:52 (now in local time)
- Local time: 11:09:52 CEST
- Universal time: 09:09:52 UTC

**The command worked** — your RTC is now storing local time (`RTC in local TZ: yes`). But notice the system clock **actually went backwards by 2 hours** because of what `--adjust-system-clock` did.

## Should You Be Concerned About the Warning?

The warning is **technically valid but doesn't apply to your use case**:

- **"Various problems with timezone changes"** — you won't change timezones, so this is irrelevant
- **"Daylight saving time adjustments"** — Pop!_OS uses `systemd-timesyncd` to handle DST, but since you disabled NTP, you'll need to **manually adjust your system clock when DST changes** (March and October in Europe). This is a real limitation but manageable.
- **"RTC is never updated"** — this is exactly what you want! Your BIOS clock becomes the reference, not some internet service.

## The Real Question

Does your **Windows 10 now show the correct time** when you boot into it? If yes, then you're good — the warning is just systemd's way of saying "we don't recommend this" (which is fair for most users, but doesn't matter for your isolated dual-boot setup).

--------------------

User prompt 5 of 6 - 4/26/2026, 1:16:33 PM:
After fiddling in the gui of cosmic settings : wah@:~$ timedatectl
               Local time: Sun 2026-04-26 13:14:06 CEST
           Universal time: Sun 2026-04-26 11:14:06 UTC
                 RTC time: Sun 2026-04-26 13:14:06
                Time zone: Europe/Amsterdam (CEST, +0200)
System clock synchronized: yes
              NTP service: active
          RTC in local TZ: yes

Warning: The system is configured to read the RTC time in the local time zone.
         This mode cannot be fully supported. It will create various problems
         with time zone changes and daylight saving time adjustments. The RTC
         time is never updated, it relies on external facilities to maintain it.
         If at all possible, use RTC in UTC by calling
         'timedatectl set-local-rtc 0'. : it's in sync ... so just in case rollback : sudo timedatectl set-ntp true : then : timedatectl set-local-rtc 0 --adjust-system-clock : corrected version as you mentioned ?

Claude Haiku 4.5:
**Yes, that's the correct rollback sequence.** Running those two commands in that order will get you back to the standard UTC configuration:

1. **`sudo timedatectl set-ntp true`** — re-enables NTP so your system syncs with time servers
2. **`sudo timedatectl set-local-rtc 0 --adjust-system-clock`** — switches RTC back to UTC mode

After running both, you should see:
- `RTC in local TZ: no`
- `NTP service: active`
- `System clock synchronized: yes`
- The warning should disappear

That said, **your current setup is actually working now** — the COSMIC GUI reconnected NTP and synced everything to the correct time. The warning is still there because `RTC in local TZ: yes` is set, but since NTP is active, the system is continuously correcting any drift.

So you have two options:

1. **Keep it as is** — NTP keeps time accurate, RTC is in local time (works with Windows), warning is just noise in your case
2. **Roll back** — Go to pure UTC mode if you prefer a "clean" configuration without the warning

Either works. It depends whether you want the simplicity of "both OSes read RTC the same way" or you want the "approved" configuration with NTP handling everything. What are you leaning toward?

--------------------

User prompt 6 of 6 - 4/26/2026, 1:18:51 PM:
Oh no worries I'll keep it ... but I have to reboot to see if it sticks then I have to reboot to see what windows is doing (shouldn't be effected but hey ... ) and then I can rejoice and if not I have the rollback on the pocket ... the save as markdown of these conversations is heaven sent ...

Claude Haiku 4.5:
**Perfect approach.** You've got a solid plan:

1. Reboot Pop!_OS to confirm the settings stick
2. Reboot into Windows 10 to verify it's still showing the correct time
3. If all goes well, celebrate — you've got a working dual-boot time setup
4. If not, you've got the rollback commands right there in your markdown notes

The fact that you're saving these conversations is smart — having the exact commands and explanations in one place beats hunting through forums or System76 docs when you need them again. Plus, your specific configuration (separate drives, no internet on Windows) is unusual enough that having your own documented solution will be useful.

Good luck with the reboots! Hopefully you'll be back here saying "all working perfectly" rather than "executing rollback." 🤞