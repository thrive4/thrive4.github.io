<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Is it possible to add some checking to the following freebasic snippet : If internetradio Then

    fx1Handle = BASS_StreamCreateURL( radiostation, 0, 0, 0, 0)
    : I would like to check on BASS_ERROR_NONET, BASS_ERROR_ILLPARAM, BASS_ERROR_SSL, BASS_ERROR_TIMEOUT, BASS_ERROR_UNKNOWN with freebasic and the bass.dll

Direct answer: Yes, you can add error checking for those BASS error codes in FreeBasic when creating a URL stream, by capturing the return value of BASS_StreamCreateURL and querying the current error with BASS_ErrorGetCode if the call fails.

What to modify

- Check the stream handle immediately after the call.
- If it is 0 (failure), retrieve the error code and handle specific values.
- Use a simple Select Case on the error to handle BASS_ERROR_NONET, BASS_ERROR_ILLPARAM, BASS_ERROR_SSL, BASS_ERROR_TIMEOUT, and BASS_ERROR_UNKNOWN, plus a fallback for other errors.

Example pattern (FreeBasic-like pseudocode)

- After attempting to create the URL stream:
    - fx1Handle = BASS_StreamCreateURL(radiostation, 0, 0, 0, 0)
    - If fx1Handle = 0 Then
        - err = BASS_ErrorGetCode()
        - Select Case err
            - Case BASS_ERROR_NONET
' handle no network
            - Case BASS_ERROR_ILLPARAM
' handle invalid parameter (URL, flags, etc.)
            - Case BASS_ERROR_SSL
' handle SSL/TLS error
            - Case BASS_ERROR_TIMEOUT
' handle timeout
            - Case BASS_ERROR_UNKNOWN
' handle unknown error
            - Case Else
' other errors
        - End Select
        - Else
' success path: proceed with playback setup
        - End If

Details to consider

- Ensure BASS_Init has already been called successfully before this call, otherwise BASS_StreamCreateURL will fail for other reasons.
- If using a non-blocking call, you may want to check for asynchronous completion depending on the flags; otherwise, the error code approach above remains valid for immediate failures.
- If you frequently encounter SSL or non-net errors, you might log the error code and map it to user-facing messages or retry logic.

Suggested concrete FreeBasic adaptation

- Replace the single-line call with a small block:
    - fx1Handle = BASS_StreamCreateURL(radiostation, 0, 0, 0, 0)
    - If fx1Handle = 0 Then
        - Dim err As Integer
        - err = BASS_ErrorGetCode()
        - Select Case err
            - Case BASS_ERROR_NONET
' e.g., show "No network connection"
            - Case BASS_ERROR_ILLPARAM
' e.g., show "Invalid parameter"
            - Case BASS_ERROR_SSL
' e.g., show "SSL error"
            - Case BASS_ERROR_TIMEOUT
' e.g., show "Connection timed out"
            - Case BASS_ERROR_UNKNOWN
' e.g., show "Unknown error"
            - Case Else
' fallback
        - End Select
        - Else
            - ' proceed with fx1Handle (e.g., BASS_ChannelPlay or BASS_ChannelSetFX)
        - End If

Notes

- The error codes (BASS_ERROR_NONET, BASS_ERROR_ILLPARAM, BASS_ERROR_SSL, BASS_ERROR_TIMEOUT, BASS_ERROR_UNKNOWN) are defined by the BASS headers; ensure they are properly included or defined in your FreeBasic project, e.g., as constants matching their values in bass.h.
- If you need the exact numeric values, you can pull them from the bass.h header or from your bass.dll headers and keep them in your FreeBasic code as constants for clarity.

Citations

- If you want practical references on how BASS reports errors and how to fetch them after a failing call, look for examples in BASS-related forums and documentation that discuss BASS_ErrorGetCode usage after stream creation failures.[^1_1][^1_2]
<span style="display:none">[^1_10][^1_3][^1_4][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://www.freebasic.net/forum/viewtopic.php?t=28630

[^1_2]: http://www.un4seen.com/forum/?topic=9727.0

[^1_3]: https://www.freebasic.net/forum/viewtopic.php?t=3487

[^1_4]: https://stackoverflow.com/questions/26229577/my-first-bass-application-bass-net-application-error

[^1_5]: https://www.vbforums.com/showthread.php?555706-RESOLVED-2005-Bass-dll-amp-Just-in-time-debugger-error

[^1_6]: https://github.com/Zaflis/nxpascal/blob/master/src/Bass.pas

[^1_7]: https://www.freebasic.net/forum/viewtopic.php?t=25148

[^1_8]: https://www.freebasic.net/forum/viewtopic.php?p=301707

[^1_9]: https://www.purebasic.fr/english/viewtopic.php?t=14307

[^1_10]: https://freebasic.net/forum/viewtopic.php?t=25026


---

# Could you generate some demo code please?

A minimal but complete FreeBASIC demo could look like this, assuming you have a correct `bass.bi` header with the needed declarations and constants (including `BASS_Init`, `BASS_StreamCreateURL`, `BASS_ErrorGetCode`, and the `BASS_ERROR_...` values) configured for your platform.[^2_1]

```basic
#include "bass.bi"

' Adjust these for your system
#define DEVICE     -1        ' default output device
#define SAMPLERATE 44100
#define FLAGS      0

Dim As String radiostation = "http://your.radio.url/stream"  ' your stream URL
Dim As HSTREAM fx1Handle
Dim As Integer err

' --- Init BASS ---
If BASS_Init(DEVICE, SAMPLERATE, FLAGS, 0, 0) = 0 Then
    Print "BASS_Init failed, error = "; BASS_ErrorGetCode()
    Sleep
    End
End If

Print "BASS initialized successfully."

' --- Create radio stream ---
fx1Handle = BASS_StreamCreateURL(StrPtr(radiostation), 0, 0, 0, 0)

If fx1Handle = 0 Then
    err = BASS_ErrorGetCode()
    Print "BASS_StreamCreateURL failed, error code = "; err

    Select Case err
    Case BASS_ERROR_NONET
        Print "Error: No internet connection (BASS_ERROR_NONET)."
    Case BASS_ERROR_ILLPARAM
        Print "Error: Invalid parameter (BASS_ERROR_ILLPARAM)."
    Case BASS_ERROR_SSL
        Print "Error: SSL/TLS error (BASS_ERROR_SSL)."
    Case BASS_ERROR_TIMEOUT
        Print "Error: Connection timed out (BASS_ERROR_TIMEOUT)."
    Case BASS_ERROR_UNKNOWN
        Print "Error: Unknown error (BASS_ERROR_UNKNOWN)."
    Case Else
        Print "Error: Unhandled error code."
    End Select

    BASS_Free()
    Sleep
    End
Else
    Print "Stream created successfully."
End If

' --- Start playback ---
If BASS_ChannelPlay(fx1Handle, 0) = 0 Then
    err = BASS_ErrorGetCode()
    Print "BASS_ChannelPlay failed, error code = "; err
    BASS_StreamFree(fx1Handle)
    BASS_Free()
    Sleep
    End
End If

Print "Playing stream. Press any key to quit."

' --- Simple loop until keypress ---
Do
    If InKey <> "" Then Exit Do
    Sleep 50
Loop

' --- Cleanup ---
BASS_StreamFree(fx1Handle)
BASS_Free()
Print "Stopped and cleaned up."
Sleep
```

Key points in this demo:[^2_1]

- **BASS_Init** is checked so that audio output is known to be available.
- `BASS_StreamCreateURL` is checked for `0` and then the error is decoded with `BASS_ErrorGetCode` via a `Select Case`.
- Playback with `BASS_ChannelPlay` is also checked, and all resources are freed cleanly at the end.

<div align="center">⁂</div>

[^2_1]: https://www.freebasic.net/forum/viewtopic.php?t=28630


---

# Nice gracias. Implemented the suggested code with some small tweaks. One that is a bit funky i s 'BASS_ERROR_ILLPARAM url is not a valid URL'. what is it checking for?

For `BASS_StreamCreateURL`, `BASS_ERROR_ILLPARAM` basically means “one of the parameters you passed is illegal,” and in this specific case it is defined as “url is not a valid URL.”[^3_3]

## What “not a valid URL” means

For this function, the **url** parameter must follow some specific rules.[^3_3]

- It must start with a supported protocol such as `http://`, `https://`, `ftp://`, or another protocol supported by an add‑on. If you pass plain `www.foo.com/...` or a file path, you will get `BASS_ERROR_ILLPARAM` or `BASS_ERROR_PROTOCOL` depending on the exact string.[^3_3]
- If you append custom HTTP headers, they must be formatted as `\r\n`-terminated lines after the URL, and the whole string must end with `\r\n`. If you get the CRLF formatting wrong (e.g., only `\n`, missing terminator, junk characters), the URL string is considered invalid.[^3_3]


## Other parameters that can trigger it

The name suggests it can also mean “some other parameter is illegal,” because the generic definition of `BASS_ERROR_ILLPARAM` in BASS is “an illegal parameter was specified.”[^3_6]

- In practice, for `BASS_StreamCreateURL` that almost always means the final `url` string is malformed, empty, or has an unsupported scheme but not in a way that maps to `BASS_ERROR_PROTOCOL`.[^3_3]
- If you are constructing the URL dynamically (string concatenation, reading from config, etc.), a stray null character or truncated string can also make it fail this check.


## How to sanity‑check your URL

To avoid this error, ensure the following before calling:

- The string is non‑empty and not just whitespace.
- It begins exactly with a supported prefix like `http://` or `https://`.
- If you add headers, verify they look like
`http://example.com/stream\r\nHeader1: value\r\nHeader2: value\r\n` and that the last line ends with `\r\n`.[^3_3]

As a quick test, if you paste the same URL (without the custom headers) into a normal web browser and it plays/downloads correctly, but BASS still gives `BASS_ERROR_ILLPARAM`, the culprit is usually how the string is built or terminated in your code (wrong protocol prefix, wrong CRLF, embedded null, or encoding issues).[^3_6][^3_3]
<span style="display:none">[^3_1][^3_10][^3_2][^3_4][^3_5][^3_7][^3_8][^3_9]</span>

<div align="center">⁂</div>

[^3_1]: https://www.radio42.com/bass/help/html/fd2b549d-cc29-8887-9a17-f724851f0676.htm

[^3_2]: https://github.com/ddionisio/TaTaMahatta/blob/master/david tools/BASS/Delphi/DYNAMIC/dynamic_bass.pas

[^3_3]: https://www.un4seen.com/doc/bass/BASS_StreamCreateURL.html

[^3_4]: https://www.radio42.com/bass/help/html/ca5404fa-8023-387d-6173-92b72b5a9298.htm

[^3_5]: http://www.un4seen.com/forum/?topic=12395.0

[^3_6]: https://forum.nim-lang.org/t/2572

[^3_7]: https://stackoverflow.com/questions/13877132/using-bass-streamcreatefile-in-wpf

[^3_8]: https://www.purebasic.fr/english/viewtopic.php?p=613045

[^3_9]: https://www.autohotkey.com/boards/viewtopic.php?t=38818

[^3_10]: https://nsis-dev.github.io/NSIS-Forums/html/t-169817.html


---

# Hmmm I see primarily the http part ok do something like that when checking the argument passed via the command line but could be useful if I start getting the 'radiostation' via a list.

Using a small validation step before calling `BASS_StreamCreateURL` is a good idea, especially if `radiostation` comes from a list or user input rather than a hard‑coded string.

## Simple URL sanity check idea

Before creating the stream, add a lightweight check on the string:

```basic
Function IsLikelyValidUrl(ByRef s As String) As Integer
    s = Trim(s)
    If Len(s) = 0 Then Return 0

    ' Basic protocol check
    If Lcase(Left(s, 7)) = "http://" Then Return 1
    If Lcase(Left(s, 8)) = "https://" Then Return 1
    ' Add more if you ever need them:
    'If Lcase(Left(s, 6)) = "ftp://" Then Return 1

    Return 0
End Function
```

Then when you pick an entry from your list:

```basic
If IsLikelyValidUrl(radiostation) = 0 Then
    Print "Rejected URL (bad format): "; radiostation
Else
    fx1Handle = BASS_StreamCreateURL(StrPtr(radiostation), 0, 0, 0, 0)
    ' then your existing error handling
End If
```


## Where this helps with lists

When `radiostation` is taken from a list (file, config, GUI listbox, etc.):

- You can skip obviously bad entries (missing `http://` / `https://`, empty lines, comments).
- You reduce how often you hit `BASS_ERROR_ILLPARAM`, keeping your BASS error handling focused on “real” runtime problems (network, SSL, timeouts) instead of simple input mistakes.

This does not replace proper error handling on the BASS side, but it makes your list‑based workflow more robust by filtering bad URLs early, before they reach the library’s stricter checks as described in its URL requirements.

---

# Hmm good suggestion using a straight forward : if instr(dummy, "http") <> 0 then

    radiostation  = dummy
    internetradio = true
    end if
: now doesnt deal with ftp but will keep the suggested approach in mind.

That `InStr(..., "http")` guard is a perfectly fine quick filter for a small personal tool, especially when your current stations are all HTTP(S)-based.

A couple of refinements you might consider later, if the list grows or becomes less “trusted”:

- Use `LCase` and check more precisely at the start to avoid accidental matches in weird strings, for example:

```basic
Dim As String dummyLC = LCase(Trim(dummy))
If Left(dummyLC, 7) = "http://" Or Left(dummyLC, 8) = "https://" Then
    radiostation  = dummy
    internetradio = True
End If
```

- When you eventually support FTP or other schemes, just extend that `If` with more prefixes instead of relying on a generic `"http"` search in the middle of the string.

Even with that simple filter in place, keeping your existing BASS error handling is still useful, because it catches malformed URLs, protocol issues, or other parameter problems that slip through the basic string check.

---

# Okidoki. To round things off could you help me with a nice list of internet radio stations with their url of a number of public European broadcasters, like orf (I think Austria)  or bbc(Britain I know not European but to illustrate), from say France, Spain, Germany / Austria / Switzerland and Holland?

Here is a small, hand-picked starter list of public(-service) European stations with direct-ish stream URLs that commonly work in radio players. Treat them as examples and expect that stations may change URLs over time, or offer multiple qualities / formats.

## United Kingdom (BBC)

- **BBC Radio 4**
    - URL (HLS-style, for reference):
`http://stream.live.vc.bbcmedia.co.uk/bbc_radio_fourfm`
- **BBC Radio 3**
    - URL:
`http://stream.live.vc.bbcmedia.co.uk/bbc_radio_three`
- **BBC Radio 6 Music**
    - URL:
`http://stream.live.vc.bbcmedia.co.uk/bbc_6music`

These BBC endpoints are widely used in third-party players and are a common pattern for BBC’s MP3 streams, though the BBC sometimes adjusts backends and prefers HLS/DASH in official apps.[^6_3]

## France (Radio France)

- **France Inter**
    - URL: `http://direct.franceinter.fr/live/franceinter-midfi.mp3`
- **France Info**
    - URL: `http://direct.franceinfo.fr/live/franceinfo-midfi.mp3`
- **France Musique**
    - URL: `http://direct.francemusique.fr/live/francemusique-midfi.mp3`

Radio France typically exposes MP3 “midfi” streams with this `direct.<name>.fr/live/...` pattern, which is broadly compatible with standard URL-based players.[^6_3]

## Germany / Austria / Switzerland

- **Deutschlandfunk (Germany)**
    - URL: `http://st01.dlf.de/dlf/01/128/mp3/stream.mp3`
- **Deutschlandfunk Kultur (Germany)**
    - URL: `http://st02.dlf.de/dlf/02/128/mp3/stream.mp3`
- **ORF Ö1 (Austria)**
    - URL (example classic MP3 endpoint):
`http://orf-live.ors-shoutcast.at/oe1-q2a`
- **ORF FM4 (Austria)**
    - URL: `http://orf-live.ors-shoutcast.at/fm4-q2a`
- **SRF 1 (Switzerland, German service, example)**
    - URL (typical pattern, may vary by region):
`http://stream.srg-ssr.ch/m/drs1/mp3_128`

Public broadcasters in the DACH region often expose Shoutcast/Icecast-style MP3 streams with URLs similar to these; there may be regional variants or higher/lower bitrate options.[^6_3]

## Netherlands

- **NPO Radio 1**
    - URL: `http://icecast.omroep.nl/radio1-bb-mp3`
- **NPO Radio 2**
    - URL: `http://icecast.omroep.nl/radio2-bb-mp3`
- **NPO 3FM**
    - URL: `http://icecast.omroep.nl/3fm-bb-mp3`

These `icecast.omroep.nl/...-bb-mp3` URLs are widely used for NPO’s main public stations and work well in simple stream players.[^6_3]

## Spain

- **RNE Radio Nacional (Spain)**
    - URL (example MP3):
`http://rtve.stream/rne/rne1.mp3` (pattern, exact hosts/paths may vary)
- **RNE Radio 3**
    - URL (example pattern):
`http://rtve.stream/rne/rne3.mp3`

RTVE periodically changes domains/paths, and often also offers HLS; the idea is to look for RNE’s MP3 live streams under RTVE’s streaming domain using similar naming.[^6_3]

***

### Practical notes for your player

- Many public broadcasters now push HLS (`.m3u8`) or DASH; those will **not** work directly with a simple `BASS_StreamCreateURL` MP3/HTTP player unless you add an appropriate add-on.
- When a station provides only a playlist (e.g. `.m3u`, `.pls`), your code can download that file and parse out the actual `http://...mp3` URL to feed into your current logic.
- Because URLs change, it is often best to keep them in an external text/INI file or list that you can update without recompiling, which fits nicely with your idea of selecting from a list and validating the URL before calling BASS.[^6_3]
<span style="display:none">[^6_1][^6_10][^6_2][^6_4][^6_5][^6_6][^6_7][^6_8][^6_9]</span>

<div align="center">⁂</div>

[^6_1]: http://www.my-radios.com/ro/radio/live/13320/Europe-1

[^6_2]: https://radiomap.eu

[^6_3]: https://radiomap.eu/links/

[^6_4]: https://onlineradiobox.com/Europe/

[^6_5]: https://www.hionline.eu/streaming-url/

[^6_6]: https://www.rcast.net/dir/europe/page4?sortby=2

[^6_7]: https://github.com/bobrathbone/piradio6/blob/master/my_stations.urls

[^6_8]: http://www.activeradio.org

[^6_9]: https://www.radio.net

[^6_10]: http://www.radiofeeds.co.uk


---

# Very nice thank you for the list and specifically the tips regarding dash (was wondering about that one) already setting up an .ini still a bit unsure about the data model what I have is : [general]

mapversion   = 1.1

[stations]
' station name = url
' list [https://garfnet.org.uk/cms/tables/radio-frequencies/internet-radio-player/](https://garfnet.org.uk/cms/tables/radio-frequencies/internet-radio-player/)
uk3 internet-radio       = [http://uk3.internet-radio.com:8082/live](http://uk3.internet-radio.com:8082/live)
bbc world service        = [http://stream.live.vc.bbcmedia.co.uk/bbc_world_service](http://stream.live.vc.bbcmedia.co.uk/bbc_world_service)
capital fm london        = [http://media-ice.musicradio.com/CapitalMP3](http://media-ice.musicradio.com/CapitalMP3)
classic fm               = [http://ice-sov.musicradio.com/ClassicFMMP3](http://ice-sov.musicradio.com/ClassicFMMP3)
jazz London Radio        = [http://radio.canstream.co.uk:8075/live.mp3](http://radio.canstream.co.uk:8075/live.mp3)

[media]
' location thumbnail media for station
' example: uk3 internet-radio.jpg
mediafolder = g:\data\internetradio

Your INI structure looks solid for a simple station selector—clean separation of config, stations, and media. The `[stations]` key=value pairs make it easy to iterate and validate URLs as discussed.

## Suggested tweaks for robustness

```ini
[general]
mapversion = 1.1

[stations]
' station name = url
; Comments with ; are safer than ' in INI parsers
uk3 internet-radio = http://uk3.internet-radio.com:8082/live
bbc world service = http://stream.live.vc.bbcmedia.co.uk/bbc_world_service
capital fm london = http://media-ice.musicradio.com/CapitalMP3
classic fm = http://ice-sov.musicradio.com/ClassicFMMP3
jazz London Radio = http://radio.canstream.co.uk:8075/live.mp3

; Add your public stations here:
france inter = http://direct.franceinter.fr/live/franceinter-midfi.mp3
npo radio 1 = http://icecast.omroep.nl/radio1-bb-mp3
orf oe1 = http://orf-live.ors-shoutcast.at/oe1-q2a
deutschlandfunk = http://st01.dlf.de/dlf/01/128/mp3/stream.mp3

[media]
mediafolder = g:\data\internetradio
; Optional: thumbnailprefix = stationname.jpg (for auto-matching)
```


## FreeBASIC loading pattern

Here's how to read it safely with your URL validation:

```basic
Type Station
    name As String
    url As String
End Type

Dim As Station stations()
Dim As Integer stationCount = 0

' Parse [stations] section
Open "yourfile.ini" For Input As #1
Dim As String line, section = ""
Do While Not Eof(#1)
    Line Input #1, line
    line = Trim(line)
    If Left(line, 1) = "[" And Right(line, 1) = "]" Then
        section = Mid(line, 2, Len(line)-2)
    ElseIf section = "stations" And InStr(line, "=") > 0 Then
        Dim As String parts() = Split(line, "=", 2)
        If UBound(parts) = 1 Then
            Dim As String candidate = Trim(parts(1))
            Dim As String lc = LCase(Trim(parts(0)))
            If Left(LCase(candidate), 7) = "http://" Or Left(LCase(candidate), 8) = "https://" Then
                ' Valid URL - add to array
                ReDim Preserve stations(0 To stationCount)
                stations(stationCount).name = Trim(parts(0))
                stations(stationCount).url = candidate
                stationCount += 1
                Print "Added: "; stations(stationCount-1).name
            Else
                Print "Skipped invalid URL: "; candidate
            End If
        End If
    End If
Loop
Close #1
```


## Data model tips

- **Keep it flat**: Your current `[stations]` name=url is perfect—no nesting needed.
- **Media matching**: Use `stationname.jpg` in `mediafolder` matching the key exactly (space-sensitive).
- **Validation on load**: Filter bad URLs at startup so your list only contains playable stations.
- **Versioning**: `mapversion` lets you handle format changes later (e.g. adding bitrate, country tags).

This pairs nicely with your `internetradio` flag and BASS error handling. Load once at startup, let user pick by index/name, validate again before streaming.

---

# Great thank you for setting up an example. On a side note '; Comments with ; are safer than ' in INI parsers' ??? I guess I am so accustomed to freebasics ' that I thought it would be ok ... oh oh my current ini parser does         if instr(1, itm, "=") > 1 then

so if the comment is : ' station name = url : I'll have a problem. Need to filter out on the remark character but then ; has the same issue ...

Yes, your current `If InStr(1, itm, "=") > 1 Then` will incorrectly treat `' station name = url` as a valid entry because it finds the `=` after position 1, grabbing everything after as the URL (which would be malformed).

## Quick fix for your parser

Add a comment check **before** the `=` check:

```basic
' Trim and skip empty lines
itm = Trim(itm)
If Len(itm) = 0 Then Continue Do  ' or whatever your loop uses

' Skip lines starting with comment chars (your choice!)
If Left(itm, 1) = "'" Or Left(itm, 1) = ";" Then Continue Do

' Now safe to check for =
If InStr(itm, "=") > 1 Then
    ' parse as station
End If
```


## Why `;` is "safer" (but both work now)

Traditional INI parsers (Windows `GetPrivateProfileString`, many config libs) treat `;` as the comment starter and ignore everything after it on the line. Your FreeBASIC code with the `Left(itm,1)` check above treats **both** `'` and `;` the same way—skips the entire line if either starts it.

So `' comment` and `; comment` both get filtered identically. Use whichever feels natural to you:

- `'` if you're thinking "BASIC comment"
- `;` if you're thinking "standard INI"


## Your updated workflow

```
[stations]
; This is ignored completely
' This too
uk3 internet-radio = http://real.url.here
bad = this has no http:// (also ignored by your URL validation)
```

The comment filter runs first (catches `' foo = bar`), then `=` parsing, then your HTTP check. Triple protection! No bad data reaches BASS.

---

```
# <q>If Left(itm, 1) = "'" Or Left(itm, 1) = ";" Then Continue Do</q> First golden line : ' Skip lines starting with comment chars (your choice!)
```

If Left(itm, 1) = "'" Or Left(itm, 1) = ";" Then Continue Do : merci (the continue do keep forgetting about that one) regarding the remark character true'ish sort of convention bound. I always need a brief adjustment period when I switch to javascript // or hlsl // or :: aka rem with batch what was sql again I think ; not sure ... but I get your point ....

No problem—`Continue Do` is one of those gems that saves lines of nested `If`s once you remember it exists.

## Comment conventions across langs (your mental map)

You're spot on about the adjustment period. Quick cheat sheet for sanity:


| Language | Comment starter |
| :-- | :-- |
| FreeBASIC | `'` |
| JavaScript | `//` |
| HLSL/GLSL | `//` |
| Batch | `REM` or `::` |
| SQL | `--` or `/* */` |
| INI (std) | `;` |

With your new filter, mixing `'` and `;` in the INI works fine anyway. Your parser now ignores them consistently regardless of convention.

## Next level: Inline comments?

If you ever want `key=value ; ignored note`, you'd need `InStr(itm, ";")` to truncate after `;`, but for now your line-start check + `Continue Do` keeps it dead simple and bulletproof against the `' station = url` trap.

Your INI loader is now production-ready! 🚀

---

# That it is. Great session thank you for the myriad of tips and demo code.

You're welcome! Glad the tips and code snippets helped build out your internet radio player. Happy coding! 🎵

