<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# 'ComfyUI/custom_nodes/ComfyUI_LocalLLMNodes/ = the installed custom node pack itself.' and prey do tell what that is where I can get it ...

It’s a GitHub repo for a ComfyUI custom node pack, and in this case the one I referenced is the project at **ComfyUI_LocalLLMNodes**. It is the actual extension code you install into `custom_nodes`, not just a placeholder folder.[^1_7]

## What it is

A ComfyUI custom node pack is basically a plugin: it adds new nodes, logic, and dependencies that ComfyUI itself does not ship with. For `ComfyUI_LocalLLMNodes`, the project description says it is meant to run local LLMs inside ComfyUI workflows for prompt generation.[^1_7]

## Where to get it

You can get it from the project’s GitHub repository here: [ComfyUI_LocalLLMNodes](https://github.com/kmlbdh/ComfyUI_LocalLLMNodes). The usual install pattern for ComfyUI custom nodes is to clone the repo into `ComfyUI/custom_nodes/` and then restart ComfyUI so it loads the new nodes.[^1_1][^1_5][^1_7]

## What goes inside

The folder `ComfyUI/custom_nodes/ComfyUI_LocalLLMNodes/` should contain the repository files, not be empty. That means the Python code, node definitions, and any install metadata live there; an empty folder would do nothing.[^1_5][^1_7]

## Practical install shape

The typical layout looks like this:

```text
ComfyUI/
  custom_nodes/
    ComfyUI_LocalLLMNodes/
  models/
    LLM/
      qwen2.5-7b-instruct.gguf
```

That is the standard pattern for ComfyUI custom nodes: put the extension in `custom_nodes`, put the model file where the extension expects it, and restart ComfyUI.[^1_1][^1_7]

## One caution

Custom nodes are often installed by cloning the repo, then installing whatever dependencies the repo asks for, usually from its README or requirements file. Some guides also note that if you use ComfyUI Manager, it can automate a lot of this, but the underlying idea is still the same: the repo itself is the thing you install.[^1_10][^1_5][^1_1]

Would you like the next step to be a **minimal “install and verify” checklist** for this exact repo on Windows or Linux?
<span style="display:none">[^1_2][^1_3][^1_4][^1_6][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://www.reddit.com/r/comfyui/comments/1rjwn6s/how_to_install_custom_nodes_from_github_in_the/

[^1_2]: https://www.youtube.com/watch?v=67h87oHQPn8

[^1_3]: https://www.reddit.com/r/comfyui/comments/1ja1al3/how_do_i_install_these_custom_nodes_i_do_not_see/

[^1_4]: https://www.youtube.com/watch?v=shqvA638zz0

[^1_5]: https://www.reddit.com/r/comfyui/comments/1and6s9/installing_nodes_but_without_the_manager/

[^1_6]: https://www.youtube.com/watch?v=pi5DftmRhB4\&vl=en

[^1_7]: https://github.com/kmlbdh/ComfyUI_LocalLLMNodes

[^1_8]: https://www.comfydeploy.com/blog/how-to-install-private-custom-nodes

[^1_9]: https://extra-ordinary.tv/2025/07/26/taming-comfyui-custom-nodes-version-hell/

[^1_10]: https://github.com/Comfy-Org/ComfyUI-Manager


---

# NArghh ... 'CMAKE_ARGS="-DGGML_CUDA=on" pip install llama-cpp-python --force-reinstall --no-cache-dir

'  ok : [https://github.com/abetlen/llama-cpp-python/releases](https://github.com/abetlen/llama-cpp-python/releases) : 400MB boom ... right and where does it go ... somewhere around here ? wah@:/media/wah/media/ai/comfyv182/python_embeded\$ ls -d */
Include/  Lib/  Scripts/  share/

Yes — that `pip install` does **not** drop a big standalone app into one obvious folder. It installs Python package files into the **ComfyUI embedded Python environment**, which in your case is that `python_embeded` directory you showed.[^2_2][^2_9]

## Where it goes

For a ComfyUI portable install, package files usually end up inside:

```text
ComfyUI/
  python_embeded/
    Lib/
      site-packages/
```

That is where `llama-cpp-python` and its compiled extension files will live after installation. The `Include/`, `Lib/`, `Scripts/`, and `share/` folders you listed are exactly the shape you’d expect for the embedded Python environment, and `site-packages` is the normal destination for installed Python modules.[^2_3][^2_9]

## What to expect

So the 400MB you saw is mostly:

- the source/build cache during compilation,
- the installed Python package,
- the compiled native extension,
- and possibly cached build artifacts if they are not cleaned immediately.[^2_9][^2_3]

It is not something you manually place into `custom_nodes` or `models`. It is installed into the Python environment that ComfyUI is using.[^2_2][^2_9]

## How to verify

You can check the installation by looking in something like:

```text
ComfyUI/python_embeded/Lib/site-packages/
```

and searching for:

- `llama_cpp`
- `llama_cpp_python`
- a compiled `.pyd` file on Windows or `.so` file on Linux
- package metadata folders like `llama_cpp_python-*.dist-info`[^2_3][^2_9]


## Important distinction

`ComfyUI/custom_nodes/ComfyUI_LocalLLMNodes/` is the **node pack** itself, while `llama-cpp-python` is a **Python dependency** that the node pack can use. So the repo goes in `custom_nodes`, but the CUDA-enabled Python package goes into the embedded Python environment.[^2_11][^2_9]

## Practical consequence

That means the installation flow is basically:

1. Put the custom node repo in `custom_nodes`.
2. Install `llama-cpp-python` into the same Python environment ComfyUI uses.
3. Put your GGUF model file in the folder the node pack expects.
4. Restart ComfyUI.[^2_9][^2_11]

One caution: GPU-enabled builds depend on your CUDA toolchain and driver compatibility, and `llama-cpp-python` installs often need a rebuild with the CUDA flags set so the package actually uses the GPU.[^2_1][^2_7][^2_2]

Would you like a **Windows/Linux command sequence** for confirming exactly where ComfyUI’s embedded Python is installing packages?
<span style="display:none">[^2_10][^2_4][^2_5][^2_6][^2_8]</span>

<div align="center">⁂</div>

[^2_1]: https://www.reddit.com/r/LocalLLaMA/comments/1evdnz1/how_to_enable_cudasupport_for_llamacpppython/

[^2_2]: https://github.com/abetlen/llama-cpp-python/discussions/1691

[^2_3]: https://github.com/abetlen/llama-cpp-python/issues/1963

[^2_4]: https://huggingface.co/dougeeai/llama-cpp-python-wheels

[^2_5]: https://medium.com/@manishkovelamudi/install-llama-cpp-python-with-gpu-support-7ccf421c069d

[^2_6]: https://medium.com/@eddieoffermann/llama-cpp-python-with-cuda-support-on-windows-11-51a4dd295b25

[^2_7]: https://github.com/abetlen/llama-cpp-python/issues/250

[^2_8]: https://github.com/ggml-org/llama.cpp/blob/master/docs/build.md

[^2_9]: https://pypi.org/project/llama-cpp-python/

[^2_10]: https://stackoverflow.com/questions/76963311/llama-cpp-python-not-using-nvidia-gpu-cuda

[^2_11]: https://github.com/kmlbdh/ComfyUI_LocalLLMNodes


---

# Merci for offering but I'll break it down to : everything from here (source.zip) : [https://github.com/kmlbdh/ComfyUI_LocalLLMNodes](https://github.com/kmlbdh/ComfyUI_LocalLLMNodes) : goes in into ComfyUI/custom_nodes/ComfyUI_LocalLLMNodes/ and the cracked open .whl (content) goes in to ComfyUI/

python_embeded/
Lib/
site-packages/<folder> ... as ever it's actually [llama_cpp_python-0.3.26-py3-none-win_amd64.whl](https://github.com/abetlen/llama-cpp-python/releases/download/v0.3.26-vulkan/llama_cpp_python-0.3.26-py3-none-win_amd64.whl)
sha256:bbedfd304a4d6c668944fb8affb950101e5ed4d16c6c827723143090a1ec5e42

44.4 MB 16 hours ago previous one was raedon (wrong file) but download is taking for ever because github is traffic shapping to > 100KB ... just love this shit ..

Yes — that is the right division of labor. The **custom node repo** goes in `ComfyUI/custom_nodes/ComfyUI_LocalLLMNodes/`, and the **wheel** for `llama-cpp-python` is installed into ComfyUI’s embedded Python environment, not copied into `custom_nodes`.[^3_1][^3_2][^3_3]

## Correct split

- `ComfyUI/custom_nodes/ComfyUI_LocalLLMNodes/` = the node pack source code.
- `ComfyUI/python_embeded/Lib/site-packages/` = where the installed Python package ends up.
- `qwen2.5-7b-instruct.gguf` or `llama3.1-8b-instruct.gguf` = your model file.[^3_3][^3_4][^3_1]


## About the wheel

That `llama_cpp_python-0.3.26-py3-none-win_amd64.whl` is indeed the dependency you install into the embedded Python, and once installed it becomes available as a normal Python package. The wheel itself is not something ComfyUI “loads” as a model; it is just the runtime library the node pack calls.[^3_4][^3_1]

## What gets installed where

If you run the install command from the ComfyUI embedded Python, the package files should land under something like:

```text
ComfyUI/python_embeded/Lib/site-packages/
```

and you can expect package folders such as `llama_cpp` plus metadata files for the install. That matches the usual embedded-Python layout used by portable ComfyUI builds.[^3_1][^3_4]

## About the download pain

Yes, GitHub release downloads can be painfully slow at times, but the important bit is to install the **correct wheel for your platform and CUDA setup**. The llama-cpp-python project and community install notes both emphasize matching the wheel to your environment rather than dropping files into random ComfyUI folders.[^3_5][^3_6][^3_4]

## Your setup in plain terms

For your current goal, think of it like this:

1. Clone or unzip `ComfyUI_LocalLLMNodes` into `custom_nodes`.
2. Install `llama-cpp-python` into ComfyUI’s embedded Python.
3. Put the GGUF model in the folder the node pack expects.
4. Restart ComfyUI and test the node.[^3_3][^3_1]

That’s the cleanest path, and your mental model is now correct. The repo is the plugin, the wheel is the runtime, and the GGUF file is the model.[^3_4][^3_3]

Would you like me to give you a **single exact install command** for your embedded Python path and a **sanity-check command** to confirm `llama_cpp` imports correctly?
<span style="display:none">[^3_10][^3_11][^3_12][^3_13][^3_7][^3_8][^3_9]</span>

<div align="center">⁂</div>

[^3_1]: https://github.com/ceruleandeep/ComfyUI-LLaVA-Captioner/issues/1

[^3_2]: https://www.reddit.com/r/comfyui/comments/1rp4lcj/llama_cpp_node_issue/

[^3_3]: https://github.com/kmlbdh/ComfyUI_LocalLLMNodes

[^3_4]: https://pypi.org/project/llama-cpp-python/

[^3_5]: https://huggingface.co/dougeeai/llama-cpp-python-wheels

[^3_6]: https://github.com/abetlen/llama-cpp-python/discussions/1691

[^3_7]: https://comfy.icu/extension/daniel-lewis-ab__ComfyUI-Llama

[^3_8]: https://comfy.icu/extension/sebagallo__comfyui-sg-llama-cpp

[^3_9]: https://www.youtube.com/watch?v=6HJfR8xkkec

[^3_10]: https://github.com/abetlen/llama-cpp-python/issues/1538

[^3_11]: https://www.youtube.com/watch?v=u96UP0GHDGE

[^3_12]: https://www.reddit.com/r/comfyui/comments/1j3z43v/trying_to_install_llama_cpp_losing_my_mind_please/

[^3_13]: https://www.kaggle.com/code/melindaweathers/installing-running-llama-cpp-python

