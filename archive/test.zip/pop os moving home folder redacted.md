<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# I am / was using the following step by step guide when I hit a brick wall with renaming the old /home to /home.old ... could you take a look I might have overlooked some things in writing the guide ...: \#\# move /home to other partition

assumes the excistence of an existing ext4 partition
with sufficent free space 64GB and up.

show mountpoints:
wah@:~\$ lsblk
NAME        MAJ:MIN RM   SIZE RO TYPE MOUNTPOINTS
sda           8:0    0 894.3G  0 disk
├─sda1        8:1    0   100M  0 part
├─sda2        8:2    0    16M  0 part
├─sda3        8:3    0    32G  0 part
├─sda4        8:4    0 861.6G  0 part
└─sda5        8:5    0   530M  0 part
sdb           8:16   0 465.8G  0 disk
├─sdb1        8:17   0     1G  0 part /boot/efi
├─sdb2        8:18   0  63.2G  0 part /
└─sdb3        8:19   0 401.5G  0 part
sdc           8:32   0 931.5G  0 disk
└─sdc1        8:33   0 931.5G  0 part
zram0       251:0    0  15.4G  0 disk [SWAP]
nvme0n1     259:0    0   1.9T  0 disk
├─nvme0n1p1 259:1    0 128.9G  0 part /mnt/recycle
└─nvme0n1p2 259:2    0   1.7T  0 part

create new mountpoint /home:
sudo mkdir -p /mnt/nvme_home
sudo mount /dev/nvme0n1p1 /mnt/nvme_home

copy existing /home to new /home:
sudo rsync -av /home/ /mnt/nvme_home/home/

verify by size:
sudo du -sh /home
sudo du -sh /mnt/nvme_home/home/
both should have the same disk usage size

get uuid:
wah@:~\$ sudo blkid /dev/nvme0n1p1
[sudo] password for wah:
/dev/nvme0n1p1: LABEL="recycle" UUID="31c512db-de02-46fb-a793-7cf730695fb4" BLOCK_SIZE="4096" TYPE="ext4" PARTLABEL="recycle" PARTUUID="d6ec80cd-beb8-4483-a622-491154be80e3"

make backup of fstab:
cp fstab fstab.o

change fstab:
sudo nano /etc/fstab
add /alter:
UUID=31c512db-de02-46fb-a793-7cf730695fb4 /mnt/recycle ext4 nosuid,nodev,nofail,x-gvfs-show 0 0
UUID=31c512db-de02-46fb-a793-7cf730695fb4 /home ext4 defaults,nofail 0 2

example before:

# /etc/fstab: static file system information.

# 

# Use 'blkid' to print the universally unique identifier for a

# device; this may be used with UUID= as a more robust way to name devices

# that works even if disks are added and removed. See fstab(5).

# 

# <file system>  <mount point>  <type>  <options>  <dump>  <pass>

PARTUUID=02ef159f-8d79-4b9f-b317-d9ae096c1d9e  /boot/efi  vfat  umask=0077  0  0
UUID=be659851-6b22-4953-b742-e28fcd0dc038  /  ext4  noatime,errors=remount-ro  0  1
/dev/disk/by-partlabel/recycle /mnt/recycle ext4 nosuid,nodev,nofail,x-gvfs-show 0 0

example after:

# /etc/fstab: static file system information.

# 

# Use 'blkid' to print the universally unique identifier for a

# device; this may be used with UUID= as a more robust way to name devices

# that works even if disks are added and removed. See fstab(5).

# 

# <file system>  <mount point>  <type>  <options>  <dump>  <pass>

PARTUUID=02ef159f-8d79-4b9f-b317-d9ae096c1d9e  /boot/efi  vfat  umask=0077  0  0
UUID=be659851-6b22-4953-b742-e28fcd0dc038 /  ext4  noatime,errors=remount-ro  0  1
UUID=31c512db-de02-46fb-a793-7cf730695fb4 /mnt/recycle ext4 nosuid,nodev,nofail,x-gvfs-show 0 0
UUID=31c512db-de02-46fb-a793-7cf730695fb4 /home ext4 defaults,nofail 0 2

verify fstab:
sudo mount -a
note no errors should occure
otherwise revert from fstab.o

This is where it goes wrong
rename can not take place /home is in use
rename old home and reboot:
sudo mv /home /home.old
sudo reboot

after reboot verify with:
mount | grep /home
mount | grep recycle
ls -la /home
You should see both mounted from /dev/nvme0n1p1.

cleanup after some days:
or monitor with:
sudo journalctl -xe | tail -50
mount | grep home
keep tabs for 30 minutes ...
then:
sudo rm -rf /home.old
:

You're trying to move /home to a new partition and hit a brick wall when renaming /home to /home.old because /home is in use. That’s the common sticking point. Here’s a concise review of potential issues in your guide and a safer, clearer workflow you can follow.

What I’d tighten or fix in the guide

- Mount order and existing mounts:
    - The new target mountpoint should be mounted somewhere clean and stable (e.g., /mnt/nvme_home) and then copied. Your later fstab uses /home for the new mount with the same UUID, which is fine, but ensure there are no conflicting mounts (e.g., /home already mounted during the copy).
- Copy verification:
    - rsync -av already preserves attributes; add --progress or -P to monitor progress. Also consider --delete-during if you intend to keep source and target in sync until switch.
- fstab entries:
    - Your example shows a mix of /mnt/recycle and /home. After you mount /dev/nvme0n1p1 to /home, you don’t also want to mount it at /mnt/recycle unless that’s a separate mount. If you want both, you need distinct filesystems or a bind/mount approach. The two lines in fstab should be:
        - UUID=31c512db-de02-46fb-a793-7cf730695fb4 /home ext4 defaults,nofail 0 2
        - UUID=31c512db-de02-46fb-a793-7cf730695fb4 /mnt/recycle ext4 nosuid,nodev,nofail,x-gvfs-show 0 0
    - Make sure the UUID used in fstab matches the actual UUID of the device you intend to mount at /home.
- Rename while in use:
    - Yes, you can’t mv /home while it’s in active use (e.g., by the login session). The usual safe path is to boot from a live USB (or another initramfs) so /home isn’t mounted, then rename and mount. If you’re not using a live environment, you can boot into single-user mode or turn off services that mount /home, but in practice a live environment is simplest.
- Reboot steps:
    - mv /home /home.old while unmounted is fine; after reboot you want /home mounted from the new filesystem. If /home is still mounted during the mv, you’ll get the “busy” error.
- Recovery path:
    - If something goes wrong, having a clean backup of /home (or a recent rsync) before attempting the swap is wise. Also keep a copy of fstab before editing (you did with fstab.o).

A clean, safer workflow you can follow

1) Prepare the new partition

- Confirm the new partition is an ext4 filesystem with enough space (64 GB+ as you noted).
- Create a stable mount point for the copy, e.g.:
    - sudo mkdir -p /mnt/nvme_home

2) Copy data off /home

- If users are logged in, do this from a live environment or single-user mode to ensure /home is not in use.
- Copy data:
    - sudo rsync -aAXv --progress /home/ /mnt/nvme_home/
        - -A preserves ACLs, -X preserves extended attributes; adjust flags as needed for your system.

3) Update fstab (planned switch)

- Get the UUID of the new filesystem:
    - sudo blkid /dev/nvme0n1p1
- Edit /etc/fstab so that /home points to the new device:
    - UUID=<your-new-uuid> /home ext4 defaults,nofail 0 2
- If you also want /mnt/recycle to be a separate mount, include a separate entry for that mount point (distinct UUID and mountpoint).

4) Ensure nothing else is mounting /home

- Before changing mounts, ensure no processes are using /home:
    - sudo lsof +D /home | wc -l
    - or reboot into a rescue/live environment to be safe.

5) Switch to the new /home

- If you are in a live environment:
    - sudo umount /home  (if any)
    - sudo mv /home /home.old  (optional, for rollback)
    - sudo mkdir -p /home
    - sudo mount -a
- If you’re not in a live environment, you’d reboot into rescue/single-user mode to unmount /home, then perform the mv and mount steps.

6) Verify

- After boot or mounting, verify:
    - mount | grep /home should show the new device mounted on /home
    - df -h /home shows the correct filesystem
    - ls -la /home should show your data

7) Rollback plan

- If /home fails to mount, revert the fstab change and reboot, then restore from /home.old or from your rsync backup.

8) Post-move cleanup

- Only delete /home.old after you’ve confirmed the new /home is healthy and in use.
- Keep a small monitor for a while (journalctl -xe, mount status) to catch any misbehaving services locking files.

A compact checklist you can paste into your guide

- Ensure you can boot into a environment where /home is not mounted (live USB or single-user).
- Copy /home to a new ext4 partition via rsync with ACLs and xattrs preserved.
- Update /etc/fstab to mount the new partition at /home using the new UUID.
- Unmount or boot in a way that /home is not in use, then swap: mv /home /home.old; mount -a (or reboot).
- Verify with mount, df, and ls; keep /home.old until you’re sure.
- Clean up after a safety window (e.g., 24–72 hours) or after confirming stability.

Would you like me to tailor this into a concise, step-by-step script you can run from a live USB, with exact commands and a rollback checklist for your environment in Amsterdam? If you share the exact device names you want to use for the new /home and any constraints (e.g., separate /home for root vs non-root users), I can produce a ready-to-run script.

