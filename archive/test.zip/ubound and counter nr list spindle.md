<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# There is a slight snag with the following code specifically :     print "current nr     " \& currentitem \& " of " \& maxitemslist

: since currentitem is the idx nr in the array ... what would be a good way to tally up or down the current nr from 1,  2,  3 etc ? freebasic code : \#include "vbcompat.bi"

' setup playlist
type lrec
as string  listfile(any)
as string  listtype(any)
as integer listseqh(any)
end type
dim shared    listrec as lrec
common shared listnr  as integer
listnr = 0

' generate list of files recursive
' based on recursive dir code of coderjeff [https://www.freebasic.net/forum/viewtopic.php?t=5758](https://www.freebasic.net/forum/viewtopic.php?t=5758)
function createlist(folder as string, filterext as string, listname as string) as integer
' setup filelist
dim chk            as boolean
redim path(1 to 1) As string
dim as integer i = 1, n = 1, attrib
dim file           as string
dim fileext        as string
dim maxfiles       as integer

    #ifdef __FB_LINUX__
      const pathchar = "/"
    #else
      const pathchar = "\"
    #endif
    
    if chdir(folder) <> 0 then
        'logentry("warning", "path " + chkpath + " not found")
        'chdir(dummy)
        print folder + " " + "not found"
        return 0
    end if
    
    ' read dir recursive starting directory
    path(1) = folder 
    if( right(path(1), 1) <> pathchar) then
        file = dir(path(1), fbNormal or fbDirectory, @attrib)
        if( attrib and fbDirectory ) then
            path(1) += pathchar
        end if
    end if
    
    while i <= n
    file = dir(path(i) + "*" , fbNormal or fbDirectory, @attrib)
        while file > ""
            if (attrib and fbDirectory) then
                if file <> "." and file <> ".." then
                    ' todo evaluate limit recursive if starting folder is root
                    if len(path(1)) > 3 then
                        n += 1
                        redim preserve path(1 to n)
                        path(n) = path(i) + file + pathchar
                    else
                        'logentry("terminate", "scanning from root dir not supported! " + path(i))
                    end if
                end if
            else
                fileext = lcase(mid(file, instrrev(file, ".")))
                if instr(1, filterext, fileext) > 0 and len(fileext) > 3 then 
                    listnr += 1
                    redim preserve listrec.listfile(0 to listnr)
                    redim preserve listrec.listtype(0 to listnr)
                    redim preserve listrec.listseqh(0 to listnr)
                    listrec.listfile(listnr)  = path(i) & file
                    listrec.listtype(listnr) = listname
                    listrec.listseqh(listnr) = 0
                    maxfiles += 1
                else
    '                    logentry("warning", "file format not supported - " + path(i) \& file)
end if
end if
file = dir(@attrib)
wend
i += 1
wend

    ' chk if filelist is created
    '    if FileExists(filelist) = false then
'        logentry("warning", "could not create filelist: " + filelist)
'    end if

    return maxfiles
    end function

function getcurrentlistitem(listtype as string, filename as string) as integer
dim itemnr as integer = -1

    for i as integer = 0 to listnr
        with listrec
            itemnr += 1
            if listrec.listtype(i) = listtype and listrec.listfile(i) = filename then
                'print listrec.listfile(i)
                'print listrec.listtype(i)
                'print listrec.listseqh(i)
                exit for
            end if
        end with
    next i
    
    return itemnr
    end function

function getmaxitemslist(listtype as string) as integer
dim itemnr as integer = 0

    for i as integer = 0 to listnr
        with listrec
            if listrec.listtype(i) = listtype then
                itemnr += 1
            end if
        end with
    next i
    
    return itemnr
    end function

sub setsequence(currentitem as integer)
dim as string lt = listrec.listtype(currentitem)
dim as integer maxseq = 0
' get highest sequence number for listtype
for i as integer = 0 to listnr
if listrec.listtype(i) = lt then
if listrec.listseqh(i) > maxseq then
maxseq = listrec.listseqh(i)
end if
end if
next
listrec.listseqh(currentitem) = maxseq + 1
end sub

sub clearseq(listtype as string)
for i as integer = 0 to listnr
if listrec.listtype(i) = listtype then
listrec.listseqh(i) = 0
end if
next
end sub

function listshuffle(listtype as string) as integer
dim as integer candidates(0 to listnr)
dim as integer count = 0
dim as integer selected = -1
dim as integer i

    ' unplayed items (listseqh = 0)
    for i = 0 to listnr
        if listrec.listtype(i) = listtype and listrec.listseqh(i) = 0 then
            candidates(count) = i
            count += 1
        end if
    next
    
    ' reset sequences listtype
    if count = 0 then
        for i = 0 to listnr
            if listrec.listtype(i) = listtype then
                listrec.listseqh(i) = 0
            end if
        next
        ' rebuild list
        count = 0
        for i = 0 to listnr
            if listrec.listtype(i) = listtype and listrec.listseqh(i) = 0 then
                candidates(count) = i
                count += 1
            end if
        next
    end if
    
    ' get unplayed item
    if count > 0 then
        dim as integer rndidx = int(rnd * count)
        selected = candidates(rndidx)
    end if
    
    return selected
    end function

function listnext(listtype as string, playtype as string, currentitem as integer) as integer
dim as integer nextidx = -1
dim as integer i

    if lcase(playtype) = "shuffle" then
        return listshuffle(listtype)
    end if
    ' linear
    for i = currentitem + 1 to listnr
        if listrec.listtype(i) = listtype then
            nextidx = i
            exit for
        end if
    next
    ' wrap to first of same type
    if nextidx = -1 then
        for i = 0 to listnr
            if listrec.listtype(i) = listtype then
                nextidx = i
                exit for
            end if
        next
    end if
    
    return nextidx
    end function

function listprevious(listtype as string, playtype as string, currentitem as integer) as integer
dim as integer i, previdx = -1

    if lcase(playtype) = "shuffle" then
        dim as integer currseq = listrec.listseqh(currentitem)
        dim as integer maxseq = 0
        dim as integer targetseq = 0
    
        ' get maximum sequence (for wrap)
        for i = 0 to listnr
            if listrec.listtype(i) = listtype then
                if listrec.listseqh(i) > maxseq then maxseq = listrec.listseqh(i)
            end if
        next
        targetseq = currseq - 1
        if targetseq < 1 then targetseq = maxseq
        for i = 0 to listnr
            if listrec.listtype(i) = listtype and listrec.listseqh(i) = targetseq then
                previdx = i
                exit for
            end if
        next
    
        return previdx
    end if
    
    ' linear
    for i = currentitem - 1 to 0 step -1
        if listrec.listtype(i) = listtype then
            return i
        end if
    next
    ' wrap
    for i = listnr to 0 step -1
        if listrec.listtype(i) = listtype then
            return i
        end if
    next
    
    return -1
    end function

dim media        as string
dim currentitem  as integer
dim maxitemslist as integer
dim playtype     as string
dim listtype     as string

print "music "; createlist("g:\data\mp3\wild child", ".mp3", "music")
print "image "; createlist("g:\data\images\classical paintings", ".jpg", "image")
print "slide "; createlist("g:\data\images\flickr\winter mixed", ".jpg", "slide")
print "video "; createlist("g:\data\aerialtv", ".mp4", "video")
print "shade "; createlist("f:\osd\media\glsl", ".gls", "shade")
print
print "total "; listnr
print

playtype = "linear"
listtype = "slide"

'init playback get first item
currentitem = listnext(listtype, playtype, 0)
setsequence(currentitem)
if lcase(playtype) = "linear" then
clearseq(listtype)
end if
maxitemslist = getmaxitemslist(listtype)
Do
Dim As String key = UCase(Inkey)
Select Case key
Case "."
' play next mp3
currentitem = listnext(listtype, playtype, currentitem)
if playtype = "shuffle" then
setsequence(currentitem)
end if
cls
Case ","
' play previous mp3
currentitem = listprevious(listtype, playtype, currentitem)
cls
Case Chr(27)
Exit Do
end select

    ' ascii interface
    Locate 10, 1
    Print "| list demonstration"
    print listtype + " selected " & listrec.listfile(currentitem)
    print "current nr     " & currentitem & " of " & maxitemslist
    print "sequence       " & listrec.listseqh(currentitem)
    print
    sleep(5)
    loop

end

Good question — what’s happening here is that in your output line:

```basic
print "current nr     " & currentitem & " of " & maxitemslist
```

…the variable `currentitem` holds the **array index**, not the **human-readable item number**. In FreeBASIC (as in most BASIC dialects), array indices start at **0**, so you’re seeing `0`, `1`, `2` where you probably want to display `1`, `2`, `3`.

### Simple fix

If you just want to show a 1-based count, the easiest solution is:

```basic
print "current nr     " & (currentitem + 1) & " of " & maxitemslist
```

That way, your display is user-friendly (`1 of 10` instead of `0 of 10`).

### Optional: handle list subsets

If your list contains multiple `listtype` entries (e.g., “music”, “image”, “slide”) mixed in the same array and you want the **position within the current listtype only**, you can compute it dynamically:

```basic
dim as integer displayedIndex = 0
for i as integer = 0 to currentitem
    if listrec.listtype(i) = listtype then displayedIndex += 1
next i
print "current nr     " & displayedIndex & " of " & maxitemslist
```

This ensures that if your array looks like:


| Index | listtype | Filename |
| :-- | :-- | :-- |
| 0 | music | a.mp3 |
| 1 | music | b.mp3 |
| 2 | image | pic1.jpg |
| 3 | music | c.mp3 |

…then `displayedIndex` correctly shows `1`, `2`, or `3` when playing a “music” item, ignoring unrelated entries.

Either approach works; the first is a quick display fix, while the second is more robust if your array mixes content types.

Would you like me to adjust the print logic in your loop to reflect the second (type-aware) version?

---

# Thank you for offering but no. Went for 'Optional: handle list subsets' works nicely thank you. On a more abstract note I'm a bit unsure about using common shared listnr  as integer

listnr = 0
all though seemingly more practical then doing arrarylen(listrec()) quite number in the code I am wondering if it might be more safer (array bound wise) to use arraylen instead of the counter in createlist() ?

That’s a great and very thoughtful question — you’re absolutely right to consider the **safety vs. convenience** trade-off here.

Let’s unpack what’s happening in your current design:

***

### Current approach — manual counter (`listnr`)

Using

```basic
COMMON SHARED listnr AS INTEGER
listnr = 0
```

and increasing `listnr` manually in `createlist()` gives you **explicit control** over how many items exist globally across all types and lists. Every place that adds an item updates `listnr` and then uses it to `REDIM PRESERVE` arrays and to control iteration.

However, this design assumes you *always* keep `listnr` perfectly synchronized with the actual array size. If any function forgets to increment or misuses `listnr`, your code can easily step outside the valid array bounds. That’s the main risk.

Example of what could go wrong:

```basic
listnr += 1
listrec.listfile(listnr) = somevalue ' <-- bounds error if array not grown first
```

So yes, the safety concern you’re hinting at is valid — it’s a manual invariant that must always line up.

***

### Alternative — using `UBOUND()` or `ARRAYLEN`

FreeBASIC lets you query the current array bounds dynamically. For example:

```basic
dim count as integer = ubound(listrec.listfile)
```

`UBOUND()` (or `LBOUND` for the lower bound) reflects the *actual allocated bounds*, so you can eliminate the need for a separate counter in most loops.

Then instead of:

```basic
for i = 0 to listnr
```

you can do:

```basic
for i = lbound(listrec.listfile) to ubound(listrec.listfile)
```

That’s **safer** because it always matches real memory allocation — you can’t accidentally overrun. But it’s slightly less efficient if you call it repeatedly in tight loops, since it queries the descriptor each time (though in practice, the performance difference is minimal and acceptable for most applications).

***

### A middle-ground approach

You can use both for clarity:

- Keep `listnr` as a logical *count* of list items.
- Use `UBOUND()` occasionally to validate that `listnr` matches the real array size or to perform safe loops if you’re unsure.

For instance:

```basic
if listnr <> ubound(listrec.listfile) then
    print "Warning: listnr out of sync with array size!"
end if
```

This helps detect rare logic errors while keeping your main code simple and fast.

***

### Bottom line

- **Manual counter (`listnr`)** → convenient, fast, but fragile if not carefully managed.
- **Dynamic bound query (`UBOUND`)** → safer, self-correcting, and the more “robust” modern approach.
- If you refactor later, you could make `listnr` a *getter function* that returns `UBOUND(listrec.listfile)` so you retain syntax familiarity but add safety:

```basic
function getListNr() as integer
    return ubound(listrec.listfile)
end function
```


***

So: your instinct is correct — relying on `UBOUND()` reduces the risk of array-bound errors. Keeping `listnr` is fine as long as it’s tightly controlled, but if you expect the codebase to grow or multiple functions to modify the list, switching to dynamic bounds (or at least validating them) is the safer long-term move.

Would you like me to show how your current functions (`createlist`, `listnext`, etc.) would look if rewritten to use `UBOUND()` instead of `listnr`?

---

# First good suggestion ubound() is more suitable in this case. Again appreciate the offer but I'll do a search and replace when needed. Just sounding and your response confirms worry did do a check through the code base and listnr is pretty isolated but yeah in the long run it could get tricky specially those cases where the app just crashes due to an out of bounds which can be quite a chore to debug in later stage ...

Exactly — that’s a really good instinct. Those subtle out‑of‑bounds issues tend to hide until you add one more feature months later, and then the app crashes without a clear trace. Especially in FreeBASIC, where the runtime doesn’t always provide detailed error diagnostics for array violations, it can turn into a real debugging time sink.

Your idea to eventually replace `listnr` with `UBOUND()` when you refactor is the right path. For now, keeping `listnr` isolated and consistent is already a strong defensive move — you’ve basically limited the “blast radius,” so even if something slips, it won’t propagate far.

A small tip that helps catch those boundary errors early: sprinkle in temporary checks like

```basic
if listnr <> ubound(listrec.listfile) then
    print "Warning: array size mismatch!"
end if
```

in debug builds. It gives you a low‑cost safety net before releasing or adding new features.

You’ve struck a good balance: build pragmatically now, but leave yourself an easy migration path toward `UBOUND()` later. That’s seasoned programming judgment right there.

Would you like a quick pattern for adding lightweight debug guards that you can toggle on and off (so you can detect these mismatches without cluttering production code)?

---

# Nope I am good for now. Would like to thank you for the displayidx tip and some food for thought regarding applying ubound.

You’re very welcome — glad those tips were useful! Sounds like you’ve got a solid handle on both the practical and long‑term sides of the design. The combination of the `displayidx` refinement and the eventual move toward `UBOUND()` will make your codebase both cleaner and more resilient.

If you ever revisit this project and start modularizing or adding media‑type‑specific logic, that groundwork will pay off immediately.

Happy coding — and may your debug sessions stay calm and uneventful!

