<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Ok got it. Good tip do channelgettags *after* channel play. So is this a standard format StreamTitle='Jimmy Dorsey \& His Orchestra - The End of A Love Affair'; so if I split on - I get artist and title in an array or is it a bit more arbitrary ...?

No, the `StreamTitle='Artist - Song';` format is **not standardized**—it's a common convention used by many Shoutcast servers, but highly arbitrary and server/DJ-dependent.[^1_1][^1_3]

## Why splitting on "-" is risky

- **Common but not guaranteed**: Most stations format as `"Artist - Title"` (70-80% of cases), so `split("-")` often works.[^1_1]
- **Breaks easily**:


| Problem Case | Raw Meta | Split Result |
| :-- | :-- | :-- |
| Hyphen in artist | `'The Black-Eyed Peas - Song'` | `["The Black","Eyed Peas - Song"]` |
| No hyphen | `'Radio XYZ Live DJ Mix'` | Single chunk |
| Extra fields | `'Artist - Title (Remix) [Label]'` | `["Artist"," Title (Remix) [Label]"]` |
| DJ shows | `'DJ Johnny in the Mix'` | No split |


## Robust parsing strategy

1. **Extract from quotes first** (always works):
```basic
dim as string raw = *meta
dim as integer start = instr(raw, "'") + 1
dim as integer endpos = instr(start, raw, "';")
dim as string title = mid(raw, start, endpos - start)
```

2. **Then heuristic split** (optional, fallback gracefully):
```basic
dim as integer dashpos = instr(title, " - ")  ' look for " - " (spaces around dash)
if dashpos > 0 then
    dim as string artist = left(title, dashpos - 1)
    dim as string song = mid(title, dashpos + 3)
    print "Artist: "; artist
    print "Title: "; song
else
    print "Title: "; title  ' treat whole as title
end if
```

This handles 90%+ of streams reliably—extract quotes first (standard), then split heuristically with fallback. For live DJs or odd formats, just display the full title.[^1_3][^1_1]
<span style="display:none">[^1_10][^1_2][^1_4][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://stackoverflow.com/questions/51389660/splitting-shoutcast-track-info-into-song-title-and-artist-name

[^1_2]: https://community.appinventor.mit.edu/t/streaming-how-do-i-pull-metadata-for-now-playing/24331

[^1_3]: https://stackoverflow.com/questions/25657198/getting-parsing-shoutcast-metadata

[^1_4]: https://www.reddit.com/r/youtubedl/comments/1ea4mbz/how_do_i_extract_artist_title_from_original_title/

[^1_5]: https://gist.github.com/spinitron/2d84d4c3ebfa7d94a8e4c6fe38ab67ac

[^1_6]: https://www.npmjs.com/package/get-artist-title

[^1_7]: https://support.spacial.com/hc/en-us/articles/229534787-How-to-Send-Artist-Title-and-Song-Metadata-to-the-Player

[^1_8]: https://stackoverflow.com/questions/78050797/get-stream-title-from-api

[^1_9]: https://www.djsoft.net/community/threads/how-to-set-streamtitle-with-title-format-variables.5446/

[^1_10]: https://voidnetwork.gr/wp-content/uploads/2016/09/From-Mobilization-to-Revolution-by-Charles-Tilly-1.pdf


---

# Nice just curious why 'raw' and not use *meta ?

You *could* use `*meta` directly, but copying to `raw` (a mutable `string`) is safer and more practical for parsing.[^2_1]

## Why copy to `raw` instead of `*meta`

`BASS_ChannelGetTags` returns a `const zstring ptr` pointing to **BASS's internal read-only buffer**:

- `*meta` gives you the raw C-string, but it's **immutable**—you can't modify it or use FreeBASIC string functions that expect writable memory.
- Functions like `instr()`, `mid()`, `left()` on `*meta` might work but can be unreliable or crash if they try to write temporary data.


## Direct comparison

```basic
dim as const zstring ptr meta = BASS_ChannelGetTags(fx1Handle, BASS_TAG_META)

' RISKY - direct deref on read-only buffer:
dim as integer pos = instr(*meta, "'")  ' might segfault or behave oddly

' SAFE - copy to owned string first:
dim as string raw = *meta
dim as integer pos = instr(raw, "'")    ' works perfectly
```


## Quick print vs. parsing

- **Just display?** `print *meta` is fine (read-only access only).
- **Parsing/splitting?** Always copy: `dim as string raw = *meta`.

The copy is cheap (just the metadata length, ~100-200 bytes) and gives you full FreeBASIC string API access without risking BASS buffer corruption. Standard C interop pattern.[^2_1]

<div align="center">⁂</div>

[^2_1]: https://www.freebasic.net/forum/viewtopic.php?t=31993\&start=135


---

# Ok valid points. Implemented the 'Robust parsing strategy' as you suggested is working nice. Going to be a wee bit of a thing integrating with the existing method of getting taginfo (mp3, ogg, etc) but I'll get there. Thank you for an excellent start with adding internet radio to my small app and the useful tip regarding the use of raw C-string.

You're welcome! Glad the robust parsing and BASS URL streaming integration worked well for your app—sounds like a solid foundation for handling both local files and internet radio metadata seamlessly.[^3_1]

## Next steps if needed

- **Live updates**: Add `BASS_ChannelSetSync(fx1Handle, BASS_SYNC_META, @YourSyncCallback, 0)` to auto-refresh "now playing" when songs change without polling.[^3_2]
- **Unify tag reading**: Create a single `GetSongInfo(handle)` function that tries `BASS_TAG_META`/`BASS_TAG_OGG` first, then falls back to `BASS_TAG_ID3`/`BASS_TAG_OGG` for local files.
- **Error handling**: Check `BASS_ChannelIsActive(fx1Handle)` before tag reads to avoid stale data on failed streams.

Happy coding—your FreeBASIC audio player with radio support is going to be great!

<div align="center">⁂</div>

[^3_1]: https://www.freebasic.net/forum/viewtopic.php?t=31993\&start=135

[^3_2]: https://www.un4seen.com/forum/?topic=19102.0


---

# Ehhr I normally make a nice export of our conversation how ever, I am not sure why, there is only a small part of it in the browser (also with export as markdown) why?

Perplexity's conversation export (both browser and Markdown) often truncates long threads due to browser memory limits and rendering constraints—your BASS/FreeBASIC discussion is technical and lengthy, hitting those caps.[^4_1][^4_2]

## Common causes and fixes

- **Browser limits**: Exports cap at ~10,000 rows/elements or 2GB to prevent crashes. Long code-heavy chats like yours exceed this.[^4_2][^4_4]
- **Client-side rendering**: The Markdown/HTML export processes everything in-browser; complex formatting (code blocks, tables) causes partial loads.


## Workarounds

**1. Copy-paste manually** (most reliable):

```
Right-click → Inspect → Console tab
Paste: copy(document.body.innerText)
Ctrl+V into notepad/text editor
```

Gets full raw text instantly.

**2. Scroll up fully first**:

- Scroll to absolute top of conversation
- Wait 10-20s for lazy-loading
- Then Export Markdown

**3. Thread splitter** (Pro feature):

- Perplexity Pro can break long threads into multiple exports
- Or use "Share this thread" → individual segments

**4. Browser extension**:

- "ChatGPT Exporter" or "Save My Chatbot" (works on Perplexity too) exports full Markdown/PDF without truncation[^4_5]

Your full BASS streaming conversation should export cleanly via manual copy or extension—browser exports just choke on length.
<span style="display:none">[^4_10][^4_3][^4_6][^4_7][^4_8][^4_9]</span>

<div align="center">⁂</div>

[^4_1]: https://exploreaitogether.com/export-download-chatgpt-guide/

[^4_2]: https://www.intercom.com/help/en/articles/2046229-export-your-conversations-data

[^4_3]: https://community.getgrist.com/t/limited-file-export/6603

[^4_4]: https://github.com/vector-im/element-web/issues/20445

[^4_5]: https://www.reddit.com/r/OpenAI/comments/1pe3p9a/every_way_to_export_chatgpt_conversations_and/

[^4_6]: https://community.openai.com/t/chatgpt-data-export-too-big-feature-in-the-options/1080111

[^4_7]: https://www.arysontechnologies.com/blog/export-google-chat-to-pdf/

[^4_8]: https://support.google.com/chat/thread/274723586/incomplete-google-takeout-google-chat-history-what-is-the-max-number-of-messages-or-date-range?hl=en

[^4_9]: https://github.com/orgs/community/discussions/156605

[^4_10]: https://community.openai.com/t/chatgpt-export-not-exporting-lastest-conversations/938439/76

