<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Would it be possible to add a metric to the following freebasic function : function getdrivestorage(drive as string, metric as string) as ULongInt

    Dim As ULARGE_INTEGER freeBytesAvailable
    Dim As ULARGE_INTEGER totalNumberOfBytes
    Dim As ULARGE_INTEGER totalNumberOfFreeBytes
    If GetDiskFreeSpaceEx(drive, @freeBytesAvailable, @totalNumberOfBytes, @totalNumberOfFreeBytes) Then
        select case metric
            case "capacity"
                return totalNumberOfBytes.QuadPart
            case "space"
                return totalNumberOfFreeBytes.QuadPart
            case else
                return 0
        end select
    Else
    '    Print "Error: "; GetLastError()
        return 0
    End If
    end function
: in this case say 'percentage' which returns the percentage free space on the drive ?

Yes — you can add a `"percentage"` case, and it should compute free space as:

$$
\text{percentage} = \frac{\text{free bytes}}{\text{total bytes}} \times 100
$$

`GetDiskFreeSpaceEx` gives you both the total bytes and the free bytes, so the calculation is straightforward. It returns `lpTotalNumberOfFreeBytes` for total free space on the volume, and `lpTotalNumberOfBytes` for total size.[^1_1][^1_2]

## Updated function

Because a percentage is not a byte count, the return type should ideally be changed from `ULongInt` to something like `Double`. If you keep `ULongInt`, the result will be truncated to an integer.

```freebasic
function getdrivestorage(drive as string, metric as string) as Double
    dim as ULARGE_INTEGER freeBytesAvailable
    dim as ULARGE_INTEGER totalNumberOfBytes
    dim as ULARGE_INTEGER totalNumberOfFreeBytes

    if GetDiskFreeSpaceEx(drive, @freeBytesAvailable, @totalNumberOfBytes, @totalNumberOfFreeBytes) then
        select case metric
            case "capacity"
                return cdbl(totalNumberOfBytes.QuadPart)
            case "space"
                return cdbl(totalNumberOfFreeBytes.QuadPart)
            case "percentage"
                if totalNumberOfBytes.QuadPart > 0 then
                    return (cdbl(totalNumberOfFreeBytes.QuadPart) / cdbl(totalNumberOfBytes.QuadPart)) * 100.0
                else
                    return 0
                end if
            case else
                return 0
        end select
    end if

    return 0
end function
```


## If you want to keep `ULongInt`

You can still add `"percentage"`, but it will return only the whole-number part:

```freebasic
case "percentage"
    if totalNumberOfBytes.QuadPart > 0 then
        return culngint((cdbl(totalNumberOfFreeBytes.QuadPart) / cdbl(totalNumberOfBytes.QuadPart)) * 100.0)
    else
        return 0
    end if
```


## Recommendation

If the function is meant to return bytes for `"capacity"` and `"space"`, and a percent for `"percentage"`, the cleanest design is to make the function return `Double`. If you want, I can also show a version that returns an `Integer` percentage plus separate byte values without changing the existing function signature.[^1_3][^1_1]
<span style="display:none">[^1_10][^1_4][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://is.muni.cz/el/fi/jaro2010/PB169/um/getdiskfreespacee.pdf

[^1_2]: http://jeffpar.github.io/kbarchive/kb/202/Q202455/

[^1_3]: https://documentation.help/FreeBASIC/KeyPgUlongint.html

[^1_4]: https://stackoverflow.com/questions/31089998/convert-free-space-in-to-percentage-windows-c

[^1_5]: https://zetcode.com/freebasic/ulong-keyword/

[^1_6]: https://www.freebasic.net/forum/viewtopic.php?t=8981

[^1_7]: https://stackoverflow.com/questions/627131/getdiskfreespaceex-reports-wrong-number-of-free-bytes

[^1_8]: https://forums.codeguru.com/showthread.php?484225-GetDiskFreeSpaceEx-problem

[^1_9]: https://pub.dev/documentation/win32/latest/win32/GetDiskFreeSpaceEx.html

[^1_10]: https://freebasic.net/forum/viewtopic.php?t=23414

