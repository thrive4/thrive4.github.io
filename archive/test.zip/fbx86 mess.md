<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Hang on it broke (as fas as I can tell) after doing this : root@pop-os:/udev/fbcx86/bin\# sudo dpkg --add-architecture i386

root@pop-os:/udev/fbcx86/bin\# sudo apt update
root@pop-os:/udev/fbcx86/bin\# sudo apt install libc6-dev:i386 linux-libc-dev:i386 libncurses-dev:i386 libtinfo-dev:i386

verify:
root@pop-os:/udev/fbcx86/bin\# ls -l /usr/lib/i386-linux-gnu/libncurses.so* /usr/lib/i386-linux-gnu/libtinfo.so*

example output if ok:
-rw-r--r-- 1 root root     31 Apr  8  2024 /usr/lib/i386-linux-gnu/libncurses.so
lrwxrwxrwx 1 root root     17 Apr  8  2024 /usr/lib/i386-linux-gnu/libncurses.so.6 -> libncurses.so.6.4
-rw-r--r-- 1 root root 177464 Apr  8  2024 /usr/lib/i386-linux-gnu/libncurses.so.6.4
lrwxrwxrwx 1 root root     13 Apr  8  2024 /usr/lib/i386-linux-gnu/libtinfo.so -> libtinfo.so.6
lrwxrwxrwx 1 root root     15 Jan 17  2022 /usr/lib/i386-linux-gnu/libtinfo.so.5 -> libtinfo.so.5.9
-rw-r--r-- 1 root root 157936 Jan 17  2022 /usr/lib/i386-linux-gnu/libtinfo.so.5.9
lrwxrwxrwx 1 root root     15 Apr  8  2024 /usr/lib/i386-linux-gnu/libtinfo.so.6 -> libtinfo.so.6.4
-rw-r--r-- 1 root root 182420 Apr  8  2024 /usr/lib/i386-linux-gnu/libtinfo.so.6.4
:

Yes — the break point is very likely **not** the `dpkg --add-architecture i386` step by itself, but the **package transaction that followed**. Adding the foreign architecture is harmless; the risk starts when APT chooses, upgrades, removes, or leaves half-configured the libc-related packages needed by either the amd64 or i386 toolchain.[^1_1][^1_2]

## Step by step

### 1. Downloading the x86 tarball

This does not break x64. The `linux-x86` archive is simply the 32-bit FreeBASIC build, while `linux-x86_64` is the 64-bit build. They are separate toolchains, so the naming can be confusing, but extracting the x86 tarball should not alter system packages.[^1_3][^1_4][^1_5]

### 2. `dpkg --add-architecture i386`

This is normally safe. It just tells APT/dpkg that i386 packages are allowed alongside amd64 packages. By itself, it should not remove or damage the x64 FreeBASIC environment.[^1_2][^1_1]

### 3. `apt update`

Also safe. This only refreshes package metadata so APT can see i386 variants. It does not install or remove anything.[^1_1][^1_2]

### 4. `apt install libc6-dev:i386 linux-libc-dev:i386 libncurses-dev:i386 libtinfo-dev:i386`

This is the step most likely to trigger trouble. If your system already had partial libc/headers mismatches, this install can force upgrades, downgrades, or removals in the libc chain, and then the x64 compiler can lose its native startup objects or linker inputs.[^1_6][^1_1]

## What likely broke x64

The x64 tree needs the native amd64 development stack, especially `libc6-dev`, `linux-libc-dev`, `gcc`, `g++`, and `binutils`. If installing the i386 packages caused `linux-libc-dev` or `libc6-dev` on amd64 to become inconsistent or partially removed, the x64 FreeBASIC build would start failing with missing `crt1.o`, `crti.o`, `crtn.o`, or `-lc/-lm/-ldl/-lpthread`.[^1_7][^1_8]

## How to prevent it

Use a **two-phase check** instead of installing i386 packages blindly:

1. Confirm the x64 toolchain works first.
2. Check whether the exact i386 packages are available without forcing removal of amd64 libc packages.
3. Install only after confirming APT would not remove native libc development packages.[^1_2][^1_1]

A safe dry run is:

```bash
sudo apt -s install libc6-dev:i386 linux-libc-dev:i386 libncurses-dev:i386 libtinfo-dev:i386
```

If the simulation shows removals or major upgrades to `libc6-dev`, `libc6`, or `linux-libc-dev` on amd64, stop and resolve that before continuing.[^1_1][^1_2]

## How to mitigate if it happens

If x64 breaks after adding i386 support, repair the native side first:

```bash
sudo apt --fix-broken install
sudo apt install --reinstall libc6-dev linux-libc-dev build-essential binutils gcc g++
```

Then reinstall the i386 packages only if you still need them. That separates “restore x64” from “add x86.”[^1_8][^1_6][^1_7]

## The warning is separate

The `missing .note.GNU-stack section implies executable stack` warning from the x86 build is unrelated to the package breakage. It’s just a linker hardening warning and usually harmless unless you want to silence it with `-z noexecstack`.[^1_9][^1_10]

## The practical conclusion

The fragile part is not FreeBASIC itself, and not `dpkg --add-architecture i386`. The fragile part is the **APT resolution** of libc and header packages after you request the i386 development set.[^1_6][^1_1]

A good rule is: run `apt -s` first, and only proceed if it does not remove or downgrade the amd64 `libc6-dev`/`linux-libc-dev` stack.
<span style="display:none">[^1_11][^1_12]</span>

<div align="center">⁂</div>

[^1_1]: https://oneuptime.com/blog/post/2026-03-02-how-to-configure-apt-for-multiple-architecture-on-ubuntu/view

[^1_2]: https://wiki.ubuntu.com/MultiarchSpec

[^1_3]: https://www.freebasic.net/forum/viewtopic.php?t=16794

[^1_4]: https://documentation.help/FreeBASIC/CompilerInstalling.html

[^1_5]: https://www.freebasic.net/forum/viewtopic.php?t=26670

[^1_6]: https://github.com/rstudio/rstudio/issues/13542

[^1_7]: https://stackoverflow.com/questions/6329887/how-to-fix-linker-error-cannot-find-crt1-o

[^1_8]: https://oneuptime.com/blog/post/2026-01-15-configure-c-cpp-development-ubuntu/view

[^1_9]: https://github.com/llvm/llvm-project/issues/57009

[^1_10]: https://stackoverflow.com/questions/73435637/how-can-i-fix-usr-bin-ld-warning-trap-o-missing-note-gnu-stack-section-imp

[^1_11]: https://forums.developer.nvidia.com/t/missing-note-gnu-stack/339260

[^1_12]: https://ubuntu-mate.community/t/i386-architecture-install/28642

