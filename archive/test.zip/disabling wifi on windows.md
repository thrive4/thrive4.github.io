<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# does disabling 'connect automatically when this network is in range' persist after rebooting on windows 10?

Yes. When it works correctly, turning off “Connect automatically when this network is in range” for a given Wi‑Fi profile is saved in that profile and **should** persist across reboots in Windows 10.[^1_2][^1_6]

However, there are known cases where this setting does not stick (it turns itself back on or is ignored), often due to driver issues, group policy, or corrupted Wi‑Fi profiles. If you find it re‑enables after reboot, typical fixes include:[^1_3][^1_7][^1_9][^1_2]

- Deleting and re‑adding the Wi‑Fi network profile, then unchecking “Connect automatically”.[^1_1][^1_2]
- Updating or reinstalling your Wi‑Fi adapter driver.[^1_9]
- Checking for WLAN group policy or registry settings such as `fMinimizeConnections` that can override the behavior.[^1_3][^1_9]

So in design: yes, it should persist; if it doesn’t on your machine, you are running into one of these bugs or policy overrides rather than expected behavior.
<span style="display:none">[^1_10][^1_4][^1_5][^1_8]</span>

<div align="center">⁂</div>

[^1_1]: https://learn.microsoft.com/en-us/answers/questions/4284538/wifi-connects-automatically-on-start-up-windows-10

[^1_2]: https://learn.microsoft.com/en-us/answers/questions/de7697d7-3c21-4019-9d53-69742230c790/connect-automatically-when-in-range?forum=windows-all

[^1_3]: https://7thzero.com/blog/windows-10-disable-persistent-wifi-auto-connect

[^1_4]: https://www.youtube.com/watch?v=BWI6njh3RE4

[^1_5]: http://7thzero.com/blog/windows-10-disable-persistent-wifi-auto-connect

[^1_6]: https://learn.microsoft.com/en-us/answers/questions/3935030/how-do-i-stop-windows-11-from-automatically-connec

[^1_7]: https://learn.microsoft.com/en-us/answers/questions/3778133/connect-automatically-when-in-range-turns-itself-o

[^1_8]: https://www.elevenforum.com/t/automatically-connecting-wifi-does-not-automatically-connect.34000/

[^1_9]: https://learn.microsoft.com/en-us/answers/questions/3805205/win-10-wifi-connect-automatically-when-in-range-se

[^1_10]: https://stackoverflow.com/questions/48144475/auto-reconnect-vpn-on-disconnection-due-to-any-reason-persistent-vpn


---

# Sigh ... ok can the device driver of the wifi network device be disabled at boot automatically with a script or some other form?

Yes, you can effectively disable the Wi‑Fi device (or at least its network interface) automatically at boot using a script plus Task Scheduler or Group Policy.

### 1. Practical approach (recommended)

Instead of disabling the driver service itself (which is messy), disable the Wi‑Fi **adapter** at startup:

1. Find the adapter name: open an elevated Command Prompt and run
`netsh interface show interface`
Note the exact name of your Wi‑Fi interface (for example, `Wi-Fi`).
2. Create a small script, for example `DisableWifi.bat`:

```bat
@echo off
netsh interface set interface name="Wi-Fi" admin=disabled
```

Or PowerShell (`DisableWifi.ps1`):

```powershell
Disable-NetAdapter -Name "Wi-Fi" -Confirm:$false
```

3. In Task Scheduler, create a new task:
    - Trigger: “At startup” (or “At log on” if that’s enough)
    - Action: start `cmd.exe` with parameters `/c "C:\path\to\DisableWifi.bat"`
or `powershell.exe -ExecutionPolicy Bypass -File "C:\path\to\DisableWifi.ps1"`
    - Run with highest privileges.

Result: every boot, Windows comes up, then the task runs and disables the Wi‑Fi adapter so it cannot connect unless you manually re‑enable it.

### 2. Actually disabling the device in Device Manager

If you really want to toggle the device itself (as in Device Manager “Disable device”), you can:

- Use PowerShell with `Disable-NetAdapter` as above (this often appears the same as Device Manager disable in practice).
- Or use tools / WMI methods that call the adapter’s `Disable` method, wrapped in a script and again launched by Task Scheduler at startup.

This is more brittle (device names or IDs changing) but doable; in most cases the adapter-disable netsh/PowerShell route is enough to guarantee no Wi‑Fi until you explicitly turn it back on.
<span style="display:none">[^2_1][^2_10][^2_2][^2_3][^2_4][^2_5][^2_6][^2_7][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://umatechnology.org/how-to-disable-wifi-using-cmd-or-powershell-in-windows-11-10/

[^2_2]: https://www.youtube.com/watch?v=oMMR8V-jG1o

[^2_3]: https://learn.microsoft.com/en-us/answers/questions/3942503/windows-10-how-to-uninstall-and-reinstall-network

[^2_4]: https://answers.microsoft.com/en-us/windows/forum/all/windows-10-how-to-uninstall-and-reinstall-network/c57caa6c-c705-4db2-b95d-62e0e46fdcd2

[^2_5]: https://www.reddit.com/r/sysadmin/comments/2hsurt/disabling_wireless_adapter/

[^2_6]: https://www.action1.com/blog/how-to-disable-or-enable-network-adapter-in-windows/

[^2_7]: https://stackoverflow.com/questions/30467363/script-to-disable-enable-network-connection

[^2_8]: https://www.edugeek.net/forums/windows-10/223870-disable-drivers-using-gpo.html

[^2_9]: https://stackoverflow.com/questions/47530182/enabling-disabling-a-device-in-windows-10-from-command-line

[^2_10]: https://www.elevenforum.com/t/safely-disable-remove-a-driver-including-dependent-services.14036/


---

# does this : netsh interface set interface name="Wi-Fi" admin=disabled : work for windows 7?

Yes, that command syntax does work on Windows 7, with two small caveats:

- You must run it from an elevated (Run as administrator) command prompt.
- The name must match the interface’s actual name on that machine (on Windows 7 Wi‑Fi is often called `"Wireless Network Connection"` rather than `"Wi‑Fi"`).

So on Windows 7 it will typically look like:

```bat
netsh interface set interface name="Wireless Network Connection" admin=disabled
```

You can confirm the exact name first with:

```bat
netsh interface show interface
```

<span style="display:none">[^3_1][^3_2][^3_3][^3_4][^3_5][^3_6][^3_7][^3_8][^3_9]</span>

<div align="center">⁂</div>

[^3_1]: https://answers.microsoft.com/en-us/windows/forum/windows_7-hardware/enabledisable-network-interface-via-command-line/17a21634-c5dd-4038-bc0a-d739209f5081

[^3_2]: https://www.action1.com/blog/how-to-disable-or-enable-network-adapter-in-windows/

[^3_3]: https://www.youtube.com/watch?v=3isEmfVrJfg

[^3_4]: https://www.ninjaone.com/blog/enable-or-disable-network-adapters/

[^3_5]: https://stackoverflow.com/questions/19831023/enable-disable-network-connection-from-command-line

[^3_6]: https://learn.microsoft.com/en-us/answers/questions/2435369/enable-disable-network-interface-via-command-line

[^3_7]: https://www.tenforums.com/network-sharing/194428-using-shortcut-netsh-exe-disable-wifi-adapter-isnt-working.html

[^3_8]: https://www.youtube.com/watch?v=Mo2oKNktyI4

[^3_9]: https://www.youtube.com/watch?v=T376CfGy8BM


---

# So a compiled .au3 with : ;Run("C:\\sys\\nvidia inspector\\nvidiaInspector.exe -setBaseClockOffset:0,0,100 -setMemoryClockOffset:0,0,200 -setOverVoltage:0,0 -setPowerTarget:0,100 -setTempTarget:0,0,80")

Run("F:\\pulse\\launchbar\\RKLauncher.exe")
Sleep(3000)
ProcessSetPriority("RKLauncher.exe", 0)
: with say run("netsh interface set interface name="Wireless Network Connection" admin=disabled") should do the trick ?

Conceptually yes, but you need to fix quoting and elevation for it to work reliably.

### 1. Quoting inside AutoIt

In AutoIt, your line has nested double quotes, so you must escape the inner ones. For example:

```autoit
; Disable Wi‑Fi adapter
Run('netsh interface set interface name="Wireless Network Connection" admin=disabled', "", @SW_HIDE)
```

or with explicit escaping:

```autoit
Run("netsh interface set interface name=\"Wireless Network Connection\" admin=disabled", "", @SW_HIDE)
```

Key points:

- Use the actual interface name from `netsh interface show interface` (on Windows 7 usually `"Wireless Network Connection"`, not `"Wi-Fi"`).
- Use single quotes around the whole string or escape inner quotes.


### 2. Admin rights

`netsh interface set interface ... admin=disabled` requires admin rights. Your compiled `.exe` must be:

- Run as administrator manually, or
- Marked in its manifest to require elevation.

Without elevation, the command will fail silently or return “Access is denied”.

### 3. Putting it together with your existing script

Something like this:

```autoit
; Apply GPU settings
Run("C:\sys\nvidia inspector\nvidiaInspector.exe -setBaseClockOffset:0,0,100 -setMemoryClockOffset:0,0,200 -setOverVoltage:0,0 -setPowerTarget:0,100 -setTempTarget:0,0,80")

; Launch RKLauncher
Run("F:\pulse\launchbar\RKLauncher.exe")
Sleep(3000)
ProcessSetPriority("RKLauncher.exe", 0)

; Disable Wi‑Fi
Run('netsh interface set interface name="Wireless Network Connection" admin=disabled', "", @SW_HIDE)
```

If the exe runs elevated and the interface name is correct, this will indeed “do the trick”: your Wi‑Fi adapter will be disabled right after those other actions run.
<span style="display:none">[^4_1][^4_10][^4_2][^4_3][^4_4][^4_5][^4_6][^4_7][^4_8][^4_9]</span>

<div align="center">⁂</div>

[^4_1]: https://www.autohotkey.com/boards/viewtopic.php?t=36366

[^4_2]: https://www.autohotkey.com/boards/viewtopic.php?t=31869

[^4_3]: https://stackoverflow.com/questions/61918509/using-netsh-to-find-an-interface-name-and-define-it-as-a-variable-in-a-batch-fil

[^4_4]: https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/netsh-interface

[^4_5]: https://www.autohotkey.com/boards/viewtopic.php?t=81299

[^4_6]: https://www.reddit.com/r/gtaglitches/comments/fycrzs/psapc_you_can_pull_your_ethernet_cable_with_a/

[^4_7]: https://www.autohotkey.com/boards/viewtopic.php?t=111218

[^4_8]: http://forum.script-coding.com/viewtopic.php?id=7985

[^4_9]: https://learn.microsoft.com/ru-ru/windows-server/administration/windows-commands/netsh-interface

[^4_10]: http://forum.script-coding.com/viewtopic.php?id=8812


---

# Gracias especialy for the corrections to the .au3. On windows 10 adding to HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System\shell > DisableWifi.bat would work or will elevation be needed?

Glad the .au3 bits helped.

Short answer: putting `DisableWifi.bat` in that `shell` value is unlikely to work the way you want, because:

1. **That key is for replacing the shell, not just “run this script at logon.”**
`HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Policies\System\Shell` tells Windows what shell to start instead of Explorer, so if you point it at a BAT file you risk breaking your desktop session rather than just running a helper script.
2. **The `netsh interface set interface ... admin=disabled` command still requires elevation.**
Even if the BAT did run, it inherits the token of whatever process launches it. A normal user logon does not run elevated, so `netsh` will fail with “The requested operation requires elevation.” You cannot bypass UAC just by choosing a different registry startup location.
3. **What to use instead**

If you want this to run automatically and successfully:
    - Use **Task Scheduler**:
        - Create a task
        - Trigger: “At log on” (or “At startup”)
        - Action: run your `DisableWifi.bat`
        - Check “Run with highest privileges”.
    - Or, if you insist on a registry‑style startup, call an **elevated helper** (for example a scheduled task you trigger) rather than running `netsh` directly from a standard startup location.

So, yes, elevation is still needed; you just handle it via an elevated scheduled task (or similar mechanism), not by dropping the BAT into that `Shell` registry value.
<span style="display:none">[^5_1][^5_2][^5_3][^5_4][^5_5][^5_6][^5_7][^5_8][^5_9]</span>

<div align="center">⁂</div>

[^5_1]: https://memstechtips.com/disable-wifi-sense-windows-10-11-regedit/

[^5_2]: https://www.youtube.com/watch?v=d8LN13mTSN4

[^5_3]: https://www.techrepublic.com/article/how-to-automatically-deny-uac-elevation-requests-in-windows-10/

[^5_4]: https://stackoverflow.com/questions/64913239/how-to-disbale-enable-logically-wifi-on-windows

[^5_5]: https://www.tenforums.com/tutorials/2944-add-delete-enable-disable-startup-items-windows-10-a.html

[^5_6]: https://learn.microsoft.com/en-us/answers/questions/3881534/the-requested-operation-requires-elevation-appear

[^5_7]: https://www.reddit.com/r/sysadmin/comments/18wrexo/how_can_we_disable_connect_automatically_for_a/

[^5_8]: https://www.techwalla.com/articles/how-to-disable-wireless-in-registry

[^5_9]: https://endpointmanagertips.com/how-to-disable-startup-items-for-standard-users/


---

# HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Run or HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce ?

**`Run`** runs your `DisableWifi.bat` every time you log on.

**`RunOnce`** runs it once only, then deletes the entry automatically.

For disabling Wi-Fi on every boot/logon, use `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Run`.

**But elevation is still required.** Both keys run under your standard user token, so `netsh interface set interface ... admin=disabled` will fail with "Access denied" unless:

- Your user account has admin privileges **and** UAC is disabled, or
- You launch an elevated helper (like `runas` or a scheduled task) from the batch.

**Recommended path:** Skip registry entirely → use Task Scheduler "At log on" with "Run with highest privileges" as mentioned before. More reliable than registry run keys for privileged operations.
<span style="display:none">[^6_1][^6_10][^6_2][^6_3][^6_4][^6_5][^6_6][^6_7][^6_8][^6_9]</span>

<div align="center">⁂</div>

[^6_1]: https://persistence-info.github.io/Data/run.html

[^6_2]: https://winreg-kb.readthedocs.io/en/latest/sources/system-keys/Run-and-RunOnce.html

[^6_3]: https://www.youtube.com/watch?v=zgFzCq5uEPw

[^6_4]: https://learn.microsoft.com/en-us/windows/win32/setupapi/run-and-runonce-registry-keys

[^6_5]: https://www.hackingarticles.in/windows-privilege-escalation-logon-autostart-execution-registry-run-keys/

[^6_6]: http://www.puhua.net/blog/posts/20200209-Run-and-RunOnce-Registry-Keys.html

[^6_7]: https://community.spiceworks.com/t/best-method-to-runonce-to-write-registry-key-for-a-standard-user/717667

[^6_8]: https://www.reddit.com/r/sysadmin/comments/14zfq49/run_once_registry/

[^6_9]: https://isc.sans.edu/diary/17348

[^6_10]: https://learn.microsoft.com/pl-pl/windows/win32/setupapi/run-and-runonce-registry-keys


---

```
# <q>Run('netsh interface set interface name="Wireless Network Connection" a</q> So a compiled .au3 with the : ; Disable Wi‑Fi
```

Run('netsh interface set interface name="Wireless Network Connection" admin=disabled', "", @SW_HIDE) : and the .exe elevated to admin would work ...

Yes, a compiled `.au3` EXE with that exact `Run()` line **will work on Windows 10** (and Windows 7) **if**:

1. **The EXE runs elevated** (right-click → "Run as administrator", **or** compiled with `#RequireAdmin` directive, **or** manifest set to require admin)
2. **Interface name is correct** (verify with `netsh interface show interface` — on Win10 it's often `"Wi-Fi"`, not `"Wireless Network Connection"`)

### Your corrected full script:

```autoit
#RequireAdmin  ; ← This makes it auto-elevate when run

; Your other commands first...
Run("C:\sys\nvidia inspector\nvidiaInspector.exe -setBaseClockOffset:0,0,100 -setMemoryClockOffset:0,0,200 -setOverVoltage:0,0 -setPowerTarget:0,100 -setTempTarget:0,0,80")
Run("F:\pulse\launchbar\RKLauncher.exe")
Sleep(3000)
ProcessSetPriority("RKLauncher.exe", 0)

; Disable Wi-Fi (works on Win7/10)
Run('netsh interface set interface name="Wi-Fi" admin=disabled', "", @SW_HIDE)  ; Win10 name
; OR for Win7:
; Run('netsh interface set interface name="Wireless Network Connection" admin=disabled', "", @SW_HIDE)
```

**Test it:** Compile → right-click the EXE → "Run as administrator" → Wi-Fi should immediately disable.

**To run automatically:** Put the EXE in `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`, **but** you must:

- Set UAC to "never notify" **OR**
- Use Task Scheduler "At logon" → "Run with highest privileges"

The `#RequireAdmin` + correct interface name + elevation = ✅ **it works reliably**.[^7_1][^7_2][^7_3]
<span style="display:none">[^7_4][^7_5][^7_6][^7_7][^7_8][^7_9]</span>

<div align="center">⁂</div>

[^7_1]: https://www.autoitscript.com/forum/topic/192873-disable-and-enable-local-connection/

[^7_2]: https://www.autoitscript.com/forum/topic/181077-add-installcmd-tot-autoit/

[^7_3]: https://autoit.de/thread/45078-an-kommandozeile-senden/

[^7_4]: https://www.autoitscript.com/forum/topic/196815-stop-internet-for-20-sec/

[^7_5]: https://www.autoitscript.com/forum/topic/131414-automagically-disableenable-network-adapter/

[^7_6]: https://autoitscript.fr/forum/viewtopic.php?start=20\&t=10936

[^7_7]: https://autoit-script.ru/threads/set-internet-opredelenie-i-perezapusk-setevyx-adapterov.13491/

[^7_8]: https://autoitscript.fr/forum/viewtopic.php?t=10936\&start=20

[^7_9]: https://www.autoitscript.com/forum/topic/201886-disableenable-specific-network-adapters/


---

# Ok excellent by the by knocking out the explorer.exe is not really a biggy the RKLauncher.exe (sort of small mac os laucher lookie like) has a link to the explorer.exe ...

Got it—that makes sense for a streamlined launcher setup. If knocking out `explorer.exe` temporarily isn't an issue (since RKLauncher provides shell access), you could even chain that behavior explicitly if desired.

Your elevated AutoIt EXE approach is solid for the Wi-Fi disable. With `#RequireAdmin` and the right interface name, it'll fire reliably from `HKCU\Run` or Task Scheduler.

To test the full flow:

1. Compile the `.au3` with `#RequireAdmin`
2. Verify interface name: `netsh interface show interface`
3. Drop EXE in Startup folder or registry `Run` key
4. Reboot → Wi-Fi off, RKLauncher up, explorer accessible via its link

Should give you exactly the clean boot you want.

---

# All right very nice thank you for the tips and corrections. Will give it a whirl on both os's.

You're welcome! Best of luck testing it on both Windows 7 and 10—should work smoothly with those tweaks. Let me know if you hit any snags. 🚀

