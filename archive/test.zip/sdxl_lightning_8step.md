<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Are there any benefits on using : [https://huggingface.co/ByteDance/SDXL-Lightning/tree/main](https://huggingface.co/ByteDance/SDXL-Lightning/tree/main) : the 8 step version over v1-5-pruned-emaonly ?

Yes, the 8-step version of SDXL-Lightning offers clear speed advantages over the standard SDXL 1.5 pruned EMA-only model while often matching or exceeding quality in prompt fidelity and detail.[^1_1][^1_5]

## Speed Gains

The 8-step Lightning model generates 1024x1024 images in roughly 1.3-1.8 seconds, compared to 13+ seconds for 50 steps on standard SDXL 1.5, representing an 86%+ reduction in inference time. This stems from progressive adversarial diffusion distillation, allowing high-quality outputs in just 1-8 steps versus dozens needed for base SDXL.[^1_3][^1_5][^1_7][^1_9]

## Quality Comparison

Users and benchmarks note the 8-step variant provides superior visual quality and prompt adherence over fewer-step Lightning options (like 2-4 steps) and rivals or beats standard SDXL 1.5 in photorealism, with fewer artifacts when paired with optimal schedulers like Euler or SGM Uniform. It's especially effective at 1024px resolution, though 1-step is experimental and less stable.[^1_2][^1_5][^1_7][^1_1]

## Usage Notes

Load `sdxl_lightning_8step.safetensors` as a full UNet checkpoint (not LoRA unless adapting to other bases), set steps to 8, CFG to 1.0, and use LCM or DPM++ schedulers for best results in tools like ComfyUI or Fooocus. Memory use stays around 11GB, similar to base SDXL but with far quicker iteration.[^1_4][^1_5][^1_1][^1_2]
<span style="display:none">[^1_10][^1_6][^1_8]</span>

<div align="center">⁂</div>

[^1_1]: https://huggingface.co/ByteDance/SDXL-Lightning

[^1_2]: https://github.com/lllyasviel/Fooocus/discussions/2318

[^1_3]: https://wiki.shakker.ai/en/sdxl-lightning

[^1_4]: https://huggingface.co/ByteDance/SDXL-Lightning/discussions/61

[^1_5]: https://www.felixsanz.dev/articles/sdxl-lightning-quick-look-and-comparison

[^1_6]: https://huggingface.co/ByteDance/SDXL-Lightning/tree/main

[^1_7]: https://sdxlturbo.ai/blog-ComfyUI-SDXL-Lightning-Performance-Test-How-Which-to-Use-248-Steps-27022

[^1_8]: https://www.facebook.com/groups/stablediffusion/posts/1254760011856138/

[^1_9]: https://www.baseten.co/blog/comparing-few-step-image-generation-models/

[^1_10]: https://huggingface.co/mishig/llms-txt/raw/main/diffusers.txt


---

# Ah ... is there a correlation between 'steps' and memory usage?

No, there isn't a strong correlation between the number of steps and memory usage in SDXL-Lightning models.[^2_1]

## Memory Consistency

Benchmarks show memory usage remains steady across step counts—like 11.24 GB for 1-step, 2-step, 4-step, and 8-step Lightning variants—since it primarily depends on the UNet model size and resolution (e.g., 1024x1024), not iteration steps. This holds for both full models and LoRA versions, with minor variations from schedulers (e.g., LCM-LoRA at 11.65 GB).[^2_4][^2_1]

## Minor Influences

Slight increases can occur with certain optimizations or loaders (e.g., FP8 or LCM), but steps themselves don't drive higher VRAM needs, unlike base SDXL where more steps mainly extend time without much memory change. Users on 8-12 GB GPUs run 8-step Lightning fine, confirming efficiency.[^2_2][^2_5][^2_1]
<span style="display:none">[^2_10][^2_3][^2_6][^2_7][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://www.felixsanz.dev/articles/sdxl-lightning-quick-look-and-comparison

[^2_2]: https://arxiv.org/html/2312.04005v2

[^2_3]: https://www.youtube.com/watch?v=KnjZIYSdbPo

[^2_4]: https://www.felixsanz.dev/es/articulos/sdxl-lightning-vistazo-rapido-y-comparativa

[^2_5]: https://www.reddit.com/r/StableDiffusion/comments/1brx05p/is_8_gb_of_ram_enough_to_run_sdxl_lightning_models/

[^2_6]: https://sdxlturbo.ai/blog-ComfyUI-SDXL-Lightning-Performance-Test-How-Which-to-Use-248-Steps-27022

[^2_7]: https://news.ycombinator.com/item?id=37752632

[^2_8]: https://huggingface.co/ByteDance/SDXL-Lightning

[^2_9]: https://replicate.com/bytedance/sdxl-lightning-4step

[^2_10]: https://www.baseten.co/library/sdxl-lightning/


---

# So steps are rendering speeds?

Yes, steps in SDXL-Lightning directly control rendering speed by defining the number of denoising iterations.

## Speed Impact

Fewer steps (e.g., 2 or 4) yield faster generation times—around 0.6-0.9 seconds per 1024x1024 image—while 8 steps take about 1.3 seconds, still far quicker than base SDXL's dozens of steps. Higher steps trade minor speed for better quality and detail adherence, but all Lightning variants stay under 2 seconds.[^3_1][^3_2]

## Quality Trade-off

Low steps prioritize speed with acceptable (but sometimes less detailed) outputs; 8 steps balance both effectively. This distillation technique enables such efficiency without proportional memory hikes.[^3_2]
<span style="display:none">[^3_10][^3_3][^3_4][^3_5][^3_6][^3_7][^3_8][^3_9]</span>

<div align="center">⁂</div>

[^3_1]: https://www.youtube.com/watch?v=KnjZIYSdbPo

[^3_2]: https://sdxlturbo.ai/blog-ComfyUI-SDXL-Lightning-Performance-Test-How-Which-to-Use-248-Steps-27022

[^3_3]: https://www.youtube.com/watch?v=t8qObhR4pUk

[^3_4]: https://sdxlturbo.ai/blog-SDXL-Lightning-Achieve-Flash-Speed-Image-Rendering-in-Just-2-Steps-ComfyUI-27028

[^3_5]: https://www.reddit.com/r/StableDiffusion/comments/1caxefs/hyper_sdxl_best_settings_and_my_assessment_of_it/

[^3_6]: https://sdxlturbo.ai/blog-Lightning-Strikes-the-Art-World-Mastering-SDXLLightning-with-Stable-Diffusion-Auto-1111-Forge-22229

[^3_7]: https://www.reddit.com/r/StableDiffusion/comments/1btvlp3/do_different_models_have_a_huge_difference_in/

[^3_8]: https://www.mindstudio.ai/blog/what-is-sdxl-stability-ai

[^3_9]: https://huggingface.co/ByteDance/SDXL-Lightning/discussions/44

[^3_10]: https://www.youtube.com/watch?v=__fbfQvbIZI


---

# Ok 11GB a bit to much for a 5060 rtx with 8GB?

Yes, 11GB VRAM demand exceeds the RTX 5060's 8GB capacity, making SDXL-Lightning challenging without tweaks.

## VRAM Shortfall

SDXL-Lightning consistently uses around 11GB for 1024x1024 images across step counts, leaving the 8GB RTX 5060 short by 3GB+ and risking out-of-memory errors. RTX 5060 specs confirm its fixed 8GB GDDR7 limit, akin to RTX 4060 limitations in AI tasks.[^4_1][^4_2][^4_9]

## Workarounds

Drop to 768x768 resolution (cuts usage to ~8-9GB), enable half-precision (fp16), use LoRA variants, or offload to CPU RAM via tools like ComfyUI with --lowvram flags for viable runs. These trade some speed/quality but enable generation on 8GB GPUs.
<span style="display:none">[^4_3][^4_4][^4_5][^4_6][^4_7][^4_8]</span>

<div align="center">⁂</div>

[^4_1]: https://www.tomshardware.com/pc-components/gpus/nvidia-rtx-5060-claimed-to-feature-just-8gb-of-vram-the-5060-ti-may-get-8gb-and-16gb-flavors

[^4_2]: https://www.msi.com/Graphics-Card/GeForce-RTX-5060-8G-GAMING-OC/Specification

[^4_3]: https://www.tomshardware.com/pc-components/gpus/geforce-rtx-5060-ti-8gb-vs-rtx-5060-ti-16gb-gpu-face-off

[^4_4]: https://www.reddit.com/r/hardware/comments/1mq1ebc/is_8gb_of_vram_enough_for_gaming_geforce_rtx_5060/

[^4_5]: https://www.club386.com/nvidia-geforce-rtx-5060-review/

[^4_6]: https://www.reddit.com/r/buildapc/comments/1n5vq04/my_experience_with_the_rtx_5060_and_its_8gb_of/

[^4_7]: https://www.nvidia.com/en-us/geforce/graphics-cards/50-series/rtx-5060-family/

[^4_8]: https://www.nvidia.com/en-us/geforce/news/ultimate-guide-to-5060/

[^4_9]: https://www.felixsanz.dev/articles/sdxl-lightning-quick-look-and-comparison


---

# ok and 512x768?

Yes, 512x768 resolution significantly lowers VRAM usage for SDXL-Lightning, making it feasible on an RTX 5060 with 8GB.

## VRAM Reduction

Lower resolutions like 512x768 typically drop usage to 6-8GB (from 11GB at 1024x1024), as memory scales quadratically with pixel count—about 1/4 the area means roughly half the VRAM peak. Users confirm SDXL runs on 8GB GPUs at this size with fp16 precision and medvram flags, avoiding out-of-memory issues.[^5_2][^5_3][^5_4][^5_11]

## Trade-offs

Quality holds up well for portraits or non-square needs, though upscaling post-generation helps detail; Lightning's speed (under 1s) remains a win.[^5_4]
<span style="display:none">[^5_1][^5_10][^5_5][^5_6][^5_7][^5_8][^5_9]</span>

<div align="center">⁂</div>

[^5_1]: https://github.com/vladmandic/sdnext/discussions/2923

[^5_2]: https://stablediffusionxl.com/sdxl-system-requirements/

[^5_3]: https://www.reddit.com/r/StableDiffusion/comments/1brx05p/is_8_gb_of_ram_enough_to_run_sdxl_lightning_models/

[^5_4]: https://www.reddit.com/r/StableDiffusion/comments/1bz39o8/8gb_vram_is_sdxl_possible/

[^5_5]: https://sdxlturbo.ai/blog-Multi-Diffusion-for-A1111-Super-Large-LOW-Vram-Upscaling-6950

[^5_6]: https://github.com/AUTOMATIC1111/stable-diffusion-webui/discussions/11713

[^5_7]: https://www.facebook.com/groups/stablediffusion/posts/1230375250961281/

[^5_8]: https://huggingface.co/Qwen/Qwen-Image-Edit/discussions/6

[^5_9]: https://www.reddit.com/r/StableDiffusion/comments/1bx49m9/are_there_factors_aside_from_vram_that_allow/

[^5_10]: https://www.youtube.com/watch?v=t8qObhR4pUk

[^5_11]: https://www.felixsanz.dev/articles/sdxl-lightning-quick-look-and-comparison


---

# So thats where to whole two step upscaling thing comes into focus been seeing that a lot in my journey through ai image land ....

Yes, two-step upscaling is a popular workflow in AI image generation to overcome VRAM limits on GPUs like your RTX 5060 8GB while achieving high-res outputs.

## Low-Res First

Generate at low resolutions (e.g., 512x768) where SDXL-Lightning fits comfortably in ~6-8GB VRAM, producing a fast base image with good composition.[^6_11]

## Upscale Stages

- **Step 1 (Latent upscale)**: Enlarge 1.5-2x in latent space (e.g., to 1024x1024) with low denoise (0.4-0.45) to add detail without changing structure.
- **Step 2 (Refinement/HiRes fix)**: Run img2img or Ultimate SD Upscale with minimal steps, refining sharpness and textures via diffusion models.[^6_1][^6_5]

This keeps peak VRAM low, leverages Lightning's speed, and yields print-ready results—exactly why it's common in ComfyUI/Forge workflows.
<span style="display:none">[^6_10][^6_2][^6_3][^6_4][^6_6][^6_7][^6_8][^6_9]</span>

<div align="center">⁂</div>

[^6_1]: https://www.reddit.com/r/EnhancerAI/comments/1phvt5v/insane_photorealism_with_z_image_turbo_2step/

[^6_2]: https://www.mindstudio.ai/blog/what-is-ideogram-upscale/

[^6_3]: https://www.upscale.media

[^6_4]: https://community.topazlabs.com/t/discussion-upscaling-in-photo-ai-4-best-quality-with-2x-4x-or-also-3x/99263

[^6_5]: https://www.reddit.com/r/StableDiffusion/comments/1kb3bib/can_someone_explain_upscaling_images_actually/

[^6_6]: https://sdxlturbo.ai/blog-flux-ai-images-refiner-and-upscale-with-sdxl-45983

[^6_7]: https://www.youtube.com/watch?v=qXDdCeKYrTs

[^6_8]: https://www.youtube.com/watch?v=7x4xJIrKhhc

[^6_9]: https://www.youtube.com/watch?v=YgTyeOoqHoc

[^6_10]: https://www.youtube.com/watch?v=ci-ImOtaiDM

[^6_11]: https://www.reddit.com/r/StableDiffusion/comments/1bz39o8/8gb_vram_is_sdxl_possible/


---

# Nice tip gracias so download sdxl_lightning_8step.safetensors add it the model folder in comfyui (where v1-5-pruned-emaonly is) and I'm good to go? (with vae vae-ft-mse-840000-ema-pruned) ...

Not quite—`sdxl_lightning_8step.safetensors` is a full checkpoint (not LoRA), so place it in ComfyUI's **models/checkpoints** folder alongside your v1-5-pruned-emaonly.[^7_1]

## VAE Compatibility

Your `vae-ft-mse-840000-ema-pruned` works perfectly as SDXL's standard VAE—load it separately in workflows via the VAE Loader node for decoding. No changes needed there.[^7_2][^7_1]

## Quick Setup Steps

- Download from Hugging Face and drop into **checkpoints**.
- In ComfyUI: Load Checkpoint → select `sdxl_lightning_8step.safetensors`.
- Set KSampler steps=8, CFG=1.0, sampler=Euler or simple, scheduler=SGM_Uniform or normal.
- Use 512x768 latent for your 8GB RTX 5060, then upscale.

You're good to generate in seconds—drag a basic SDXL workflow JSON if needed from tutorials.[^7_4][^7_1]
<span style="display:none">[^7_10][^7_3][^7_5][^7_6][^7_7][^7_8][^7_9]</span>

<div align="center">⁂</div>

[^7_1]: https://www.stablediffusiontutorials.com/2024/03/sdxl-lightning.html

[^7_2]: https://www.promptzone.com/jaroslav/how-to-install-and-run-sdxl-models-in-comfyui-a-complete-guide-2nk2

[^7_3]: https://www.youtube.com/watch?v=I6O-7PMU1kU

[^7_4]: https://sdxlturbo.ai/blog-SDXL-Lightning-For-Stable-Diffusion-ComfyUI-How-To-Use-And-What-We-Should-Know-27021

[^7_5]: https://www.youtube.com/watch?v=KOXXzPqqC_I

[^7_6]: https://www.youtube.com/watch?v=PK54CJhftps

[^7_7]: https://www.reddit.com/r/comfyui/comments/1p5edmj/comfyui_for_beginners_pt_1_installation_interface/

[^7_8]: https://comfyui-wiki.com/en/install

[^7_9]: https://github.com/Comfy-Org/ComfyUI/discussions/2867

[^7_10]: https://www.reddit.com/r/StableDiffusion/comments/1p5edbe/comfyui_for_beginners_pt_1_installation_interface/


---

# Cushty ok will give it a whirl merci.

You're welcome! Have fun spinning up those quick gens with Lightning—hit me up if you run into workflow snags. 🚀

