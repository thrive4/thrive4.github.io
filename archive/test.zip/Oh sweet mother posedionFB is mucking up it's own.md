<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Oh sweet mother posedionFB is mucking up it's own project files FB.poseidon ... could you give me a direct fbc compile string fbc -c etc etc

Yes — with `fbc` you can do it directly on the command line. The clean approach is to compile the `.bas` files to objects, then link them with an rpath so the executable finds `libbass.so` in its own folder at runtime.[^1_1][^1_2]

## Example build

If `libbass.so` will sit next to `audioplayer`, use:

```bash
fbc -c audioplayer.bas
fbc -c listplay.bas
fbc -c utilaudio.bas
fbc -c utilfile.bas

fbc audioplayer.o listplay.o utilaudio.o utilfile.o \
  -l bass \
  -Wl,-rpath,'$ORIGIN' \
  -o audioplayer
```

`-Wl,-rpath,'$ORIGIN'` passes the literal `$ORIGIN` token to the linker so the runtime loader searches the executable’s directory.[^1_3][^1_4]
`-l bass` tells the linker to use `libbass.so`.[^1_1]

## If the library is in a subfolder

If you want to keep the library in `libs/`, use:

```bash
fbc audioplayer.o listplay.o utilaudio.o utilfile.o \
  -l bass \
  -Wl,-rpath,'$ORIGIN/libs' \
  -o audioplayer
```

That makes the binary look in `./libs` relative to the executable at runtime.[^1_2][^1_4]

## If quoting gets in the way

Some shells or build wrappers need escaped dollar signs, so if the above does not stick, try:

```bash
-Wl,-rpath,\$ORIGIN
```

or, in a Makefile-style context, `$$ORIGIN` to preserve the literal token until link time.[^1_5][^1_2]
The important part is that the final linked binary contains the runtime path, not just the shell command.[^1_3]

## Quick check

After building, run:

```bash
ldd ./audioplayer
```

If it is correct, `libbass.so` should resolve instead of showing `not found`.[^1_4][^1_1]
That gives you the Linux equivalent of “exe and DLL in the same folder” without installing the library system-wide.[^1_4]
<span style="display:none">[^1_10][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://documentation.help/FreeBASIC/ProPgSharedLibraries.html

[^1_2]: https://stackoverflow.com/questions/42344932/how-to-include-correctly-wl-rpath-origin-linker-argument-in-a-makefile

[^1_3]: https://stackoverflow.com/questions/33853344/what-are-the-recommended-gnu-linker-options-to-specify-origin-in-rpath

[^1_4]: https://blog.alumik.cn/posts/58/

[^1_5]: https://stackoverflow.com/questions/6324131/rpath-origin-not-having-desired-effect

[^1_6]: https://stackoverflow.com/questions/31537183/how-to-link-shared-library-from-non-existingin-compile-time-folder/31537402

[^1_7]: https://github.com/bazel-contrib/rules_foreign_cc/issues/940

[^1_8]: https://stackoverflow.com/questions/6562403/i-dont-understand-wl-rpath-wl/6562437

[^1_9]: https://stackoverflow.com/questions/39554743/how-to-use-rpath-in-compile-to-set-executables-search-shared-library-in-its-sam

[^1_10]: https://www.freebasic.net/forum/viewtopic.php?t=23673

