<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# We were having a conversation over the prompt with reagard to flux and other models like sd 1.5 and sdxl and one thing I forgot to ask was how deos flux deal with the seed in the prompt ... does it still exist and if so does it have the same significance as in more or less generate the image?

Flux still uses a seed, and it matters in essentially the same way as in SD 1.5 / SDXL: it controls the starting noise, which in turn fixes the overall composition and many details for a given prompt and settings.[^1_1][^1_3][^1_9]

### Does a seed still exist in Flux?

- Yes, Flux.1‑dev and related Flux models expose a seed parameter in most UIs and APIs.[^1_3][^1_9][^1_1]
- If you don’t set it, the system picks a random seed each time, so rerunning the same prompt gives different images.[^1_5][^1_1]


### How significant is the seed in Flux?

- Using the same prompt, same settings, and same seed will reproduce the **same** image (or extremely close to it), just like SD 1.5 / SDXL.[^1_9][^1_1][^1_3]
- Changing only the seed (keeping prompt and parameters fixed) gives you different variants that still follow the prompt, again very similar to Stable Diffusion behavior.[^1_1][^1_5]


### Any practical differences vs SD 1.5 / SDXL?

- Conceptually it’s the same idea: the seed is the “coordinate” in the noise space for that prompt and configuration.[^1_2][^1_5][^1_9]
- In practice, Flux is often a bit more *prompt‑stable* than older SD models, so small prompt tweaks with the same seed tend to preserve global composition and character more than you might expect from SD 1.5, but the seed is still just fixing the initial noise, not “locking” specific objects independently.[^1_6][^1_8][^1_3]


### How to think about it when prompting Flux

- Use a fixed seed when you want to iterate on a composition (same pose, framing, character) while nudging the prompt.[^1_3][^1_9][^1_1]
- Clear or randomize the seed when you’re happy with the prompt but want fresh compositions or completely different takes.[^1_5][^1_1][^1_3]

So yes: the seed definitely still exists in Flux, and its significance for what image you get is broadly the same as in SD 1.5 / SDXL; what’s changed more is the model’s prompt behavior, not the core role of the seed.
<span style="display:none">[^1_10][^1_4][^1_7]</span>

<div align="center">⁂</div>

[^1_1]: https://www.youtube.com/watch?v=JpdReAj30oA

[^1_2]: https://ai-art-tutorials.com/what-is-seed-in-stable-diffusion-xl-sdxl-how-to-use-it-to-create-better-ai-images-why-is-seed-important-for-creators-112

[^1_3]: https://www.youtube.com/watch?v=njNCn6BK79g

[^1_4]: https://tripleminds.co/blogs/technology/flux-vs-sdxl-vs-pony/

[^1_5]: https://venice.ai/blog/how-to-use-seed-numbers-to-create-consistent-ai-generated-images

[^1_6]: https://www.reddit.com/r/StableDiffusion/comments/1eilxf7/interesting_how_flux_doesnt_seem_to_alter_the/

[^1_7]: https://www.linkedin.com/posts/benjaminbertram_ai-fluxkontext-imageediting-activity-7334231493659013121-Drk2

[^1_8]: https://getimg.ai/blog/flux-1-vs-stable-diffusion-ai-text-to-image-models-comparison

[^1_9]: https://deepinfra.com/blog/flux1-dev-guide

[^1_10]: https://digitaldivas.ai/2025/03/22/creating-stunning-ai-influencers-the-complete-stable-diffusion-guide-for-1-5-sdxl-and-flux/


---

# Ok good to hear and as bonus it 'might' a bit more 'prompt stable' (so larger deltas in the prompt are handeld more consistent?) what is the syntax could you give me an example prompt?

Yes—Flux tends to keep composition and identity more stable across prompt edits than SD 1.5, so you can make bigger textual changes while the overall layout stays similar, especially if you keep the same seed. This is not absolute “lock-in,” but in practice you’ll often see less drastic shifts for medium‑sized prompt tweaks than you might be used to.

### Basic “natural language + seed” example

Here’s a simple example you could drop into (say) a web UI that has a seed field:

Prompt:
> A cinematic portrait of a young woman with short curly brown hair, wearing a dark green jacket, standing on a rainy Amsterdam street at night, neon reflections on the wet cobblestones, soft depth of field, shot on a 50mm lens, moody atmosphere

Settings (conceptually):

- Model: Flux (any variant)
- Seed: 123456
- Steps / CFG / etc.: whatever your UI defaults to

If you:

- Keep the **same seed** (123456) and only change “young woman” → “young man with a trimmed beard”, you’ll usually get the same camera angle, lighting, and street layout, but with the subject swapped.
- Keep the **same seed** and change only atmosphere bits (e.g. “moody atmosphere” → “hopeful atmosphere, soft warm light on the face”), the pose and framing often stay, while lighting and color mood shift.


### “Prompt‑stable” iteration workflow

A practical way to use this stability:

1. Start with:
> A full‑body shot of a woman in a red raincoat crossing a canal bridge in Amsterdam at sunrise, soft mist over the water, cinematic lighting, realistic photography

Seed: 987654.
2. To get a winter version with the same basic scene:
> A full‑body shot of a woman in a red winter coat crossing a snowy canal bridge in Amsterdam at sunrise, light snowfall in the air, cinematic lighting, realistic photography

Seed: still 987654.

Result: same bridge, angle, and stance most of the time; clothing, weather, and textures adapt.

### If you’re generating via API or scripts

Different platforms wrap Flux a bit differently, but the pattern is always:

- A text field for the prompt (often just natural language, no need for comma‑spam like SD 1.5).
- A numeric `seed` parameter.
- Optional: other parameters like guidance, number of steps, resolution.

Conceptually it looks like:

```json
{
  "prompt": "A cinematic portrait of a young woman with short curly brown hair, wearing a dark green jacket, standing on a rainy Amsterdam street at night, neon reflections on the wet cobblestones, soft depth of field, shot on a 50mm lens, moody atmosphere",
  "seed": 123456,
  "num_inference_steps": 30,
  "guidance_scale": 3.5,
  "width": 1024,
  "height": 1024
}
```

If you tell me which front‑end you’re using (ComfyUI, Fooocus, Invoke, Replicate, etc.), I can adapt this into the exact syntax that environment expects.
<span style="display:none">[^2_1][^2_10][^2_2][^2_3][^2_4][^2_5][^2_6][^2_7][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://fal.ai/learn/tools/how-to-use-flux

[^2_2]: https://www.ambienceai.com/tutorials/flux-prompting-guide

[^2_3]: https://docs.bfl.ai/guides/prompting_summary

[^2_4]: https://ltx.studio/blog/flux-prompting-guide

[^2_5]: https://getimg.ai/blog/flux-1-prompt-guide-pro-tips-and-common-mistakes-to-avoid

[^2_6]: https://www.youtube.com/watch?v=OSGavfgb5IA

[^2_7]: https://deepinfra.com/blog/flux1-dev-guide

[^2_8]: https://docs.bfl.ml/guides/prompting_summary

[^2_9]: https://nebius.com/blog/posts/creating-images-with-flux-prompt-guide

[^2_10]: https://fal.ai/learn/devs/flux-2-klein-prompt-guide


---

# Good gracias. Can the seed be integrated in the prompt if so how?

You generally should not put the seed *inside* the text prompt for Flux; it belongs in a separate numeric parameter, just like in SD.[^3_1][^3_10]

### 1. Why not put the seed in the prompt?

- The model treats the prompt as plain language, so something like “seed 12345” will just be read as weird words, not as a control signal.[^3_10][^3_1]
- The actual seed that controls the noise/variation is a numeric field in the UI or API (often called “seed”); that’s what must be set for reproducibility.[^3_1][^3_10]

Example (conceptual):

- Prompt:
> A cinematic portrait of a woman in a red coat on a rainy Amsterdam street at night, neon reflections, soft depth of field, realistic photography
- Seed field: `123456`

Putting “seed 123456” in the text will not lock anything; setting `seed = 123456` in the parameter will.

### 2. When would you ever put it *in* the prompt?

There are only “organizational” reasons, not technical ones:

- To keep a record:
> A cinematic portrait of a woman in a red coat… — seed 123456
- To share with others in chat/forums so they know which seed to plug into their own seed field.

But in those cases the seed text is just documentation for humans; the real control still comes from the separate seed parameter.[^3_2][^3_3][^3_1]

So: you **can** write the seed in the prompt as a note for yourself, but it does not *do* anything there; you must set the numeric seed alongside the prompt in your UI or script for it to actually influence the image.
<span style="display:none">[^3_4][^3_5][^3_6][^3_7][^3_8][^3_9]</span>

<div align="center">⁂</div>

[^3_1]: https://skywork.ai/blog/flux-prompting-ultimate-guide-flux1-dev-schnell/

[^3_2]: https://www.youtube.com/watch?v=JpdReAj30oA

[^3_3]: https://www.youtube.com/watch?v=njNCn6BK79g

[^3_4]: https://www.flux.ai/p/blog/prompting-guide-working-with-flux-from-idea-to-schematic

[^3_5]: https://getimg.ai/blog/flux-1-prompt-guide-pro-tips-and-common-mistakes-to-avoid

[^3_6]: https://www.youtube.com/watch?v=JJe-1g2zj2s

[^3_7]: https://www.youtube.com/watch?v=OSGavfgb5IA

[^3_8]: https://skywork.ai/blog/flux1-prompts-tested-templates-tips-2025/

[^3_9]: https://www.reddit.com/r/StableDiffusion/comments/1el0pv9/what_do_we_actually_know_about_actual_prompt/

[^3_10]: https://deepinfra.com/blog/flux1-dev-guide


---

# Ok very good gracias. Just a sneak preview I'm using confyui portable on windows with a 5060 rtx 8GB vram card what would be a basic step for step guide to get a version of flux running on it?

You can absolutely run Flux in ComfyUI Portable on a 5060 8 GB; the main constraint will be resolution and batch size. Below is a minimal, practical step‑by‑step that assumes you already have ComfyUI Portable working with some SD model.

***

## 1. Check your ComfyUI portable structure

In your `ComfyUI_windows_portable` folder you should see something like:

- `ComfyUI_windows_portable/ComfyUI/models/checkpoints`
- `ComfyUI_windows_portable/ComfyUI/models/clip`
- `ComfyUI_windows_portable/ComfyUI/models/vae`
- `run_nvidia_gpu.bat`

You’ll be putting Flux files mostly under `models/checkpoints` (and sometimes `models/clip` depending on the build).

***

## 2. Download a Flux model file

For a first test, use one of the smaller or “fast” variants (for 8 GB VRAM):

- Look for something like `flux.1-schnell` or a smaller `flux.1-dev` on a model hub (Civitai, Hugging Face, etc.).
- Download the `.safetensors` (or `.ckpt`) file.

Then:

1. Put the checkpoint in
`ComfyUI_windows_portable/ComfyUI/models/checkpoints`
2. If the author also provides a separate CLIP or text encoder file, place that in
`ComfyUI_windows_portable/ComfyUI/models/clip`

If the model page specifies any special folder structure (e.g. “put this in /unet” or similar), follow that; otherwise `checkpoints` is the default.

***

## 3. (Optional but recommended) Install ComfyUI Manager

If you haven’t:

1. Download the “manager for portable” installer script (often something like `install-manager-for-portable-version.bat`) from its GitHub page.
2. Drop it into `ComfyUI_windows_portable` (same level as `run_nvidia_gpu.bat`).
3. Run that installer once, then restart ComfyUI.

After that you’ll have a “Manager” button inside ComfyUI to install custom nodes via a GUI.

***

## 4. Install Flux‑compatible nodes (if needed)

Some Flux checkpoints work with stock K‑Sampler + normal nodes, others expect specific custom nodes or samplers. Basic approach:

1. Open ComfyUI in your browser (run `run_nvidia_gpu.bat`).
2. Click the Manager button.
3. Go to “Custom Nodes”.
4. Search for things like:
    - “flux”
    - “black-forest-labs”
    - Any node pack mentioned on the model’s download page.

Install the nodes that match the Flux model you downloaded. Then:

- Close ComfyUI.
- Run `run_nvidia_gpu.bat` again to reload nodes.

If your Flux model’s page says “works with vanilla ComfyUI, no custom nodes required”, you can skip this step.

***

## 5. Build a minimal Flux workflow

Start from a blank workflow and add:

1. **Checkpoint Loader**
    - Choose your Flux model from the dropdown (e.g. `flux.1-schnell.safetensors`).
2. **CLIP Text Encode** (or the Flux‑specific text encoder node if provided)
    - Connect the `clip` output from the Checkpoint Loader to this.
    - Set your positive prompt here.
3. **CLIP Text Encode (negative)**
    - Same `clip` input, but a negative prompt (e.g. “low quality, blurry, distorted, extra limbs, watermark”).
4. **Empty Latent Image**
    - Set width/height. For 8 GB VRAM on a 5060, start modest:
        - 768×768 or 1024×576 / 832×832
        - Batch size: 1
5. **K‑Sampler** (or specific Flux sampler node)
    - Inputs:
        - `model` from Checkpoint Loader.
        - `latent_image` from Empty Latent Image.
        - `positive` and `negative` from the text encoders.
    - Parameters:
        - Steps: 20–28 to start.
        - CFG: 3–5 (Flux usually prefers lower CFG than SD 1.5).
        - Seed: type a fixed number (e.g. 123456) so you can repeat results.
6. **VAE Decode**
    - Connect `latent` from the sampler.
    - If your Flux checkpoint includes a built‑in VAE, use that; otherwise you may need a VAE checkpoint in `models/vae`.
7. **Save Image**
    - Connect from VAE Decode’s `image` output.

Run the workflow; if VRAM is tight or you get CUDA OOM errors, reduce resolution or steps.

***

## 6. Practical VRAM tips for an RTX 5060 8 GB

- Start at 768×768, batch 1, steps 20; if it runs fine, push up resolution slowly.
- Prefer “schnell” (or other lightweight Flux variants) for experimentation; the full “dev” models are heavier.
- Avoid high‑res fix / tiled nodes at first; they eat a lot of VRAM.
- If you want larger images, try:
    - Generate at 768×768.
    - Upscale later with a separate upscaler workflow.

***

## 7. Using seed in your ComfyUI Flux workflow

In the K‑Sampler node:

- `seed` field: put a fixed number for reproducibility (e.g. 987654).
- To explore:
    - Keep seed fixed while editing the prompt → more “prompt‑stable” iterations.
    - Change only the seed to get different compositions with the same description.

If you send a screenshot/name of the Flux checkpoint you’re eyeing, I can suggest exact node names and safe resolution settings tailored to that model and your 8 GB card.
<span style="display:none">[^4_1][^4_10][^4_2][^4_3][^4_4][^4_5][^4_6][^4_7][^4_8][^4_9]</span>

<div align="center">⁂</div>

[^4_1]: https://www.stablediffusiontutorials.com/2024/01/install-comfy-ui-locally.html

[^4_2]: https://comfyui.org/en/windows-native-comfyui-install

[^4_3]: https://stable-diffusion-art.com/how-to-install-comfyui/

[^4_4]: https://comfyui-wiki.com/en/install/install-comfyui/install-comfyui-on-windows

[^4_5]: https://civitai.com/articles/21928/comfyui-tutorial-1-installation-guide-for-beginners-portable-version

[^4_6]: https://docs.comfy.org/installation/comfyui_portable_windows

[^4_7]: https://www.youtube.com/watch?v=1FWADRx_p9I

[^4_8]: https://www.youtube.com/watch?v=Xvss-1CclBw

[^4_9]: https://docs.comfy.org/installation/system_requirements

[^4_10]: https://www.youtube.com/watch?v=txgJ6d0WEDM


---

# 3. CLIP Text Encode (negative) ? I thought flux does not use a negative prompt?

You’re right to question that; your intuition matches what the Flux authors say.

- **Out of the box, Flux does *not* support a separate negative prompt channel the way SD 1.5 / SDXL do.** The official Black Forest Labs docs explicitly say Flux models don’t use negative prompts and recommend working *without* them.[^5_9]
- People *have* built ComfyUI workflows that simulate negatives for Flux (using tricks like dynamic CFG or extra guidance nodes), but that’s an advanced hack, not the default behavior.[^5_4][^5_7][^5_8]

So for a **simple, “vanilla” Flux setup in ComfyUI**, you’d typically do:

- One text encode node for your main prompt.
- No separate “negative” text encode, just leave that concept out of the graph.
- Control quality by:
    - Writing more precise positive prompts (“sharp focus, detailed hands, realistic anatomy”) instead of “blurry, bad hands” in a negative box.[^5_9]
    - Adjusting steps / resolution / CFG as exposed by your particular Flux nodes.

If you later decide to play with the advanced ComfyUI negative‑prompt workflows for Flux, that’s where a second text encoder and special sampler/guider nodes come into play, but I would treat that as “Phase 2,” once you’re already comfortable with normal Flux prompting.
<span style="display:none">[^5_1][^5_10][^5_2][^5_3][^5_5][^5_6]</span>

<div align="center">⁂</div>

[^5_1]: https://huggingface.co/black-forest-labs/FLUX.1-dev/discussions/256

[^5_2]: https://www.aiphotogenerator.net/blog/2026/02/negative-prompts-stable-diffusion-guide

[^5_3]: https://www.reddit.com/r/StableDiffusion/comments/1fn014f/so_is_negative_prompt_possible_in_flux_and_what/

[^5_4]: https://merlio.app/blog/negative-prompts-in-flux-guide

[^5_5]: https://www.reddit.com/r/StableDiffusion/comments/1eqgrn3/why_flux_does_not_have_negative_prompt/

[^5_6]: https://www.reddit.com/r/StableDiffusion/comments/1elqtkm/flux_and_negative_prompt/

[^5_7]: https://www.youtube.com/watch?v=Pi3G7Gotxcc

[^5_8]: https://www.youtube.com/watch?v=4HJWE-Zv4yo

[^5_9]: https://docs.bfl.ml/guides/prompting_guide_t2i_negative

[^5_10]: https://merlio.app/blog/how-to-write-negative-prompts-in-flux


---

# So download flux model > optional clip if needed > optional VAE if needed > and place in mentioned folder then setup the work flow? No python libs etc?

Yes, that's correct for the simplest Flux setup in recent ComfyUI portable versions (post-August 2024 updates)—**no extra Python libraries or manual pip installs needed** if you pick the right model variant and update via Manager.

### Minimal files you need (pick FP8 "single-file" for 8GB VRAM)

1. **Flux checkpoint** (e.g., `flux1-dev-fp8.safetensors` or `flux1-schnell-fp8.safetensors`)
→ `ComfyUI/models/checkpoints/`[^6_1]
2. **Text encoders** (these two .safetensors files):
    - `clip_l.safetensors`
    - `t5xxl_fp8_e4m3fn.safetensors` (or `t5xxl_fp16.safetensors` for slightly better quality)
→ `ComfyUI/models/clip/`[^6_3][^6_1]
3. **VAE** (`ae.safetensors`, rename to `flux_ae.safetensors` if needed)
→ `ComfyUI/models/vae/`[^6_6][^6_1]

### No Python libs because:

- ComfyUI added **native Flux support** in late 2024—no custom nodes required for basic single-file FP8 models.[^6_1]
- Your portable version auto-handles PyTorch/CUDA via the bundled environment.
- Manager → "Update All" pulls any Flux-specific code changes automatically.


### Quick test sequence:

1. Drop files in folders above.
2. Run `run_nvidia_gpu.bat`.
3. **Manager** → **Update All** → browser refresh (critical step).
4. Load a Flux workflow JSON (search ComfyUI examples or download one) or build manually with **UNETLoader**, **DualCLIPLoader**, **FluxSampler**.
5. Queue prompt at 768x768, CFG 1.0 (Flux default), steps 20.

If you see missing node errors, install via Manager → Custom Nodes → search "flux" (1-2 nodes max). Your RTX 5060 8GB will handle FP8 Flux fine at modest resolutions.
<span style="display:none">[^6_10][^6_2][^6_4][^6_5][^6_7][^6_8][^6_9]</span>

<div align="center">⁂</div>

[^6_1]: https://stable-diffusion-art.com/flux-comfyui/

[^6_2]: https://neurocanvas.net/blog/flux-comfyui-guide/

[^6_3]: https://codemonk.io/blog/install-flux-models-comfyui/

[^6_4]: https://www.youtube.com/watch?v=P1uDOhUTrqw

[^6_5]: https://www.runcomfy.com/tutorials/a-comprehensive-guide-on-comfyui-flux

[^6_6]: https://comfyui-wiki.com/en/tutorial/advanced/image/flux/flux-1-dev-t2i

[^6_7]: https://www.youtube.com/watch?v=0plLyIp1xbI

[^6_8]: https://www.youtube.com/watch?v=cCD_HVIp24M

[^6_9]: https://www.reddit.com/r/comfyui/comments/1euw6t6/the_guide_to_installing_and_using_flux_models/

[^6_10]: https://www.youtube.com/watch?v=ImWHS5Ux36E


---

# Ok so something like : [https://huggingface.co/Comfy-Org/flux1-schnell/tree/main](https://huggingface.co/Comfy-Org/flux1-schnell/tree/main) : seems to be comfyui compatible and in terms of setup in comfyui ... sigh ... why are people doing stuff like this : [https://comfyanonymous.github.io/ComfyUI_examples/flux/](https://comfyanonymous.github.io/ComfyUI_examples/flux/) : 'Here’s a simple example. You can load or drag the following image in ComfyUI to get the workflow:' it's in the comment of the .png ...

Yes, the Comfy-Org/flux1-schnell repo is perfect for ComfyUI portable—it's pre-optimized single-file FP8 checkpoints that work natively without splitting files or custom nodes.[^7_1][^7_4][^7_10]

### Quick file grab from that repo:

1. **flux1-schnell-fp8.safetensors** (~12GB) → `ComfyUI/models/checkpoints/`
2. **clip_l.safetensors** → `ComfyUI/models/clip/`
3. **t5xxl_fp8_e4m3fn.safetensors** → `ComfyUI/models/clip/`
4. **ae.safetensors** (VAE) → `ComfyUI/models/vae/` (rename to `flux_ae.safetensors` if needed)

### Why PNG workflow images? (The "sigh" part)

You're right—dragging PNGs feels clunky. Here's the **manual node sequence** so you build it yourself:

```
[Empty Latent Image] → [Flux1 Schnell Loader] → [KSampler (Flux)] → [VAE Decode] → [Save Image]
                          ↓
[CLIP Text Encode (Flux)] ← [DualCLIPLoader (Flux)]
```

**Node-by-node breakdown:**

1. **Empty Latent Image**: 768×768, batch=1
2. **DualCLIPLoader**: loads `clip_l.safetensors` + `t5xxl_fp8...` automatically
3. **UNet Loader**: select `flux1-schnell-fp8.safetensors`
4. **CLIP Text Encode (Prompt)**: connect DualCLIP → positive prompt only (no negative)
5. **SamplerCustomAdvanced/Flux Sampler**:
    - Steps: 4-8 (schnell is distilled)
    - CFG: 1.0
    - Sampler: `uni_pc`
    - Scheduler: `simple` or `beta`
    - Seed: fixed number
6. **VAE Loader**: loads `flux_ae.safetensors`
7. **VAE Decode** + **Save Image**

### Fastest path (if you hate building):

1. Right-click ComfyUI canvas → **Add Node** → **Loaders** → **Load Checkpoint (Flux)**
2. It'll auto-connect most things. Tweak resolution/steps and run.

The PNG workflow is just ComfyUI's quirky "JSON embedded in image metadata" trick—functional but annoying for documentation. Building manually once teaches you the graph better anyway.

**Test prompt**: `"A cyberpunk street in Amsterdam at night, neon signs reflecting on wet cobblestones, realistic photography"`, seed 123456, 768×768. Should run clean on your 8GB 5060.[^7_4][^7_1]
<span style="display:none">[^7_2][^7_3][^7_5][^7_6][^7_7][^7_8][^7_9]</span>

<div align="center">⁂</div>

[^7_1]: https://www.seaart.ai/news/flux-1-schnell

[^7_2]: https://www.youtube.com/watch?v=6sdO_6o6rH4

[^7_3]: https://huggingface.co/black-forest-labs/FLUX.1-schnell/discussions/13

[^7_4]: https://stable-diffusion-art.com/flux-comfyui/

[^7_5]: https://www.youtube.com/watch?v=tXO6SJ-6Eb8

[^7_6]: https://comfyui-wiki.com/en/tutorial/advanced/image/flux/flux-1-dev-t2i

[^7_7]: https://www.reddit.com/r/StableDiffusion/comments/1ei52iu/tutorial_how_to_integrate_flux1_models_into/

[^7_8]: https://github.com/comfyanonymous/ComfyUI/issues/4258

[^7_9]: https://docs.comfy.org/tutorials/flux/flux-1-text-to-image

[^7_10]: https://www.youtube.com/watch?v=ImWHS5Ux36E


---

# Ok a keeper. Thank you for the sneak preview I'm a bit better prepared.

You're welcome! Glad the Flux setup preview helps get you prepped for ComfyUI on that RTX 5060. Ping me when you're diving in if you hit any snags. 🚀

