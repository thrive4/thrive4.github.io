<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Nice very good will do. By the by looking through 'local.sqlite' where is it storing the actual event data?

The actual event records are in the tables inside `local.sqlite`, mainly in `cal_events`, with some related data in companion tables.

In a typical Lightning/Thunderbird calendar DB:

- `cal_events` holds one row per event (plus tasks), with columns like:
    - `id` (event UID)
    - `cal_id` (which calendar it belongs to)
    - `title`, `priority`, `privacy`
    - `event_start`, `event_end`, `event_stamp` (timestamps, usually stored as Unix time)
    - `event_start_tz`, `event_end_tz` (timezone info)
- Other tables (for example, alarms or recurrence data) reference the event by its `id`/`cal_id`, but the core details (summary, times, etc.) live in `cal_events`.[^1_1][^1_3][^1_5]

If you open `local.sqlite` with `sqlite3` or a GUI, `SELECT * FROM cal_events LIMIT 5;` is usually the quickest way to see the stored event data.
<span style="display:none">[^1_10][^1_2][^1_4][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://support.mozilla.org/en-US/questions/1103992

[^1_2]: https://www.youtube.com/watch?v=VzUHeLsJOrs

[^1_3]: https://support.mozilla.org/gl/questions/1103992

[^1_4]: https://club.ministryoftesting.com/t/how-can-i-view-the-contents-of-the-local-sqlite-database/79936

[^1_5]: http://forums.mozillazine.org/viewtopic.php?t=2461673

[^1_6]: https://sqlite.org/forum/info/ac1d837c8a496987fe7f49f04875786e581d1c5144725bbccfa5f4b88b8d31bf

[^1_7]: https://de.openoffice.info/viewtopic.php?t=31715

[^1_8]: https://stackoverflow.com/questions/5074273/where-is-sqlite-database-stored-on-disk

[^1_9]: https://groups.google.com/g/mozilla.support.calendar/c/99R5mhWBAi4

[^1_10]: https://sqlite.org/forum/info/4c7228516d012f7f


---

# Ah sorry oopsie should have scrolled the table a little bit more to the right ... ok cal_calendar_schema_version v22 handy for a quick check to see where thunderbird is at odd though can't find the table that has the 'Location' field ...

The event **location** is stored as a property in a separate table, not as a direct column in `cal_events`.

In `local.sqlite`:

- `cal_events` has core fields (title, start/end, etc.) and an `id` for each item.[^2_2][^2_8]
- Extra fields like Location are stored as key/value properties, typically in a table such as `cal_properties` (naming can vary a bit by version), linked by `item_id` (the event `id`) and a `key` column like `LOCATION`.[^2_8][^2_2]

So if you want to see locations, you usually:

- Look up events in `cal_events` to get their `id`.
- Join or query the properties table: for example, “all properties where `key = 'LOCATION'` for that `item_id`.”[^2_2][^2_8]

That’s why you don’t see a “location” column when you scroll across `cal_events`; it’s in the related properties table instead.
<span style="display:none">[^2_1][^2_10][^2_3][^2_4][^2_5][^2_6][^2_7][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://groups.google.com/g/mozilla.dev.apps.thunderbird/c/yqmms-lGmzw

[^2_2]: https://support.mozilla.org/gl/questions/1103992

[^2_3]: https://forums.mozillazine.org/viewtopic.php?t=728135

[^2_4]: https://www.cs.stonybrook.edu/students/technical-faqs/how-add-calendar-thunderbird-email-client

[^2_5]: https://www.youtube.com/watch?v=htnHM6T2PYc

[^2_6]: https://forum.manjaro.org/t/where-is-the-thunderbird-calendar-list/162279

[^2_7]: https://www.icdsoft.com/en/kb/view/1677_configuring_thunderbird_lightning_caldav

[^2_8]: https://support.mozilla.org/en-US/questions/1169200

[^2_9]: https://forums.mozillazine.org/viewtopic.php?t=1021905

[^2_10]: https://services.addons.thunderbird.net/En-Us/thunderbird/addon/lightning-calendar-tabs/versions/


---

# Hmm cryptic : cal_properties > key > value : values is (blob) ... ah never mind my mini me sqlite viewer can quite deal with the table. Switched db browser for sqlite value is no longer a blob intresting structure a stacked record : 6f4a6222-4a01-4383-b08b-6f1778537221	TRANSP	OPAQUE			c5ee7959-221d-465b-8822-1b2c6df078a2

6f4a6222-4a01-4383-b08b-6f1778537221	LOCATION	amazing oriental			c5ee7959-221d-465b-8822-1b2c6df078a2
6f4a6222-4a01-4383-b08b-6f1778537221	X-MOZ-GENERATION	3			c5ee7959-221d-465b-8822-1b2c6df078a2
6f4a6222-4a01-4383-b08b-6f1778537221	CATEGORIES	Personal			c5ee7959-221d-465b-8822-1b2c6df078a2

Exactly, you’ve read that structure right.

For Lightning/Thunderbird:

- The first UUID is the **item/event id**.
- `key` is the property name (`LOCATION`, `TRANSP`, `CATEGORIES`, etc.).
- `value` is the actual content (`amazing oriental`, `OPAQUE`, `Personal`, etc.).
- The last UUID is the **calendar id** that the event belongs to.

So an event is basically “core row in `cal_events` + stacked rows in `cal_properties`,” and properties like Location, Categories, and transparency are just separate key/value records tied together by that item id and calendar id.

