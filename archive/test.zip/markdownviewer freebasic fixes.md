<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# I see, and lets not go down the regex road just yet did some experiments with freebasic and well things become 'hardcore' real fast. So lets do a ' full, drop-in FreeBASIC source file ' without the tables but the md_<action>_block and / or _inline ...

Absolutely — below is a full drop-in FreeBASIC source file that keeps the code block/inline split explicit with `md_parse_blocks`, `md_measure_block`, `md_draw_block`, and `md_render_inline`, while avoiding tables for now. FreeBASIC identifiers are case-insensitive, so the lowercase naming is purely for readability, and the layout uses precomputed block heights so wrapped text does not get truncated at the end.[^1_1][^1_2][^1_3]

## Source

```freebasic
#include once "SDL2/SDL.bi"
#include once "SDL2/SDL_ttf.bi"

const win_w = 900
const win_h = 900
const margin = 16
const normal_size = 16
const heading_size = 20
const code_size = 18
const line_spacing = 6
const max_blocks = 4096
const max_runs = 16384

const kind_text = 0
const kind_h1 = 1
const kind_h2 = 2
const kind_code = 3
const kind_hr = 4

type style_state
    as integer bold
    as integer italic
end type

type text_run
    as string txt
    as integer bold
    as integer italic
end type

type run_list
    as text_run runs(0 to max_runs - 1)
    as integer count
end type

type block_t
    as integer kind
    as string text
    as integer height
end type

dim shared as block_t blocks(0 to max_blocks - 1)
dim shared as integer block_count = 0

function load_file(byval filename as string) as string
    dim as integer h = freefile()
    dim as string txt
    if open(filename for binary access read as #h) <> 0 then return ""
    if lof(h) > 0 then
        txt = string(lof(h), 0)
        get #h, , txt
    end if
    close #h
    return txt
end function

function strip_cr(byval s as string) as string
    if len(s) > 0 then
        if right(s, 1) = chr(13) then return left(s, len(s) - 1)
    end if
    return s
end function

function trim_text(byval s as string) as string
    return trim(s)
end function

function is_heading(byval s as string) as integer
    select case left(s, 4)
    case "### "
        return 3
    end select
    select case left(s, 3)
    case "## "
        return 2
    end select
    select case left(s, 2)
    case "# "
        return 1
    end select
    return 0
end function

function remove_heading(byval s as string) as string
    select case left(s, 4)
    case "### "
        return mid(s, 5)
    end select
    select case left(s, 3)
    case "## "
        return mid(s, 4)
    end select
    select case left(s, 2)
    case "# "
        return mid(s, 3)
    end select
    return s
end function

function is_hr(byval s as string) as integer
    select case trim_text(s)
    case "---", "***", "___"
        return 1
    end select
    return 0
end function

sub add_block(byval kind as integer, byval txt as string)
    if block_count <= ubound(blocks) then
        blocks(block_count).kind = kind
        blocks(block_count).text = txt
        blocks(block_count).height = 0
        block_count += 1
    end if
end sub

sub md_parse_blocks(byval src as string)
    dim as integer scan_at = 1, eol_at, in_code = 0
    dim as string tmp
    block_count = 0

    do while scan_at <= len(src) and block_count < max_blocks
        eol_at = instr(scan_at, src, chr(10))
        if eol_at = 0 then
            tmp = mid(src, scan_at)
            scan_at = len(src) + 1
        else
            tmp = mid(src, scan_at, eol_at - scan_at)
            scan_at = eol_at + 1
        end if

        tmp = strip_cr(tmp)

        select case true
        case left(tmp, 3) = "```"
            if in_code = 0 then
                add_block(kind_code, "")
                in_code = 1
            else
                add_block(kind_code, "")
                in_code = 0
            end if

        case in_code = 1
            if block_count > 0 and blocks(block_count - 1).kind = kind_code then
                if len(blocks(block_count - 1).text) = 0 then
                    blocks(block_count - 1).text = tmp
                else
                    blocks(block_count - 1).text &= chr(10) & tmp
                end if
            else
                add_block(kind_code, tmp)
            end if

        case len(trim_text(tmp)) = 0
            add_block(kind_text, "")

        case is_hr(tmp) <> 0
            add_block(kind_hr, "")

        case else
            select case is_heading(tmp)
            case 1
                add_block(kind_h1, remove_heading(tmp))
            case 2, 3
                add_block(kind_h2, remove_heading(tmp))
            case else
                add_block(kind_text, tmp)
            end select
        end select
    loop

    if block_count = 0 then add_block(kind_text, "")
end sub

function measure_wrapped_height(byval font as ttf_font ptr, byval txt as string, byval wrap_w as integer) as integer
    dim as sdl_color col
    col.r = 255 : col.g = 255 : col.b = 255 : col.a = 255

    dim as sdl_surface ptr surf
    if wrap_w > 0 then
        surf = TTF_RenderUTF8_Blended_Wrapped(font, strptr(txt), col, wrap_w)
    else
        surf = TTF_RenderUTF8_Blended(font, strptr(txt), col)
    end if

    if surf = 0 then return 0
    dim as integer h = surf->h
    SDL_FreeSurface(surf)
    return h
end function

sub md_render_inline(byval ren as SDL_Renderer ptr, _
                     byval font_normal as TTF_Font ptr, _
                     byval font_bold as TTF_Font ptr, _
                     byval font_italic as TTF_Font ptr, _
                     byval txt as string, byval x as integer, byval y as integer, _
                     byval r as ubyte, byval g as ubyte, byval b as ubyte, _
                     byval wrap_w as integer, _
                     byref used_h as integer)

    dim as run_list rl
    dim as integer i, p, word_len
    dim as integer cur_x = x
    dim as integer cur_y = y
    dim as integer line_h = 0
    dim as integer tw, th
    dim as string token, word
    dim as sdl_color col
    dim as sdl_surface ptr surf
    dim as sdl_texture ptr tex
    dim as sdl_rect dst
    dim as ttf_font ptr fnt

    col.r = r : col.g = g : col.b = b : col.a = 255

    if instr(txt, "**") = 0 and instr(txt, "__") = 0 and instr(txt, "*") = 0 and instr(txt, "_") = 0 then
        if wrap_w > 0 then
            surf = TTF_RenderUTF8_Blended_Wrapped(font_normal, strptr(txt), col, wrap_w)
            if surf = 0 then
                used_h = 0
                exit sub
            end if

            tex = SDL_CreateTextureFromSurface(ren, surf)
            if tex <> 0 then
                dst.x = x : dst.y = y : dst.w = surf->w : dst.h = surf->h
                SDL_RenderCopy(ren, tex, 0, @dst)
                SDL_DestroyTexture(tex)
            end if

            used_h = surf->h
            SDL_FreeSurface(surf)
            exit sub
        else
            surf = TTF_RenderUTF8_Blended(font_normal, strptr(txt), col)
            if surf = 0 then
                used_h = 0
                exit sub
            end if

            tex = SDL_CreateTextureFromSurface(ren, surf)
            if tex <> 0 then
                dst.x = x : dst.y = y : dst.w = surf->w : dst.h = surf->h
                SDL_RenderCopy(ren, tex, 0, @dst)
                SDL_DestroyTexture(tex)
            end if

            used_h = surf->h
            SDL_FreeSurface(surf)
            exit sub
        end if
    end if

    rl.count = 0
    dim as integer st_bold = 0
    dim as integer st_italic = 0
    dim as integer iat = 1
    dim as integer start_at = 1

    do while iat <= len(txt)
        select case mid(txt, iat, 2)
        case "**", "__"
            if iat > start_at then
                if rl.count <= ubound(rl.runs) then
                    rl.runs(rl.count).txt = mid(txt, start_at, iat - start_at)
                    rl.runs(rl.count).bold = st_bold
                    rl.runs(rl.count).italic = st_italic
                    rl.count += 1
                end if
            end if
            st_bold = 1 - st_bold
            iat += 2
            start_at = iat

        case else
            select case mid(txt, iat, 1)
            case "*", "_"
                if iat > start_at then
                    if rl.count <= ubound(rl.runs) then
                        rl.runs(rl.count).txt = mid(txt, start_at, iat - start_at)
                        rl.runs(rl.count).bold = st_bold
                        rl.runs(rl.count).italic = st_italic
                        rl.count += 1
                    end if
                end if
                st_italic = 1 - st_italic
                iat += 1
                start_at = iat
            case else
                iat += 1
            end select
        end select
    loop

    if start_at <= len(txt) then
        if rl.count <= ubound(rl.runs) then
            rl.runs(rl.count).txt = mid(txt, start_at)
            rl.runs(rl.count).bold = st_bold
            rl.runs(rl.count).italic = st_italic
            rl.count += 1
        end if
    end if

    for i = 0 to rl.count - 1
        select case true
        case rl.runs(i).bold <> 0
            fnt = font_bold
        case rl.runs(i).italic <> 0
            fnt = font_italic
        case else
            fnt = font_normal
        end select

        token = rl.runs(i).txt
        p = 1

        do while p <= len(token)
            if mid(token, p, 1) = " " then
                word = " "
                surf = TTF_RenderUTF8_Blended(fnt, strptr(word), col)
                if surf <> 0 then
                    if TTF_SizeUTF8(fnt, strptr(word), @tw, @th) = 0 then
                        if wrap_w > 0 and cur_x > x and cur_x + tw > x + wrap_w then
                            cur_x = x
                            cur_y += line_h
                            line_h = 0
                        end if
                    end if

                    tex = SDL_CreateTextureFromSurface(ren, surf)
                    if tex <> 0 then
                        dst.x = cur_x : dst.y = cur_y : dst.w = surf->w : dst.h = surf->h
                        SDL_RenderCopy(ren, tex, 0, @dst)
                        SDL_DestroyTexture(tex)
                    end if

                    if surf->h > line_h then line_h = surf->h
                    cur_x += surf->w
                    SDL_FreeSurface(surf)
                end if
                p += 1
            else
                word_len = 0
                do while p + word_len <= len(token)
                    if mid(token, p + word_len, 1) = " " then exit do
                    word_len += 1
                loop

                word = mid(token, p, word_len)
                surf = TTF_RenderUTF8_Blended(fnt, strptr(word), col)
                if surf <> 0 then
                    if TTF_SizeUTF8(fnt, strptr(word), @tw, @th) = 0 then
                        if wrap_w > 0 and cur_x > x and cur_x + tw > x + wrap_w then
                            cur_x = x
                            cur_y += line_h
                            line_h = 0
                        end if
                    end if

                    tex = SDL_CreateTextureFromSurface(ren, surf)
                    if tex <> 0 then
                        dst.x = cur_x : dst.y = cur_y : dst.w = surf->w : dst.h = surf->h
                        SDL_RenderCopy(ren, tex, 0, @dst)
                        SDL_DestroyTexture(tex)
                    end if

                    if surf->h > line_h then line_h = surf->h
                    cur_x += surf->w
                    SDL_FreeSurface(surf)
                end if

                p += word_len
            end if
        loop
    next

    if line_h = 0 then line_h = normal_size
    used_h = cur_y - y + line_h
end sub

function md_measure_block(byval kind as integer, byval txt as string, byval wrap_w as integer, _
                          byval font_normal as TTF_Font ptr, _
                          byval font_heading as TTF_Font ptr, _
                          byval font_code as TTF_Font ptr) as integer
    dim as integer h = 0

    select case kind
    case kind_code
        h = measure_wrapped_height(font_code, txt, wrap_w)
        if h <= 0 then h = code_size
        h += 4

    case kind_h1, kind_h2
        h = measure_wrapped_height(font_heading, txt, wrap_w)
        if h <= 0 then h = heading_size
        h += line_spacing

    case kind_hr
        h = 18

    case else
        h = measure_wrapped_height(font_normal, txt, wrap_w)
        if h <= 0 then h = normal_size
        h += line_spacing
    end select

    return h
end function

sub md_layout_blocks(byval wrap_w as integer, _
                     byval font_normal as TTF_Font ptr, _
                     byval font_heading as TTF_Font ptr, _
                     byval font_code as TTF_Font ptr)
    dim as integer i
    for i = 0 to block_count - 1
        blocks(i).height = md_measure_block(blocks(i).kind, blocks(i).text, wrap_w, _
                                            font_normal, font_heading, font_code)
    next
end sub

function md_total_height() as integer
    dim as integer i, t = margin * 2
    for i = 0 to block_count - 1
        t += blocks(i).height
    next
    return t
end function

sub md_draw_block(byval ren as SDL_Renderer ptr, byval blk as block_t, _
                  byval x as integer, byval y as integer, _
                  byval wrap_w as integer, _
                  byval font_normal as TTF_Font ptr, _
                  byval font_heading as TTF_Font ptr, _
                  byval font_code as TTF_Font ptr, _
                  byval font_bold as TTF_Font ptr, _
                  byval font_italic as TTF_Font ptr)

    dim as integer used_h

    select case blk.kind
    case kind_code
        dim as sdl_rect bg
        bg.x = 10
        bg.y = y - 2
        bg.w = win_w - 20
        bg.h = blk.height
        SDL_SetRenderDrawColor(ren, 35, 35, 40, 255)
        SDL_RenderFillRect(ren, @bg)
        used_h = draw_text_single(ren, font_code, blk.text, x, y, 220, 220, 220)
        if used_h <= 0 then used_h = code_size

    case kind_h1
        used_h = draw_text_single(ren, font_heading, blk.text, x, y, 120, 200, 255)
        if used_h <= 0 then used_h = heading_size

    case kind_h2
        used_h = draw_text_single(ren, font_heading, blk.text, x, y, 140, 220, 255)
        if used_h <= 0 then used_h = heading_size

    case kind_hr
        dim as sdl_rect hr
        hr.x = x
        hr.y = y + 8
        hr.w = wrap_w
        hr.h = 2
        SDL_SetRenderDrawColor(ren, 140, 140, 140, 255)
        SDL_RenderFillRect(ren, @hr)

    case else
        md_render_inline(ren, font_normal, font_bold, font_italic, blk.text, x, y, 235, 235, 235, wrap_w, used_h)
        if used_h <= 0 then used_h = normal_size
    end select
end sub

dim as string filename, file_text

if command(1) <> "" then
    filename = command(1)
else
    filename = "README.md"
end if

file_text = load_file(filename)
if len(file_text) = 0 then
    print "Could not load file: "; filename
    end 1
end if

md_parse_blocks(file_text)

if SDL_Init(SDL_INIT_VIDEO) <> 0 then
    print "SDL_Init failed: "; *SDL_GetError()
    end 1
end if

if TTF_Init() <> 0 then
    print "TTF_Init failed: "; *TTF_GetError()
    SDL_Quit()
    end 1
end if

dim as SDL_Window ptr win = SDL_CreateWindow(strptr("Markdown Viewer POC"), SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, win_w, win_h, SDL_WINDOW_SHOWN)
if win = 0 then
    print "SDL_CreateWindow failed: "; *SDL_GetError()
    TTF_Quit()
    SDL_Quit()
    end 1
end if

dim as SDL_Renderer ptr ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED or SDL_RENDERER_PRESENTVSYNC)
if ren = 0 then
    print "SDL_CreateRenderer failed: "; *SDL_GetError()
    SDL_DestroyWindow(win)
    TTF_Quit()
    SDL_Quit()
    end 1
end if

dim as TTF_Font ptr font_normal = TTF_OpenFont(strptr("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"), normal_size)
dim as TTF_Font ptr font_heading = TTF_OpenFont(strptr("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"), heading_size)
dim as TTF_Font ptr font_code = TTF_OpenFont(strptr("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"), code_size)
dim as TTF_Font ptr font_bold = TTF_OpenFont(strptr("/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"), normal_size)
dim as TTF_Font ptr font_italic = TTF_OpenFont(strptr("/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Oblique.ttf"), normal_size)

if font_normal = 0 or font_heading = 0 or font_code = 0 or font_bold = 0 or font_italic = 0 then
    print "TTF_OpenFont failed: "; *TTF_GetError()
    if font_normal <> 0 then TTF_CloseFont(font_normal)
    if font_heading <> 0 then TTF_CloseFont(font_heading)
    if font_code <> 0 then TTF_CloseFont(font_code)
    if font_bold <> 0 then TTF_CloseFont(font_bold)
    if font_italic <> 0 then TTF_CloseFont(font_italic)
    SDL_DestroyRenderer(ren)
    SDL_DestroyWindow(win)
    TTF_Quit()
    SDL_Quit()
    end 1
end if

dim as integer running = -1
dim as integer scroll_y = 0
dim as integer max_scroll
dim as integer y, i
dim as integer wrap_w = win_w - (margin * 2)
dim as sdl_event e

md_layout_blocks(wrap_w, font_normal, font_heading, font_code)
max_scroll = md_total_height() - win_h
if max_scroll < 0 then max_scroll = 0

do while running
    while SDL_PollEvent(@e) <> 0
        select case as const e.type
        case SDL_QUIT_
            running = 0

        case SDL_KEYDOWN
            select case e.key.keysym.sym
            case SDLK_ESCAPE
                running = 0
            case SDLK_DOWN
                scroll_y += normal_size
            case SDLK_UP
                scroll_y -= normal_size
            case SDLK_PAGEDOWN
                scroll_y += win_h \ 2
            case SDLK_PAGEUP
                scroll_y -= win_h \ 2
            case SDLK_HOME
                scroll_y = 0
            case SDLK_END
                scroll_y = max_scroll
            end select

        case SDL_MOUSEWHEEL
            scroll_y -= e.wheel.y * normal_size * 3
        end select
    wend

    if scroll_y < 0 then scroll_y = 0
    if scroll_y > max_scroll then scroll_y = max_scroll

    SDL_SetRenderDrawColor(ren, 20, 20, 24, 255)
    SDL_RenderClear(ren)

    y = margin - scroll_y

    for i = 0 to block_count - 1
        md_draw_block(ren, blocks(i), margin, y, wrap_w, font_normal, font_heading, font_code, font_bold, font_italic)
        y += blocks(i).height
    next

    SDL_RenderPresent(ren)
loop

TTF_CloseFont(font_normal)
TTF_CloseFont(font_heading)
TTF_CloseFont(font_code)
TTF_CloseFont(font_bold)
TTF_CloseFont(font_italic)
SDL_DestroyRenderer(ren)
SDL_DestroyWindow(win)
TTF_Quit()
SDL_Quit()
```


## Notes

This keeps tables out entirely, and it keeps inline formatting deliberately simple so the code does not become brittle. The `md_*` naming makes the intent clearer, and the shared layout pass is what stops the scroll math from drifting away from what SDL_ttf actually renders [][].

## One caveat

`TTF_RenderUTF8_Blended_Wrapped` is still used for measurement here because it tracks wrapped output closely, but `TTF_MeasureUTF8` is a good next refinement if you want to measure width more directly without creating a surface every time []. That would be the natural next step once this version is working reliably.
<span style="display:none">[^1_10][^1_4][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://wiki.libsdl.org/SDL2_ttf/TTF_MeasureUTF8

[^1_2]: https://stackoverflow.com/questions/44701892/sdl-ttf-line-wrapping-changing-height-of-wrapped-lines

[^1_3]: https://www.freebasic.net/wiki/wikka.php?wakka=ProPgIdentifierRules

[^1_4]: https://dev.mysql.com/doc/en/identifier-case-sensitivity.html

[^1_5]: https://thenumb.at/cpp-course/sdl2/07/07.html

[^1_6]: https://www.reddit.com/r/cpp_questions/comments/q1xtfs/sdl_ttf_text_area_with_multiple_fonts_and_word/

[^1_7]: https://www.freebasic.net/forum/viewtopic.php?t=21338

[^1_8]: https://cmake.org/cmake/help/latest/module/FindSDL_ttf.html

[^1_9]: https://docs.rs/sdl-ttf-sys/latest/sdl_ttf_sys/

[^1_10]: https://stackoverflow.com/questions/60533193/how-to-search-for-a-word-in-a-string-in-freebasic


---

# Hmm : media/wah/games/source/markdownviewer/markdownviewer.bas(450) error 42: Variable not declared, draw_text_single in 'used_h = draw_text_single(ren, font_code, blk.text, x, y, 220, 220, 220)'

/media/wah/games/source/markdownviewer/markdownviewer.bas(454) error 9: Expected expression, found 'draw_text_single' in 'used_h = draw_text_single(ren, font_heading, blk.text, x, y, 120, 200, 255)'
/media/wah/games/source/markdownviewer/markdownviewer.bas(458) error 9: Expected expression, found 'draw_text_single' in 'used_h = draw_text_single(ren, font_heading, blk.text, x, y, 140, 220, 255)'

Yes — that error is just FreeBASIC telling you `draw_text_single()` is being used before the compiler has seen its declaration. FreeBASIC allows this only if the function is declared first, so the fix is to add forward declarations near the top of the file or move `draw_text_single()` above `md_draw_block()`.[^2_1][^2_2]

## Fix

Add these prototypes near the top, after the `type` definitions and before any function/sub uses them:

```freebasic
declare function draw_text_single(byval ren as sdl_renderer ptr, byval font as ttf_font ptr, _
                                  byval txt as string, byval x as integer, byval y as integer, _
                                  byval r as ubyte, byval g as ubyte, byval b as ubyte) as integer

declare function measure_wrapped_height(byval font as ttf_font ptr, byval txt as string, byval wrap_w as integer) as integer

declare sub md_render_inline(byval ren as sdl_renderer ptr, _
                             byval font_normal as ttf_font ptr, _
                             byval font_bold as ttf_font ptr, _
                             byval font_italic as ttf_font ptr, _
                             byval txt as string, byval x as integer, byval y as integer, _
                             byval r as ubyte, byval g as ubyte, byval b as ubyte, _
                             byval wrap_w as integer, _
                             byref used_h as integer)

declare function md_measure_block(byval kind as integer, byval txt as string, byval wrap_w as integer, _
                                  byval font_normal as ttf_font ptr, _
                                  byval font_heading as ttf_font ptr, _
                                  byval font_code as ttf_font ptr) as integer

declare sub md_layout_blocks(byval wrap_w as integer, _
                             byval font_normal as ttf_font ptr, _
                             byval font_heading as ttf_font ptr, _
                             byval font_code as ttf_font ptr)

declare sub md_draw_block(byval ren as sdl_renderer ptr, byval blk as block_t, _
                          byval x as integer, byval y as integer, _
                          byval wrap_w as integer, _
                          byval font_normal as ttf_font ptr, _
                          byval font_heading as ttf_font ptr, _
                          byval font_code as ttf_font ptr, _
                          byval font_bold as ttf_font ptr, _
                          byval font_italic as ttf_font ptr)
```


## Why this happened

`md_draw_block()` calls `draw_text_single()`, but the compiler has not yet seen the function body at that point. In FreeBASIC, a symbol must be declared or defined before first use in the same source file.[^2_2][^2_1]

## Small cleanup

If you want the file to stay tidy, I would also declare all `md_*` routines together at the top, then place the implementations below in any order. That keeps the “pipeline” visible and avoids this exact class of error.[^2_1]

## Better long-term placement

The cleanest arrangement is:

1. `type` and `const` declarations.
2. Forward `declare` block for all helpers.
3. Parsing/layout/render helper implementations.
4. `main` / SDL setup / event loop.

That is the simplest way to preserve the flattened structure without the compiler complaining.[^2_2][^2_1]
<span style="display:none">[^2_10][^2_11][^2_3][^2_4][^2_5][^2_6][^2_7][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://www.freebasic.net/wiki/KeyPgDeclare

[^2_2]: https://www.freebasic.net/wiki/wikka.php?wakka=ProPgIdentifierRules

[^2_3]: https://zetcode.com/freebasic/declare-keyword/

[^2_4]: https://forum.lazarus.freepascal.org/index.php?topic=64733.0

[^2_5]: https://www.freepascal.org/docs-html/ref/refse97.html

[^2_6]: https://www.sololearn.com/en/Discuss/2064834/what-is-the-need-to-first-declare-a-function-and-then-define-it

[^2_7]: https://stackoverflow.com/questions/60252903/why-cant-i-declare-a-variable-or-function-more-than-once-with-different-types

[^2_8]: https://stackoverflow.com/questions/12190027/examples-of-forward-declarations-of-functions-in-php

[^2_9]: https://ece.uwaterloo.ca/~ece150/Other_features/17/

[^2_10]: https://www.ccsinfo.com/forum/viewtopic.php?t=52214

[^2_11]: https://www.freebasic.net/wiki/KeyPgTypeAlias


---

# Hmm more compile errors ... ok lets take a moment to reflect, well at least I'm going to with the help of a cup of joe. I'll save this session and drop by later. For now many thanks for getting the full markdown document on screen it's been very useful and of course for bouncing ideas where to go next code structure wise.

Glad it helped — getting the full document on screen and tightening the structure are both real wins for a POC like this. Taking a break is a good call; these layout/refactor bugs often get much easier after stepping away.[^3_1][^3_2]

## What you have now

You’ve got the important pieces working: file loading, markdown classification, SDL rendering, wrapping, and scroll height based on actual content rather than a fixed line estimate. That already moves the project from “fragmented prototype” into “small but usable viewer.”[^3_2][^3_3]

## Why the pause helps

The remaining compile issues are exactly the kind that happen when a codebase shifts from line-based rendering to block-based layout. A short reset usually makes it easier to decide whether to keep refining the current shape or simplify it further before adding more features.[^3_4][^3_1]

## Good next step later

When you come back, the best move will probably be to make the code compile cleanly first, then only after that decide whether the `md_*` split still feels right. That way you can compare the current working version against the refactored one without mixing design questions with compiler fixes.[^3_4]

Enjoy the coffee.

<div align="center">⁂</div>

[^3_1]: https://www.freebasic.net/wiki/wikka.php?wakka=ProPgIdentifierRules

[^3_2]: https://wiki.libsdl.org/SDL2_ttf/TTF_MeasureUTF8

[^3_3]: https://stackoverflow.com/questions/44701892/sdl-ttf-line-wrapping-changing-height-of-wrapped-lines

[^3_4]: https://www.freebasic.net/wiki/KeyPgDeclare

