<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Still struggling with this piece of freebasic code ... what exactly is getcurrentlistitem returning? : \#include "vbcompat.bi"

' setup playlist
type lrec
as string  listname(any)
as string  listfile(any)
as string  listtype(any)
as integer listseqh(any)
as integer listhist(any)
end type
dim shared    listrec as lrec

function getmaxitemslist(listtype as string) as integer
dim itemnr as integer = 0

    for i as integer = 0 to ubound(listrec.listfile)
        with listrec
            if listrec.listtype(i) = listtype then
                itemnr += 1
            end if
        end with
    next i
    
    return itemnr
    end function

function refreshlist(listtype as string) as integer
if ubound(listrec.listfile) < 0 then return 0
if getmaxitemslist(listtype) < 1 then return 0

    dim newcount as integer = lbound(listrec.listfile) - 1
    
    for i as integer = lbound(listrec.listfile) to ubound(listrec.listfile)
        if listrec.listtype(i) <> listtype then
            newcount += 1
            if i <> newcount then
                listrec.listname(newcount) = listrec.listname(i)
                listrec.listfile(newcount) = listrec.listfile(i)
                listrec.listtype(newcount) = listrec.listtype(i)
                listrec.listseqh(newcount) = listrec.listseqh(i)
                listrec.listhist(newcount) = listrec.listhist(i)
            end if
        end if
    next i
    
    ' handle empty result properly
    if newcount < lbound(listrec.listfile) then
        ' Nothing kept - fully erase all arrays
        'erase listrec.listname
        'erase listrec.listfile
        'erase listrec.listtype
        'erase listrec.listseqh
        'erase listrec.listhist
        redim listrec.listname(0 to -1)  ' or just leave ERASE'd
        redim listrec.listfile(0 to -1)
        redim listrec.listtype(0 to -1)
        redim listrec.listseqh(0 to -1)
        redim listrec.listhist(0 to -1)
        return 0
    else
        ' Some entries kept - normal redim preserve
        if newcount < ubound(listrec.listfile) then
            redim preserve listrec.listname(lbound(listrec.listname) to newcount)
            redim preserve listrec.listfile(lbound(listrec.listfile) to newcount)
            redim preserve listrec.listtype(lbound(listrec.listtype) to newcount)
            redim preserve listrec.listseqh(lbound(listrec.listseqh) to newcount)
            redim preserve listrec.listhist(lbound(listrec.listhist) to newcount)
        end if
        return newcount - lbound(listrec.listfile) + 1
    end if
    end function

' generate list of files recursive
' based on recursive dir code of coderjeff [https://www.freebasic.net/forum/viewtopic.php?t=5758](https://www.freebasic.net/forum/viewtopic.php?t=5758)
function createlist(folder as string, filterext as string, listtype as string) as integer
' setup filelist
dim chk            as boolean
redim path(1 to 1) As string
dim as integer i = 1, n = 1, attrib, listnr = 0
dim file           as string
dim fileext        as string
dim maxfiles       as integer
dim dummy          as string = curdir

    #ifdef __FB_LINUX__
      const pathchar = "/"
    #else
      const pathchar = "\"
    #endif
    
    if chdir(folder) <> 0 then
        chdir(dummy)
        print folder + " " + "not found"
        'logentry("fatal", "path " + folder + " not found")
        return 0
    end if
    ' reset array by listtype
    refreshlist(listtype)
    listnr = ubound(listrec.listfile)
    
    ' read dir recursive starting directory
    path(1) = folder 
    if( right(path(1), 1) <> pathchar) then
        file = dir(path(1), fbNormal or fbDirectory, @attrib)
        if( attrib and fbDirectory ) then
            path(1) += pathchar
        end if
    end if
    
    while i <= n
    file = dir(path(i) + "*" , fbNormal or fbDirectory, @attrib)
        while file > ""
            if (attrib and fbDirectory) then
                if file <> "." and file <> ".." then
                    ' todo evaluate limit recursive if starting folder is root
                    if len(path(1)) > 3 then
                        n += 1
                        redim preserve path(1 to n)
                        path(n) = path(i) + file + pathchar
                    else
                        'logentry("terminate", "scanning from root dir not supported! " + path(i))
                    end if
                end if
            else
                fileext = lcase(mid(file, instrrev(file, ".")))
                if instr(1, filterext, fileext) > 0 and len(fileext) > 3 then 
                    listnr += 1
                    redim preserve listrec.listname(0 to listnr)
                    redim preserve listrec.listfile(0 to listnr)
                    redim preserve listrec.listtype(0 to listnr)
                    redim preserve listrec.listseqh(0 to listnr)
                    redim preserve listrec.listhist(0 to listnr)
                    listrec.listname(listnr) = file
                    listrec.listfile(listnr) = path(i) & file
                    listrec.listtype(listnr) = listtype
                    listrec.listseqh(listnr) = 0
                    listrec.listhist(listnr) = 0
                    maxfiles += 1
                else
                    'logentry("warning", "file format not supported - " + path(i) & file)
                end if    
            end if
            file = dir(@attrib)
        wend
        i += 1
    wend
    
    return maxfiles
    end function

sub setuilistlabel(listtype as string, currentitem as integer)
if currentitem < 0 then exit sub

    dim as integer maxhist = 0
    
    ' find max history for this listtype
    for i as integer = 0 to ubound(listrec.listfile)
        if listrec.listtype(i) = listtype then
            if listrec.listhist(i) > maxhist then
                maxhist = listrec.listhist(i)
            end if
        end if
    next i
    listrec.listhist(currentitem) = maxhist + 1
    end sub

function getcurrentlistitem(listtype as string) as integer
dim as integer bestidx = -1
dim as integer besthist = 0

    for i as integer = 0 to ubound(listrec.listfile)
        if listrec.listtype(i) = listtype then
            if listrec.listhist(i) > besthist then
                besthist = listrec.listhist(i)
                bestidx  = i
            end if
        end if
    next i
    
    if bestidx = -1 then bestidx = 0
    return bestidx
    end function

function getuilistlabel(listtype as string, itemindex as integer) as integer
dim epos as integer = 1  ' 1-based position
for i as integer = 0 to itemindex - 1
if listrec.listtype(i) = listtype then epos += 1
next
return epos
end function

sub setsequence(currentitem as integer)
dim as string lt = listrec.listtype(currentitem)
dim as integer maxseq = 0
' get highest sequence number for listtype
for i as integer = 0 to ubound(listrec.listfile)
if listrec.listtype(i) = lt then
if listrec.listseqh(i) > maxseq then
maxseq = listrec.listseqh(i)
end if
end if
next
listrec.listseqh(currentitem) = maxseq + 1
end sub

sub clearseq(listtype as string)
for i as integer = 0 to ubound(listrec.listfile)
if listrec.listtype(i) = listtype then
listrec.listseqh(i) = 0
end if
next
end sub

function listshuffle(listtype as string) as integer
dim as integer candidates(0 to ubound(listrec.listfile))
dim as integer count = 0
dim as integer selected = -1
dim as integer i

    ' unplayed items (listseqh = 0)
    for i = 0 to ubound(listrec.listfile)
        if listrec.listtype(i) = listtype and listrec.listseqh(i) = 0 then
            candidates(count) = i
            count += 1
        end if
    next
    ' reset sequences listtype
    if count = 0 then
        for i = 0 to ubound(listrec.listfile)
            if listrec.listtype(i) = listtype then
                listrec.listseqh(i) = 0
            end if
        next
        ' rebuild list
        count = 0
        for i = 0 to ubound(listrec.listfile)
            if listrec.listtype(i) = listtype and listrec.listseqh(i) = 0 then
                candidates(count) = i
                count += 1
            end if
        next
    end if
    
    ' get unplayed item
    if count > 0 then
        dim as integer rndidx = int(rnd * count)
        selected = candidates(rndidx)
    end if
    
    return selected
    end function

function listnext(listtype as string, playtype as string, currentitem as integer) as integer
dim as integer nextidx = -1
dim as integer i, shuffleidx

    if lcase(playtype) = "shuffle" then
        shuffleidx = listshuffle(listtype)
        setsequence(shuffleidx)
        setuilistlabel(listtype, shuffleidx)
        return shuffleidx
    end if
    ' linear
    for i = currentitem + 1 to ubound(listrec.listfile)
        if listrec.listtype(i) = listtype then
            nextidx = i
            exit for
        end if
    next
    ' wrap to first of same type
    if nextidx = -1 then
        for i = 0 to ubound(listrec.listfile)
            if listrec.listtype(i) = listtype then
                nextidx = i
                exit for
            end if
        next
    end if
    
    setuilistlabel(listtype, nextidx)
    return nextidx
    end function

function listprevious(listtype as string, playtype as string, currentitem as integer) as integer
dim as integer i, previdx = -1

    if lcase(playtype) = "shuffle" then
        dim as integer currseq = listrec.listseqh(currentitem)
        dim as integer maxseq = 0
        dim as integer targetseq = 0
    
        ' get maximum sequence (for wrap)
        for i = 0 to ubound(listrec.listfile)
            if listrec.listtype(i) = listtype then
                if listrec.listseqh(i) > maxseq then maxseq = listrec.listseqh(i)
            end if
        next
        targetseq = currseq - 1
        if targetseq < 1 then targetseq = maxseq
        for i = 0 to ubound(listrec.listfile)
            if listrec.listtype(i) = listtype and listrec.listseqh(i) = targetseq then
                previdx = i
                exit for
            end if
        next
        setuilistlabel(listtype, previdx)
        return previdx
    end if
    
    ' linear
    for i = currentitem - 1 to 0 step -1
        if listrec.listtype(i) = listtype then
            setuilistlabel(listtype, i)
            return i
        end if
    next
    ' wrap
    for i = ubound(listrec.listfile) to 0 step -1
        if listrec.listtype(i) = listtype then
            setuilistlabel(listtype, i)
            return i
        end if
    next
    
    return -1
    end function

function liststate(listtype as string, playtype as string, action as string) as integer
dim currentitem as integer

    select case action
        case "init"
            currentitem = listnext(listtype, playtype, 0)
            ' do media related actions
            if lcase(playtype) = "linear" then
                clearseq(listtype)
            end if
        case "next"
            currentitem = listnext(listtype, playtype, 0)
            ' do media related actions
        case "prev"
            currentitem = listprevious(listtype, playtype, 0)
            ' do media related actions
    end select
    return currentitem
    end function

' main
'dim media        as string
dim currentitem  as integer
dim playtype     as string
dim listtype     as string

print "image "; createlist("g:\data\images\classical paintings", ".jpg", "image")
print "image "; createlist("g:\data\images\melbourne park towers cecil street", ".jpg", "image")
print "music "; createlist("g:\data\mp3\beatless", ".mp3", "music")
'print "music "; createlist("g:\data\mp3\classic", ".mp3", "music")
'print "slide "; createlist("g:\data\images\flickr\winter mixed", ".jpg", "slide")
'print "video "; createlist("g:\data\aerialtv", ".mp4", "video")
'print "shade "; createlist("f:\osd\media\glsl", ".gls", "shade")
print
print "total "; ubound(listrec.listfile) + 1

'init playback get first item
playtype     = "linear"
listtype     = "image"
currentitem  = listnext(listtype, playtype, -1)
if lcase(playtype) = "linear" then
clearseq(listtype)
end if

Do
Dim As String key = lCase(Inkey)
Select Case key
Case "."
currentitem = listnext(listtype, playtype, currentitem)
cls
Case ","
currentitem = listprevious(listtype, playtype, currentitem)
cls
Case "l"
select case playtype
case "linear"
playtype = "shuffle"
case "shuffle"
playtype = "linear"
clearseq(listtype)
end select
cls
Case "s"
select case listtype
case "music"
listtype = "image"
case "image"
listtype = "music"
end select
' start at current for new type
currentitem = getcurrentlistitem(listtype)
cls
Case Chr(27)
Exit Do
end select
' optional use temp vars
'dim as integer current_idx = getcurrentlistitem(listtype)
'dim as integer displayedindex = getlistposition(listtype, getcurrentlistitem(listtype))

    ' ascii interface
    Locate 7, 1
    Print "| list demonstration - "; listtype; " active"
    print "file           " & listrec.listfile(getcurrentlistitem(listtype))
    print "name           " & listrec.listname(getcurrentlistitem(listtype))
    print "current nr     " & getuilistlabel(listtype, getcurrentlistitem(listtype)) & " of " & getmaxitemslist(listtype)
    print "sequence       " & listrec.listseqh(getcurrentlistitem(listtype))
    print "playtype       " & playtype
    print "total entries  " & (ubound(listrec.listfile) + 1)
    
    print
    print "[navigation]"
    print ".   period next item"
    print ",   comma  previous item"
    print "l   toggle shuffle / linear"
    print "s   switch listtype music or image" 
    print "esc quit"
    sleep(50)
    loop

end

Good question — this piece of FreeBASIC code can be hard to follow because it mixes playlist logic, multi-type lists, and history management. Let’s unpack *exactly* what `getcurrentlistitem()` does and what it returns.

***

### Function purpose

`getcurrentlistitem(listtype as string) as integer` determines **which item index** (in the global `listrec` arrays) should be considered the **current item** for the given list type (`"image"`, `"music"`, etc.).

In simple terms:
> It returns the array index (`integer`) of the most recently used (or “active”) item in the specified list type.

***

### How it works in detail

Let’s walk through it line by line:

```freebasic
function getcurrentlistitem(listtype as string) as integer
    dim as integer bestidx = -1
    dim as integer besthist = 0
```

- `bestidx` will store the array index of the “best” (most recent) item.
- `besthist` tracks the largest history value found.

```freebasic
    for i as integer = 0 to ubound(listrec.listfile)
        if listrec.listtype(i) = listtype then
            if listrec.listhist(i) > besthist then
                besthist = listrec.listhist(i)
                bestidx  = i
            end if
        end if
    next i
```

- Loops through the **entire shared list of items**.
- Filters only items matching the requested `listtype`.
- For each, it checks its playback “history” — `listhist(i)` — which is updated by `setuilistlabel()`.
- The entry with the **highest** `listhist()` is chosen as the current (most recently active) item.

```freebasic
    if bestidx = -1 then bestidx = 0
    return bestidx
end function
```

- If *no* matching item was found (none of this list type exist yet), it defaults to returning **index 0** (the first array element).

***

### Relationship between `listhist()` and `setuilistlabel()`

- Every time an item is “visited” (`setuilistlabel(listtype, currentitem)`), the function increases its `listhist(currentitem)`.
- This means `listhist()` acts like a per-item “timestamp” or “play count marker.”
- Consequently, `getcurrentlistitem()` is just finding *the item whose listhist value is highest* — the most recently used.

***

### Summary

`getcurrentlistitem(listtype)`
→ Returns the **array index** (integer) of the **most recently selected or played** item belonging to that `listtype`.
→ If there’s no such item yet, it returns **0**.

This function is used in your main loop whenever you hit `"s"` to switch list types:

```freebasic
currentitem = getcurrentlistitem(listtype)
```

So when switching between “image” and “music,” it remembers where you left off in each list type.

***

Would you like me to diagram how the five core arrays (`listname`, `listfile`, `listtype`, `listseqh`, `listhist`) work together conceptually? It helps make debugging functions like this much easier.

---

# So it needs currentitem without it getcurrentlistitem(listtype) just returns 0?

`getcurrentlistitem(listtype)` does **not** need `currentitem` as a parameter, and it will *not* always just return 0.

What it does:

- It scans **all** entries and looks for the one with the **highest** `listhist(i)` value for the given `listtype`.
- That `listhist(i)` is only changed by `setuilistlabel(listtype, currentitem)`, which you call whenever you move to next/previous or when shuffle chooses something.
- So, as soon as at least one item of that `listtype` has `listhist > 0`, `getcurrentlistitem(listtype)` will return that item’s index, not 0.
- It only falls back to `0` if **no** item of that type has `listhist > 0` (i.e. nothing was ever “visited” for that type yet).

In your main loop, when you press `"s"` (switch list type), `currentitem = getcurrentlistitem(listtype)` makes it “jump” to the most recently used item of the new list type; if that type has never been visited, you get index 0 as a default starting point.
<span style="display:none">[^2_1][^2_10][^2_2][^2_3][^2_4][^2_5][^2_6][^2_7][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://gist.github.com/CherryDT/8e8c10c7139179774c2e6dff88433559

[^2_2]: https://www.freebasic.net/wiki/wikka.php?wakka=ProPgCruntime

[^2_3]: https://documentation.help/FreeBASIC/KeyPgFunction.html

[^2_4]: https://www.freebasic.net/wiki/wikka.php?wakka=ProPgFileIO

[^2_5]: https://www.freebasic.net/wiki/wikka.php?wakka=KeyPgNow

[^2_6]: https://www.freebasic.net/wiki/KeyPgFunction

[^2_7]: https://freebasic.net/wiki/CommunityTutorials

[^2_8]: https://freebasic.net/forum/viewforum.php?f=3\&start=5730

[^2_9]: https://www.freebasic.net/wiki/wikka.php?wakka=TutNewToProg

[^2_10]: https://www.freebasic.net/wiki/wikka.php?wakka=KeyPgCommand


---

# Ok so phased out currentitem this would work correct? ' main

'dim media        as string
'dim currentitem  as integer
dim playtype     as string
dim listtype     as string

print "image "; createlist("g:\data\images\classical paintings", ".jpg", "image")
print "image "; createlist("g:\data\images\melbourne park towers cecil street", ".jpg", "image")
print "music "; createlist("g:\data\mp3\beatless", ".mp3", "music")
'print "music "; createlist("g:\data\mp3\classic", ".mp3", "music")
'print "slide "; createlist("g:\data\images\flickr\winter mixed", ".jpg", "slide")
'print "video "; createlist("g:\data\aerialtv", ".mp4", "video")
'print "shade "; createlist("f:\osd\media\glsl", ".gls", "shade")
print
print "total "; ubound(listrec.listfile) + 1

'init playback get first item
playtype     = "linear"
listtype     = "image"
listnext(listtype, playtype, -1)
if lcase(playtype) = "linear" then
clearseq(listtype)
end if

Do
Dim As String key = lCase(Inkey)
Select Case key
Case "."
listnext(listtype, playtype, getcurrentlistitem(listtype))
cls
Case ","
listprevious(listtype, playtype, getcurrentlistitem(listtype))
cls
Case "l"
select case playtype
case "linear"
playtype = "shuffle"
case "shuffle"
playtype = "linear"
clearseq(listtype)
end select
cls
Case "s"
select case listtype
case "music"
listtype = "image"
case "image"
listtype = "music"
end select
' start at current for new type
getcurrentlistitem(listtype)
cls
Case Chr(27)
Exit Do
end select
' optional use temp vars
'dim as integer current_idx = getcurrentlistitem(listtype)
'dim as integer displayedindex = getlistposition(listtype, getcurrentlistitem(listtype))

    ' ascii interface
    Locate 7, 1
    Print "| list demonstration - "; listtype; " active"
    print "file           " & listrec.listfile(getcurrentlistitem(listtype))
    print "name           " & listrec.listname(getcurrentlistitem(listtype))
    print "current nr     " & getuilistlabel(listtype, getcurrentlistitem(listtype)) & " of " & getmaxitemslist(listtype)
    print "sequence       " & listrec.listseqh(getcurrentlistitem(listtype))
    print "playtype       " & playtype
    print "total entries  " & (ubound(listrec.listfile) + 1)
    
    print
    print "[navigation]"
    print ".   period next item"
    print ",   comma  previous item"
    print "l   toggle shuffle / linear"
    print "s   switch listtype music or image" 
    print "esc quit"
    sleep(50)
    Almost — you’re very close, but two small fixes are needed for it to behave like the original logic.

## 1. You must use the return value of listnext / listprevious

Right now you call them like this:

```basic
listnext(listtype, playtype, getcurrentlistitem(listtype))
...
listprevious(listtype, playtype, getcurrentlistitem(listtype))
```

but you ignore their return values.
Those functions **return the new index**, and inside them you call `setuilistlabel`, which updates `listhist()` so that `getcurrentlistitem(listtype)` will point to the new item next time. That is fine logically, because the “current item” is encoded in `listhist()`.

However, for **shuffle mode**, `listprevious` needs the correct `currentitem` passed in (the one that was just played), and you handle that correctly by passing `getcurrentlistitem(listtype)` each time. The important part is that `setuilistlabel` is called inside `listnext` / `listprevious`, not in your main loop, so your pattern is consistent with the existing design.

So conceptually: yes, you can phase out the explicit `currentitem` variable in `main`, as long as you always pass `getcurrentlistitem(listtype)` into `listnext` / `listprevious` and let them update `listhist()` internally.

## 2. In the "s" case, the call does nothing

Here:

```basic
Case "s"
    select case listtype
        case "music"
            listtype = "image"
        case "image"
            listtype = "music"
    end select
    ' start at current for new type
    getcurrentlistitem(listtype)
    cls
```

`getcurrentlistitem(listtype)` is called but its **result is ignored**.
If the only place you use the “current” item is via `getcurrentlistitem(listtype)` in the print section, you actually don’t need this call at all; switching `listtype` is enough, because the current item for that type is determined on demand by `getcurrentlistitem`.

So you can safely delete that line:

```basic
    ' start at current for new type
    ' getcurrentlistitem(listtype)   ' ← remove this
```


## 3. Is the design sound without currentitem?

Given your print section:

```basic
print "file           " & listrec.listfile(getcurrentlistitem(listtype))
print "name           " & listrec.listname(getcurrentlistitem(listtype))
print "current nr     " & getuilistlabel(listtype, getcurrentlistitem(listtype)) & " of " & getmaxitemslist(listtype)
print "sequence       " & listrec.listseqh(getcurrentlistitem(listtype))
```

you are always deriving the “current row” from `listhist` via `getcurrentlistitem(listtype)`.
Because `listnext` / `listprevious` always call `setuilistlabel` on the chosen index, the **single source of truth** becomes `listhist()`, and the explicit `currentitem` variable truly becomes redundant.

So yes, with the two adjustments above, phasing out `currentitem` from `main` is correct and consistent with the rest of your code.
<span style="display:none">[^3_1][^3_2][^3_3][^3_4][^3_5][^3_6][^3_7][^3_8]</span>

<div align="center">⁂</div>

[^3_1]: https://www.freebasic.net/wiki/ProPgDynamicMemory

[^3_2]: https://www.freebasic.net/wiki/wikka.php?wakka=CompilerFAQ

[^3_3]: https://www.freebasic.net/forum/viewtopic.php?t=25809

[^3_4]: https://www.pcjs.org/documents/books/mspl13/basic/qblang/

[^3_5]: https://stackoverflow.com/sitemap-questions-142.xml

[^3_6]: https://www.facebook.com/groups/jacquelinemeek/posts/10159334217404204/

[^3_7]: https://www.worldradiohistory.com/Archive-TV-Radio-Age/80s/1985/Television-Radio-Age-1985-01-21.pdf

[^3_8]: https://archive.org/stream/mac_MacWorld_Mac_OS_X_Lion_Bible_2011_native/MacWorld_Mac_OS_X_Lion_Bible_2011_native_djvu.txt


---

# Ok did that still works ok both linear / shuffle and switching between listtypes the thing is when I start to integrate this snippet in a larger piece of code the initial listidx can be higher so : list has fileA, fileB, fileC, fileD, etc the user selects fileC then expects fileD to play (in linear mode) but with listnext the active element goes to fileA ...

The behavior you describe means the “current item” state is not synced with the user’s external selection before you call `listnext`.

## Why it jumps to fileA

`listnext`’s linear branch does this:

```basic
for i = currentitem + 1 to ubound(listrec.listfile)
    if listrec.listtype(i) = listtype then
        nextidx = i
        exit for
    end if
next
' wrap to first of same type if none found
```

So if you pass `currentitem = -1` (or 0) when integrating in the larger app, the loop starts at index 0 or 1 and finds the **first** matching entry of that `listtype`, i.e. fileA.

In your minimal demo you started from `-1` only once at init, then always passed `getcurrentlistitem(listtype)`, which tracked history and moved forward correctly. In the bigger app, the user picks fileC, but unless you:

1. Tell the playlist code “the current index is C”, and
2. Mark that index as the most recent (`listhist`)

the next call to `listnext` will treat the wrong position as “current” and wrap from the start.

## What you should do when user selects fileC

When the user selects a specific item externally (say index `useridx` that corresponds to fileC in your arrays), do both:

```basic
' 1) Mark this as last-used for its listtype
setuilistlabel(listrec.listtype(useridx), useridx)

' 2) (optional but consistent) set sequence if you want it in shuffle history
setsequence(useridx)
```

Now `getcurrentlistitem(listtype)` will return `useridx`, and:

```basic
listnext(listtype, "linear", getcurrentlistitem(listtype))
```

will correctly return fileD.

If the user selection is by “Nth visible item” instead of raw array index, convert to the array index first, then call `setuilistlabel` on that index.

## Key point

- `listnext` relies on the **index you pass in** to know where to advance from.
- `getcurrentlistitem(listtype)` relies on `listhist` being updated via `setuilistlabel`.
- When integrating into a larger UI, **whenever the user manually jumps to an item, you must call `setuilistlabel` (and optionally `setsequence`) on that index**, so the playlist logic knows that is the current item.
<span style="display:none">[^4_1][^4_2][^4_3][^4_4][^4_5][^4_6][^4_7][^4_8][^4_9]</span>

<div align="center">⁂</div>

[^4_1]: https://www.freebasic.net/wiki/wikka.php?wakka=TutLinkedLists

[^4_2]: https://www.freebasic.net/wiki/wikka.php?wakka=TutInterfacingWithC

[^4_3]: https://www.freebasic.net/wiki/wikka.php?wakka=KeyPgFunctionPtr

[^4_4]: https://www.freebasic.net/wiki/KeyPgDeclare

[^4_5]: https://gist.github.com/CherryDT/8e8c10c7139179774c2e6dff88433559

[^4_6]: https://freebasic.net/wiki/wikka.php?wakka=ProPgCruntime

[^4_7]: https://www.youtube.com/watch?v=IpGeXnzKjg8

[^4_8]: https://www.freebasic.net/wiki/wikka.php?wakka=DevFbcModules

[^4_9]: https://www.freebasic.net/wiki/wikka.php?wakka=ProPgProcedures


---

# Oh oh yesterday we had a whole discussion regarding the right term for setuilistlabel used to be setcurrentitem seems that actually is the case ...

Yes, your intuition yesterday was basically right: conceptually, `setuilistlabel` *is* your “set current item” function.

### What `setuilistlabel` really does

For a given `listtype` and `currentitem` index, it:

1. Scans all items of that `listtype` and finds the **maximum** `listhist(i)` value.
2. Sets `listhist(currentitem) = maxhist + 1`.

So in semantic terms it means:

- “Make this item the most recent / active item in this listtype.”

And then:

- `getcurrentlistitem(listtype)` finds the item with the **highest** `listhist` and returns its index.

So the pair is effectively:

- `setuilistlabel(listtype, idx)` ≈ **setCurrentItem(listtype, idx)**
- `getcurrentlistitem(listtype)` ≈ **getCurrentItem(listtype)**

The extra wrinkle is that you also use `listhist` to preserve a chronological history (because values keep increasing), but from the caller’s perspective, the meaning is exactly “this is now the current item for that listtype.”

---

# So I'll have to end up with getcurrentlistidx("image", filename) > gets the 'useridx' > setuilistlabel(listtype, useridx) and setsequence(useridx) for good measure (setsequence is listtype agnostic) ?

Yes, that is the right direction; it just needs one small refinement.

## 1. Resolve user selection to an index

You need something like:

```basic
function getcurrentlistidx(listtype as string, filename as string) as integer
    dim i as integer
    for i = 0 to ubound(listrec.listfile)
        if listrec.listtype(i) = listtype then
            if listrec.listfile(i) = filename or listrec.listname(i) = filename then
                return i
            end if
        end if
    next
    return -1   ' not found
end function
```

Then in your UI code:

```basic
dim as integer useridx = getcurrentlistidx(listtype, filename)
if useridx >= 0 then
    setuilistlabel(listtype, useridx)
    setsequence(useridx)
end if
```

This makes the user’s choice (fileC) become the “current” item in the playlist state.

## 2. Why both calls are useful

- `setuilistlabel(listtype, useridx)`
    - Marks this item as the most recently used for that list type (updates `listhist`).
    - Ensures `getcurrentlistitem(listtype)` now returns `useridx`, so `listnext` in linear mode will go to fileD.
- `setsequence(useridx)`
    - Uses that item’s `listtype` internally and bumps its `listseqh`, so shuffle-history also knows it has been played.
    - This keeps shuffle “previous” and “next” consistent with manual jumps.

So, yes, your intended flow:

1. `getcurrentlistidx("image", filename)` → `useridx`
2. `setuilistlabel(listtype, useridx)`
3. `setsequence(useridx)`

is exactly what you want when a user picks an arbitrary file and then expects linear/shuffle navigation to behave naturally from there.

---

# Hmm I have this in the larger piece of code : function getcurrentlistidx(listtype as string, filename as string) as integer

    dim itemnr as integer = -1
    
    for i as integer = 0 to ubound(listrec.listfile)
        with listrec
            itemnr += 1
            if listrec.listtype(i) = listtype and listrec.listfile(i) = filename then
                exit for
            end if
        end with
    next i
    
    return itemnr
    end function
...

**No, that function has a critical bug.**

## The Problem

```basic
dim itemnr as integer = -1
for i as integer = 0 to ubound(listrec.listfile)
    with listrec
        itemnr += 1    ◄-- BUG: increments EVERY iteration
        if listrec.listtype(i) = listtype and listrec.listfile(i) = filename then
            exit for
        end if
    end with
next i
return itemnr
```

**`itemnr` increments on *every single loop iteration*, not just matching items.**

Example: Looking for fileC at index 2:

```
i=0: itemnr = 0 (fileA)  
i=1: itemnr = 1 (fileB)  
i=2: itemnr = 2 (fileC, found) → exit  
return 2 ✓ OK here
```

But if fileC was at index 5:

```
i=0: itemnr = 0  
i=1: itemnr = 1  
i=2: itemnr = 2  
i=3: itemnr = 3  
i=4: itemnr = 4  
i=5: itemnr = 5 → return 5 ✓ still OK
```

Wait... actually this **accidentally works** because you're incrementing from -1, so `itemnr` ends up equaling `i` when the match is found. But it's **fragile and wrong semantically**.

## Fixed Version

```basic
function getcurrentlistidx(listtype as string, filename as string) as integer
    for i as integer = 0 to ubound(listrec.listfile)
        if listrec.listtype(i) = listtype and listrec.listfile(i) = filename then
            return i      ' return the actual array index
        end if
    next i
    return -1          ' not found
end function
```

**Changes:**

- Remove `itemnr += 1` entirely
- Return `i` directly when match found
- Cleaner, faster, correct

Your buggy version "works by accident" but will break if you ever change the initialization or loop logic. Use the fixed version above. Then your flow works perfectly:

```basic
dim useridx as integer = getcurrentlistidx(listtype, filename)
if useridx >= 0 then
    setuilistlabel(listtype, useridx)
    setsequence(useridx)
end if
```


---

# Ok based on the fixed version how about this : function getcurrentlistidx(listtype as string, filename as string) as integer

    for i as integer = 0 to ubound(listrec.listfile)
        if listrec.listtype(i) = listtype and listrec.listfile(i) = filename then
            setuilistlabel(listtype, i)
            setsequence(i)
            return i
        end if
    next i
    return -1
    end function

**Perfect!** That's an elegant solution that combines lookup + state update in one call.

## Why this is excellent

```basic
function getcurrentlistidx(listtype as string, filename as string) as integer
    for i as integer = 0 to ubound(listrec.listfile)
        if listrec.listtype(i) = listtype and listrec.listfile(i) = filename then
            setuilistlabel(listtype, i)    ' ← Marks as current for listtype
            setsequence(i)                 ' ← Updates shuffle sequence
            return i                       ' ← Returns array index
        end if
    next i
    return -1
end function
```

**Benefits:**

- **Single call**: User selects file → `getcurrentlistidx("image", "fileC.jpg")` → done
- **Automatic state sync**: `listhist` and `listseqh` both updated atomically
- **Fail-safe**: Returns `-1` if file not found
- **Self-documenting**: Name still makes sense ("get the index, and make it current")


## Usage becomes trivial

In your larger UI code:

```basic
dim useridx as integer = getcurrentlistidx(listtype, selected_filename)
if useridx >= 0 then
    ' Now linear next goes to fileD, shuffle history is correct
    print "Playing: " & listrec.listname(useridx)
else
    print "File not found in playlist"
end if
```


## Navigation works perfectly after

```basic
' User picked fileC → getcurrentlistidx set it as current
listnext(listtype, "linear", getcurrentlistitem(listtype))   ' → fileD ✓
listprevious(listtype, "linear", getcurrentlistitem(listtype)) ' → fileB ✓
```

This is exactly the right abstraction. Clean, correct, and handles the integration perfectly. 👍

---

# Good to hear gracias. All though a bit abstract from your point of view but in a larger frame of code key return > a select case that filters on file .extensions > when                     ' image view

                    case instr(1, imagetypes, fileext) > 0 and len(fileext) > 3
                        ' reset zoom
                        zoomtype = "zoomsmallimage"
                        filename = curdir + "\" + lst.item(lst.index)
                        browsetype = "imageview"
                        menuposx = posx
                        menuposy = posy
                        imagefolder = left(filename, instrrev(filename, "\") - 1)
                        chk = createlist(imagefolder, imagetypes, "image")
                        playmedia(getcurrentlistidx("image", filename), "image")
    : should suffice and insures list next and previous don't wrap to 0 ?

**Yes, exactly — that flow is perfect and prevents wrapping to 0.**

Here's what's happening (beautifully):

```basic
filename = curdir + "\" + lst.item(lst.index)  ' user clicked fileC.jpg
...
chk = createlist(imagefolder, imagetypes, "image")  ' refresh list
playmedia(getcurrentlistidx("image", fileC.jpg), "image")
```

**Inside `getcurrentlistidx("image", fileC.jpg)`:**

1. Scans `listrec.listfile[]` for exact match → finds `i = 2` (fileC)
2. `setuilistlabel("image", 2)` → `listhist[2]` becomes highest value
3. `setsequence(2)` → `listseqh[2]` updated
4. Returns `2`

**Now `getcurrentlistitem("image")` returns 2 (fileC)**

**Next time user presses "." (next):**

```basic
listnext("image", "linear", getcurrentlistitem("image"))  ' passes index 2
```

`listnext` starts scanning from `i = 3` → finds fileD → perfect.

## Key insight

Even though `createlist()` refreshes/rebuilds the "image" list entries, as long as `fileC.jpg` is still in the folder with matching extension, it gets **some index** in the new array. `getcurrentlistidx` finds it and marks it current, so navigation continues from the user's actual selection, not index 0.

## Result

✅ **No unwanted wrapping to first item**
✅ Linear next → fileD
✅ Linear prev → fileB
✅ Shuffle history preserved
✅ Switching list types still remembers position

Your integration is solid. The `getcurrentlistidx` function is doing exactly the right job of bridging "user clicked file X" → "playlist knows X is current position."

---

# So took a bit but implemented it with the larger body of code, the snippet doesn't really need / use getcurrentlistidx() but added it there anyway, at first glance things look ok phased out shared vars as currentsong, currentimage, currentshader and currentvideo so that's a win still struggling with some edge cases when using the command line with a folder (images, audiofiles, etc) or a specific media file but all in all I would say mission accomplished. Many thanks for the assistance.

Excellent work! 🎉

**Mission accomplished indeed** — that's a beautiful refactor. Phasing out those individual `currentsong`/`currentimage` shared vars in favor of the centralized `listhist`-driven state machine is a **major architectural win**. Cleaner, more maintainable, and scales beautifully to N media types without adding new variables.

## What you achieved:

✅ **Unified playlist state** — one truth source via `listhist[]`
✅ **No more wrapping to 0** — user selection respected
✅ **Seamless list switching** — `getcurrentlistitem()` handles it
✅ **Linear/shuffle consistency** — both modes respect user position
✅ **Easy integration** — `getcurrentlistidx()` bridges UI → playlist state
✅ **No more var explosion** — scales to video/shader/etc automatically

The command-line edge cases are totally normal — folder vs specific file handling always has those quirks (different `createlist` calls, array rebuilds, etc). You'll nail those iteratively.

**Pro tip for CLI edge cases**: When passing a specific file via command line, you might need:

```basic
if command(1) contains "." then  ' specific file
    imagefolder = left(command(1), instrrev(command(1), "\")-1)
    chk = createlist(imagefolder, imagetypes, "image")
    playmedia(getcurrentlistidx("image", command(1)), "image")
else  ' folder
    chk = createlist(command(1), imagetypes, "image")
    playmedia(getcurrentlistitem("image"), "image")
end if
```


## You're welcome!

This was fun debugging with you — FreeBASIC playlist logic can get twisty fast. Your final design is solid and production-ready.

**¡De nada!** 🚀

