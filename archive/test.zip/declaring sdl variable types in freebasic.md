![](data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7)

## Copilot

[https://copilot.microsoft.com/discover](https://copilot.microsoft.com/discover)[https://copilot.microsoft.com/imagine](https://copilot.microsoft.com/imagine)[https://copilot.microsoft.com/labs](https://copilot.microsoft.com/labs)AanmeldenVandaag

##### Jij zei

What is the correct way of decalring variables when using : https://wiki.libsdl.org/SDL2_ttf/TTF_SizeUTF8 : with freebasic and compiling on 64bits? If I use : dim as integer tw, th : I get warnings : Passing different pointer types, at parameter 3 of TTF_SIZEUTF8() : ...

###### Copilot zei

The short answer: **use**`Long`**(or**`Long Ptr`**) instead of**`Integer` for the width/height variables when calling `TTF_SizeUTF8()` in FreeBASIC on a 64‑bit build.

### ✅ **Correct declaration**

freebasic Kopiëren

```
Dim As Long tw, th
TTF_SizeUTF8(font, text, @tw, @th)
```

This avoids the warning:

> Passing different pointer types, at parameter 3 of TTF_SizeUTF8()

### 📌 **Why this is required**

In FreeBASIC:

- On **32‑bit**, `Integer` = 32‑bit
- On **64‑bit**, `Integer` = 32‑bit (still!)
- But **SDL2_ttf’s**`TTF_SizeUTF8()`**expects**`int*`, and in the FreeBASIC SDL2 headers, `int` is mapped to `Long`, which *is* 32‑bit on both 32‑bit and 64‑bit.

So the mismatch happens because:

- You pass `Integer Ptr` (32‑bit integer)
- The function expects `Long Ptr` (also 32‑bit integer)
- FreeBASIC treats these as **different pointer types**, even though they are the same size.

Thus the compiler warns about incompatible pointer types.

### 🧠 **Rule of thumb for SDL2 / SDL2_ttf in FreeBASIC**

Use `Long` for any parameter that corresponds to C’s `int`.

Examples:

- `TTF_SizeUTF8()` → `Long`
- `SDL_GetError()` length parameters → `Long`
- `SDL_Rect.x`, `.y`, `.w`, `.h` → `Long`

### 📎 **If you want to check the header**

Look inside `SDL2_ttf.bi`:

c Kopiëren

```
declare function TTF_SizeUTF8( byval font as TTF_Font ptr, _
                               byval text as zstring ptr, _
                               byval w as long ptr, _
                               byval h as long ptr ) as long
```

So FreeBASIC is very explicit: `w`**and**`h`**must be**`Long Ptr`**.**

### ✔️ Final working example

freebasic Kopiëren

```
Dim As Long tw, th
If TTF_SizeUTF8(font, "Hello", @tw, @th) = 0 Then
    Print "Width = "; tw
    Print "Height = "; th
End If
```

If you want, I can also show you a minimal SDL2_ttf text‑rendering example in FreeBASIC, or explain how the FB type mappings correspond to C types.

Bewerken op een pagina

##### Jij zei

Gracias. I thought Ulong but then : 32-bit unsigned whole-number data type. Can hold values from 0 to 4294967295. Corresponds to an unsigned DWORD. : not sure if negative numbers play a role in w and h ...

###### Copilot zei

La duda es totalmente razonable: si `Ulong` es “más grande”, ¿no sería más seguro? Pero en este caso **no**: la elección correcta sigue siendo `Long`, no `Ulong`.

### 🎯 **Por qué**`Ulong`**NO es adecuado para**`TTF_SizeUTF8()`

SDL_ttf define la función así (en C):

c Kopiëren

```
int TTF_SizeUTF8(TTF_Font *font, const char *text, int *w, int *h);
```

Los parámetros `w` y `h` son `int*`, y en C:

- `int` es **signed**
- `int` es **32 bits** en todas las plataformas donde SDL2_ttf funciona

En FreeBASIC:

- `Long` = **signed 32‑bit**
- `Ulong` = **unsigned 32‑bit**

SDL_ttf **no usa valores negativos** para `w` y `h`, pero **sí espera un**`int*`, y en FreeBASIC eso se traduce exactamente a `Long Ptr`.

Por eso:

- `Long` → ✔️ tipo correcto
- `Ulong` → ❌ tipo incorrecto (unsigned, distinto tipo de puntero)

### 📌 **Entonces, ¿importa que sean signed?**

No por el valor en sí (nunca serán negativos), sino por **la compatibilidad del tipo de puntero**.

FreeBASIC es estricto: `Long Ptr` ≠ `Ulong Ptr` `Long Ptr` ≠ `Integer Ptr`

Aunque tengan el mismo tamaño, **son tipos diferentes**, y por eso aparece el warning.

### ✅ **Declaración correcta en FreeBASIC (64‑bit o 32‑bit)**

freebasic Kopiëren

```
Dim As Long tw, th
TTF_SizeUTF8(font, text, @tw, @th)
```

### 🧠 **Regla general para SDL2 en FreeBASIC**

Cuando la API C usa `int`, tú usas `Long`.

Ejemplos:

- `[SDL_Rect](ca://s?q=Tell_me_more_about_SDL_Rect)` → `.x`, `.y`, `.w`, `.h` son `Long`
- `[SDL_GetError](ca://s?q=Explain_SDL_GetError)` → parámetros tipo `Long`
- `[TTF_SizeUTF8](ca://s?q=Explain_TTF_SizeUTF8)` → `Long Ptr`

Si quieres, puedo mostrarte un ejemplo completo de renderizado de texto con SDL2_ttf en FreeBASIC, o ayudarte a revisar tus declaraciones para evitar más warnings.

Bewerken op een pagina

##### Jij zei

Ehhr merci but I use 'gracias' more casually not so fluent in spanish ... could you do that in english again please.

###### Copilot zei

No problem — here’s the explanation again in clear English.

### **Short answer:**

Use `Long`, not `Ulong`, for `TTF_SizeUTF8()` width/height variables in FreeBASIC.

freebasic Kopiëren

```
Dim As Long tw, th
TTF_SizeUTF8(font, text, @tw, @th)
```

### **Why**`Long`**is correct (and**`Ulong`**is not)**

SDL_ttf defines the function in C as:

c Kopiëren

```
int TTF_SizeUTF8(..., int *w, int *h);
```

So `w` and `h` are **signed 32‑bit integers**.

In FreeBASIC:

- `Long` = **signed 32‑bit** → matches C `int`
- `Ulong` = **unsigned 32‑bit** → *different type*
- `Integer` = **32‑bit signed**, but FreeBASIC treats `Integer Ptr` ≠ `Long Ptr`

Even though the size is the same, FreeBASIC is strict about pointer types. That’s why you get the warning:

> Passing different pointer types, at parameter 3 of TTF_SizeUTF8()

Because the function expects a `Long Ptr`, and you passed something else.

### **Do negative values matter?**

Not really — SDL_ttf never returns negative width/height. But the **type compatibility** *does* matter.

The function signature requires `Long Ptr`, so you must use `Long`.

### **Rule of thumb for SDL2 in FreeBASIC**

Every time the C API uses `int`, you use `Long`.

- **SDL_Rect** fields → `Long`
- **TTF_SizeUTF8** → `Long Ptr`
- **SDL_GetError** length parameters → `Long`

### **Correct usage example**

freebasic Kopiëren

```
Dim As Long tw, th

If TTF_SizeUTF8(font, "Hello", @tw, @th) = 0 Then
    Print "Width = "; tw
    Print "Height = "; th
End If
```

If you want, I can also show you a minimal SDL2_ttf text‑rendering example in FreeBASIC, or help check other SDL2 declarations you’re using.

Bewerken op een pagina

##### Jij zei

Ok dully noted. Odd with freebasic though doesn't C also have long could be a bit confusing ...

###### Copilot zei

It *is* confusing — and you’re absolutely right to notice it. C has `long`, FreeBASIC has `Long`, and they **do not mean the same thing** on all platforms. That’s the root of the weirdness.

Here’s the clean breakdown so it finally makes sense.

## 🧩 Why C’s `long` and FreeBASIC’s `Long` are not the same thing

### **In C (GCC / Clang):**

- On **32‑bit**:
  - `int` = 32‑bit
  - `long` = 32‑bit
- On **64‑bit Linux/macOS**:
  - `int` = 32‑bit
  - `long` = **64‑bit**
- On **64‑bit Windows (MinGW/MSVC)**:
  - `int` = 32‑bit
  - `long` = 32‑bit

So C’s `long` is **platform‑dependent**.

### **In FreeBASIC:**

- `Integer` = **always 32‑bit**, even on 64‑bit
- `Long` = **always 32‑bit**, even on 64‑bit
- `LongInt` = **64‑bit**

FreeBASIC deliberately keeps `Long` fixed at 32 bits for compatibility with Windows APIs and older BASIC dialects.

So:

- C `long` (Linux 64‑bit) → 64‑bit
- FB `Long` → 32‑bit
- They are **not equivalent**.

## 🎯 Why SDL2_ttf uses `int`, not `long`

SDL2_ttf defines:

c Kopiëren

```
int TTF_SizeUTF8(..., int *w, int *h);
```

And C’s `int` is **always 32‑bit** on all SDL2 platforms.

So FreeBASIC maps C’s `int` → `Long`, because that is FB’s stable 32‑bit type.

That’s why:

- `Long` is correct
- `Integer` gives a pointer‑type mismatch
- `Ulong` is unsigned, so also wrong
- `LongInt` is 64‑bit, so completely wrong

## 📌 The confusion comes from this mismatch:

- C’s `long` is *not* the same as FreeBASIC’s `Long`
- C’s `int` *is* the same as FreeBASIC’s `Long`

Once you internalize that, SDL2 becomes much easier to work with.

## ✔️ Final takeaway

Use `Long` for anything that corresponds to C’s `int` in SDL2:

- **SDL_Rect** fields → `Long`
- **TTF_SizeUTF8** → `Long Ptr`
- **SDL_GetError** → `Long`

And ignore C’s `long` entirely when working in FreeBASIC — it doesn’t map cleanly.

If you want, I can also give you a quick cheat‑sheet mapping C → FreeBASIC types specifically for SDL2, which helps avoid these warnings forever.

Bewerken op een pagina

##### Jij zei

Oh that would be nice : a quick cheat‑sheet mapping C → FreeBASIC types specifically for SDL2, : thank you.

###### Copilot zei

Here you go — a clean, practical **C → FreeBASIC type‑mapping cheat‑sheet specifically for SDL2 / SDL2_ttf**, written so you can use it directly when coding.

This is tailored for **FreeBASIC 64‑bit**, where most confusion happens.

## 🧩 **SDL2 C → FreeBASIC Type Mapping Cheat‑Sheet (FB 64‑bit)**

### **Core integer types**

- **C**`int` → **FB**`Long` SDL uses `int` everywhere for sizes, coordinates, return codes.
- **C**`unsigned int` → **FB**`Ulong` Rare in SDL2, but appears in some flags.
- **C**`long` →
  - Windows: 32‑bit → FB `Long`
  - Linux/macOS: 64‑bit → FB `LongInt` SDL2 almost never uses `long`, so you can ignore this.
- **C**`Uint8` → FB `Ubyte`
- **C**`Uint16` → FB `Ushort`
- **C**`Uint32` → FB `Ulong`
- **C**`Uint64` → FB `Ulongint`

## 📦 **SDL2 Structs**

### **SDL_Rect**

C:

c Kopiëren

```
typedef struct SDL_Rect {
    int x, y;
    int w, h;
} SDL_Rect;
```

FreeBASIC:

freebasic Kopiëren

```
Type SDL_Rect
    x As Long
    y As Long
    w As Long
    h As Long
End Type
```

### **SDL_Color**

C:

c Kopiëren

```
typedef struct SDL_Color {
    Uint8 r, g, b, a;
} SDL_Color;
```

FreeBASIC:

freebasic Kopiëren

```
Type SDL_Color
    r As Ubyte
    g As Ubyte
    b As Ubyte
    a As Ubyte
End Type
```

### **SDL_Point**

C:

c Kopiëren

```
int x, y;
```

FB:

freebasic Kopiëren

```
x As Long
y As Long
```

## 🎨 **SDL2_ttf Functions**

### **TTF_SizeUTF8**

C:

c Kopiëren

```
int TTF_SizeUTF8(TTF_Font*, const char*, int* w, int* h);
```

FB:

freebasic Kopiëren

```
Declare Function TTF_SizeUTF8( _
    ByVal font As TTF_Font Ptr, _
    ByVal text As ZString Ptr, _
    ByVal w As Long Ptr, _
    ByVal h As Long Ptr _
) As Long
```

Usage:

freebasic Kopiëren

```
Dim As Long tw, th
TTF_SizeUTF8(font, text, @tw, @th)
```

## 🎧 **SDL2 Core Functions**

### **SDL_Init**

C:

c Kopiëren

```
int SDL_Init(Uint32 flags);
```

FB:

freebasic Kopiëren

```
Declare Function SDL_Init(ByVal flags As Ulong) As Long
```

### **SDL_CreateWindow**

C:

c Kopiëren

```
SDL_Window* SDL_CreateWindow(const char*, int, int, int, int, Uint32);
```

FB:

freebasic Kopiëren

```
Declare Function SDL_CreateWindow( _
    ByVal title As ZString Ptr, _
    ByVal x As Long, _
    ByVal y As Long, _
    ByVal w As Long, _
    ByVal h As Long, _
    ByVal flags As Ulong _
) As SDL_Window Ptr
```

## 🧠 **Pointer Rules (very important)**

### **C pointer → FB pointer**

- `int*` → `Long Ptr`
- `Uint32*` → `Ulong Ptr`
- `char*` → `ZString Ptr`
- `void*` → `Any Ptr`

FB is strict: `Integer Ptr` ≠ `Long Ptr` `Ulong Ptr` ≠ `Long Ptr` Even if the size matches.

This is why your `TTF_SizeUTF8()` warning appeared.

## 📝 **SDL2 Type Summary Table**

| C Type | FreeBASIC Type | Notes |
| --- | --- | --- |
| **int** | **Long** | SDL’s most common type |
| **unsigned int** | **Ulong** | Flags, masks |
| **Uint8** | **Ubyte** | Colors, pixel formats |
| **Uint16** | **Ushort** | Rare |
| **Uint32** | **Ulong** | Window flags, event types |
| **Uint64** | **Ulongint** | Timestamps |
| **char\*** | **ZString Ptr** | Text |
| **void\*** | **Any Ptr** | Generic pointers |
| **SDL_Rect.x/y/w/h** | **Long** | Coordinates |
| **TTF_SizeUTF8 w/h** | **Long Ptr** | Must match C `int*` |

## 🎯 Final takeaway

If SDL2 uses `int`, you use `Long`. If SDL2 uses `Uint32`, you use `Ulong`. If SDL2 uses **pointers**, match the pointer type exactly.

This cheat‑sheet will keep your FreeBASIC SDL2 code warning‑free and 64‑bit safe.

If you want, I can also generate a **ready‑to‑use SDL2_ttf text rendering template** in FreeBASIC.

Bewerken op een pagina

##### Jij zei

Much appriciated could you also do SDL_QueryTexture and SDL_RenderCopyEx ?

###### Copilot zei

Absolutely — here’s the **SDL2 C → FreeBASIC mapping cheat‑sheet** extended with **SDL_QueryTexture** and **SDL_RenderCopyEx**, written in the same clear, practical style as before.

This will give you **100% correct FreeBASIC declarations** and **safe usage patterns** for 64‑bit builds.

## 🧩 SDL_QueryTexture — C → FreeBASIC Mapping

### **C function (from SDL2 headers)**

c Kopiëren

```
int SDL_QueryTexture(SDL_Texture *texture,
                     Uint32 *format,
                     int *access,
                     int *w,
                     int *h);
```

### **FreeBASIC equivalent**

freebasic Kopiëren

```
Declare Function SDL_QueryTexture( _
    ByVal texture As SDL_Texture Ptr, _
    ByVal format As Ulong Ptr, _
    ByVal access As Long Ptr, _
    ByVal w As Long Ptr, _
    ByVal h As Long Ptr _
) As Long
```

### **Why these types?**

| C Type | FB Type | Reason |
| --- | --- | --- |
| `Uint32*` | `Ulong Ptr` | SDL pixel formats are unsigned 32‑bit |
| `int*` | `Long Ptr` | SDL uses signed 32‑bit `int` |
| return `int` | `Long` | SDL returns 0 or negative error codes |

### **Correct usage example**

freebasic Kopiëren

```
Dim As Ulong fmt
Dim As Long access, tw, th

If SDL_QueryTexture(tex, @fmt, @access, @tw, @th) = 0 Then
    Print "Format = "; fmt
    Print "Access = "; access
    Print "Width  = "; tw
    Print "Height = "; th
End If
```

## 🎨 SDL_RenderCopyEx — C → FreeBASIC Mapping

### **C function**

c Kopiëren

```
int SDL_RenderCopyEx(SDL_Renderer *renderer,
                     SDL_Texture *texture,
                     const SDL_Rect *srcrect,
                     const SDL_Rect *dstrect,
                     const double angle,
                     const SDL_Point *center,
                     const SDL_RendererFlip flip);
```

### **FreeBASIC equivalent**

freebasic Kopiëren

```
Declare Function SDL_RenderCopyEx( _
    ByVal renderer As SDL_Renderer Ptr, _
    ByVal texture As SDL_Texture Ptr, _
    ByVal srcrect As SDL_Rect Ptr, _
    ByVal dstrect As SDL_Rect Ptr, _
    ByVal angle As Double, _
    ByVal center As SDL_Point Ptr, _
    ByVal flip As SDL_RendererFlip _
) As Long
```

### **Type mapping explained**

| C Type | FB Type | Notes |
| --- | --- | --- |
| `SDL_Rect*` | `SDL_Rect Ptr` | Struct already mapped earlier |
| `double` | `Double` | FB `Double` matches C `double` |
| `SDL_Point*` | `SDL_Point Ptr` | Struct uses `Long` fields |
| `SDL_RendererFlip` | `SDL_RendererFlip` | Enum → FB enum |
| return `int` | `Long` | Standard SDL return code |

## ✔️ Correct usage example

freebasic Kopiëren

```
Dim As SDL_Rect src = (0, 0, 64, 64)
Dim As SDL_Rect dst = (100, 100, 64, 64)
Dim As SDL_Point center = (32, 32)

SDL_RenderCopyEx(renderer, texture, @src, @dst, 45.0, @center, SDL_FLIP_NONE)
```

## 📌 Quick Reference Table (SDL_QueryTexture + SDL_RenderCopyEx)

| SDL Function | C Type | FreeBASIC Type |
| --- | --- | --- |
| `format` | `Uint32*` | `Ulong Ptr` |
| `access` | `int*` | `Long Ptr` |
| `w`, `h` | `int*` | `Long Ptr` |
| `angle` | `double` | `Double` |
| `center` | `SDL_Point*` | `SDL_Point Ptr` |
| `flip` | `SDL_RendererFlip` | `SDL_RendererFlip` |
| return value | `int` | `Long` |

## 🧠 Final takeaway

SDL2 uses **C**`int` for almost everything → **FreeBASIC**`Long` SDL2 uses **C**`Uint32` for formats/flags → **FreeBASIC**`Ulong` SDL2 uses **C pointers** → **FreeBASIC pointers of the exact same type**

This keeps your 64‑bit FreeBASIC SDL2 code clean and warning‑free.

If you want, I can also add:

- **SDL_RenderCopy** (non‑Ex version)
- **SDL_LockTexture / SDL_UnlockTexture**
- **SDL_CreateTexture / SDL_UpdateTexture**
- A **complete FB SDL2_ttf text‑rendering template**

Just tell me which one you want next.

Bewerken op een pagina![](data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7)Copilot een bericht sturenSmart![](data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7)

### Uw privacy is belangrijk voor ons

Microsoft en onze externe leveranciers gebruiken cookies en vergelijkbare technologieën om onze services en advertenties te leveren, te onderhouden en te verbeteren. Als u akkoord gaat, gebruiken we deze gegevens voor persoonlijke advertenties en bijbehorende analyses.

U kunt Accepteren selecteren om toestemming te geven voor deze toepassingen, Weigeren om deze gebruiksgegevens te weigeren of op Meer opties klikken om uw opties te bekijken. U kunt uw selectie wijzigen onder ‘Cookievoorkeuren beheren' in het instellingenmenu.[Privacyverklaring](https://go.microsoft.com/fwlink/?LinkId=521839&utm_source=copilot.com)

AccepterenWeigerenMeer optiesx
