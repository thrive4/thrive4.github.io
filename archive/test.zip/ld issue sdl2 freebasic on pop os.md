<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# What is your take on this : root@pop-os:/udev/fbc/bin\# dpkg -l | grep -i sdl

ii  libsdl2-2.0-0:amd64                            2.30.0+dfsg-1ubuntu3.1                                          amd64        Simple DirectMedia Layer : freebasic error : d: cannot find -lSDL2: No such file or directory

Compile Error...

Your SDL runtime package is installed, but the **development** linker target is missing. The error `cannot find -lSDL2` means the linker is looking for the unversioned `libSDL2.so` file, which normally comes from the `libsdl2-dev` package, not `libsdl2-2.0-0`.[^1_5][^1_8]

## What this means

- `libsdl2-2.0-0` provides the shared runtime library, such as `libSDL2-2.0.so.0`.
- `libsdl2-dev` provides the linkable development files, including `libSDL2.so` that `-lSDL2` resolves to.[^1_8][^1_5]


## Likely fix

Install the dev package:

```bash
sudo apt update
sudo apt install libsdl2-dev
```

Then try compiling again. If your FreeBASIC setup also needs the headers and pkg-config metadata, that package should cover it as well.[^1_5][^1_8]

## If it still fails

Check whether the linker can see the library directory and whether FreeBASIC is using the right library path. On Ubuntu-like systems, SDL2 libraries are commonly under `/usr/lib/x86_64-linux-gnu`, and build systems often need that path explicitly if they are not picking it up automatically.[^1_8][^1_5]

## Why this happened

Seeing `ii libsdl2-2.0-0` in `dpkg -l` only confirms the runtime is installed; it does not guarantee the compiler can link against SDL2. That exact “installed but cannot find `-lSDL2`” pattern is typical when the `-dev` package is missing.[^1_3][^1_6]
<span style="display:none">[^1_1][^1_10][^1_2][^1_4][^1_7][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://stackoverflow.com/questions/72356820/compiler-cant-find-sdl2-classes-how-to-properly-include-and-link-them

[^1_2]: https://stackoverflow.com/questions/29711336/libsdl2-2-0-so-0-cannot-open-shared-object-file/64332558

[^1_3]: https://www.volcengine.com/theme/2201237-U-7-1

[^1_4]: https://discourse.libsdl.org/t/cant-compile-sdl2-for-32-bit-on-64-bit-ubuntu-using-arm-gnu-toolchain/46423

[^1_5]: https://discourse.libsdl.org/t/does-anyone-static-link-sdl2/21377

[^1_6]: https://www.freebasic.net/forum/viewtopic.php?t=24813

[^1_7]: https://www.reddit.com/r/SDL2/comments/p67c9x/desperately_need_help_solving_error_cannot_find/

[^1_8]: https://github.com/FNA-XNA/FAudio/issues/109

[^1_9]: https://retropie.org.uk/forum/topic/34951/error-initializing-sdl-wayland-not-available

[^1_10]: http://forum.squareline.io/t/sls-exported-vscode-template-project-runtime-error-dyld-92608-library-not-loaded-rpath-sdl2-framework-versions-a-sdl2/2336

