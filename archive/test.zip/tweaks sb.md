<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# There is one slight snag with following javascript code it  generates the formated  json for saving as : [

{
"scene": "A",
"weather": "weather",
"location": "location",
"entityA": "entityA",
"poseA": "poseA",
"descriptionA": "descriptionA",
"entityB": "entityB",
"poseB": "poseB",
"descriptionB": "descriptionB",
"style": "style",
"renderstyle": "renderstyle",
"camera": "camera",
"seed": "seed",
"updated": "2026-01-08T21:33:25.611Z",
"private": false
}
]instead of : the format : {
"title": "My Storyboard",
"version": 1,
"lookup": "storyboardlkup.json",
"scenes":
[
{
"scene": "A",
"weather": "weather",
"location": "location",
"entityA": "entityA",
"poseA": "poseA",
"descriptionA": "descriptionA",
"entityB": "entityB",
"poseB": "poseB",
"descriptionB": "descriptionB",
"style": "style",
"renderstyle": "renderstyle",
"camera": "camera",
"seed": "seed",
"updated": "2025-10-15T15:30:32.539Z",
"private": false
}
]
}
: is it possible to fix this? : page : <!DOCTYPE html>

<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Storyboard Input Generator</title>
    <link rel="stylesheet" href="storyboard.css" />
</head>
<body>
  <h1>Storyboard Input Generator</h1>

  <div id="topControls">
    <button id="loadDefaultJsonBtn">Load JSON (sb/storyboard.json)</button>
    <button id="loadFileBtn">Load JSON from File</button>
    <input type="file" id="fileInput" accept=".json" />
    <div id="thumbnailContainer" title="Scene thumbnail">
      <span id="thumbnailAlt">No scene loaded</span>
      <img id="sceneThumbnail" src="" alt="Scene thumbnail" style="display:none" />
    </div>
  </div>

  <div id="content">No storyboard loaded.</div>

  <!-- Fullscreen Modal -->
  <div id="overlayModal" class="modal">
    <div class="modal-header">
      <div>
        <h2 id="modalTitle">Edit Field</h2>
        <div class="breadcrumb" id="modalBreadcrumb"></div>
      </div>
      ```
      <span id="closeModal" class="close">&times;</span>
      ```
    </div>
    <div class="modal-body">
      <div id="lookupSearchContainer" style="display:none;">
        <div class="search-row">
          <input type="text" id="lookupSearch" placeholder="Search options...">
          ```
          <button id="lookupSortBtn" title="Toggle sort (A-Z / Z-A)">??</button>
          ```
        </div>
        <ul id="lookupList"></ul>
      </div>
      <textarea id="modalTextarea" placeholder="Enter new value..."></textarea>
    </div>
    <div class="modal-footer">
      <button id="saveModalBtn">Save</button>
      <button id="cancelModalBtn">Cancel</button>
    </div>
  </div>

  <script>
    let currentStoryboardConfig = null;
    let currentStoryboard = [];
    let currentSceneKeysOrder = [];
    let currentLookupData = {};

    const sceneThumbnail = document.getElementById('sceneThumbnail');
    const thumbnailAlt = document.getElementById('thumbnailAlt');

    function getNowISOString() { return new Date().toISOString(); }

    function updateThumbnailForScene(sceneName) {
      if (!sceneName) {
        sceneThumbnail.style.display = 'none';
        thumbnailAlt.textContent = 'No scene loaded';
        return;
      }
      const imgSrc = `sb/${sceneName}.jpg`;
      sceneThumbnail.src = imgSrc;
      sceneThumbnail.style.display = 'inline-block';
      thumbnailAlt.textContent = sceneName + '.jpg';
      sceneThumbnail.alt = `Thumbnail for scene ${sceneName}`;
    }

    function renderSceneForm(sceneObj) {
      const container = document.getElementById('content');
      container.innerHTML = '';

      const sceneDiv = document.createElement('div');
      sceneDiv.className = 'scene';

      const sceneHeader = document.createElement('h2');
      sceneHeader.textContent = `Scene: ${sceneObj.scene || '(unknown)'}`;
      sceneDiv.appendChild(sceneHeader);

      const form = document.createElement('form');
      form.id = 'storyboardForm';

      currentSceneKeysOrder = Object.keys(sceneObj)
        .filter(k => k !== 'updated' && k !== 'private');
      currentSceneKeysOrder.sort((a,b) => (a === 'scene' ? -1 : b === 'scene' ? 1 : 0));

      currentSceneKeysOrder.forEach(key => {
        const groupDiv = document.createElement('div');
        groupDiv.className = 'input-group';

        const label = document.createElement('label');
        label.setAttribute('for', key);
        label.textContent = key;
        label.title = 'Click to edit this field (lookup or free text)';

        const input = document.createElement('input');
        input.type = 'text';
        input.id = key;
        input.name = key;
        input.value = sceneObj[key] !== undefined ? sceneObj[key] : '';

        label.addEventListener('click', () => openModalForInput(input, key, sceneObj.scene));

        groupDiv.appendChild(label);
        groupDiv.appendChild(input);
        form.appendChild(groupDiv);
      });

      const generateBtn = document.createElement('button');
      generateBtn.type = 'button';
      generateBtn.id = 'generateBtn';
      generateBtn.textContent = 'Generate';
      generateBtn.onclick = () => {
        const values = [];
        currentSceneKeysOrder.forEach(key => {
          if (key === 'scene') return;
          const val = form.elements[key].value.trim();
          if (val.length) values.push(val);
        });
        commaSeparatedOutput.value = values.join(', ');

        const newObj = {};
        currentSceneKeysOrder.forEach(key => {
          newObj[key] = form.elements[key].value;
        });
        newObj.updated = getNowISOString();
        newObj.private = false;
        generatedJsonOutput.value = JSON.stringify([newObj], null, 2);
      };
      form.appendChild(generateBtn);

      const labelPrompt = document.createElement('div');
      labelPrompt.className = 'output-label';
      labelPrompt.textContent = 'Prompt (comma-separated topic values):';
      form.appendChild(labelPrompt);

      const commaSeparatedOutput = document.createElement('textarea');
      commaSeparatedOutput.id = 'commaSeparatedOutput';
      commaSeparatedOutput.placeholder = 'Prompt will appear here...';
      form.appendChild(commaSeparatedOutput);

      const labelGenJson = document.createElement('div');
      labelGenJson.className = 'output-label';
      labelGenJson.textContent = 'Generated JSON (array with flat objects):';
      form.appendChild(labelGenJson);

      const generatedJsonOutput = document.createElement('textarea');
      generatedJsonOutput.id = 'generatedJsonOutput';
      generatedJsonOutput.readOnly = true;
      generatedJsonOutput.placeholder = 'Generated JSON appears here...';
      form.appendChild(generatedJsonOutput);

      const saveJsonBtn = document.createElement('button');
      saveJsonBtn.type = 'button';
      saveJsonBtn.id = 'saveJsonBtn';
      saveJsonBtn.textContent = 'Save JSON';
      saveJsonBtn.style.marginTop = '10px';
      saveJsonBtn.onclick = () => {
        const jsonString = generatedJsonOutput.value;
        let filename = 'scene.json';
        try {
          const parsed = JSON.parse(jsonString);
          if (Array.isArray(parsed) && parsed.length > 0 && parsed[0].scene) {
            filename = parsed[0].scene + '.json';
          }
        } catch {}
        const blob = new Blob([jsonString], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      };
      form.appendChild(saveJsonBtn);

      sceneDiv.appendChild(form);
      container.appendChild(sceneDiv);
      updateThumbnailForScene(sceneObj.scene);
    }

    function loadConfigFromText(jsonText) {
      const parsed = JSON.parse(jsonText);
      if (!parsed.scenes || !Array.isArray(parsed.scenes) || parsed.scenes.length === 0) {
        alert('Invalid JSON format: Expected an object with a non-empty "scenes" array');
        return;
      }
      currentStoryboardConfig = parsed;
      currentStoryboard = parsed.scenes;
      if (parsed.lookup) {
        loadLookupJson(parsed.lookup).then(() => {
          renderSceneForm(currentStoryboard[0]);
        }).catch(err => {
          console.error(err);
          alert('Failed to load lookup JSON, continuing without lookups.');
          currentLookupData = {};
          renderSceneForm(currentStoryboard[0]);
        });
      } else {
        currentLookupData = {};
        renderSceneForm(currentStoryboard[0]);
      }
    }

    async function loadLookupJson(lookupFileName) {
      const response = await fetch('sb/' + lookupFileName);
      if (!response.ok) throw new Error('Lookup fetch failed: ' + response.status);
      const text = await response.text();
      currentLookupData = JSON.parse(text);
    }

    async function loadDefaultJson() {
      try {
        const response = await fetch('sb/storyboard.json');
        if (!response.ok) throw new Error('Network response not ok');
        const text = await response.text();
        loadConfigFromText(text);
      } catch (e) {
        alert('Failed to load default storyboard.json: ' + e.message);
      }
    }

    document.getElementById('loadDefaultJsonBtn').addEventListener('click', loadDefaultJson);
    const fileInput = document.getElementById('fileInput');
    document.getElementById('loadFileBtn').addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', (event) => {
      const file = event.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (e) => {
        loadConfigFromText(e.target.result);
        fileInput.value = '';
      };
      reader.readAsText(file);
    });

    loadDefaultJson();

    // Modal Logic
    const modal = document.getElementById('overlayModal');
    const modalTitle = document.getElementById('modalTitle');
    const modalBreadcrumb = document.getElementById('modalBreadcrumb');
    const modalTextarea = document.getElementById('modalTextarea');
    const saveModalBtn = document.getElementById('saveModalBtn');
    const cancelModalBtn = document.getElementById('cancelModalBtn');
    const closeModal = document.getElementById('closeModal');
    const lookupSearchContainer = document.getElementById('lookupSearchContainer');
    const lookupSearch = document.getElementById('lookupSearch');
    const lookupSortBtn = document.getElementById('lookupSortBtn');
    const lookupList = document.getElementById('lookupList');

    let currentInput = null;
    let currentKey = null;
    let allLookupItems = [];
    let sortDirection = 'asc';

    function highlightMatch(text, term) {
      if (!term) return text;
      const regex = new RegExp(`(${term})`, 'gi');
      ```
      return text.replace(regex, '<span class="match-highlight">$1</span>');
      ```
    }

    function filterLookupList() {
      const term = lookupSearch.value.toLowerCase().trim();
      allLookupItems.forEach(item => {
        const matches = !term || item.dataset.originalText.toLowerCase().includes(term);
        item.classList.toggle('hidden', !matches);
        if (matches) {
          item.innerHTML = highlightMatch(item.dataset.originalText, term);
        }
      });
    }

    function sortLookupList() {
      const visibleItems = Array.from(allLookupItems).filter(item => !item.classList.contains('hidden'));
      const sorted = visibleItems.sort((a, b) => {
        const textA = a.dataset.originalText.toLowerCase();
        const textB = b.dataset.originalText.toLowerCase();
        return sortDirection === 'asc' ? textA.localeCompare(textB) : textB.localeCompare(textA);
      });
      
      sorted.forEach(item => lookupList.appendChild(item));
    }

    function openModalForInput(inputElement, key, sceneName = '') {
      currentInput = inputElement;
      currentKey = key;
      sortDirection = 'asc';
      lookupSortBtn.className = 'lookupSortBtn asc';
      
      modalTitle.textContent = `Editing Field: ${key}`;
      modalBreadcrumb.textContent = `Scene: ${sceneName || 'Unknown'} ? ${key}`;

      const options = currentLookupData && currentLookupData[key];
      if (Array.isArray(options) && options.length > 0) {
        lookupSearchContainer.style.display = 'flex';
        modalTextarea.style.display = 'none';
        lookupList.innerHTML = '';

        allLookupItems = [];
        options.forEach(opt => {
          const li = document.createElement('li');
          li.className = 'lookup-item';
          li.dataset.originalText = opt;
          li.innerHTML = opt;

          if (String(inputElement.value).trim() === String(opt).trim()) {
            li.classList.add('selected');
          }

          li.addEventListener('click', () => {
            allLookupItems.forEach(i => i.classList.remove('selected'));
            li.classList.add('selected');
            currentInput.value = opt;
          });

          lookupList.appendChild(li);
          allLookupItems.push(li);
        });

        lookupSearch.value = '';
        lookupSearch.focus();
        lookupSearch.addEventListener('input', filterLookupList);
        lookupSortBtn.onclick = () => {
          sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
          lookupSortBtn.className = `lookupSortBtn ${sortDirection}`;
          sortLookupList();
        };
      } else {
        lookupSearchContainer.style.display = 'none';
        lookupSearch.value = '';
        modalTextarea.style.display = 'block';
        modalTextarea.value = inputElement.value;
        modalTextarea.focus();
      }

      modal.style.display = 'flex';
    }

    function closeModalHandler() {
      modal.style.display = 'none';
      modalTextarea.value = '';
      lookupList.innerHTML = '';
      lookupSearch.value = '';
      allLookupItems = [];
      currentInput = null;
      currentKey = null;
      if (lookupSearch._listener) lookupSearch.removeEventListener('input', lookupSearch._listener);
    }

    function saveModalHandler() {
      if (currentInput && modalTextarea.style.display !== 'none') {
        currentInput.value = modalTextarea.value.trim();
      }
      closeModalHandler();
    }

    saveModalBtn.onclick = saveModalHandler;
    cancelModalBtn.onclick = closeModalHandler;
    closeModal.onclick = closeModalHandler;

    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeModalHandler();
    });
  </script>
</body>
</html>
Yes — the issue is that your current "Generate" button handler always wraps the new scene object inside an **array**, like this:

```js
generatedJsonOutput.value = JSON.stringify([newObj], null, 2);
```

That causes the file to be an array (`[...]`) instead of a proper top-level object with `"title"`, `"version"`, `"lookup"`, and `"scenes"` as keys.

You can fix it by modifying that part of the code to generate the full JSON object structure you want.
Here’s the minimal and correct change:

***

### ✅ Fixed section of JavaScript

Inside the function `renderSceneForm`, replace this block:

```js
newObj.updated = getNowISOString();
newObj.private = false;
generatedJsonOutput.value = JSON.stringify([newObj], null, 2);
```

with this:

```js
newObj.updated = getNowISOString();
newObj.private = false;

// Wrap scene object inside full storyboard structure
const storyboardObj = {
  title: currentStoryboardConfig?.title || "My Storyboard",
  version: currentStoryboardConfig?.version || 1,
  lookup: currentStoryboardConfig?.lookup || "storyboardlkup.json",
  scenes: [newObj]
};

generatedJsonOutput.value = JSON.stringify(storyboardObj, null, 2);
```


***

### Explanation

- You were producing an array (`[newObj]`) by default.
- The fixed snippet wraps that inside a parent object containing:
    - `"title"`: taken from the loaded config if available, or defaults to `"My Storyboard"`.
    - `"version"`: preserves existing version or defaults to 1.
    - `"lookup"`: uses the same lookup file as your loaded configuration.
    - `"scenes"`: wraps your single generated scene into an array — the correct format.

That will make the saved JSON look like:

```json
{
  "title": "My Storyboard",
  "version": 1,
  "lookup": "storyboardlkup.json",
  "scenes": [
    {
      "scene": "A",
      "weather": "weather",
      "location": "location",
      "entityA": "entityA",
      ...
      "updated": "2026-01-08T21:33:25.611Z",
      "private": false
    }
  ]
}
```

Would you like me to show how to make the **Save JSON button** automatically include this structure too (in case someone edits multiple scenes later)?

---

# Yep that did the trick merci.

Glad to hear it worked — de rien 😊!
Would you like me to help you extend it so it can handle **multiple scenes** in the same storyboard file later on?

---

# Hmm tempting but it's good for now.

Totally fair — no need to fix what’s working! 😊
If you ever decide to add multi‑scene support or automatic thumbnail generation, I can help you design it cleanly.

Want me to suggest a small quality‑of‑life tweak for saving and naming files dynamically?

