<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Could you isolate the trasisition effect here : [https://theme-toggle.rdsx.dev/](https://theme-toggle.rdsx.dev/) : it's the demo button with 'see this is simple, now the skylimit is your imagination

we've seen all the svg mask animations, but we can use clip-paths too
' in front of it ... and then generate a simple html page with the css and anything needed to get the effect swipe?

Yes — the transition on that page is a **View Transitions API** theme swap, and the “simple” button uses an SVG `clipPath` to reveal the new theme in a circular-ish swipe. The page itself explicitly mentions the clip-path approach and that SVG is preferred when you want more control like blur or gradients.[^1_1]

## What it uses

The core idea is:

- Toggle the theme class/state.
- Wrap the change in `document.startViewTransition(...)`.
- Style `::view-transition-new(root)` with a masked or clipped reveal.
- Animate the mask/clip so the new theme appears to “wipe” in.

The “simple” toggle code from the related demo uses an SVG `clipPath` and a circle inside it, which matches the effect you described.[^1_2][^1_3]

## Simple HTML

Here is a single-file demo you can save as `index.html`. It recreates a swipe/reveal theme transition using View Transitions plus a CSS clip-path animation.

```html
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Theme Swipe Transition</title>
  <style>
    :root {
      color-scheme: light dark;
      --bg: #f6f7fb;
      --fg: #111827;
      --card: rgba(255,255,255,0.72);
      --border: rgba(17, 24, 39, 0.12);
      --accent: #6366f1;
    }

    html.dark {
      --bg: #0f172a;
      --fg: #e5e7eb;
      --card: rgba(15,23,42,0.72);
      --border: rgba(229, 231, 235, 0.14);
      --accent: #a78bfa;
    }

    html, body {
      height: 100%;
      margin: 0;
      background: var(--bg);
      color: var(--fg);
      font: 16px/1.5 system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
    }

    body {
      display: grid;
      place-items: center;
      overflow: hidden;
    }

    .wrap {
      width: min(720px, calc(100vw - 32px));
      padding: 32px;
      border: 1px solid var(--border);
      border-radius: 24px;
      backdrop-filter: blur(18px);
      background: var(--card);
      box-shadow: 0 24px 80px rgba(0,0,0,.12);
    }

    h1 {
      margin: 0 0 12px;
      font-size: clamp(28px, 5vw, 56px);
      line-height: 1.05;
    }

    p {
      margin: 0 0 24px;
      max-width: 60ch;
      opacity: 0.85;
    }

    button {
      appearance: none;
      border: 0;
      border-radius: 999px;
      padding: 14px 20px;
      background: var(--accent);
      color: white;
      font-weight: 700;
      cursor: pointer;
      box-shadow: 0 12px 30px rgba(99,102,241,.35);
    }

    button:active {
      transform: translateY(1px);
    }

    @keyframes swipe-in {
      from {
        clip-path: circle(0% at var(--x, 50%) var(--y, 50%));
      }
      to {
        clip-path: circle(150% at var(--x, 50%) var(--y, 50%));
      }
    }

    html::view-transition-old(root) {
      animation: none;
    }

    html::view-transition-new(root) {
      animation: swipe-in 650ms cubic-bezier(.22, 1, .36, 1);
    }

    @media (prefers-reduced-motion: reduce) {
      html::view-transition-new(root) {
        animation: none;
      }
    }
  </style>
</head>
<body>
  <div class="wrap">
    <h1>See this is simple.</h1>
    <p>Now the sky limit is your imagination. We can use clip-paths too for a clean theme swipe transition.</p>
    <button id="toggle">Toggle theme</button>
  </div>

  <script>
    const btn = document.getElementById('toggle');

    function switchTheme() {
      document.documentElement.classList.toggle('dark');
    }

    btn.addEventListener('click', (e) => {
      const x = `${e.clientX}px`;
      const y = `${e.clientY}px`;
      document.documentElement.style.setProperty('--x', x);
      document.documentElement.style.setProperty('--y', y);

      if (!document.startViewTransition) {
        switchTheme();
        return;
      }

      document.startViewTransition(() => {
        switchTheme();
      });
    });
  </script>
</body>
</html>
```


## Notes

This version uses the click position as the clip-path center, so the swipe expands from where the button is pressed. The source demo you pointed to also discusses SVG-based alternatives and notes that clip-path is simpler but less flexible than SVG when you want blur or gradients.[^1_4]

## If you want it closer

I can also make it closer to the original by:

- using an inline SVG clip path,
- matching the exact easing,
- adding a blurred gradient edge,
- or making the transition originate from the button itself.
<span style="display:none">[^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://www.w3schools.com/graphics/svg_clipping_masking.asp

[^1_2]: https://toggles.dev/expand

[^1_3]: https://toggles.dev/simple

[^1_4]: https://developer.mozilla.org/en-US/docs/Web/SVG/Tutorials/SVG_from_scratch/Clipping_and_masking

[^1_5]: https://www.youtube.com/watch?v=f_aqzyIDudI

[^1_6]: https://www.youtube.com/watch?v=RiWxhm5ZdFM

[^1_7]: https://medium.com/@gordonnl/stylised-line-animations-ded23320ffe5

[^1_8]: https://iankduffy.com/articles/creating-a-theme-switcher-using-view-transition/

[^1_9]: https://github.com/rudrodip/theme-toggle-effect


---

# nice almost it's : ::view-transition-group(root) {

animation-duration: 0.7s;
animation-timing-function: var(--expo-out);
}

::view-transition-new(root) {
animation-name: reveal-light;
animation-fill-mode: both;
}

::view-transition-old(root),
.dark::view-transition-old(root) {
animation: none;
animation-fill-mode: both;
z-index: -1;
}
.dark::view-transition-new(root) {
animation-name: reveal-dark;
animation-fill-mode: both;
}

@keyframes reveal-dark {
from {
clip-path: polygon(50% -71%, -50% 71%, -50% 71%, 50% -71%);
}
to {
clip-path: polygon(50% -71%, -50% 71%, 50% 171%, 171% 50%);
}
}

@keyframes reveal-light {
from {
clip-path: polygon(171% 50%, 50% 171%, 50% 171%, 171% 50%);
}
to {
clip-path: polygon(171% 50%, 50% 171%, -50% 71%, 50% -71%);
}
}: for the effect I was looking for. never the less gracias. Kinky usage of svg's going on there I'll keep it simple for now but this sure has a lot of potential applications.

Yes — that’s the effect. Your snippet is the cleaner “polygon wipe” version, while the earlier one I gave was the simpler circular reveal; both are valid View Transitions approaches, and the API is designed exactly for this kind of custom animated state swap.[^2_1][^2_2]

## What changed

The important piece is that `::view-transition-group(root)` gets the duration and easing, while `::view-transition-new(root)` and `.dark::view-transition-new(root)` each get different keyframes for light vs dark reveals.[^2_3][^2_4]
Your `reveal-dark` and `reveal-light` keyframes use matching polygon point counts so the clipping shape can animate smoothly between states.[^2_5][^2_6]

## Clean demo file

Here is a minimal HTML page using your exact effect pattern:

```html
<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Theme Wipe Transition</title>
  <style>
    :root {
      --bg: #f6f7fb;
      --fg: #111827;
      --card: rgba(255,255,255,.72);
      --border: rgba(17,24,39,.12);
      --accent: #6366f1;
      --expo-out: cubic-bezier(.16, 1, .3, 1);
    }

    html.dark {
      --bg: #0f172a;
      --fg: #e5e7eb;
      --card: rgba(15,23,42,.72);
      --border: rgba(229,231,235,.14);
      --accent: #a78bfa;
    }

    html, body {
      height: 100%;
      margin: 0;
    }

    body {
      display: grid;
      place-items: center;
      font: 16px/1.5 system-ui, sans-serif;
      background: var(--bg);
      color: var(--fg);
      overflow: hidden;
    }

    .card {
      width: min(720px, calc(100vw - 32px));
      padding: 32px;
      border-radius: 24px;
      border: 1px solid var(--border);
      background: var(--card);
      backdrop-filter: blur(18px);
      box-shadow: 0 24px 80px rgba(0,0,0,.12);
    }

    h1 {
      margin: 0 0 12px;
      font-size: clamp(28px, 5vw, 56px);
      line-height: 1.05;
    }

    p {
      margin: 0 0 24px;
      max-width: 60ch;
      opacity: .86;
    }

    button {
      appearance: none;
      border: 0;
      border-radius: 999px;
      padding: 14px 20px;
      background: var(--accent);
      color: white;
      font-weight: 700;
      cursor: pointer;
      box-shadow: 0 12px 30px rgba(99,102,241,.35);
    }

    button:active {
      transform: translateY(1px);
    }

    ::view-transition-group(root) {
      animation-duration: 0.7s;
      animation-timing-function: var(--expo-out);
    }

    ::view-transition-new(root) {
      animation-name: reveal-light;
      animation-fill-mode: both;
    }

    ::view-transition-old(root),
    .dark::view-transition-old(root) {
      animation: none;
      animation-fill-mode: both;
      z-index: -1;
    }

    .dark::view-transition-new(root) {
      animation-name: reveal-dark;
      animation-fill-mode: both;
    }

    @keyframes reveal-dark {
      from {
        clip-path: polygon(50% -71%, -50% 71%, -50% 71%, 50% -71%);
      }
      to {
        clip-path: polygon(50% -71%, -50% 71%, 50% 171%, 171% 50%);
      }
    }

    @keyframes reveal-light {
      from {
        clip-path: polygon(171% 50%, 50% 171%, 50% 171%, 171% 50%);
      }
      to {
        clip-path: polygon(171% 50%, 50% 171%, -50% 71%, 50% -71%);
      }
    }

    @media (prefers-reduced-motion: reduce) {
      ::view-transition-group(root),
      ::view-transition-new(root),
      ::view-transition-old(root),
      .dark::view-transition-new(root) {
        animation: none !important;
      }
    }
  </style>
</head>
<body>
  <main class="card">
    <h1>See this is simple.</h1>
    <p>Now the sky limit is your imagination. We’ve seen SVG masks, but clip-paths work nicely too.</p>
    <button id="toggle">Toggle theme</button>
  </main>

  <script>
    const btn = document.getElementById('toggle');

    function switchTheme() {
      document.documentElement.classList.toggle('dark');
    }

    btn.addEventListener('click', () => {
      if (!document.startViewTransition) {
        switchTheme();
        return;
      }
      document.startViewTransition(() => {
        switchTheme();
      });
    });
  </script>
</body>
</html>
```


## Why this works

The browser snapshots the old and new page states, then animates the transition using the pseudo-elements you style with CSS.[^2_7][^2_2]
Because the clip-path shapes are authored as polygons with the same number of points, the reveal feels smooth instead of jumping between unrelated shapes.[^2_8][^2_5]

## Practical use

This pattern is useful for theme toggles, panel swaps, route changes, and any UI where you want a strong directional reveal without introducing SVG assets.
The polygon version is especially nice when you want a crisp geometric wipe and don’t need the extra flexibility of SVG filters or gradient edges.[^2_9][^2_10]
<span style="display:none">[^2_11]</span>

<div align="center">⁂</div>

[^2_1]: https://developer.mozilla.org/en-US/docs/Web/API/View_Transition_API

[^2_2]: https://developer.chrome.com/docs/web-platform/view-transitions

[^2_3]: https://theme-toggle.rdsx.dev

[^2_4]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Selectors/::view-transition-group

[^2_5]: https://stackoverflow.com/questions/73084287/how-do-you-make-a-css-clip-path-polygon-transition-smooth

[^2_6]: https://theproductguy.in/blogs/css-clip-path-guide/

[^2_7]: https://github.com/WICG/view-transitions/blob/main/nested-explainer.md

[^2_8]: https://css-tricks.com/animating-with-clip-path/

[^2_9]: https://www.cssscript.com/smooh-theme-toggle-effects/

[^2_10]: https://developer.mozilla.org/en-US/docs/Web/SVG/Tutorials/SVG_from_scratch/Clipping_and_masking

[^2_11]: https://piccalil.li/blog/some-practical-examples-of-view-transitions-to-elevate-your-ui/


---

# Lovely and thanks for the cleared up demo version. Going to tinker with this some more drop by at a later date.

Glad it helped. Have fun tinkering with it — that effect has a lot of room to play with.

