<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# I am using the following query with sqlite :select title, category, subcategory from docuold where category = subcategory; : oddly enough I am getting zero results while I know for a fact that there are instances where category actuality has the same value as subcategory, all tough it might not be in the same record,  do you have some suggestions?

This query only returns rows where `category` and `subcategory` are equal in the *same row*. If your matching values live in different rows, the condition `category = subcategory` will never be true for that data.

## Why your query returns zero rows

Your current query:

```sql
SELECT title, category, subcategory
FROM docuold
WHERE category = subcategory;
```

only finds rows like:


| title | category | subcategory |
| :-- | :-- | :-- |
| A | books | books |

If your data instead looks like:


| title | category | subcategory |
| :-- | :-- | :-- |
| A | books | novels |
| B | novels | fiction |

then `category = subcategory` is never true in any single record, even though the *value* `"novels"` appears as a category in one row and as a subcategory in another.

Other things to double‑check:

- Extra spaces or case differences, e.g. `"Books"` vs `"books "`; use `TRIM` and `LOWER` if needed:

```sql
WHERE LOWER(TRIM(category)) = LOWER(TRIM(subcategory));
```

- NULLs: if either column is NULL in a row, that row will not match.


## If you want values that appear in both columns

If what you really want is “all rows where the `category` value also appears somewhere in the `subcategory` column (possibly in another row)”, use `IN`:

```sql
SELECT title, category, subcategory
FROM docuold
WHERE category IN (SELECT subcategory FROM docuold);
```

Similarly, for subcategories that also exist as categories:

```sql
SELECT title, category, subcategory
FROM docuold
WHERE subcategory IN (SELECT category FROM docuold);
```


## If you want to see the overlapping values

To just list the values that appear in both columns:

```sql
SELECT DISTINCT category AS value
FROM docuold
WHERE category IS NOT NULL
  AND category IN (SELECT subcategory FROM docuold);
```

or, using a self‑join:

```sql
SELECT DISTINCT d1.category AS value
FROM docuold d1
JOIN docuold d2
  ON d1.category = d2.subcategory;
```

<span style="display:none">[^1_1][^1_10][^1_2][^1_3][^1_4][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://twelvescompany.co.uk/post/self-join-query-optimizations

[^1_2]: https://stackoverflow.com/questions/58383887/category-and-subcategory-does-not-match

[^1_3]: https://colinchsql.github.io/2023-09-26/10-39-38-961978-optimizing-sql-queries-with-complex-self-joins/

[^1_4]: https://sqlite.org/forum/info/635cb9fb605d53ef

[^1_5]: https://sqlite.work/optimizing-sqlite-query-performance-by-controlling-join-and-limit-execution-order/

[^1_6]: https://forum.xojo.com/t/puzzling-sqlite-behavior/29027

[^1_7]: https://stackoverflow.com/questions/59381556/optimizing-sqlite-self-joins

[^1_8]: https://stackoverflow.com/questions/72577645/trouble-with-sqlite-query-subquery

[^1_9]: https://stackoverflow.com/questions/3296511/improve-performance-of-self-join-in-sqlite

[^1_10]: https://www.reddit.com/r/dotnet/comments/peezp0/ef_core_data_modelling_categorysubcategory_and/


---

# Nice gracias. By the by are queries for overlapping values case insensitive and auto trimming?

No, not by default. In SQLite, plain equality comparisons and `IN` conditions are case-sensitive and do not auto-trim whitespace.

## Case sensitivity

By default:

- `WHERE category = subcategory` is case-sensitive for ASCII letters.
- `"Books"` and `"books"` will not match unless you explicitly use a case-insensitive collation or functions.[^2_1][^2_2]

To make your overlap queries case-insensitive, you can do for example:

```sql
SELECT title, category, subcategory
FROM docuold
WHERE category COLLATE NOCASE IN (SELECT subcategory FROM docuold);
```

or

```sql
WHERE LOWER(category) = LOWER(subcategory);
```


## Trimming whitespace

SQLite does not auto-trim strings before comparison. A value `"books"` and `"books "` are different unless you normalize them.[^2_1]

To ignore leading/trailing spaces, wrap with `TRIM`:

```sql
WHERE TRIM(category) = TRIM(subcategory);
```

For both trimming and case-insensitive comparison together:

```sql
WHERE LOWER(TRIM(category)) = LOWER(TRIM(subcategory));
```

So: no automatic case-insensitivity, no automatic trimming—both need to be expressed explicitly in the query or in the column definition (e.g., `COLLATE NOCASE`).[^2_2][^2_1]
<span style="display:none">[^2_10][^2_3][^2_4][^2_5][^2_6][^2_7][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://www.designcise.com/web/tutorial/how-to-do-case-insensitive-comparisons-in-sqlite

[^2_2]: https://stackoverflow.com/questions/973541/how-to-set-sqlite3-to-be-case-insensitive-when-string-comparing

[^2_3]: https://shallowdepth.online/posts/2022/01/5-ways-to-implement-case-insensitive-search-in-sqlite-with-full-unicode-support/

[^2_4]: https://www.sql-easy.com/learn/sqlite-case/

[^2_5]: https://sqlite.org/forum/info/af7978156ce072e7e1060f0741dc10d33dc7ccaf702f6d67c5ab692bffa25174

[^2_6]: https://groups.google.com/g/rhomobile/c/vhDVrfy2fqU

[^2_7]: http://sqlite.org/c3ref/stricmp.html

[^2_8]: https://pt.stackoverflow.com/questions/1785/como-fazer-comparações-case-insensitive-no-sqlite

[^2_9]: https://spin.atomicobject.com/case-insensitive-unicode-sqlite/

[^2_10]: https://www.delftstack.com/howto/sqlite/case-insensitive-string-comparison-in-sqlite3/


---

# Ok went for : SELECT DISTINCT category AS value

FROM docuold
WHERE category IS NOT NULL
AND lower(trim(category)) IN (SELECT lower(trim(subcategory)) FROM docuold);
: but good to know what 'IN' defaults are. As ever merci for the info and examples.

That query is a solid choice for what you described. It normalizes both columns the same way before comparing, so you get robust overlapping values even with messy data.

## What your query is doing

- `DISTINCT category AS value`: returns each matching category only once, which is great for getting a clean list of overlapping values.
- `category IS NOT NULL`: avoids NULL issues, since `NULL` never equals anything.
- `lower(trim(category)) IN (SELECT lower(trim(subcategory)) FROM docuold)`:
    - `trim(...)` removes leading/trailing spaces.
    - `lower(...)` normalizes case.
    - `IN (...)` checks whether the normalized category exists anywhere in the normalized subcategory column, possibly in different rows.

This is exactly the right pattern if your concern is “do these values overlap logically, regardless of case and stray spaces”.

## Minor optional refinements

If the table is large and you ever need to optimize:

- You could add computed/extra columns that store normalized values (e.g., `category_norm`) and index them, then compare `category_norm IN (SELECT subcategory_norm ...)`.
- For readability, some people also like to move the subquery into a CTE:

```sql
WITH norm_sub AS (
  SELECT DISTINCT lower(trim(subcategory)) AS sub_norm
  FROM docuold
  WHERE subcategory IS NOT NULL
)
SELECT DISTINCT category AS value
FROM docuold
WHERE category IS NOT NULL
  AND lower(trim(category)) IN (SELECT sub_norm FROM norm_sub);
```

But functionally, what you have now is correct and idiomatic for SQLite in this use case.

