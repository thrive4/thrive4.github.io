<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Could you have a look at the following freebasic code I am expecting archive\test.mp3 to return f:\dev\freebasic\audioplayer\archive\ it returns archive\ : ' resolve path commandline argument

Function resolvepath(path As String) As String

    Dim buffer        as String * 260
    dim resolvedpath  as string
    Dim length        as Integer 
    length = GetFullPathName(path, 260, buffer, Null)
    resolvedpath = Left(buffer, length)
    if checkpath(resolvedpath) = false and instr(path, "..") = 0 then
        resolvedpath = path
    end if  
    
    return resolvedpath
    end function

Short answer: The code you posted seems to resolve a path using GetFullPathName, then falls back to the original path if the resolved path isn’t valid and the input didn’t contain "..". That logic can still yield an unexpected result if GetFullPathName returns something different from the intended working directory, or if the checkpath function is incomplete.

What’s going on

- Your function calls GetFullPathName(path, 260, buffer, Null) and uses the number of characters returned to slice the buffer. If path is a relative path like archive\test.mp3, GetFullPathName should yield a full path (e.g., F:\dev\freebasic\audioplayer\archive\test.mp3) assuming the current directory is the project root. If the actual current working directory isn’t what you expect at runtime, you’ll get a different full path.
- The subsequent check path uses checkpath(resolvedpath). If that returns false and the original path does not contain "..", you reset to the original path. This means you’re only allowing an unresolved path when the original path had a parent-directory reference; otherwise you keep the relative input even if the full path exists or not.
- If your goal is to make archive\test.mp3 resolve to F:\dev\freebasic\audioplayer\archive\, you likely want to extract the directory portion of the full path (without the file) or ensure you’re computing the directory of the file, then combine it with the filename, or simply return the directory path if you’re testing for a directory.

How to adjust for your expected behavior

- If you want resolvepath to return the full directory containing the file (i.e., archive\), you can modify to strip the file part after GetFullPathName, keeping only the directory.
- If you want to ensure any relative path is resolved to a full path and that directory exists or is valid, you may:
    - Use GetFullPathName to get the full path to the file.
    - Then extract the directory portion: dir = Left(fullpath, InStrRev(fullpath, "\") - 1)
    - Return that directory or verify it exists as needed.
- If you want to preserve relative paths when the full path is not valid, ensure your logic checks the directory's existence rather than the file’s path, and consider using PathCombine-like behavior to join base and relative components robustly.

Concrete example (conceptual FreeBasic-like pseudocode)

- Get full path to the file:
length = GetFullPathName(path, 260, buffer, Null)
fullpath = Left(buffer, length)
- Get directory portion:
pos = InStrRev(fullpath, "\")
if pos > 0 then
dir = Left(fullpath, pos - 1)
else
dir = fullpath
end if
- Return dir (or use dir as the resolved path)

Notes and potential pitfalls

- Ensure the current working directory during execution is what you expect; otherwise, relative paths resolve differently.
- Verify the semantics of checkpath: does it verify existence, accessibility, or something else? If it’s returning false too aggressively, you may end up returning the input path unchanged.
- If archive\test.mp3 is intended as a directory path, confirm whether you truly want the directory part or the file path.

If you’d like, share how you’re invoking this function (e.g., the exact input values and what the rest of the program does with the returned path). That will help tailor a corrected resolvepath implementation to produce archive\ as the result for archive\test.mp3.

Citations

- I didn’t fetch external sources in this turn, but the analysis is based on the code snippet you provided. If you want, I can look up FreeBASIC path-handling discussions to align the approach with common practices.
<span style="display:none">[^1_1][^1_10][^1_2][^1_3][^1_4][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://www.freebasic.net/forum/viewtopic.php?t=27996

[^1_2]: https://www.freebasic.net/forum/search.php?author_id=1041\&sr=posts

[^1_3]: https://freebasic.net/forum/viewtopic.php?t=13302

[^1_4]: https://www.freebasic.net/forum/viewtopic.php?t=9520

[^1_5]: https://www.example-code.com/purebasic/fac_path_functions.asp

[^1_6]: https://stackoverflow.com/questions/tagged/freebasic

[^1_7]: https://freebasic.net/forum/viewtopic.php?t=32809\&start=15

[^1_8]: https://freebasic.net/forum/viewtopic.php?t=32903

[^1_9]: https://freebasic.net/forum/viewtopic.php?t=10288

[^1_10]: https://freebasic.net/forum/viewtopic.php?t=983


---

# Hmm just for the record does freebasics FileExists check relative? So 'archive\test.mp3' true or false?

FreeBASIC’s `FileExists` does work with relative paths, including something like `"archive\test.mp3"`, but it checks them relative to the *current working directory*, not the executable’s directory.[^2_1][^2_9]

- If the current working directory is `F:\dev\freebasic\audioplayer\`, then `FileExists("archive\test.mp3")` will return **TRUE** when that file is actually present under that folder.[^2_9][^2_1]
- If the current working directory is something else (for example you launched the EXE from another folder, or a dialog changed it), the same call can return **FALSE** even though the file exists next to your EXE.[^2_3][^2_1]

In practice, many FreeBASIC users call `ChDir ExePath` once at startup so that all relative paths like `"archive\test.mp3"` consistently resolve relative to the EXE’s location.[^2_1]
<span style="display:none">[^2_10][^2_2][^2_4][^2_5][^2_6][^2_7][^2_8]</span>

<div align="center">⁂</div>

[^2_1]: https://www.freebasic.net/forum/viewtopic.php?t=25057

[^2_2]: https://www.freebasic.net/forum/viewtopic.php?t=12134

[^2_3]: https://stackoverflow.com/questions/12941908/checking-the-existence-of-a-file-using-relative-path

[^2_4]: https://www.freebasic.net/forum/viewtopic.php?p=105922

[^2_5]: https://www.freebasic.net/forum/viewtopic.php?t=32809

[^2_6]: https://www.freebasic.net/wiki/wikka.php?wakka=KeyPgFileexists

[^2_7]: https://www.freebasic.net/forum/viewtopic.php?t=7012

[^2_8]: https://www.freebasic.net/forum/viewtopic.php?t=12114

[^2_9]: https://www.freebasic.net/wiki/wikka.php?wakka=KeyPgOpen

[^2_10]: https://documentation.help/FreeBASIC/documentation.pdf


---

# 'FreeBASIC’s FileExists does work with relative paths, including something like "archive\test.mp3", but it checks them relative to the current working directory, not the executable’s directory.' .. oh oh ... so it does not resolve to the full path ... leading to ambiguous results ...

Yes, that’s the tricky part: `FileExists` only answers “does this path (as given) exist from the current working directory’s point of view?”, it does **not** normalize or expand it to a full path.

Because of that:

- Two different working directories can give different true/false results for the exact same relative string `"archive\test.mp3"`, which is what makes it **ambiguous** in a larger application.
- You cannot safely store or log the result as if it were a canonical path; you still only have the original relative text unless you explicitly resolve it yourself (for example with `GetFullPathName` or similar API) and then call `FileExists` on that resolved string.

To avoid ambiguity, typical patterns are:

- Set the working directory once at startup (for example to the EXE directory) and rely on relative paths only within that controlled context.
- Or always convert to an absolute path first, then call `FileExists` and only use the absolute string in your logic and logs.

---

# I see ... so calling this ... : ' resolve path commandline argument

Function resolvepath(path As String) As String

    Dim buffer        as String * 260
    dim resolvedpath  as string
    Dim length        as Integer 
    length = GetFullPathName(path, 260, buffer, Null)
    resolvedpath = Left(buffer, length)
    if checkpath(resolvedpath) = false and instr(path, "..") = 0 then
        resolvedpath = path
    end if  
    
    return resolvedpath
    end function
: is not good because I end up with 'archive\test.mp3' when doing dummy = resolvepath(command(1)) when command(1) is  'archive\test.mp3' instead of getting the buffer ...?

Yes, the fallback line is exactly what is “breaking” your resolution logic in that case.

With your function:

```basic
Function resolvepath(path As String) As String
    Dim buffer        as String * 260
    dim resolvedpath  as string
    Dim length        as Integer 
    length = GetFullPathName(path, 260, buffer, Null)
    resolvedpath = Left(buffer, length)
    if checkpath(resolvedpath) = false and instr(path, "..") = 0 then
        resolvedpath = path
    end if  
    return resolvedpath
end function
```

this happens for `command(1) = "archive\test.mp3"`:

1. `GetFullPathName` *does* produce a fully qualified path like `F:\dev\freebasic\audioplayer\archive\test.mp3` (assuming the working directory is correct).[^4_8]
2. Then `checkpath(resolvedpath)` returns `FALSE` (for example because it expects a directory, or the file is not there yet, or its logic is stricter than you think).
3. Because `Instr(path, "..") = 0`, the `IF` condition is true, and you overwrite the good absolute path with the original relative string `"archive\test.mp3"`.

So the function is internally resolving to a full path, but then throws that away and returns the original relative path if `checkpath` says “no”. That is why `dummy = resolvepath(command(1))` ends up as `"archive\test.mp3"` instead of the buffer content.

If your intent is:

- “Always return a fully qualified path if it can be computed, regardless of whether the file currently exists”,

then you should remove or change the `checkpath` block, for example:

```basic
Function resolvepath(path As String) As String
    Dim buffer        as String * 260
    dim resolvedpath  as string
    Dim length        as Integer 

    length = GetFullPathName(path, 260, buffer, Null)
    If length > 0 Then
        resolvedpath = Left(buffer, length)
    Else
        resolvedpath = path  '' fallback only if API fails
    End If

    return resolvedpath
End Function
```

If your intent instead is to resolve and *also* verify existence, consider:

- Returning the full path regardless, and using a separate `Exists`/`checkpath` test in the caller.
- Or changing `checkpath` to operate on the directory part only if that is what actually matters.
<span style="display:none">[^4_1][^4_10][^4_2][^4_3][^4_4][^4_5][^4_6][^4_7][^4_9]</span>

<div align="center">⁂</div>

[^4_1]: https://www.freebasic.net/forum/viewtopic.php?t=29245

[^4_2]: https://github.com/thrive4/app.fb.audioplayer-bass/blob/main/utilfile.bas

[^4_3]: https://stackoverflow.com/questions/17632117/how-to-extract-the-file-name-without-folder-path-with-getfullpathname

[^4_4]: https://www.freebasic.net/forum/viewtopic.php?t=10670

[^4_5]: https://www.freebasic.net/wiki/wikka.php?wakka=KeyPgCommand

[^4_6]: https://www.freebasic.net/forum/viewtopic.php?t=26483\&start=15

[^4_7]: https://www.freebasic.net/forum/viewtopic.php?p=131724

[^4_8]: https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-getfullpathnamew

[^4_9]: https://www.freebasic.net/forum/viewtopic.php?t=31809\&start=210

[^4_10]: https://forums.silverfrost.com/viewtopic.php?t=3197\&view=previous\&sid=4af6a43dd49e3cb1dde5813446feec0f


---

# Well this is opened a can of worms but that's good a lot issues became evident that have been addressed, so gracias for the tweaked resolvepath still on the fence when this occurs ...f:\dev\freebasic\projects\audioplayer-bass\http:\uk3.internet-radio.com:8082\live .. I can prevent it or deal with it in resolvepath ... what do you think?

That mixed path is definitely worth handling centrally in `resolvepath`, not left to the rest of the program.

## What is happening

A string like:

```text
f:\dev\freebasic\projects\audioplayer-bass\http:\uk3.internet-radio.com:8082\live
```

is basically a local path that accidentally contains something that “looks like” an URL in the middle. On Windows APIs such as `GetFullPathName`, once the string has a valid drive and root (`f:\...`), everything after that is treated as normal path text, so the embedded `http:\...` will not be recognized as a URL and will just become more path components.[^5_1]

## Two reasonable strategies

### 1. Treat URL-ish strings as *not* file paths

If the user can pass URLs (`http://...`, `https://...`, maybe `ftp://...`), then `resolvepath` should detect those patterns and simply return them unchanged, skipping any attempt to resolve them as filesystem paths.

Example logic (conceptually):

- If `path` matches something like:
    - starts with `http://`, `https://`, `ftp://`, or
    - contains `"://"` before any backslash
- Then: return `path` directly and do not call `GetFullPathName`.

That way, a pure URL stays a URL, and you can later decide “if result contains `://` then treat as stream/URL; otherwise treat as local file”.

This does *not* solve your mixed string above, though, because that one already has a `f:\` at the start.

### 2. Treat混 local+URL as an error and fail fast

For the exact kind of broken string you showed, the safest approach is to consider it invalid and make the caller handle it (log error, show message, etc.), instead of trying to “fix” it.

You can detect this by:

- Checking if the string contains both:
    - A valid drive prefix at the start (`^[A-Za-z]:\`)
    - And a URL-like pattern later (`"://"` or `"http:\"`, `"https:\"` etc.)
- If both present, then:
    - Either return an empty string or some sentinel like `"ERROR_PATH"`.
    - Or return just the original `path` and let the caller detect validity via a second function (e.g., `IsValidPath`).

This keeps `resolvepath` from turning obviously broken input into some strange but “valid” full path.

## Practical recommendation

Given how you describe the player:

- Keep `resolvepath` focused on:
    - “Make a command-line argument into a full path *if it represents a local file*.”
- Do:
    - If it looks like a URL (`://` or starts with `http` etc.), return it unchanged.
    - If it is a local path (absolute or relative), pass it to `GetFullPathName` and return that result.
    - If it looks like a mixture (starts with drive letter but also contains URL-like stuff), treat it as invalid and signal error.

This way:

- Local files always become a clean absolute path.
- URLs always remain URLs.
- Broken mixes are rejected in one place instead of leaking into song-opening logic.

<div align="center">⁂</div>

[^5_1]: https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-getfullpathnamew


---

# Sound the current solution is : ' check for stream in command line

if instr(command(1), "http") <> 0 then
filename = command(1)
end if
: used to be : if instr(dummy, "http") <> 0 then
filename = dummy
end if
: dummy was the result of resolvepath ...

That change is an improvement and avoids exactly the “mixed path” mess you ran into.

## Why checking `command(1)` is better

- Your old logic was:

```basic
dummy = resolvepath(command(1))
if instr(dummy, "http") <> 0 then
    filename = dummy
end if
```

Because `resolvepath` runs `GetFullPathName`, anything that *looks* like a path fragment (including `http:\...`) can get glued into a longer Windows path string, so the `"http"` inside `dummy` might no longer clearly represent a real URL, or could be mangled into a weird absolute path.[^6_1]
- Your new logic:

```basic
if instr(command(1), "http") <> 0 then
    filename = command(1)
end if
```

checks the **raw** command-line argument before any path processing, so:
    - Clean URLs like `http://uk3.internet-radio.com:8082/live` are detected correctly as streams.
    - They bypass `resolvepath`, so `GetFullPathName` never corrupts them into a fake filesystem path.[^6_1]


## Recommended refinement

To make it more robust and avoid false positives:

- Use a slightly stricter test, for example:

```basic
dim arg as string = lcase$(command(1))

if left$(arg, 7) = "http://" or left$(arg, 8) = "https://" then
    filename = command(1)  '' treat as stream
else
    filename = resolvepath(command(1))  '' treat as local file
end if
```

- This way:
    - Real HTTP/HTTPS URLs go straight to the streaming logic.
    - Everything else (including `archive\test.mp3`, `F:\path\file.mp3`) goes through `resolvepath` and becomes a clean absolute path.

That keeps your “stream vs. local file” decision clear and avoids the `f:\dev\...\http:\uk3...` type of accidents.

<div align="center">⁂</div>

[^6_1]: https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-getfullpathnamew


---

# Hmm ok taking your prior suggestion into account I'll settle on : ' resolve path commandline argument

Function resolvepath(path As String) As String
Dim buffer        as String * 260
dim resolvedpath  as string
Dim length        as Integer

    if instr(path, "http") = 0 then
        length = GetFullPathName(path, 260, buffer, Null)
        If length > 0 Then
            resolvedpath = Left(buffer, length)
        Else
            resolvedpath = path ' fallback if API fails
        End If
    else
        resolvedpath = path
    end if
    return resolvedpath
    End Function

That's a solid, pragmatic solution that handles both local files and streams cleanly in one place.

## Why this works well

Your updated `resolvepath` now:

- Skips `GetFullPathName` entirely for anything containing `"http"`, preserving raw URLs like `http://uk3.internet-radio.com:8082/live`.
- Only resolves filesystem paths for non-HTTP strings, turning `archive\test.mp3` into `F:\dev\freebasic\audioplayer\archive\test.mp3`.
- Eliminates the problematic `checkpath` fallback, so you always get either a full path or the original input (no more relative strings sneaking through).


## Minor polish suggestion

For even better reliability, consider case-insensitive checking:

```basic
if instr(lcase(path), "http") = 0 then
```

This catches `HTTP://`, `Https://`, etc., without affecting the returned path.

## Usage stays simple

Now your main logic becomes straightforward:

```basic
filename = resolvepath(command(1))
' Use filename - it's either a full local path or original URL
if instr(lcase(filename), "http") <> 0 then
    ' stream handling
else
    ' local file handling, with guaranteed absolute path
end if
```

No more separate checks before calling the function, and no risk of mangled mixed paths. Clean and consistent.

---

# Oh fiddlesticks ... "HTTP" by Katy Perry

"[http://yourlove.com](http://yourlove.com)" by Devo .. christ ..

Those are perfect counterexamples—your `instr(path, "http")` check will falsely treat song titles or metadata containing "http" (like "HTTP" by Katy Perry or URLs in tags) as streams, bypassing path resolution when you actually want local file handling.

## Quick fix: stricter URL detection

Replace the simple `instr` with a proper URL prefix check:

```basic
Function resolvepath(path As String) As String
    Dim buffer        as String * 260
    Dim resolvedpath  as String
    Dim length        as Integer 
    Dim lowerpath     as String = Lcase(path)

    ' Only skip resolution for actual HTTP/HTTPS URLs
    if left$(lowerpath, 7) = "http://" or left$(lowerpath, 8) = "https://" then
        resolvedpath = path
    else
        length = GetFullPathName(path, 260, buffer, Null)
        if length > 0 then
            resolvedpath = Left(buffer, length)
        else
            resolvedpath = path
        end if
    end if
    
    return resolvedpath
End Function
```


## Why this solves it

- `"archive/HTTP by Katy Perry.mp3"` → resolves to full path (no `http://` prefix)
- `"[http://yourlove.com] Devo.mp3"` → resolves to full path
- `"http://uk3.internet-radio.com:8082/live"` → stays as URL
- `"HTTPS://stream.example.com"` → stays as URL

Now "http" anywhere except as a proper URL scheme gets treated as a local file path. No false positives from artist names, lyrics, or ID3 tags. Clean separation.

---

# Hmm yep and you actually suggested it earlier ... well this has been an excellent session many thanks for the suggestions and explanation regarding FileExists (need to go through more of my code on that one)  and resolvepath.

You're welcome—glad the session helped clarify those path pitfalls and get `resolvepath` dialed in properly. The prefix check should handle edge cases like song titles reliably now.

## Next steps for FileExists

Since you're auditing more code:

- Add `ChDir ExePath()` early in `main()` to lock the working directory to your EXE location.
- Or wrap `FileExists` calls like: `FileExists(resolvepath(filename))` to always use absolute paths.

That combo eliminates all relative path ambiguity across your app. Happy coding!

