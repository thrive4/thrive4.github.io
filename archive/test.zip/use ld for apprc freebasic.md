<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Would it be possible to ld this windows .rc : //=============================================================================

// Generic project resource file
//=============================================================================

// add helpfile in exe windows only
//helpfile rcdata "help.txt"

// add an icon windows only?
FB_PROGRAM_ICON ICON "f:\\dev\\freebasic\\projects\\audioplayer-bass\\app.ico"

// add version and file info in exe windows only
VS_VERSION_INFO VERSIONINFO
FILEVERSION 1, 9, 0, 000
PRODUCTVERSION 1, 9, 0, 0
FILEFLAGSMASK 0x3fL
\#ifdef _DEBUG
FILEFLAGS 0x9L
\#else
FILEFLAGS 0x8L
\#endif
FILEOS 0x4L
FILETYPE 0x1L
FILESUBTYPE 0x0L
BEGIN
BLOCK "StringFileInfo"
BEGIN
BLOCK "040904b0"
BEGIN
VALUE "Comments", "needs bass un4seen libs"
VALUE "CompanyName", ""
VALUE "FileDescription", "audioplayer with u4seen bass"
VALUE "FileVersion", "1, 9, 0, 000"
VALUE "InternalName", ""
VALUE "LegalCopyright", ""
VALUE "OriginalFilename", "audioplayer"
VALUE "PrivateBuild", ""
VALUE "ProductName", "audioplayer"
VALUE "ProductVersion", "1, 9, 0, 0"
END
END
BLOCK "VarFileInfo"
BEGIN
VALUE "Translation", 0x409, 1200
END
END
: say like : ld -r -b binary -o apprc.o app.rc : fbc main.bas apprc.o -o myapp and then access fileversion and other meta data on both windows and unix?

Yes, but not in the way you’re describing. A Windows `.rc` file is normally turned into a Windows resource object (`.res`) by a resource compiler, then linked into a PE/Windows executable; `ld -r -b binary` is for embedding raw binary data, not for understanding or preserving `VERSIONINFO` semantics.[^1_1][^1_2]

## What works

If your goal is to ship the `.rc` contents inside the program, you can convert the file to a binary object and read it back at runtime as raw text or bytes. GNU `ld -r -b binary` creates linker symbols for the embedded data, and FreeBASIC can access embedded binary data via those linker-generated symbols.[^1_3][^1_4][^1_5]

## What does not work

That approach does **not** make Windows show the file version in the executable’s Properties dialog, because Windows version metadata lives in a real `VERSIONINFO` resource inside the PE `.rsrc` section. The version resource is compiled from `.rc` into a `.res` and linked into the executable as a Windows resource.[^1_6][^1_7][^1_2]

## Cross-platform metadata

On Windows, the standard way to expose `FileVersion`, `ProductVersion`, and related fields is the `VERSIONINFO` resource, which can be queried with Windows version APIs. On Unix-like systems, there is no equivalent built-in file-properties UI for that metadata, so the usual pattern is to keep your own version string in the program and print it from `--version` or embed it as a resource/data blob for your own parsing.[^1_8][^1_2]

## Practical FreeBASIC approach

A practical cross-platform design is:

- Keep version numbers in a shared source file or build define.
- On Windows, compile a `.rc` to `.res` and link it in so Explorer shows the metadata.
- On Unix, embed the same version text in your app and expose it via `--version` or an About dialog.[^1_2][^1_4][^1_8]

If you want, I can show you a FreeBASIC build setup for both Windows and Linux that uses one version source and produces the right metadata on each platform.
<span style="display:none">[^1_10][^1_11][^1_12][^1_13][^1_14][^1_15][^1_16][^1_17][^1_18][^1_19][^1_20][^1_21][^1_22][^1_23][^1_24][^1_25][^1_26][^1_27][^1_28][^1_29][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://sourceware.org/binutils/docs/ld.pdf

[^1_2]: https://learn.microsoft.com/en-us/windows/win32/menurc/versioninfo-resource

[^1_3]: https://www.freebasic.net/wiki/wikka.php?wakka=ProPgDataExecutable

[^1_4]: https://freebasic.net/wiki/ProPgDataExecutable

[^1_5]: https://blog.cybershenanigans.space/posts/embedding-files-in-c-cpp-programs/

[^1_6]: https://users.rust-lang.org/t/does-exe-file-contain-version-information/85096

[^1_7]: https://www.osr.com/nt-insider/2011-issue2/creating-proper-version-information-resource/

[^1_8]: https://forum.lazarus.freepascal.org/index.php?topic=53641.0

[^1_9]: https://documentation.help/FreeBASIC/KeyPgOpen.html

[^1_10]: https://github.com/conan-io/conan/issues/11474

[^1_11]: https://bumbershootsoft.wordpress.com/2019/04/07/working-with-dlls-on-windows-mac-and-linux/

[^1_12]: https://www.freebasic.net/forum/viewtopic.php?t=29653

[^1_13]: https://sourceware.org/binutils/

[^1_14]: https://www.freebasic.net/forum/viewtopic.php?t=2130

[^1_15]: https://jumpcloud.com/it-index/what-is-elf-executable-and-linkable-format

[^1_16]: https://stackoverflow.com/questions/20250216/c-sharp-getting-file-version-of-embedded-resource-files

[^1_17]: https://docwiki.embarcadero.com/RADStudio/Athens/en/Version_Info

[^1_18]: https://inventivehq.com/blog/executable-file-formats-guide

[^1_19]: https://www.freebasic.net/forum/viewtopic.php?t=13493

[^1_20]: https://github.com/BYVoid/OpenCC/issues/1057

[^1_21]: https://www.freebasic.net/wiki/KeyPgGetfileio

[^1_22]: https://www.codeguru.com/cplusplus/get-versioninfo-from-resource-file/

[^1_23]: https://stackoverflow.com/questions/59774709/embedding-any-file-into-gcc-compiled-program-and-accessing-it-inside-program

[^1_24]: https://sourceware.org/binutils/docs-2.29/ld/Options.html

[^1_25]: https://github.com/freebasic/fbc/blob/master/inc/FreeImage.bi

[^1_26]: https://home.cs.colorado.edu/~main/cs1300/doc/gnu/ld_3.html

[^1_27]: https://www.math.utah.edu/docs/info/ld_2.html

[^1_28]: https://www.linuxjournal.com/content/embedding-file-executable-aka-hello-world-version-5967

[^1_29]: https://freebasic.net/forum/viewtopic.php?t=32995


---

# Ok just to get  a feel could you generate some freebasic code that can read the apprc.o in a tad more granular way as this example : [https://www.freebasic.net/wiki/ProPgDataExecutable](https://www.freebasic.net/wiki/ProPgDataExecutable) ...

Yes. If `apprc.o` was created with `ld -r -b binary`, you can read it in FreeBASIC as a raw byte blob and then inspect the bytes at whatever granularity you want. The linker exposes start/end symbols for the embedded data, which you can use to get a pointer and length just like the FreeBASIC embedded-data example.[^2_1][^2_2]

## Example code

```vb
' apprc_read.bas
#Ifdef __FB_WIN32__
    Const BIN_PREFIX = "_binary_"
#Else
    Const BIN_PREFIX = "_binary_"
#EndIf

Extern _binary_apprc_o_start Alias "_binary_apprc_o_start" As UByte
Extern _binary_apprc_o_end   Alias "_binary_apprc_o_end"   As UByte

Dim As UByte Ptr p = @_binary_apprc_o_start
Dim As UByte Ptr e = @_binary_apprc_o_end
Dim As UInteger n = CUInt(e - p)

Print "apprc.o size = "; n; " bytes"
Print

' dump bytes in hex + ASCII
For i As UInteger = 0 To n - 1 Step 16
    Print Hex(i, 8); "  ";
    For j As UInteger = 0 To 15
        If i + j < n Then
            Print Hex(p[i + j], 2); " ";
        Else
            Print "   ";
        End If
    Next
    Print " ";
    For j As UInteger = 0 To 15
        If i + j < n Then
            Dim c As UByte = p[i + j]
            If c >= 32 And c <= 126 Then
                Print Chr(c);
            Else
                Print ".";
            End If
        End If
    Next
    Print
Next
```

This is the same basic technique as the wiki example: declare the linker-generated start/end symbols, take their addresses, and walk the bytes between them.[^2_2][^2_1]

## Important detail

With `ld -r -b binary -o apprc.o app.rc`, the object usually embeds the **raw bytes of the `.rc` file itself**, not the compiled Windows resource structure. So if your goal is to read `VERSIONINFO` fields, you’ll be parsing the text of the `.rc` source, not the real Windows resource format.[^2_3][^2_4]

## How to make it more granular

If you want line-by-line or token-by-token access, treat the embedded blob as a string and split on line endings. For example, you can copy it into a `String`, then parse out lines containing `FILEVERSION`, `PRODUCTVERSION`, or `VALUE "FileDescription", ...`.[^2_4][^2_1]

## Small parsing sketch

```vb
Dim As String rcText = String(n, Chr(0))
For i As UInteger = 0 To n - 1
    rcText[i] = Chr(p[i])
Next

Dim As Integer pos = 1
Do
    Dim As Integer nl = Instr(pos, rcText, Chr(10))
    Dim As String line
    If nl = 0 Then
        line = Mid(rcText, pos)
    Else
        line = Mid(rcText, pos, nl - pos)
    End If

    If Len(Trim(line)) > 0 Then Print line
    If nl = 0 Then Exit Do
    pos = nl + 1
Loop
```

That gives you a line-based view of the embedded file, which is usually the easiest first step before building a real parser. The FreeBASIC docs show the general file/binary access pattern, and the same byte-reading idea applies here.[^2_5][^2_6]

## Practical recommendation

For cross-platform version metadata, I would keep one plain text version file or `#define` source and embed that, rather than trying to parse a Windows `.rc` on Unix. If you really want the `.rc` content itself, the approach above is fine, but it is best treated as a text resource, not as the finished Windows resource data.[^2_1][^2_4]

If you want, I can turn this into a small FreeBASIC parser that extracts `FILEVERSION`, `PRODUCTVERSION`, and the `VALUE` strings into variables.
<span style="display:none">[^2_10][^2_11][^2_12][^2_7][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://freebasic.net/wiki/ProPgDataExecutable

[^2_2]: https://www.freebasic.net/forum/viewtopic.php?t=29653

[^2_3]: https://sourceware.org/binutils/docs/ld.pdf

[^2_4]: https://learn.microsoft.com/en-us/windows/win32/menurc/versioninfo-resource

[^2_5]: https://github.com/freebasic/fbc/blob/master/examples/files/binary.bas

[^2_6]: https://fossies.org/windows/misc/FreeBASIC-1.10.1-win64.zip/FreeBASIC-1.10.1-win64/examples/manual/fileio/access.bas?M=17

[^2_7]: https://www.freebasic.net/wiki/wikka.php?wakka=ProPgDataExecutable

[^2_8]: https://www.freebasic.net/forum/viewtopic.php?t=20733

[^2_9]: https://fossies.org/linux/FreeBASIC/examples/manual/fileio/open.bas

[^2_10]: https://freebasic.net/forum/viewtopic.php?t=31690

[^2_11]: https://github.com/raysan5/raylib/discussions/2492

[^2_12]: https://freebasic.net/forum/viewtopic.php?t=32995

