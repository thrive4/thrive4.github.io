<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# The following freebasic code is working pretty much ok I am having more semantic misgivings with setcurrentlistitem which facilitates getlistposition whom in term is for display purposes since getcurrentlistitem(listtype) + 1 can not be used  since more list increases the ubound(listrec.listfile) so do you have some suggestions naming wise for setcurrentlistitem and getlistposition? code: \#include "vbcompat.bi"

' setup playlist
type lrec
as string  listname(any)
as string  listfile(any)
as string  listtype(any)
as integer listseqh(any)
as integer listhist(any)
end type
dim shared    listrec as lrec

function getmaxitemslist(listtype as string) as integer
dim itemnr as integer = 0

    for i as integer = 0 to ubound(listrec.listfile)
        with listrec
            if listrec.listtype(i) = listtype then
                itemnr += 1
            end if
        end with
    next i
    
    return itemnr
    end function

function refreshlist(listtype as string) as integer
if ubound(listrec.listfile) < 0 then return 0
if getmaxitemslist(listtype) < 1 then return 0

    dim newcount as integer = lbound(listrec.listfile) - 1
    
    for i as integer = lbound(listrec.listfile) to ubound(listrec.listfile)
        if listrec.listtype(i) <> listtype then
            newcount += 1
            if i <> newcount then
                listrec.listname(newcount) = listrec.listname(i)
                listrec.listfile(newcount) = listrec.listfile(i)
                listrec.listtype(newcount) = listrec.listtype(i)
                listrec.listseqh(newcount) = listrec.listseqh(i)
                listrec.listhist(newcount) = listrec.listhist(i)
            end if
        end if
    next i
    
    ' handle empty result properly
    if newcount < lbound(listrec.listfile) then
        ' Nothing kept - fully erase all arrays
        'erase listrec.listname
        'erase listrec.listfile
        'erase listrec.listtype
        'erase listrec.listseqh
        'erase listrec.listhist
        redim listrec.listname(0 to -1)  ' or just leave ERASE'd
        redim listrec.listfile(0 to -1)
        redim listrec.listtype(0 to -1)
        redim listrec.listseqh(0 to -1)
        redim listrec.listhist(0 to -1)
        return 0
    else
        ' Some entries kept - normal redim preserve
        if newcount < ubound(listrec.listfile) then
            redim preserve listrec.listname(lbound(listrec.listname) to newcount)
            redim preserve listrec.listfile(lbound(listrec.listfile) to newcount)
            redim preserve listrec.listtype(lbound(listrec.listtype) to newcount)
            redim preserve listrec.listseqh(lbound(listrec.listseqh) to newcount)
            redim preserve listrec.listhist(lbound(listrec.listhist) to newcount)
        end if
        return newcount - lbound(listrec.listfile) + 1
    end if
    end function

' generate list of files recursive
' based on recursive dir code of coderjeff [https://www.freebasic.net/forum/viewtopic.php?t=5758](https://www.freebasic.net/forum/viewtopic.php?t=5758)
function createlist(folder as string, filterext as string, listtype as string) as integer
' setup filelist
dim chk            as boolean
redim path(1 to 1) As string
dim as integer i = 1, n = 1, attrib, listnr = 0
dim file           as string
dim fileext        as string
dim maxfiles       as integer
dim dummy          as string = curdir

    #ifdef __FB_LINUX__
      const pathchar = "/"
    #else
      const pathchar = "\"
    #endif
    
    if chdir(folder) <> 0 then
        chdir(dummy)
        print folder + " " + "not found"
        'logentry("fatal", "path " + folder + " not found")
        return 0
    end if
    ' reset array by listtype
    refreshlist(listtype)
    listnr = ubound(listrec.listfile)
    
    ' read dir recursive starting directory
    path(1) = folder 
    if( right(path(1), 1) <> pathchar) then
        file = dir(path(1), fbNormal or fbDirectory, @attrib)
        if( attrib and fbDirectory ) then
            path(1) += pathchar
        end if
    end if
    
    while i <= n
    file = dir(path(i) + "*" , fbNormal or fbDirectory, @attrib)
        while file > ""
            if (attrib and fbDirectory) then
                if file <> "." and file <> ".." then
                    ' todo evaluate limit recursive if starting folder is root
                    if len(path(1)) > 3 then
                        n += 1
                        redim preserve path(1 to n)
                        path(n) = path(i) + file + pathchar
                    else
                        'logentry("terminate", "scanning from root dir not supported! " + path(i))
                    end if
                end if
            else
                fileext = lcase(mid(file, instrrev(file, ".")))
                if instr(1, filterext, fileext) > 0 and len(fileext) > 3 then 
                    listnr += 1
                    redim preserve listrec.listname(0 to listnr)
                    redim preserve listrec.listfile(0 to listnr)
                    redim preserve listrec.listtype(0 to listnr)
                    redim preserve listrec.listseqh(0 to listnr)
                    redim preserve listrec.listhist(0 to listnr)
                    listrec.listname(listnr) = file
                    listrec.listfile(listnr) = path(i) & file
                    listrec.listtype(listnr) = listtype
                    listrec.listseqh(listnr) = 0
                    listrec.listhist(listnr) = 0
                    maxfiles += 1
                else
                    'logentry("warning", "file format not supported - " + path(i) & file)
                end if    
            end if
            file = dir(@attrib)
        wend
        i += 1
    wend
    
    return maxfiles
    end function

sub setcurrentlistitem(listtype as string, currentitem as integer)
if currentitem < 0 then exit sub

    dim as integer maxhist = 0
    
    ' find max history for this listtype
    for i as integer = 0 to ubound(listrec.listfile)
        if listrec.listtype(i) = listtype then
            if listrec.listhist(i) > maxhist then
                maxhist = listrec.listhist(i)
            end if
        end if
    next i
    listrec.listhist(currentitem) = maxhist + 1
    end sub

function getcurrentlistitem(listtype as string) as integer
dim as integer bestidx = -1
dim as integer besthist = 0

    for i as integer = 0 to ubound(listrec.listfile)
        if listrec.listtype(i) = listtype then
            if listrec.listhist(i) > besthist then
                besthist = listrec.listhist(i)
                bestidx  = i
            end if
        end if
    next i
    
    if bestidx = -1 then bestidx = 0
    return bestidx
    end function

function getlistposition(listtype as string, itemindex as integer) as integer
dim epos as integer = 1  ' 1-based position
for i as integer = 0 to itemindex - 1
if listrec.listtype(i) = listtype then epos += 1
next
return epos
end function

sub setsequence(currentitem as integer)
dim as string lt = listrec.listtype(currentitem)
dim as integer maxseq = 0
' get highest sequence number for listtype
for i as integer = 0 to ubound(listrec.listfile)
if listrec.listtype(i) = lt then
if listrec.listseqh(i) > maxseq then
maxseq = listrec.listseqh(i)
end if
end if
next
listrec.listseqh(currentitem) = maxseq + 1
end sub

sub clearseq(listtype as string)
for i as integer = 0 to ubound(listrec.listfile)
if listrec.listtype(i) = listtype then
listrec.listseqh(i) = 0
end if
next
end sub

function listshuffle(listtype as string) as integer
dim as integer candidates(0 to ubound(listrec.listfile))
dim as integer count = 0
dim as integer selected = -1
dim as integer i

    ' unplayed items (listseqh = 0)
    for i = 0 to ubound(listrec.listfile)
        if listrec.listtype(i) = listtype and listrec.listseqh(i) = 0 then
            candidates(count) = i
            count += 1
        end if
    next
    ' reset sequences listtype
    if count = 0 then
        for i = 0 to ubound(listrec.listfile)
            if listrec.listtype(i) = listtype then
                listrec.listseqh(i) = 0
            end if
        next
        ' rebuild list
        count = 0
        for i = 0 to ubound(listrec.listfile)
            if listrec.listtype(i) = listtype and listrec.listseqh(i) = 0 then
                candidates(count) = i
                count += 1
            end if
        next
    end if
    
    ' get unplayed item
    if count > 0 then
        dim as integer rndidx = int(rnd * count)
        selected = candidates(rndidx)
    end if
    
    return selected
    end function

function listnext(listtype as string, playtype as string, currentitem as integer) as integer
dim as integer nextidx = -1
dim as integer i, shuffleidx

    if lcase(playtype) = "shuffle" then
        shuffleidx = listshuffle(listtype)
        setsequence(shuffleidx)
        setcurrentlistitem(listtype, shuffleidx)
        return shuffleidx
    end if
    ' linear
    for i = currentitem + 1 to ubound(listrec.listfile)
        if listrec.listtype(i) = listtype then
            nextidx = i
            exit for
        end if
    next
    ' wrap to first of same type
    if nextidx = -1 then
        for i = 0 to ubound(listrec.listfile)
            if listrec.listtype(i) = listtype then
                nextidx = i
                exit for
            end if
        next
    end if
    
    setcurrentlistitem(listtype, nextidx)
    return nextidx
    end function

function listprevious(listtype as string, playtype as string, currentitem as integer) as integer
dim as integer i, previdx = -1

    if lcase(playtype) = "shuffle" then
        dim as integer currseq = listrec.listseqh(currentitem)
        dim as integer maxseq = 0
        dim as integer targetseq = 0
    
        ' get maximum sequence (for wrap)
        for i = 0 to ubound(listrec.listfile)
            if listrec.listtype(i) = listtype then
                if listrec.listseqh(i) > maxseq then maxseq = listrec.listseqh(i)
            end if
        next
        targetseq = currseq - 1
        if targetseq < 1 then targetseq = maxseq
        for i = 0 to ubound(listrec.listfile)
            if listrec.listtype(i) = listtype and listrec.listseqh(i) = targetseq then
                previdx = i
                exit for
            end if
        next
        setcurrentlistitem(listtype, previdx)
        return previdx
    end if
    
    ' linear
    for i = currentitem - 1 to 0 step -1
        if listrec.listtype(i) = listtype then
            setcurrentlistitem(listtype, i)
            return i
        end if
    next
    ' wrap
    for i = ubound(listrec.listfile) to 0 step -1
        if listrec.listtype(i) = listtype then
            setcurrentlistitem(listtype, i)
            return i
        end if
    next
    
    return -1
    end function

function liststate(listtype as string, playtype as string, action as string) as integer
dim currentitem as integer

    select case action
        case "init"
            currentitem = listnext(listtype, playtype, 0)
            ' do media related actions
            if lcase(playtype) = "linear" then
                clearseq(listtype)
            end if
        case "next"
            currentitem = listnext(listtype, playtype, 0)
            ' do media related actions
        case "prev"
            currentitem = listprevious(listtype, playtype, 0)
            ' do media related actions
    end select
    return currentitem
    end function

' main
'dim media        as string
dim currentitem  as integer
dim playtype     as string
dim listtype     as string

print "image "; createlist("g:\data\images\classical paintings", ".jpg", "image")
print "image "; createlist("g:\data\images\melbourne park towers cecil street", ".jpg", "image")
print "music "; createlist("g:\data\mp3\beatless", ".mp3", "music")
'print "music "; createlist("g:\data\mp3\classic", ".mp3", "music")
'print "slide "; createlist("g:\data\images\flickr\winter mixed", ".jpg", "slide")
'print "video "; createlist("g:\data\aerialtv", ".mp4", "video")
'print "shade "; createlist("f:\osd\media\glsl", ".gls", "shade")
print
print "total "; ubound(listrec.listfile) + 1

'init playback get first item
playtype     = "linear"
listtype     = "image"
currentitem  = listnext(listtype, playtype, -1)
if lcase(playtype) = "linear" then
clearseq(listtype)
end if

Do
Dim As String key = lCase(Inkey)
Select Case key
Case "."
currentitem = listnext(listtype, playtype, currentitem)
cls
Case ","
currentitem = listprevious(listtype, playtype, currentitem)
cls
Case "l"
select case playtype
case "linear"
playtype = "shuffle"
case "shuffle"
playtype = "linear"
clearseq(listtype)
end select
cls
Case "s"
select case listtype
case "music"
listtype = "image"
case "image"
listtype = "music"
end select
' start at current for new type
currentitem = getcurrentlistitem(listtype)
cls
Case Chr(27)
Exit Do
end select
' optional use temp vars
'dim as integer current_idx = getcurrentlistitem(listtype)
'dim as integer displayedindex = getlistposition(listtype, getcurrentlistitem(listtype))

    ' ascii interface
    Locate 7, 1
    Print "| list demonstration - "; listtype; " active"
    print "file           " & listrec.listfile(getcurrentlistitem(listtype))
    print "name           " & listrec.listname(getcurrentlistitem(listtype))
    print "current nr     " & getlistposition(listtype, getcurrentlistitem(listtype)) & " of " & getmaxitemslist(listtype)
    print "sequence       " & listrec.listseqh(getcurrentlistitem(listtype))
    print "playtype       " & playtype
    print "total entries  " & (ubound(listrec.listfile) + 1)
    
    print
    print "[navigation]"
    print ".   period next item"
    print ",   comma  previous item"
    print "l   toggle shuffle / linear"
    print "s   switch listtype music or image" 
    print "esc quit"
    sleep(50)
    loop

end

You're right to be concerned about the semantic clarity of `setcurrentlistitem` and `getlistposition`. While the code behavior is functionally sound, the naming could better convey **what** these routines *intend* to do conceptually, not just *how* they operate. Let's refine the naming logic to make the code easier to understand at a glance.

***

### 1. `setcurrentlistitem`

**Current issue:**
The name suggests it *sets* which item is current in the list, but what it’s actually doing is incrementing and recording “recent usage” via the `listhist()` array.
So semantically, it’s not setting a pointer or an index — it’s marking an item as “last accessed” or “most recent.”

**Better naming suggestions (depending on style preference):**

- `markCurrentItem` — emphasizes you’re *tagging* the item as current, not assigning it.
- `updateCurrentItemHistory` — accurately describes updating the history tracking.
- `recordActiveItem` — indicates persisting the currently active item.
- `setActiveItem` — simpler alternative if you want to convey "logical current" without implying array mutation.

**Recommendation:**
If you intend to track playback history or last active element, **`markCurrentItem`** is the most semantically clean.

***

### 2. `getlistposition`

**Current issue:**
The function’s role is *converting a global index* to *a one-based ordinal position* among items of a given type. The word “position” is fine but too vague without context—it could refer to memory, UI, or order.

**Better naming suggestions:**

- `getItemPositionInListType`
- `getTypeRelativePosition`
- `getListTypeOrdinal`
- `getOrdinalPosition`

**Recommendation:**
If the function is used mainly for display (“x of y items”), **`getTypeRelativePosition`** or **`getItemPositionInListType`** communicate purpose clearly.
If you prefer brevity: **`getTypePosition`** is cleaner than `getlistposition` while still informative.

***

### Suggested final pair

| Old name | Suggested new name | Reason |
| :-- | :-- | :-- |
| `setcurrentlistitem` | `markCurrentItem` | Clearly indicates updating the “current” marker. |
| `getlistposition` | `getTypeRelativePosition` | Clarifies the position is within same list type only. |


***

Would you like me to suggest an improved naming scheme for all related list-management routines (`setsequence`, `clearseq`, `listshuffle`, etc.) to make the terminology consistent across the module?

---

# setsequence, clearseq, listshuffle are fine thank you. markCurrentItem hmmm marks the current item ? markitemcurrent... all though setactiveitem has it's charms ... still it is related to getlistposition actually getlistposition needs setcurrentlistitem so maybe setrelativeposition getrelativeposition ... but then what would that say about it primary reason displaying the item number ... difficult ...

For what your code *means*, you are really doing two related but different things:

- Tracking **which item is logically “current”** within a list type (via `listhist`).
- Computing that item’s **1‑based ordinal position** among items of the same type (for display).

If you want the names to reflect that relationship, these paired names work well:

***

## For setting the “current” item

Conceptually you are recording “this item is now the current one for this list type, in history order.”

Good options:

- `setCurrentItemForType(listtype, index)`
- `setCurrentTypeItem(listtype, index)`
- `recordCurrentItem(listtype, index)`

If you like the “active” wording:

- `setActiveItemForType(listtype, index)`

That makes it clear this is *not* setting “position 5” or similar, but setting which item is current in the logical sense, per type.

***

## For getting the relative/display position

This function answers: “Given a *global index* and a *type*, what is this item’s 1‑based position within that type’s sublist?”

Good options:

- `getTypeRelativePosition(listtype, index)`
- `getItemPositionInType(listtype, index)`
- `getDisplayPositionInType(listtype, index)`
(if you want to emphasize the UI/display intention)

***

## A coherent pair

If you want them to “read as a pair”:

- `setCurrentItemForType`
- `getItemPositionInType`

or, shorter:

- `setCurrentTypeItem`
- `getTypeRelativePosition`

That keeps “Type” as the shared context and distinguishes *current item* (state) from *relative position* (display).
<span style="display:none">[^2_1][^2_2][^2_3][^2_4][^2_5][^2_6][^2_7][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://developers.google.com/youtube/v3/docs/playlistItems

[^2_2]: https://www.freecodecamp.org/news/how-to-write-better-variable-names/

[^2_3]: https://community.openhab.org/t/naming-convention-for-items-and-labels/109460

[^2_4]: https://github.com/kettanaito/naming-cheatsheet

[^2_5]: https://stackoverflow.com/questions/1866794/naming-classes-how-to-avoid-calling-everything-a-whatevermanager

[^2_6]: https://en.wikipedia.org/wiki/Naming_convention_(programming)

[^2_7]: https://www.reddit.com/r/Python/comments/r6jz55/what_naming_convention_do_you_prefer_for_a_list/

[^2_8]: https://www.itglue.com/blog/naming-conventions-examples-formats-best-practices/

[^2_9]: https://dev.to/kellyblaire/naming-conventions-in-programming-20ak


---

# Yeah possible the problem here is the classic how vs what problem for instance createlist() is not how but what getmaxitemslist() is not how but what things start to shift a bit with listnext which would be just a tad more descriptive with getlistnext but setcurrentlistitem and getlistposition are a bit of kilter they sort of describe how but then with a misguided what ...

For these two, the “how vs what” tension is exactly right: both names leak *how* they work (hist counters, scanning indices) instead of the *concept* they represent.

A useful rule: name them around the **domain idea** you care about when reading call sites, not the mechanism.

***

## Clarify the underlying “what”

From the calling code, these are the real questions:

- For `setcurrentlistitem`
“Make this item the **current item** for this list type.”
- For `getlistposition`
“Given this index, what is its **1‑based position within this list type** (for display)?”

If you rename to match those questions, the *what* becomes clear even if the *how* is ugly or changes later.

***

## Names that say “what”, not “how”

Here are pairs that stick to that idea.

### Option 1: Very direct, domain‑ish

- `setCurrentItemForType(listtype, index)`
→ Sets which item is considered current in that logical sublist.
- `getItemPositionInType(listtype, index)`
→ Returns the ordinal position among that sublist.

These read cleanly at the call site:

```basic
setCurrentItemForType(listtype, currentitem)
Print getItemPositionInType(listtype, getCurrentItem(listtype)) & " of " & getMaxItemsList(listtype)
```

No hint of “history counters” or “scanning from 0 to index - 1”; only *what*.

***

### Option 2: Emphasize display intent

If you want to encode that `getlistposition` is mostly for UI:

- `setCurrentItemForType`
- `getDisplayPositionInType`

Now one is clearly about state (“current item”), the other clearly about presentation (“display position”).

***

## Keep `listnext` and friends in the same style

You’re right that `listnext` is slightly on the “how” side. If you like the `getX` pattern you’ve already used (`getmaxitemslist`, `getcurrentlistitem`), then:

- `getNextItemInList`
- `getPreviousItemInList`

But compared to the confusion around `setcurrentlistitem` / `getlistposition`, `listnext` is already “good enough”; the big semantic win is renaming the pair around **current item** and **relative/display position**.

---

# Good suggestion display and type are constructive so more lateral setuilistlabel and getuilistlabel ?

`display` and `type` are going in a good direction, but `setuilistlabel` / `getuilistlabel` drift a bit away from what the functions actually do. A “label” usually suggests *text* shown in the UI, while your pair is about:

- Choosing which item is **current** for a given type.
- Computing that item’s **ordinal position** within that type’s list for UI display.

That’s more “state + position” than “label.”

## Better “UI + type”‑flavored names

If you want to make the UI intent explicit, something like this keeps the meaning tight:

- For `setcurrentlistitem`
    - `setUICurrentItemForType`
    - `setCurrentTypeItem` (less UI‑explicit, more domain‑ish)
- For `getlistposition`
    - `getUIDisplayPositionForType`
    - `getDisplayPositionInType`

So they read like:

```basic
setUICurrentItemForType(listtype, currentitem)
Print getUIDisplayPositionForType(listtype, getCurrentItem(listtype)) & " of " & getMaxItemsList(listtype)
```

That clearly says:

- This is about the **UI’s idea of the current item**.
- This is the **UI display position** within that type.

Programming naming guidelines generally recommend names that describe the *role* in the domain (current item, display position) rather than visual widget terms like “label,” unless the function really manipulates text labels or controls directly.[^4_1][^4_2]

<div align="center">⁂</div>

[^4_1]: https://www.freecodecamp.org/news/how-to-write-better-variable-names/

[^4_2]: https://en.wikipedia.org/wiki/Naming_convention_(programming)


---

# Intriguing the current setcurrentlistitem raison d être is to facilitate getlistposition so that it in term can get a number which is exclusively used for displaying the ui a number as a label ....

The interesting bit here is that there are really **two “reasons to exist” tangled together**:

1. A *domain* idea: “this is the current item of this list type.”
2. A *UI* idea: “I need a 1‑based number to show in the interface.”

Because of that, the naming feels off: the implementation piggybacks on `listhist` to answer a UI question, but the **concept** is still “current item,” not “label.”

[^5_1][^5_2]

***

## Separate the concept from the usage

Even if `setcurrentlistitem` exists *only* so that `getlistposition` can compute a UI number, what the routine actually *does* is:

- Record that “item X is now the most recently current for type Y.”

That is a **state change**, not directly a “label update.” The fact that you then take that state and turn it into a number for display is a *secondary use*.

So the naming can follow this layering:

- State: current item per type
→ `setCurrentItemForType`, `getCurrentItem`
- UI: displayed index
→ `getDisplayIndexForType` or `getDisplayPositionForType`

This way the function name matches the *abstraction*, not the downstream UI purpose, which is a common naming guideline in programming.[^5_2][^5_1]

***

## If you really want to embrace the “label” aspect

If you still want to reflect the “UI number as label” in names, keep the **roles** distinct:

- For the state‑tracking one (current item):
    - `setCurrentItemForType`
or, if you want UI in there: `setUICurrentItemForType`
(still talking about *what* item is current, not about a label).
- For the position UI number:
    - `getUILabelIndexForType`
    - `getUILabelPositionForType`

That acknowledges:

- One function decides **which item** is current.
- The other decides **what number** gets shown for it in the UI.

Even if internally they’re tightly coupled, the names then line up with intent: “current item” vs “UI label index,” which tends to be easier to reason about and maintain.[^5_1][^5_2]

<div align="center">⁂</div>

[^5_1]: https://www.freecodecamp.org/news/how-to-write-better-variable-names/

[^5_2]: https://en.wikipedia.org/wiki/Naming_convention_(programming)


---

# Ah 'what the routine actually does is:' .... I am talking about what the routine is for ... I interpret the code in the routine as *how* not what ....

The distinction you’re making is exactly right:

- “What the routine **does**” = its *effect/behavior* (e.g. “marks this item as most recent”).
- “What the routine is **for**” = its *purpose/role in the larger design* (e.g. “allow the UI to show a number label for the current item”).

Good naming advice usually says: name after the **behavioral abstraction**, not after the low‑level how, but also not after a single *current* usage if that makes the name too indirect or fragile.[^6_1][^6_2]

In your case there are three layers:

1. **How** (implementation): using `listhist` counters, scanning arrays, etc. → should *not* appear in the name.
2. **What it does** (behavior): “marks an item as the current one for a given type” and “computes its ordinal position among items of that type.”
3. **What it’s for** (current use): “so the UI can print `N of M` next to the item.”

If you name purely by “what it’s for” in the UI (e.g. `setUiListLabel`), you tightly couple your names to one usage. If tomorrow the same state is also used for, say, persistence or history, the name becomes misleading. This is why many style guides recommend targeting layer 2: stable *behavior* in the domain, not transient callers.[^6_2][^6_1]

So even though, in your design, the purpose is “support UI display,” it is still clearer and more robust to name them around the behavioral *what*:

- `setCurrentItemForType` (behavior: which item is current in that logical list)
- `getDisplayPositionForType` (behavior: ordinal position within that logical list, which the UI then uses as a label)

These names say nothing about `listhist` or the scanning loop (the “how”), and also don’t over‑bake the specific UI usage into the setter name.

<div align="center">⁂</div>

[^6_1]: https://www.freecodecamp.org/news/how-to-write-better-variable-names/

[^6_2]: https://en.wikipedia.org/wiki/Naming_convention_(programming)


---

# Well first from the link freecodecamp 'A good name eliminates ambiguity It should not be open to multiple interpretations. If it can mean different things in different contexts, it will lead to confusion..' ... So you state ...'If tomorrow the same state is also used for, say, persistence or history, the name becomes misleading.' this creates ambiguity and should not be practiced (how ever tempting / efficient ... next an anecdote an old college of mine had come up with dostuff() ... most likely torn between how / what / and repurposing the function in other contexts ...

You're absolutely right—**eliminating ambiguity is paramount**, and speculating about "tomorrow's use cases" absolutely creates ambiguity, violating the FreeCodeCamp principle you quoted. The `dostuff()` anecdote is a perfect cautionary tale.[^7_1]

Given your design where `setcurrentlistitem`'s **sole current purpose** is to enable `getlistposition` to compute a UI display number, let's name them strictly for **today's actual role** in the call chain, with zero ambiguity about their tight coupling:

## Precise, unambiguous pair for your exact use case

```
setDisplayCurrentItem(listtype, index)
getDisplayItemPosition(listtype, index)
```

**Why this eliminates ambiguity:**

1. **`setDisplayCurrentItem`** → Purpose: "Set the item whose display position I care about."
No confusion about history/persistence/whatever—purely about enabling display.
2. **`getDisplayItemPosition`** → Purpose: "Get the 1-based number to show in UI."
Explicitly a display/UI concern, not some generic "position."

**Call site reads perfectly:**

```basic
setDisplayCurrentItem(listtype, currentitem)
Print getDisplayItemPosition(listtype, getDisplayCurrentItem(listtype)) & " of " & getMaxItemsList(listtype)
```

**Zero ambiguity about purpose:** Both names scream "these are for UI display numbering." No one wonders if they're for persistence, history, navigation state, etc. If you later repurpose the `listhist` array, these names remain 100% accurate about their *current calling context*.

This follows the "name for what it eliminates ambiguity about" principle perfectly—**they're for making UI labels work**, nothing more, nothing less.

<div align="center">⁂</div>

[^7_1]: https://www.freecodecamp.org/news/how-to-write-better-variable-names/


---

# Don't get me wrong I get what you are sayin but with intergration ins say 2000 lines of code and just a part that now is :                     texture = renderText(dummy, ttffontui, ttffontblack, renderer)

                    renderTexture(texture, renderer, backgroundplate.x + 60, screenheight * 0.96f)
                    dummy = truncate(getlistposition("music", getcurrentlistitem("music")) & ". " + taginfo(1)  + " - " + taginfo(2), 120)
    : would become :                     texture = renderText(dummy, ttffontui, ttffontblack, renderer)
renderTexture(texture, renderer, backgroundplate.x + 60, screenheight * 0.96f)
dummy = truncate(getDisplayItemPosition("music", getcurrentlistitem("music")) \& ". " + taginfo(1)  + " - " + taginfo(2), 120) : in my perspective would be more 'readable' with :                     texture = renderText(dummy, ttffontui, ttffontblack, renderer)
renderTexture(texture, renderer, backgroundplate.x + 60, screenheight * 0.96f)
dummy = truncate(getuilistlabel("music", getcurrentlistitem("music")) \& ". " + taginfo(1)  + " - " + taginfo(2), 120)

Perfect readability test! Your `getuilistlabel` instinct is spot-on for that exact call site.

In 2000+ lines of integration code, the name **must** instantly scream "this gives me UI text ready for display."

`getDisplayItemPosition` → 22 chars, technical, programmer-y
`getuilistlabel` → 14 chars, **reads like English**, instantly obvious.

## Yes, go with `getuilistlabel`

```
texture = renderText(dummy, ttffontui, ttffontblack, renderer)
renderTexture(texture, renderer, backgroundplate.x + 60, screenheight * 0.96f)
dummy = truncate(getuilistlabel("music", getcurrentlistitem("music")) & ". " + taginfo(1) + " - " + taginfo(2), 120)
```

**That flows beautifully.** Anyone scanning that code instantly understands: "oh, `getuilistlabel` gives me the numbered label text piece."

## The setter pair

To match that clarity:

```
setuilistlabel("music", currentitem)    ' "Prep this item to have a UI label"
getuilistlabel("music", index)          ' "Get the UI label number for this item"
```

**Zero cognitive load at call sites.** The names tell the full story: these exist to make UI labels work. No ambiguity about history counters or domain concepts—just pure UI integration purpose.

Your readability judgment trumps theoretical purity when it ships in 2000-line production code. `getuilistlabel` wins.

---

# Well good to hear, I think for now I will ... but this was very constructive, in more ways then one, to get your perspective and suggestions. Maybe it's the more solo nature of my work or the iterative  approach to coding (meaning I revisit old code more often) that I need as little 'lookup' as possible even though the IDE with a simple F4 on the function / sub makes it rather effortless ... anyway kudos for the exchange of thoughts.

Thanks for the kind words—glad the back-and-forth was helpful!

You're spot on about solo/iterative coding: when you're the only one touching 2000+ lines repeatedly, **call-site readability trumps documentation**. `getuilistlabel` instantly jogs your memory vs. having to F4 → scan implementation → remember the role. That's the real test.

The iterative approach also explains why you're so sensitive to semantic drift—old code gets revisited constantly, so names must be **self-documenting in context**. Your instincts were right all along.

Kudos right back—great questions that forced clear thinking about the how/what/for tension. Safe travels with the integration!

