<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# There are still some lingering issues I have with heterogeneous partition types on a drive with regard to pop os (debian) ext4 and windows ntfs. So common knowledge don't make a swapfile for pop os on a ntfs partition, next mixing ntfs and ext4 on a same drive causes slight issues mount point wise which can be more or less addressed with some tricks in fstab ... but how about things like running a windows app under wine which writes to a ext4 partition or should it write to a nfts partition and just in general pop os support to ntfs (read / write) what is considered safe?

On Pop!_OS (and Linux in general), it is safe for Windows apps under Wine to read/write on **either** ext4 or NTFS, but ext4 is preferred for anything performance‑sensitive, while NTFS is best reserved for shared/cross‑OS data and with some caveats.

## Basics: ext4 vs NTFS on the same drive

- Linux has full, mature read/write support for ext4; it is the native filesystem and the most reliable choice for your Linux system and apps.
- NTFS support on Linux is good but still a reverse‑engineered driver; it works fine for everyday use but is more fragile if Windows leaves the partition “dirty” (fast startup, hibernation, crashes, etc.). In those cases Linux will mount it read‑only or refuse to mount until you fix it from Windows.

Mixing ext4 and NTFS partitions on the same physical drive is technically fine; the “issues” are mostly about mount options, permissions, and Windows’ habit of leaving NTFS in a state that Linux doesn’t like. Proper entries in `/etc/fstab` and disabling Windows Fast Startup/hibernation usually resolve this.

## Where should Wine programs write?

Think of Wine apps as just Linux processes that happen to speak the Windows API:

- They do **not** need NTFS. A Windows `.exe` can live on ext4, and Wine will happily run it and let it store its files on ext4. This is usually the best choice for your Wine prefix (`~/.wine`) and for most program data, because ext4 is faster and more robust on Linux.
- You only really **need** NTFS when you want to share the same files between Linux and a real Windows install (e.g., a shared “Games” or “Documents” partition). In that case, it is fine for Wine apps to read/write that NTFS partition as long as it is cleanly unmounted from Windows and mounted correctly in Linux.

So in practice:

- Put Wine prefixes, installed apps, and “Linux‑only” game libraries on ext4.
- Use an NTFS (or exFAT) data partition only for stuff you truly want both Windows and Linux to see, and accept a small performance/robustness trade‑off.


## Safety and best practices for NTFS under Pop!_OS

To keep NTFS usage “safe enough”:

- In Windows:
    - Disable Fast Startup and avoid hibernation so partitions are cleanly closed.
    - Run `chkdsk` if Linux refuses to mount or only mounts read‑only.
- In Pop!_OS:
    - Mount NTFS partitions with proper options in `/etc/fstab` (uid/gid/umask/fmask/dmask) so your user has the right permissions.
    - Treat NTFS as less trusted: keep backups, and avoid putting irreplaceable Linux system data there.

As for the specific “don’t put swap on NTFS”: keep swap on a dedicated partition or an ext4 swapfile, never on NTFS. That advice doesn’t extend to general file I/O; normal data on NTFS is fine, just not as ideal as ext4 for heavy Linux workloads.

## Practical recommendation

- Install Pop!_OS on ext4, including your home and Wine prefixes.
- Create one separate NTFS (or exFAT) partition strictly as a shared “data” volume between Windows and Pop!_OS.
- Point Wine apps to that shared partition only for data you genuinely need on both OSes; keep everything else on ext4.

If you describe your current partition layout (what’s on which drive, which ones you want shared), I can suggest concrete `/etc/fstab` entries and a layout tailored to your setup.
<span style="display:none">[^1_1][^1_10][^1_2][^1_3][^1_4][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://www.reddit.com/r/pop_os/comments/qigyh4/using_pop_os_with_ntfs_partition/

[^1_2]: http://livebg.net/docs/wine/wine-user/with-windows.html

[^1_3]: https://www.reddit.com/r/linux4noobs/comments/ekpisk/ntfs_or_ext4/

[^1_4]: https://www.reddit.com/r/pop_os/comments/11mvu23/ntfs_vs_ext4/

[^1_5]: https://www.reddit.com/r/pop_os/comments/ukdxvf/correct_way_to_mount_an_ntfs_drive_in_pop_os_2110/

[^1_6]: https://forum.winehq.org/viewtopic.php?t=38306

[^1_7]: https://yomotherboard.com/question/what-filesystem-should-i-choose-for-dual-booting-windows-and-linux/

[^1_8]: https://ubuntuforums.org/showthread.php?t=2242045

[^1_9]: https://www.reddit.com/r/pop_os/comments/x0z30w/nfts_disk_wont_write_on_pop_os_2204/

[^1_10]: https://www.reddit.com/r/linuxquestions/comments/13shuo5/how_does_wine_translate_between_ntfs_and_ext4/


---

# Lot to take in here ... ok lets start with games they can be quite large, on the other hand they often might not run under wine / pop os, so putting them on a ntfs partition (with windows as bakup os) is a more cautious route which in turn means trying a game under wine / pop os will inevitability mean the game is launched from ntfs and most likely will want  to write to nfts ...

You’re thinking about it in exactly the right way. For big games that you want to keep playable in Windows, putting them on an NTFS “games” partition and launching them from there under Wine is a very common and reasonable setup.

Here’s the practical picture:

## Is running games off NTFS under Wine “safe”?

- From a data‑integrity standpoint, it’s generally safe as long as Windows is **fully** shut down (no Fast Startup, no hibernation) before you boot Pop!_OS, and the NTFS partition is clean.
- Wine does not care that the filesystem is NTFS vs ext4; it just sees a mounted directory. The main risks are the same as any NTFS‑on‑Linux use: if Windows crashes or leaves the filesystem dirty and you keep writing from Linux, you can corrupt files.

So: if Windows is cleanly shut down and NTFS is mounted normally in Pop!_OS, letting games read/write from that partition is acceptable.

## Downsides of running from NTFS

For games in particular, there are some practical downsides:

- Slight performance hit: NTFS drivers on Linux are not as fast/optimized as ext4, especially for many small file reads/writes and metadata operations. Load times and patching can be a bit slower.
- More fragile for very write‑heavy workloads: big patches, shader cache generation, log spam, etc., stress the filesystem more. NTFS will handle it, but if something goes wrong (power loss, dirty shutdown from Windows), recovery is trickier than with ext4.
- Permissions quirks: NTFS doesn’t support Linux ownership/permissions natively, so everything is synthesized via mount options. This usually works, but sometimes you get odd behavior if you move files back and forth between tools, users, or OSes.

None of these are “show‑stoppers”; they’re just reasons why ext4 is nicer when you can use it.

## When NTFS is the right choice

Giving your constraints:

- If a game is **primarily** for Windows and you’re just “trying it under Wine to see if it runs,” keeping it on the NTFS “Windows games” partition is smart. You avoid doubling disk usage and keep Windows as the primary, reliable environment for that install.
- If the game turns out to run great under Wine and you play it mostly in Pop!_OS, you can later decide to:
    - Reinstall it to an ext4 library (Lutris/Steam library on ext4), or
    - Copy the entire game directory from NTFS to ext4 and point Wine/launcher to the ext4 copy.

That way you start cautious (NTFS shared), then move successful games to ext4 for better performance and robustness.

## Concrete workflow to keep things sane

I’d recommend this pattern:

1. Have one NTFS “Games” partition used by Windows.
2. In Pop!_OS, mount that NTFS partition at a stable path (e.g. `/mnt/games_ntfs`) via `/etc/fstab`.
3. For new Windows‑only games:
    - Install them in Windows on the NTFS partition.
    - In Wine/Lutris/Steam on Pop!_OS, point the game to that existing install on `/mnt/games_ntfs/...` and test.
4. If a game becomes a “Linux primary” title for you:
    - Copy it to an ext4 library (e.g. `/games/ext4-library/...`) when convenient.
    - Reconfigure the launcher to use the ext4 location.

Meanwhile, always:

- Disable Windows Fast Startup and avoid hibernation so NTFS is clean when you boot Pop!_OS.
- If Pop!_OS ever complains or mounts NTFS read‑only, reboot into Windows, run a disk check, then return to Pop!_OS.

If you tell me your current drive layout (sizes and which partitions are ext4/NTFS) and how much space you want to reserve for Windows vs Pop!_OS games, I can suggest a concrete partition/library layout and an example `/etc/fstab` line for your NTFS games partition.

---

# Ok sound advice. 'Disable Windows Fast Startup' pops up a lot ... where can I do that?

Here’s where to turn it off in Windows 10/11:

1. Open the classic Control Panel.
    - Press Win key, type “Control Panel”, press Enter.
2. Go to “Hardware and Sound” → “Power Options”.
3. In the left sidebar, click “Choose what the power buttons do”.
4. Click the link “Change settings that are currently unavailable” (you may get an admin/UAC prompt).
5. Under “Shutdown settings”, untick “Turn on fast startup (recommended)”.
6. Click “Save changes”.
7. Do a full shutdown and power on again (not restart) to be sure it’s really doing a full shutdown now.

If you ever want the “nuclear” option: disabling hibernation from an elevated Command Prompt or PowerShell (`powercfg /hibernate off`) also disables Fast Startup, because it relies on the hibernation file.
<span style="display:none">[^3_1][^3_10][^3_2][^3_3][^3_4][^3_5][^3_6][^3_7][^3_8][^3_9]</span>

<div align="center">⁂</div>

[^3_1]: https://windowsforum.com/threads/disable-windows-fast-startup-pros-cons-and-a-clear-step-by-step-guide.386509/

[^3_2]: https://www.ninjaone.com/script-hub/how-to-disable-fast-startup-in-windows/

[^3_3]: https://help.uaudio.com/hc/en-us/articles/213195423-How-To-Disable-Fast-Startup-in-Windows

[^3_4]: https://www.pdq.com/blog/how-to-disable-fast-startup/

[^3_5]: https://www.asus.com/support/faq/1045548/

[^3_6]: https://www.asus.com/us/support/faq/1045548/

[^3_7]: https://www.dedoimedo.com/computers/windows-11-fast-startup-disable.html

[^3_8]: https://www.youtube.com/watch?v=d0mqnt0pzRc

[^3_9]: https://learn.microsoft.com/en-us/answers/questions/4040546/how-do-i-disable-fast-startup

[^3_10]: https://support.lenovo.com/us/en/solutions/ht513773-how-to-enable-or-disable-fast-startup-on-windows-11


---

# Ahhh : powercfg /hibernate off : forgot about that one didn't know it also disables fast startup .... gracias. powercfg -q what's supposed to indicate 'fast startup' ?

`powercfg -q` just dumps all power settings; there isn’t a single obvious “Fast Startup: On/Off” line in that output, so it’s a pain to read for this purpose.

Much easier ways to check Fast Startup:

1. Using `powercfg /a`
    - Open an elevated Command Prompt.
    - Run:
`powercfg /a`
    - If hibernation is disabled by `powercfg /hibernate off`, you’ll see that hibernate and Fast Startup–related states are unavailable. That effectively means Fast Startup is off too, because it depends on hibernation.
2. Using the registry / PowerShell (most precise)
    - Open PowerShell as admin and run:
`(Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power").HiberbootEnabled`
    - Result `1` = Fast Startup enabled.
    - Result `0` = Fast Startup disabled.

In short: `powercfg -q` can show all the underlying settings but there’s no simple, dedicated “fast startup” flag there; for a clear yes/no, use Control Panel, `powercfg /a`, or the `HiberbootEnabled` registry value.
<span style="display:none">[^4_1][^4_10][^4_2][^4_3][^4_4][^4_5][^4_6][^4_7][^4_8][^4_9]</span>

<div align="center">⁂</div>

[^4_1]: https://www.elevenforum.com/t/is-fast-startup-on-or-off.37100/

[^4_2]: https://dev.to/kasuken/turn-on-or-off-fast-startup-in-windows-11-4pgh

[^4_3]: https://www.windowscentral.com/software-apps/windows-11/how-to-enable-or-disable-fast-startup-on-windows-11

[^4_4]: https://www.youtube.com/watch?v=JBp4hNwBqsA

[^4_5]: https://www.windowscentral.com/how-control-fast-startup-feature-your-windows-10-pc

[^4_6]: https://www.hp.com/us-en/shop/tech-takes/how-to-optimize-fast-startup-windows

[^4_7]: https://learn.microsoft.com/en-us/answers/questions/2824869/turn-on-fast-startup

[^4_8]: https://learn.microsoft.com/en-us/answers/questions/5537465/how-to-disable-hibernation-and-fast-start-up-in-wi

[^4_9]: https://support.lenovo.com/us/en/solutions/ht513773-how-to-enable-or-disable-fast-startup-on-windows-11

[^4_10]: https://www.tenforums.com/tutorials/4189-turn-off-fast-startup-windows-10-a-14.html


---

# Ok granted I'm on windows 7 at the moment but : g:\\>powercfg /a

The following sleep states are available on this system: Standby ( S3 )
The following sleep states are not available on this system:
Standby (S1)
The system firmware does not support this standby state.
Standby (S2)
The system firmware does not support this standby state.
Hibernate
Hibernation has not been enabled.
Hybrid Sleep

On Windows 7 specifically, what you’re seeing is normal and actually good news for dual‑booting:

- Windows 7 does **not** have the Fast Startup / Fast Boot feature that was introduced later with Windows 8+.
- On your output, `Hibernate` is “not available” and “Hibernation has not been enabled”, which means there is no hibernation file and therefore nothing like Fast Startup happening via hybrid shutdown.

So:

- `powercfg /hibernate off` on Windows 7 simply turns hibernation off (or confirms it’s off); there is no separate “Fast Startup” toggle in this OS.
- `powercfg -q` on Windows 7 will not show any “Fast Startup” related setting the way it does on Windows 10/11; all you care about is that hibernation is disabled and you are doing normal full shutdowns.

For your dual‑boot Pop!_OS + Windows 7 setup, that effectively means you’re already in a “Fast Startup disabled” world as long as you keep hibernation off and always shut down Windows fully before booting Linux.
<span style="display:none">[^5_1][^5_10][^5_2][^5_3][^5_4][^5_5][^5_6][^5_7][^5_8][^5_9]</span>

<div align="center">⁂</div>

[^5_1]: https://www.itarian.com/blog/how-to-disable-fast-startup/

[^5_2]: https://droidrant.com/how-do-i-disable-fast-startup-windows-7/

[^5_3]: https://blog.comodo.com/pc-security/how-to-disable-fast-startup/

[^5_4]: https://bettercomputertech.com/windows-fast-startup-should-you-turn-it-off/

[^5_5]: https://help.uaudio.com/hc/en-us/articles/213195423-How-To-Disable-Fast-Startup-in-Windows

[^5_6]: https://www.asus.com/us/support/faq/1045548/

[^5_7]: https://www.pdq.com/blog/how-to-disable-fast-startup/

[^5_8]: https://learn.microsoft.com/en-us/answers/questions/2754501/how-to-turn-off-fast-startup-or-quick-boot-in-wind?page=1

[^5_9]: https://www.reddit.com/r/Surface/comments/4x7n41/psa_disable_fast_startup_to_force_windows_to_load/

[^5_10]: https://www.youtube.com/watch?v=6P-fR74qWIw


---

# Ok I'll do it on windows 10 (but I don't go online with that but I assume the info is correct) that 'system firmware' thing I noticed that on my new system there is some setting fast boot in the bios ... is that related?

**No, the BIOS "Fast Boot" setting is unrelated to Windows Fast Startup.**

The BIOS/UEFI "Fast Boot" (sometimes called "Ultra Fast Boot") speeds up the initial firmware phase before Windows loads. It skips some hardware checks, memory tests, and peripheral initialization to get to the OS bootloader faster. This affects the POST screen and early boot, but has no impact on NTFS filesystem state or dual-booting with Pop!_OS.[^6_6]

Windows Fast Startup (the power option we discussed) happens entirely within Windows during shutdown—it hibernates the kernel and marks NTFS partitions as "dirty" for Linux. You can leave BIOS Fast Boot enabled if you want quicker boots; it won't interfere with NTFS mounting or Wine access on your ext4/NTFS setup.

For your Windows 10 machine (the one going offline), just follow the Control Panel steps from before to disable Fast Startup there. Your Windows 7 system is already good to go.
<span style="display:none">[^6_1][^6_10][^6_2][^6_3][^6_4][^6_5][^6_7][^6_8][^6_9]</span>

<div align="center">⁂</div>

[^6_1]: https://www.microfusion.org/blog/how-to-fix-linux-ntfs-read-only-access-issue-when-dual-booting-with-windows-10/

[^6_2]: https://superops.com/tech-hub/what-is-windows-fast-boot

[^6_3]: https://windowsforum.com/threads/boost-windows-boot-time-with-fast-startup-firmware-tweaks-and-safe-service-pruning.384148/

[^6_4]: https://www.howtogeek.com/243901/the-pros-and-cons-of-windows-10s-fast-startup-mode/

[^6_5]: https://windowsforum.com/threads/disable-windows-fast-startup-pros-cons-and-a-clear-step-by-step-guide.386509/

[^6_6]: https://forum.zorin.com/t/secure-boot-fast-boot-fast-startup-explained/25765

[^6_7]: https://www.asus.com/support/faq/1045548/

[^6_8]: https://www.youtube.com/watch?v=lnUDoZtoMjE

[^6_9]: https://www.reddit.com/r/overclocking/comments/1mdgbfx/i_have_a_question_that_doesnt_let_me_sleep_at/

[^6_10]: https://www.youtube.com/watch?v=gBlgWJYUcnI


---

# Good all right will do the tweaks on windows 10 hopefully this will lead to a more peaceful coexistence of the partions between the two os's also might add a somewhat larger ext4 partition so that pop os has some more wiggle room. Thank you for the advice and tips.

You're welcome! Those tweaks should make your ext4 and NTFS partitions play much nicer together, and adding more space to the ext4 side for Pop!_OS is a smart move for smoother Wine/gaming workflows. Safe dual-booting ahead. 🚀

