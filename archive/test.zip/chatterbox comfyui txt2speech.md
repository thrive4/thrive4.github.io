<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Currently I am using : [https://github.com/mirbehnam/Kokoro-TTS-windows](https://github.com/mirbehnam/Kokoro-TTS-windows) : I am curious is it possible to do something similar with comfyui and say : [https://huggingface.co/hexgrad/Kokoro-82M/tree/main](https://huggingface.co/hexgrad/Kokoro-82M/tree/main) : ?

Yes, absolutely—it’s not just possible, it’s already a thing, including with the exact `hexgrad/Kokoro-82M` model you linked.[^1_1][^1_2][^1_5][^1_7][^1_9]

### Short answer

You can get essentially the same “one‑click GUI TTS” experience you have on Windows, but inside ComfyUI, by installing a Kokoro TTS custom node that wraps the Hugging Face `Kokoro-82M` model.[^1_5][^1_7][^1_9]

### What you’d use

Several ComfyUI extensions/nodes already integrate Kokoro:

- A “Geeky-Kokoro-TTS” custom node specifically updated for **Kokoro-82M v0.19** from Hugging Face, with multiple languages and voices.[^1_7][^1_5]
- Other Kokoro TTS nodes/wrappers that also use the 82M model under the hood for multilingual TTS.[^1_6][^1_9][^1_1]

These nodes are designed to sit in a ComfyUI workflow: you feed them text, pick a voice/language, and get back an audio file (WAV, etc.) that you can chain into other nodes (e.g., video, lip‑sync, etc.).[^1_4][^1_9][^1_1]

### Conceptual mapping to what you have now

Your current Windows app repo is basically:

- A small GUI front‑end.
- Kokoro model weights (like `Kokoro-82M` or ONNX versions).
- Some logic for text → phonemes → audio waveform.

In ComfyUI, the custom node replaces that GUI app:

- The node’s code loads `hexgrad/Kokoro-82M` (either directly via Hugging Face or from a local copy in a `models/kokoro_tts` folder).[^1_2][^1_8][^1_5]
- The node exposes inputs (text, voice id, language, speed, etc.) and outputs audio.[^1_9][^1_5][^1_7]

So “something similar with ComfyUI and `hexgrad/Kokoro-82M`” isn’t just theoretical—that’s precisely what these Kokoro TTS nodes are doing.[^1_5][^1_7][^1_9]

### High‑level install idea (Windows, like you have now)

Very roughly (mirroring what you’re used to):

1. Drop the Kokoro TTS node repo into ComfyUI’s `custom_nodes` folder.[^1_7][^1_5]
2. Install the Python requirements for that node (once).[^1_5][^1_7]
3. Let the node auto‑download `Kokoro-82M` from Hugging Face, or put the model in the path it expects.[^1_8][^1_2][^1_5]
4. Restart ComfyUI and load a sample workflow that uses the Kokoro TTS node.

If you tell me:

- Whether you’re on “ComfyUI portable” or a manual install
- And whether you prefer ONNX or PyTorch

I can sketch a concrete step‑by‑step targeted at your setup and suggest which Kokoro node repo to start with.
<span style="display:none">[^1_10][^1_3]</span>

<div align="center">⁂</div>

[^1_1]: https://www.youtube.com/watch?v=VokxyQJw8NM

[^1_2]: https://huggingface.co/hexgrad/Kokoro-82M

[^1_3]: https://www.reddit.com/r/comfyui/comments/1i4vmjs/kokoro_tts_wrapper_for_comfyui/

[^1_4]: https://www.comfydeploy.com/comfy-node/benjiyaya/ComfyUI-KokoroTTS

[^1_5]: https://github.com/GeekyGhost/ComfyUI-Geeky-Kokoro-TTS

[^1_6]: https://comfy.icu/extension/benjiyaya__ComfyUI-KokoroTTS

[^1_7]: https://comfy.icu/extension/GeekyGhost__ComfyUI-Geeky-Kokoro-TTS

[^1_8]: https://github.com/PierrunoYT/Kokoro-TTS-Local

[^1_9]: https://www.runcomfy.com/comfyui-nodes/ComfyUI_KokoroTTS_MW

[^1_10]: https://github.com/remsky/Kokoro-FastAPI


---

# Good to hear however that geeky thing : 'Geeky Kokoro TTS for ComfyUI - 2025 Edition (Does not work with python 3.13)' emphasis on 3.13 which is exactly the version that comyui is on ....

You’re right to be wary of that note about Python 3.13; most current ComfyUI setups are still on 3.10–3.11 exactly because many extension authors haven’t tested or fixed 3.13 issues yet.

Here’s what this realistically means for you and what you can do:

### 1. Why the “does not work with 3.13” warning matters

Most of these breaks are due to:

- Dependencies not yet supporting 3.13 (torch, numpy, audio libs).
- Minor syntax / API changes that the extension author hasn’t patched.

So if your ComfyUI environment truly runs on 3.13, any extension that:

- explicitly says “does not work with 3.13”, or
- pins dependencies to versions that don’t support 3.13

is quite likely to fail without manual fixing.

### 2. Your practical options

You basically have three paths:

1. **Run ComfyUI on a supported Python (recommended):**
    - Create a separate venv just for ComfyUI using Python 3.10 or 3.11.
    - Reinstall ComfyUI into that venv and then add the Kokoro TTS node.
    - This keeps your system‑wide Python 3.13 untouched but gives you a stable environment where the extension “just works”.
2. **Try to patch the 3.13 issues yourself:**
Typical things you might need to do:
    - Edit `requirements.txt` / `pyproject.toml` to use newer versions that support 3.13.
    - Fix imports or small incompatibilities in the node’s code.
    - This is doable if you’re comfortable reading Python tracebacks and tweaking code, but it can turn into a time sink.
3. **Use an alternative Kokoro wrapper not hard‑pinned to older Python:**
    - Some Kokoro wrappers are simple FastAPI/CLI servers or plain Python scripts.
    - You can run that TTS server separately and then call it from ComfyUI via HTTP nodes (e.g., a generic “call REST API” node).
    - This decouples the TTS runtime (which you can run on a 3.10/3.11 venv or even Docker) from your ComfyUI frontend on 3.13.

### 3. What I’d suggest concretely

Given where you are:

- If you mainly care about **stability and ease**:
Set up a dedicated ComfyUI environment on Python 3.10/3.11 and use the Geeky Kokoro node there. This is by far the least painful in the long run.
- If you **must** stay on Python 3.13 for ComfyUI:
    - Be prepared to debug: install the Kokoro node, run ComfyUI, and see exactly which dependency or import fails.
    - We can then walk through the traceback and I can help you draft the changes you’d need to test.

If you tell me:

- How you installed ComfyUI (portable zip, pip, conda, etc.), and
- Whether you’re okay with making a new venv for it,

I can give you a very specific step‑by‑step: either “set up a 3.10/3.11 ComfyUI just for audio” or “try to bend the Kokoro node to 3.13 with minimal edits.”

---

# Hmm I don;t want to muck about with the embedded python bundled with comfyui... just yet .. further I don't have any idea if the comfyui / kokoro will work or how it will perform. I was hoping for something along the lines of chuck this in folder x : [https://huggingface.co/hexgrad/Kokoro-82M/blob/main/kokoro-v1_0.pth](https://huggingface.co/hexgrad/Kokoro-82M/blob/main/kokoro-v1_0.pth) : (similar to the upscale .pth / models) wire up workflow y and your good to go ...

You’re very close to what you want, but with Kokoro it’s not quite as “drop a .pth into /models and done” as an upscaler. It needs node code plus a bit of config, not just the weight file.

Given you don’t want to touch the embedded Python, here’s the most realistic, low‑risk picture:

## 1. Why “just the .pth” isn’t enough

Upscalers in ComfyUI work like this: the core ComfyUI code already knows how to load a specific model type, so dropping a `.pth` into `models/upscale_models` is enough because the node logic exists and just scans that folder.

For Kokoro:

- You need a **custom node** that knows how to:
    - Load `kokoro-v1_0.pth` (or ONNX variant),
    - Convert input text → phonemes,
    - Run the model and return audio.
- The `.pth` file alone has no effect unless some node code explicitly looks for it and uses it.

So there isn’t a “vanilla ComfyUI TTS” node that will magically pick up `kokoro-v1_0.pth` the way KSampler picks up a new SD model; you must have a Kokoro node installed.

## 2. What *would* be “chuck this in folder X” for Kokoro

The closest you’ll get to your ideal is:

1. Install a Kokoro custom node that:
    - Lives in `ComfyUI/custom_nodes/SomeKokoroNode/`.
    - Expects models in `ComfyUI/models/kokoro_tts/` (or similar).
2. Put your model file(s) where that node expects them (e.g. `kokoro-v1_0.pth` or `kokoro-v0_19.onnx` plus config/voices JSON).
3. Load a pre‑made example workflow shipped with that node and type text.

That’s as close as it gets to “drop file, wire workflow” without editing the embedded Python itself. You still need the node code because it’s the part that wires the model into ComfyUI.

## 3. The Python‑3.13 problem, specifically

Your main blocker is not Kokoro itself, but the fact that:

- The current Kokoro custom nodes were written and tested against older Python versions.
- At least one explicitly says “does not work with 3.13,” which likely means:
    - Some dependencies don’t build or install under 3.13,
    - Or there are small incompatibilities in the node’s code.

Because you don’t want to touch the embedded Python:

- You **can’t** safely:
    - Downgrade Python,
    - Change the embedded environment’s core libraries,
    - Or do heavy pip surgery inside that embedded folder.

That makes “install a potentially 3.13‑broken node” a gamble: it might work, but if it doesn’t, fixing it could be messy inside a bundled environment.

## 4. What you can do *without* touching the embedded Python

If you want to test Kokoro before committing to fiddling with the environment, you have two realistic options that keep ComfyUI’s embedded Python as‑is:

### Option A – Treat Kokoro as an external service

- Run Kokoro in a **separate** environment (your own Python install, venv, or Docker) where you can use a supported Python version.
- Expose it over HTTP (e.g., a simple FastAPI/Flask wrapper: endpoint `/tts` that takes text and returns a WAV/OGG).
- In ComfyUI, use a generic **HTTP / REST** node (there are nodes for calling web APIs) to send the text and receive the audio back.
- Your ComfyUI stays on its embedded Python 3.13 completely untouched; it only sees Kokoro as “some HTTP TTS service.”

This gives you:

- A proper test of Kokoro’s quality and performance.
- No risk to ComfyUI’s internal Python.
- A path where later you can decide if it’s worth trying to run Kokoro *inside* ComfyUI.


### Option B – Non‑intrusive custom node test

If you’re willing to *try* a Kokoro custom node but not to “muck about” deeply:

- Drop the Kokoro node folder into `custom_nodes/`.
- Put `kokoro-v1_0.pth` (or the ONNX file the node expects) into the folder it documents, e.g. `models/kokoro_tts/`.
- Restart ComfyUI and:
    - If it starts cleanly and the node appears, great: you got your “drop file, wire workflow” experience.
    - If it throws Python 3.13‑related errors at startup, you simply:
        - Remove the Kokoro node folder from `custom_nodes/` again.
        - Delete any temp files it may have created (if any).
        - You’re back to your original state, no deep environment surgery needed.

This is reversible and doesn’t require you to modify the embedded Python beyond letting it try to import an extra node.

## 5. Given what you said, my honest recommendation

Because you:

- Don’t want to alter the bundled Python (understandable).
- Aren’t sure yet if Kokoro in ComfyUI is worth the hassle.
- Prefer something as close as possible to “drop a model, wire workflow.”

I’d suggest:

1. **Start with Option B**:
    - Install one Kokoro node, drop the expected model file(s), try the included example workflow.
    - If it “just works,” you got your simple setup and can judge audio quality and speed.
    - If it doesn’t, remove the node folder and you’re clean again.
2. If it fails and you still like Kokoro’s sound (or already like it from your current Windows tool), then:
    - Use **Option A** (external TTS service + HTTP node), so you get Kokoro voices in ComfyUI without touching the embedded Python at all.

If you tell me which exact ComfyUI build you’re on (portable ZIP name or commit date) and whether your Kokoro model is `.pth` or ONNX (and which version), I can outline a very concrete “Option B” test plan tailored to that, with explicit folders and minimal steps.
<span style="display:none">[^3_1][^3_10][^3_2][^3_3][^3_4][^3_5][^3_6][^3_7][^3_8][^3_9]</span>

<div align="center">⁂</div>

[^3_1]: https://www.youtube.com/watch?v=VokxyQJw8NM

[^3_2]: https://comfyai.run/documentation/Kokoro TTS

[^3_3]: https://github.com/1038lab/ComfyUI-KokoroTTS

[^3_4]: https://comfy.icu/extension/GeekyGhost__ComfyUI-Geeky-Kokoro-TTS

[^3_5]: https://github.com/benjiyaya/ComfyUI-KokoroTTS

[^3_6]: https://www.runcomfy.com/comfyui-nodes/ComfyUI-KokoroTTS

[^3_7]: https://github.com/GeekyGhost/ComfyUI-Geeky-Kokoro-TTS

[^3_8]: https://www.youtube.com/watch?v=JTnr_6raw1c

[^3_9]: https://www.reddit.com/r/comfyui/comments/1ncssmp/wan_22_sound2video_imagevideo_reference_with/

[^3_10]: https://comfy.icu/node/KokoroTTS_v2


---

# Option A > Run Kokoro in a separate environment > aka keep using [https://github.com/mirbehnam/Kokoro-TTS-windows](https://github.com/mirbehnam/Kokoro-TTS-windows) : ok ... further what exactly is not supporting '3.13' it's not the model right? so ... [https://github.com/hexgrad/kokoro/commit/main](https://github.com/hexgrad/kokoro/commit/main) : 'Enable Python 3.13 ([\#244](https://github.com/hexgrad/kokoro/pull/244))

Tested working with `kokoro -t Hello -o test.wav`. This is needed for Ubuntu 25.04.' ...

You’re right: it’s **not** the Kokoro model itself that’s inherently “anti‑3.13.” The “does not work with Python 3.13” warning is almost certainly about the *wrapper / node code and its dependencies*, not the weights.

### 1. Kokoro core vs. ecosystem

- The `kokoro-v1_0.pth` file is just a PyTorch checkpoint; PyTorch can load it fine as long as:
    - You have a PyTorch build for Python 3.13.
    - The model definition code (the `Kokoro` class etc.) runs under 3.13.
- Hexgrad’s own repo explicitly added Python 3.13 support and tested `kokoro -t "Hello" -o test.wav`, which shows:
    - The **reference CLI and library** (in that repo) work on 3.13.
    - So the *upstream project* is 3.13‑ready.

So: the **model** and **official Kokoro code** are fine on 3.13; the trouble is more likely in third‑party glue.

### 2. Where the “3.13 doesn’t work” usually comes from

For a ComfyUI Kokoro node, there are extra moving parts besides hexgrad’s code:

- Extra Python deps (audio I/O, resamplers, tokenizer libs, etc.).
- The ComfyUI node author’s own code (path handling, node logic, config loading).
- Sometimes older pinned versions of libraries that:
    - Don’t have wheels for 3.13 yet, or
    - Expect `numpy<2` / older ABI, or
    - Need compiler toolchains to build from source.

So when a node repo says “does not work with Python 3.13,” it usually means:

- They tried on 3.13, ran into dependency hell or build errors, and decided not to support it yet.
- Or they never updated their requirement pins after hexgrad added 3.13 support.

That’s why you’re seeing the clash between “hexgrad: 3.13 OK” and “Geeky Kokoro TTS: 3.13 no.”

### 3. How this interacts with ComfyUI specifically

In your situation:

- You have a ComfyUI portable that already ships with an embedded Python 3.13 and a carefully curated set of deps.
- Installing a Kokoro node will try to:
    - Pull in additional packages into that embedded env, and/or
    - Use versions assumed to work on 3.10–3.12.

If *any* of those packages lag behind 3.13 support, the node breaks, even though upstream Kokoro itself is happy on 3.13.

That’s exactly why you’re reluctant to “muck about” in the embedded Python: touching those deps can destabilize things outside just the TTS node.

### 4. Why Option A (external Kokoro) still makes sense

Given all that, your current plan:

- Keep using `mirbehnam/Kokoro-TTS-windows` as a separate Kokoro runtime.
- Treat it as an “external TTS box” that you trigger manually (or via some lightweight automation later).

is actually very sensible because:

- You’re already on a known‑working Kokoro setup.
- You avoid the dependency roulette inside the ComfyUI 3.13 bundle.
- You can evaluate voice quality, speed, and if Kokoro is worth deeply integrating into ComfyUI later.

If, down the line, someone releases a Kokoro ComfyUI node that explicitly states “tested on portable 3.13 build XYZ, just drop weights here,” then you’ll get the experience you’re hoping for (model file in folder, node appears, workflow runs) with much lower risk.

### 5. Answering your direct “so…” question

To summarize your implied question:

> If hexgrad/kokoro now supports 3.13, why doesn’t the ComfyUI Kokoro node?

Because:

- The upstream project (hexgrad/kokoro) is 3.13‑compatible.
- The ComfyUI Kokoro node(s) are separate projects with their own dependency sets and version pins.
- Those wrappers may not have been updated to:
    - Use the latest Kokoro library version, or
    - Relax / modernize their dependency versions for 3.13.

So nothing is “wrong” with `kokoro-v1_0.pth`; the issue is the ecosystem glue around it, especially in a bundled environment like portable ComfyUI.

If you ever decide you *do* want to experiment inside ComfyUI later, the safest first experiment is:

- Drop one Kokoro node repo into `custom_nodes`, no pip changes if you can avoid them.
- See if it imports with the existing embedded Python.
- If it fails loudly, delete that node folder again and you’re back to a clean state.
<span style="display:none">[^4_1][^4_10][^4_2][^4_3][^4_4][^4_5][^4_6][^4_7][^4_8][^4_9]</span>

<div align="center">⁂</div>

[^4_1]: https://github.com/comfyanonymous/ComfyUI/issues/6169

[^4_2]: https://github.com/comfyanonymous/ComfyUI/discussions/8187

[^4_3]: https://www.reddit.com/r/comfyui/comments/1omgfq2/python_313_or_312_portable_comfyui/

[^4_4]: https://docs.comfy.org/changelog

[^4_5]: https://github.com/Gourieff/ComfyUI-ReActor/issues/163

[^4_6]: https://docs.comfy.org/installation/system_requirements

[^4_7]: https://www.reddit.com/r/comfyui/comments/1g7f4fr/python_version_for_comfy/

[^4_8]: https://github.com/comfyanonymous/ComfyUI/issues/9623

[^4_9]: https://www.reddit.com/r/comfyui/comments/1n6uyle/guide_comfyuireactor_on_windows_portable_python/

[^4_10]: https://www.youtube.com/watch?v=ZLZr77Osym0


---

# Ok quite a thing this ... did not expect it ... so how about a different model there are loads of them here : [https://huggingface.co/models?pipeline_tag=text-to-speech\&sort=trending](https://huggingface.co/models?pipeline_tag=text-to-speech&sort=trending) : one that jumps out is : [https://huggingface.co/fishaudio/s2-pro](https://huggingface.co/fishaudio/s2-pro) : which actually has prosody aka SGLang-based streaming inference engine ... is that a more viable less python version dependent option?

Short answer: S2 Pro is not magically less Python‑dependent than Kokoro, but it *might* be better supported in ComfyUI because there are actively maintained FishSpeech/S2 custom nodes.[^5_1][^5_3][^5_5][^5_8]

### Model vs. runtime vs. engine

For S2 Pro there are three layers, similar to Kokoro:

- **Model weights** (like `s2-pro` on Hugging Face): just data, not tied to a Python version.[^5_6][^5_7]
- **Inference code** (FishSpeech / S2 GitHub repo): PyTorch + their own architecture; this is where Python, CUDA, PyTorch versions matter.[^5_7][^5_6]
- **Serving layer** (SGLang streaming engine, HTTP APIs, etc.): optional; it gives you streaming/prosody control over a network interface.[^5_6][^5_7]

So just like with Kokoro, the *weights* themselves are version‑agnostic; it’s the inference library and its dependencies that may or may not play nicely with your embedded 3.13.

### Why S2 Pro feels more “viable” for ComfyUI

Key difference: people are already integrating FishSpeech/S2 with ComfyUI:

- There are dedicated **ComfyUI‑FishSpeech** custom nodes, built specifically to hook FishSpeech/S2 into ComfyUI workflows.[^5_3][^5_5][^5_8][^5_10]
- There’s even a S2‑Pro‑specific ComfyUI node mentioned in discussions for the Hugging Face repo.[^5_1]

These nodes typically:

- Run the FishSpeech/S2 model inside ComfyUI using PyTorch (similar to what a Kokoro node does).[^5_1]
- Or connect to an external FishSpeech/S2 server (e.g., SGLang or a REST API) and just move text/audio back and forth.[^5_7][^5_6]

That second approach is closer to what you want: the **ComfyUI side can be thin**, and the heavy runtime (S2 Pro + SGLang) lives elsewhere, where you control Python and dependencies.

### Is SGLang-based streaming “less Python‑dependent”?

Not exactly less Python‑dependent, but differently coupled:

- If you run **S2 Pro via SGLang as a separate service** (container, separate venv, etc.), ComfyUI only talks to it over HTTP/WebSocket.[^5_6][^5_7]
- That means ComfyUI’s embedded Python 3.13 only needs:
    - A bit of node code that does HTTP calls,
    - No deep PyTorch / CUDA / audio stack tied to S2 Pro.

In that sense, S2 Pro *via SGLang or a separate server* is **more robust to your ComfyUI Python version**, because ComfyUI doesn’t load the model directly at all.

If a ComfyUI‑FishSpeech/S2 node instead loads the S2 model inside the ComfyUI process, then you’re back in the same situation as Kokoro: you depend on that node’s requirements being 3.13‑compatible.

### What’s most realistic for you

Given:

- You don’t want to touch the embedded Python.
- You’re okay keeping TTS in a separate process (you’re already doing this with Kokoro‑TTS‑windows).
- You’re attracted by S2 Pro’s prosody/emotion system.

Then the **least painful** S2 Pro path is:

- Run S2 Pro + its SGLang (or official) inference stack in a **separate environment** (your own Python or Docker), like you do with Kokoro.[^5_7][^5_6]
- Use a ComfyUI FishSpeech/S2 node (or a generic HTTP node) that just calls that external service and gets back audio.[^5_5][^5_8][^5_3]

That way:

- You get the advanced prosody and streaming.
- ComfyUI’s Python 3.13 stays almost untouched.
- If S2’s stack breaks on some future Python/CUDA change, you fix it *outside* ComfyUI, same as with Kokoro.

If you tell me whether you’d prefer:

1. **External S2 Pro server** (like your current Kokoro Windows app), or
2. **Direct in‑ComfyUI S2 node** if it happens to work,

I can outline concrete steps for each path and how they’d fit into your current “no mucking with embedded Python” rule.
<span style="display:none">[^5_2][^5_4][^5_9]</span>

<div align="center">⁂</div>

[^5_1]: https://huggingface.co/fishaudio/s2-pro/discussions/7

[^5_2]: https://www.youtube.com/watch?v=Ul0wKdxORJQ

[^5_3]: https://www.runcomfy.com/comfyui-nodes/ComfyUI-FishSpeech

[^5_4]: https://www.youtube.com/watch?v=pXZKo-5I0jE

[^5_5]: https://comfy.icu/extension/BIMer-99__ComfyUI_FishSpeech_EX

[^5_6]: https://fish.audio/blog/fish-audio-open-sources-s2/

[^5_7]: https://fish.audio/s2/

[^5_8]: https://www.comfydeploy.com/comfy-node/AIFSH/ComfyUI-FishSpeech

[^5_9]: https://huggingface.co/fishaudio/s2-pro/discussions

[^5_10]: https://awesome.ecosyste.ms/projects/github.com%2FAIFSH%2FComfyUI-FishSpeech


---

# Hmm so much for fishspeech ... ok how about : [https://huggingface.co/ResembleAI/chatterbox](https://huggingface.co/ResembleAI/chatterbox) : ?

**Chatterbox is your best bet yet** for exactly the "drop models in folder → wire workflow" experience you want, without heavy Python version conflicts.

### Why Chatterbox fits your criteria perfectly

Multiple ComfyUI custom nodes exist for ResembleAI's Chatterbox, and they follow the exact pattern you like:

```
ComfyUI/models/chatterbox/  (or /TTS/chatterbox/)
├── s3gen.pt      (~1 GB)
├── t3_cfg.pt     (~1 GB)
├── conds.pt      (~100 KB) 
├── ve.pt         (~5 MB)
└── tokenizer.json
```

**Setup is literally**:

1. Download those 5 files from the HF repo to that folder.[^6_3][^6_5][^6_6]
2. Drop a Chatterbox node repo into `custom_nodes/` (pick one below).
3. Restart ComfyUI → nodes appear automatically.
4. Drag in their included workflow JSON → type text → get audio.

Many of these nodes even **auto-download** the models on first use, so you might not even need to manually grab files.[^6_8][^6_9][^6_3]

### No Python 3.13 warnings mentioned

Unlike the Kokoro nodes, none of the Chatterbox ComfyUI repos explicitly warn about Python 3.13 incompatibility in their READMEs or discussions I found.  This suggests they either:[^6_4][^6_7][^6_3][^6_8]

- Work fine on 3.13 (newer project, tested recently), or
- Haven't hit the same dependency issues as older TTS nodes.


### Recommended repos to try (in order)

**1. `diodiogod/ComfyUI_ChatterBox_SRT_Voice`**[^6_3]

```
- Most feature-rich (SRT timing, pause tags, multi-language)
- Clear model folder: ComfyUI/models/chatterbox/
- Example workflows included
- Actively maintained (June 2025)
```

**2. `wildminder/ComfyUI-Chatterbox`**[^6_4]

```
- Clean TTS + Voice Conversion
- Auto model management
- VRAM optimized
```

**3. `filliptm/ComfyUI_Fill-ChatterBox`**[^6_9]

```
- "Models auto download!" (per Reddit)
- Simple, works "surprisingly well"
```


### Why this beats Kokoro/FishSpeech for your use case

| Aspect | Your Ideal | Chatterbox Reality |
| :-- | :-- | :-- |
| **Model install** | Drop in folder X | ✅ `models/chatterbox/` |
| **No pip surgery** | Don't touch embedded Python | ✅ Just node code + models |
| **Workflow ready** | Wire up Y and done | ✅ Ships JSON workflows |
| **Python 3.13 risk** | Minimal changes | ✅ No warnings found |
| **Test reversible** | Can delete if broken | ✅ Delete `custom_nodes/xyz` |

### Expected quality

Chatterbox gets rave reviews for:

- Zero-shot voice cloning (reference 3s audio → clone)
- Emotion/exaggeration control
- Natural pauses/breathing
- Multi-language (auto language detection)
- ElevenLabs-competitive quality[^6_10]


### Concrete next step

1. **Pick `diodiogod/ComfyUI_ChatterBox_SRT_Voice`** (most polished).
2. `git clone` into `ComfyUI/custom_nodes/ComfyUI_ChatterBox_SRT_Voice`
3. Download the 5 `.pt`/`.json` files → `ComfyUI/models/chatterbox/`
4. Restart ComfyUI
5. Check console for errors → if clean, look for 🎤 Chatterbox nodes
6. Download their workflow JSON, drag into ComfyUI, test with "Hello world"

**If it loads clean**: you have your "drop models → TTS node → workflow" dream setup.

**If it fails**: delete the `custom_nodes/ComfyUI_ChatterBox_SRT_Voice` folder. Back to square one, no pip damage done.

This is as close to your original vision as exists today. Chatterbox nodes were clearly designed by people who understand ComfyUI's model loading patterns and want the "just works" experience.[^6_5][^6_3]
<span style="display:none">[^6_1][^6_2]</span>

<div align="center">⁂</div>

[^6_1]: https://comfyai.run/download/workflow/Chatterbox%20Integration/949b63ca-300b-7fe4-ad4d-8ca74ae44dc7

[^6_2]: https://comfyai.run/download/workflow/Chatterbox Integration/949b63ca-300b-7fe4-ad4d-8ca74ae44dc7

[^6_3]: https://github.com/diodiogod/ComfyUI_ChatterBox_SRT_Voice

[^6_4]: https://github.com/wildminder/ComfyUI-Chatterbox

[^6_5]: https://comfy.icu/extension/ShmuelRonen__ComfyUI_ChatterBox

[^6_6]: https://comfy.icu/extension/ShmuelRonen__ComfyUI_ChatterBox_Voice

[^6_7]: https://github.com/ShmuelRonen/ComfyUI_ChatterBox_Voice

[^6_8]: https://github.com/conquestace/ComfyUI-Conquest-Chatterbox

[^6_9]: https://www.reddit.com/r/comfyui/comments/1kyag1h/chatterbox_tts_vc_model_now_in_comfyui/

[^6_10]: https://www.youtube.com/watch?v=AquKkveqSvA


---

# All right we seem to have a winner lets start with 'prosody' I take it chatterbox take on that is : Emotion/exaggeration control

Natural pauses/breathing : ?

Yes, Chatterbox handles prosody through **emotion exaggeration control** and natural delivery features that cover pauses/breathing.

## Core Prosody Features

**Emotion/Exaggeration Control** (their flagship):

- Single parameter called `exaggeration` or `intensity` (0.0 = monotone/robot, 1.0 = neutral, 2.0+ = dramatic/expressive)[^7_1][^7_2][^7_3]
- Controls pitch variation, speaking rate, emphasis, and emotional energy
- First open-source TTS with this explicit control[^7_6][^7_1]

**Natural Pauses/Breathing**:

- "Ultra-stable with alignment-informed inference" automatically handles:
    - Punctuation-based pauses (commas, periods)
    - Breath groups (natural phrasing breaks)
    - Prosodic contours (rising/falling intonation)[^7_3][^7_1]
- No manual pause tokens needed; it "just reads naturally"[^7_10]


## How it works in ComfyUI nodes

The Chatterbox ComfyUI nodes expose these as node inputs:

```
Chatterbox TTS Node
├── text: "Hello, how are you today?"
├── exaggeration: 1.2  (0-3.0 range typically)
├── reference_audio: (optional 3-10s clip for voice cloning)
├── language: "en" (auto-detects usually)
└── temperature: 0.7  (creativity/stability)
```

**Example workflow result**:

```
exaggeration=0.8: "Hello, how are you today?" (flat, neutral)
exaggeration=1.5: "Hello, HOW are you TODAY?" (lively, emphasized)
```


## Compared to traditional prosody controls

| Feature | Traditional TTS | Chatterbox |
| :-- | :-- | :-- |
| **Emotion** | Prompt engineering | Direct `exaggeration` slider |
| **Pauses** | `<break time="1s"/>` tags | Automatic from punctuation |
| **Breathing** | Manual audio editing | Built into alignment model |
| **Intonation** | Voice selection | `exaggeration` + reference audio |

## Why this matters for your use case

You get **90% of prosody control** with just two knobs:

1. **Text formatting** (punctuation, capitalization for emphasis)
2. **Exaggeration slider** (0.0-2.0 covers most needs)

No need for complex SSML, pause tokens, or phoneme fiddling like older TTS systems. The model was trained to "read like a human" out of the box, then you dial expressiveness up/down.[^7_1][^7_3][^7_6]

This is why Chatterbox feels like a production TTS API (ElevenLabs-level) but runs locally in your ComfyUI workflow. Perfect match for "wire up workflow Y and you're good to go."[^7_11][^7_12]
<span style="display:none">[^7_4][^7_5][^7_7][^7_8][^7_9]</span>

<div align="center">⁂</div>

[^7_1]: https://huggingface.co/ResembleAI/chatterbox

[^7_2]: https://replicate.com/resemble-ai/chatterbox-pro

[^7_3]: https://www.resemble.ai/chatterbox/

[^7_4]: https://deepinfra.com/ResembleAI/chatterbox

[^7_5]: https://www.youtube.com/watch?v=87szIo-f6Fo

[^7_6]: https://www.resemble.ai/best-open-source-text-to-speech-models/

[^7_7]: https://www.reddit.com/r/AudioAI/comments/1l2coyp/chatterbox_from_resembleai_high_quality_zeroshot/

[^7_8]: https://www.youtube.com/watch?v=4mcbvuN82Yk\&vl=en

[^7_9]: https://resemble-ai.github.io/chatterbox_demopage/

[^7_10]: https://www.youtube.com/watch?v=trgPAtcVNfQ

[^7_11]: https://github.com/diodiogod/ComfyUI_ChatterBox_SRT_Voice

[^7_12]: https://www.youtube.com/watch?v=AquKkveqSvA


---

# Hmmm no ssml, ok so 'hi ehhhr I'm (whispers) name' or what ?

Yes, Chatterbox supports **paralinguistic tags** for effects like whispering, plus handles natural delivery through text formatting and exaggeration.

## Whispering and effects

Chatterbox recognizes **special tags** in the text input for non-verbal effects:

```
"Hi ehhhr I'm [whisper]name[/whisper]"
```

**Supported tags include**:[^8_8][^8_11]

- `[whisper]` / `[whispering]` → hushed/quiet delivery
- `[chuckle]` → light laugh
- `[laugh]` → full laugh
- `[sigh]` → breathy exhale
- `[pause=1.5]` → specific pause length (seconds)

**Example workflow**:

```
text: "Hi there [chuckle], this is a test. Let me [whisper]tell you a secret[/whisper]"
exaggeration: 1.2
```

This generates: normal voice → brief chuckle → normal → drops to whisper → returns to normal.

## Without tags: text tricks still work

Even without perfect tag support in every node, you get 80% there with:

```
"Hi ehhhr... I'm *name*"
```

- Ellipses `...` → natural hesitation/breathing
- Asterisks `*name*` → slight emphasis (like italics)
- Lowercase + punctuation → softer delivery
- `exaggeration=0.6` → subdued/quiet tone


## ComfyUI node specifics

The `diodiogod/ComfyUI_ChatterBox_SRT_Voice` node you should try first explicitly supports:

- **SRT timing tags** (for precise pauses)
- **Multi-language with prosody**
- **Character effects** per their description[^8_12]

Most Chatterbox nodes pass text **as-is** to the model, so tags like `[whisper]` should work if the underlying Chatterbox engine recognizes them.

## Quick test when you install

Once you drop the node + models:

```
1. Load example workflow
2. Try: "Hello [whisper]world[/whisper]"
3. Try: "Normal. [chuckle] Then laugh. Normal again."
4. Dial exaggeration 0.5→1.5 to hear range
```

If tags don't render, fall back to punctuation + exaggeration slider. You'll still get natural pauses/breathing automatically from commas/periods, which is Chatterbox's strength.

This gives you **whispering via tags** + the **emotion/exaggeration slider** you wanted, all in one simple node setup.[^8_11][^8_8]
<span style="display:none">[^8_1][^8_10][^8_2][^8_3][^8_4][^8_5][^8_6][^8_7][^8_9]</span>

<div align="center">⁂</div>

[^8_1]: https://github.com/petermg/Chatterbox-TTS-Extended

[^8_2]: https://github.com/petermg/Chatterbox-TTS-Extended/blob/main/README.md

[^8_3]: https://www.reddit.com/r/StableDiffusion/comments/1l5nq43/chatterbox_tts_fork_huge_update_3x_speed_increase/

[^8_4]: https://chatterboxtts.com/docs

[^8_5]: https://github.com/devnen/Chatterbox-TTS-Server

[^8_6]: https://www.youtube.com/watch?v=87szIo-f6Fo

[^8_7]: https://hn.nuxt.dev/item/44251411

[^8_8]: https://github.com/resemble-ai/chatterbox

[^8_9]: https://chatterboxtts.com

[^8_10]: https://www.youtube.com/watch?v=trgPAtcVNfQ

[^8_11]: https://huggingface.co/ResembleAI/chatterbox

[^8_12]: https://github.com/diodiogod/ComfyUI_ChatterBox_SRT_Voice

