<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# With freebasic ubound(listrec.listfile) inits with -1 why is that?

`Ubound(listrec.listfile)` returns `-1` when the dynamic array field `listfile` has not been allocated yet, so its internal descriptor is “empty” and indicates “no elements.”[^1_8]

## FreeBASIC array bounds basics

- Dynamic arrays (including array fields in UDTs) start out in an unallocated state if you only declare them with `()` and never `ReDim` them.[^1_2]
- For such unallocated arrays, `LBound` and `UBound` are defined to signal “no dimension,” commonly `LBound = 0` and `UBound = -1`.[^1_4]


## How this applies to `listrec.listfile`

- If `listrec.listfile` is declared like `listfile() As SomeType` inside a TYPE, but you never `ReDim` it, it stays uninitialized as a variable-length array.[^1_5]
- When you then call `Ubound(listrec.listfile)`, the runtime sees an unallocated array descriptor and returns `-1`, meaning there is currently no valid upper index. This allows you to test whether the array has been allocated before accessing it.[^1_8]
<span style="display:none">[^1_1][^1_10][^1_3][^1_6][^1_7][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://github.com/freebasic/fbc/blob/master/todo.txt

[^1_2]: https://github.com/D5n9sMatrix/doc-learn-fbc1

[^1_3]: https://ps.allbasic.info/index6402.html?topic=4130.0

[^1_4]: https://wiki.documentfoundation.org/images/f/fa/LibOBasic_09_StructDataTypes_Flat_A4_EN_v101.pdf

[^1_5]: http://www.wildgardenseed.com/RQDP/FreeBasic/FBhelp/contents.html

[^1_6]: https://www.vbforums.com/showthread.php?814721-RESOLVED-UBound-Null-Array

[^1_7]: https://www.freebasic.net/forum/viewtopic.php?t=21146\&start=15

[^1_8]: https://www.freebasic.net/forum/viewtopic.php?t=16582

[^1_9]: https://www.auditsi.eu/?wpfb_dl=26

[^1_10]: https://stackoverflow.com/questions/62278461/uboundarray-doesnt-work-to-know-how-many-elements-has-the-array-with-method


---

# so doing : print "image "; createlist("g:\data\images\classical paintings", ".jpg", "image")

print "music "; createlist("g:\data\mp3\beatless", ".mp3", "music")
print "music "; createlist("g:\data\mp3\classic", ".mp3", "music")
:  function createlist(folder as string, filterext as string, listtype as string) as integer
' setup filelist
dim chk            as boolean
redim path(1 to 1) As string
dim as integer i = 1, n = 1, attrib, listnr = 0
dim file           as string
dim fileext        as string
dim maxfiles       as integer
dim dummy          as string = curdir

    #ifdef __FB_LINUX__
      const pathchar = "/"
    #else
      const pathchar = "\"
    #endif
    
    if chdir(folder) <> 0 then
        chdir(dummy)
        print folder + " " + "not found"
        'logentry("fatal", "path " + folder + " not found")
    end if
    ' reset array by listtype
    refreshlist(listtype)
    listnr = ubound(listrec.listfile)
    
    ' read dir recursive starting directory
    path(1) = folder 
    if( right(path(1), 1) <> pathchar) then
        file = dir(path(1), fbNormal or fbDirectory, @attrib)
        if( attrib and fbDirectory ) then
            path(1) += pathchar
        end if
    end if
    
    while i <= n
    file = dir(path(i) + "*" , fbNormal or fbDirectory, @attrib)
        while file > ""
            if (attrib and fbDirectory) then
                if file <> "." and file <> ".." then
                    ' todo evaluate limit recursive if starting folder is root
                    if len(path(1)) > 3 then
                        n += 1
                        redim preserve path(1 to n)
                        path(n) = path(i) + file + pathchar
                    else
                        'logentry("terminate", "scanning from root dir not supported! " + path(i))
                    end if
                end if
            else
                fileext = lcase(mid(file, instrrev(file, ".")))
                if instr(1, filterext, fileext) > 0 and len(fileext) > 3 then 
                    listnr += 1
                    redim preserve listrec.listname(0 to listnr)
                    redim preserve listrec.listfile(0 to listnr)
                    redim preserve listrec.listtype(0 to listnr)
                    redim preserve listrec.listseqh(0 to listnr)
                    listrec.listname(listnr) = file
                    listrec.listfile(listnr) = path(i) & file
                    listrec.listtype(listnr) = listtype
                    listrec.listseqh(listnr) = 0
                    maxfiles += 1
                else
                    'logentry("warning", "file format not supported - " + path(i) & file)
                end if    
            end if
            file = dir(@attrib)
        wend
        i += 1
    wend
    
    return maxfiles
    end function
: is ok?

`createlist` is mostly fine, but there are a few logic issues and one important safety issue to fix around `UBound` and `ChDir`.

## `UBound` / initialization

In your `createlist`:

```basic
refreshlist(listtype)
listnr = ubound(listrec.listfile)
```

If `refreshlist` leaves `listrec.listfile()` *unallocated* (dynamic array not yet `ReDim`’d), `UBound(listrec.listfile)` will be `-1`. That is actually convenient: you then start adding at index 0 by doing `listnr += 1` before the first write, so the first element becomes index 0, which matches your `ReDim ... (0 to listnr)` calls later. That pattern is valid as long as `refreshlist` really resets the array to an unallocated/empty state consistent with that convention.

What you must avoid is any code path where `listnr` is still `-1` but you *access* `listrec.listfile(listnr)`. In your code you only start accessing after a successful `listnr += 1`, so that is OK.

## `ChDir` error path

This block:

```basic
if chdir(folder) <> 0 then
    chdir(dummy)
    print folder + " " + "not found"
    'logentry("fatal", "path " + folder + " not found")
end if
```

After printing the error, you fall through and keep running, but `path(1)` will still be `folder`, and `Dir(path(1), ...)` will fail or behave unexpectedly. For robustness:

- Return immediately on error:

```basic
if chdir(folder) <> 0 then
    chdir(dummy)
    print folder + " " + "not found"
    return 0
end if
```

- Or set a flag and skip the recursion loop.


## `Dir` usage and recursion

Inside the main loop you have:

```basic
file = dir(path(i) + "*", fbNormal or fbDirectory, @attrib)
while file > ""
    ...
    file = dir(@attrib)
wend
```

That is correct `Dir` usage: first call with path + mask, subsequent calls with only attribute. The recursion via `path()` and `ReDim Preserve path(1 to n)` is also fine, though note:

- `ReDim Preserve` in a tight loop can be slow; consider growing in larger chunks if performance matters.
- The guard `if len(path(1)) > 3 then` is a bit odd; usually you’d test `len(path(i)) > 3` if you want to avoid scanning root-level directories.


## Array growth for `listrec.*`

This part is logically consistent:

```basic
listnr += 1
redim preserve listrec.listname(0 to listnr)
redim preserve listrec.listfile(0 to listnr)
redim preserve listrec.listtype(0 to listnr)
redim preserve listrec.listseqh(0 to listnr)
listrec.listname(listnr) = file
listrec.listfile(listnr) = path(i) & file
listrec.listtype(listnr) = listtype
listrec.listseqh(listnr) = 0
maxfiles += 1
```

- Starting from `listnr = -1` for an empty list, the first found file sets `listnr` to 0 and creates arrays indexed 0..0, which is correct.
- All four arrays stay in sync by using the same `0 to listnr` bounds.

Just make sure:

- `listrec.listname`, `listrec.listfile`, `listrec.listtype`, `listrec.listseqh` are all declared as dynamic arrays (with `()` and no bounds) in the type.
- `refreshlist(listtype)` clears or deallocates all of them consistently so `UBound` is `-1` when there are no entries of that type.


## Function return value

`maxfiles` is only incremented on matches and returned at the end, which matches your `print "image "; createlist(...)` usage. That is fine.

## Minimal changes suggested

- Early return on invalid `folder`.
- Optionally, ensure `refreshlist` makes `UBound(listrec.listfile) = -1` for an empty list.
- Optionally, change the root guard to `len(path(i)) > 3`.

With those adjustments, the structure and the `UBound` usage are OK.
<span style="display:none">[^2_1][^2_10][^2_2][^2_3][^2_4][^2_5][^2_6][^2_7][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://www.freebasic.net/wiki/wikka.php?wakka=ProPgInitialization

[^2_2]: https://www.freebasic.net/wiki/wikka.php?wakka=ProPgArrays

[^2_3]: https://documentation.help/FreeBASIC/TutDynamicArrays.html

[^2_4]: https://qb64phoenix.com/forum/showthread.php?pid=11890

[^2_5]: https://www.freebasic.net/wiki/TutIntroArrays

[^2_6]: https://freebasic.net/wiki/wikka.php?wakka=TutDynaArrayType

[^2_7]: https://www.freebasic.net/forum/viewtopic.php?t=15947

[^2_8]: https://www.freebasic.net/wiki/wikka.php?wakka=KeyPgUbound

[^2_9]: https://www.freebasic.net/forum/viewtopic.php?t=17654

[^2_10]: https://www.freebasic.net/forum/viewtopic.php?t=22836


---

# Regarding chdir the remarked logentry("fatal", "path " + folder + " not found") normaly does that but I have isolated the code but in this case indeed return 0 is good. Next : 'len(path(i)) > 3 if you want to avoid scanning root-level directories.' that is actually the intentenion, at least for now other wise the routine will scan all subsequent folders which can take forever for the files complying to filterext (not so good experience with that ... ) ergo : 'logentry("terminate", "scanning from root dir not supported! " + path(i) and ' todo evaluate limit recursive if starting folder is root ... 'Optionally, ensure refreshlist makes UBound(listrec.listfile) = -1 for an empty list.' how and where?

`refreshlist` needs to *deallocate* (or at least reset) the dynamic arrays so that `UBound(...)` gives `-1` when the list is empty. In FreeBASIC, a dynamic array has `UBound = -1` when it has never been `ReDim`’d (or after it has been `Erase`d), which is what you want to detect “no elements yet”.[^3_10]

## Where to make `UBound = -1`

Do it inside `refreshlist`, because that is your “reset state” hook for a given `listtype`. For example, if `listrec` is a single global/Shared instance, and the `listtype` is just a tag string, you can clear *all* arrays there:

```basic
sub refreshlist(listtype as string)
    ' Clear all list arrays for now (you can specialize per type later)
    erase listrec.listname
    erase listrec.listfile
    erase listrec.listtype
    erase listrec.listseqh
end sub
```

After `Erase`, each dynamic array is deallocated; `UBound(listrec.listfile)` will return `-1`, so your code:

```basic
refreshlist(listtype)
listnr = UBound(listrec.listfile)   ' now -1 for empty list
...
listnr += 1                         ' first item becomes index 0
ReDim Preserve listrec.listfile(0 to listnr)
```

works exactly as intended.[^3_11]

If, instead, `refreshlist` *pre-allocates* something like `ReDim listrec.listfile(0 To 0)` for an empty list, then `UBound` will be `0` and your “start at -1, then `+= 1`” logic breaks, so the key rule is:

- Either: use `Erase` / unallocated state and the “`UBound = -1` → `listnr += 1`” pattern.
- Or: if you prefer to keep arrays always allocated, change the pattern to:

```basic
listnr = UBound(listrec.listfile)
' if empty list defined as 0 to -1, UBound = -1
' if empty list defined as 0 to -1 via Erase, same
' add new item:
listnr += 1
ReDim Preserve listrec.listfile(0 to listnr)
```


with the guarantee that `refreshlist` always makes the array “0 to -1” (via `Erase`) and never “0 to 0” when empty.[^3_10]

## On your `len(path(i)) > 3` guard

Your reasoning is sound: by rejecting paths where `Len(path(i)) <= 3` you effectively refuse to recurse from a drive root like `C:\` (length 3) or similar, which avoids scanning the whole drive tree when starting from root. That matches the “scanning from root dir not supported” log entry and is a practical safety/UX decision in a recursive file search.[^3_2]
<span style="display:none">[^3_1][^3_3][^3_4][^3_5][^3_6][^3_7][^3_8][^3_9]</span>

<div align="center">⁂</div>

[^3_1]: http://www.petesqbsite.com/sections/express/issue10/fberrormanagement.html

[^3_2]: https://www.freebasic.net/forum/viewtopic.php?t=23211

[^3_3]: https://freebasic.net/forum/viewtopic.php?t=11028

[^3_4]: https://stackoverflow.com/questions/34046133/error-handling-mkdir-and-chdir-in-c

[^3_5]: https://www.freebasic.net/wiki/wikka.php?wakka=ProPgErrorHandling

[^3_6]: https://www.freebasic.net/forum/viewtopic.php?t=24003

[^3_7]: https://www.freebasic.net/wiki/wikka.php?wakka=CatPgError

[^3_8]: https://www.freebasic.net/wiki/wikka.php?wakka=CompilerErrMsg

[^3_9]: https://documentation.help/FreeBASIC/CatPgError.html

[^3_10]: https://www.freebasic.net/wiki/wikka.php?wakka=ProPgArrays

[^3_11]: https://documentation.help/FreeBASIC/TutDynamicArrays.html


---

# Hmm not so sure about using erase I'll ponder on that one. Ok I'm going to past the whole thing how ever the main focus is on liststate() I'm attempting to abstract the flow to one line but I'm not sure how to handle currentitem per listtype the current and oblivious route is shared vars like currentsong (for music) currentimage (for image) , etc but maybe I'm missing a trick ...? \#include "vbcompat.bi"

' setup playlist
type lrec
as string  listname(any)
as string  listfile(any)
as string  listtype(any)
as integer listseqh(any)
end type
dim shared    listrec as lrec

function getmaxitemslist(listtype as string) as integer
dim itemnr as integer = 0

    for i as integer = 0 to ubound(listrec.listfile)
        with listrec
            if listrec.listtype(i) = listtype then
                itemnr += 1
            end if
        end with
    next i
    
    return itemnr
    end function

function refreshlist(listtype as string) as integer
' nothing to remove
if len(listrec.listfile) = 0 then return 0
if getmaxitemslist(listtype) < 1 then return 0

    dim newcount as integer = lbound(listrec.listfile) - 1
    
    for i as integer = lbound(listrec.listfile) to ubound(listrec.listfile)
        if listrec.listtype(i) <> listtype then
            newcount += 1
            if i <> newcount then
                listrec.listname(newcount) = listrec.listname(i)
                listrec.listfile(newcount) = listrec.listfile(i)
                listrec.listtype(newcount) = listrec.listtype(i)
                listrec.listseqh(newcount) = listrec.listseqh(i)
            end if
        end if
    next i
    
    ' shrink arrays if needed
    if newcount < ubound(listrec.listfile) then
        redim preserve listrec.listname(lbound(listrec.listname) to newcount)
        redim preserve listrec.listfile(lbound(listrec.listfile) to newcount)
        redim preserve listrec.listtype(lbound(listrec.listtype) to newcount)
        redim preserve listrec.listseqh(lbound(listrec.listseqh) to newcount)
    end if
    
    return newcount - (lbound(listrec.listfile) - 1)
    end function

' generate list of files recursive
' based on recursive dir code of coderjeff [https://www.freebasic.net/forum/viewtopic.php?t=5758](https://www.freebasic.net/forum/viewtopic.php?t=5758)
function createlist(folder as string, filterext as string, listtype as string) as integer
' setup filelist
dim chk            as boolean
redim path(1 to 1) As string
dim as integer i = 1, n = 1, attrib, listnr = 0
dim file           as string
dim fileext        as string
dim maxfiles       as integer
dim dummy          as string = curdir

    #ifdef __FB_LINUX__
      const pathchar = "/"
    #else
      const pathchar = "\"
    #endif
    
    if chdir(folder) <> 0 then
        chdir(dummy)
        print folder + " " + "not found"
        'logentry("fatal", "path " + folder + " not found")
        return 0
    end if
    ' reset array by listtype
    refreshlist(listtype)
    listnr = ubound(listrec.listfile)
    
    ' read dir recursive starting directory
    path(1) = folder 
    if( right(path(1), 1) <> pathchar) then
        file = dir(path(1), fbNormal or fbDirectory, @attrib)
        if( attrib and fbDirectory ) then
            path(1) += pathchar
        end if
    end if
    
    while i <= n
    file = dir(path(i) + "*" , fbNormal or fbDirectory, @attrib)
        while file > ""
            if (attrib and fbDirectory) then
                if file <> "." and file <> ".." then
                    ' todo evaluate limit recursive if starting folder is root
                    if len(path(1)) > 3 then
                        n += 1
                        redim preserve path(1 to n)
                        path(n) = path(i) + file + pathchar
                    else
                        'logentry("terminate", "scanning from root dir not supported! " + path(i))
                    end if
                end if
            else
                fileext = lcase(mid(file, instrrev(file, ".")))
                if instr(1, filterext, fileext) > 0 and len(fileext) > 3 then 
                    listnr += 1
                    redim preserve listrec.listname(0 to listnr)
                    redim preserve listrec.listfile(0 to listnr)
                    redim preserve listrec.listtype(0 to listnr)
                    redim preserve listrec.listseqh(0 to listnr)
                    listrec.listname(listnr) = file
                    listrec.listfile(listnr) = path(i) & file
                    listrec.listtype(listnr) = listtype
                    listrec.listseqh(listnr) = 0
                    maxfiles += 1
                else
                    'logentry("warning", "file format not supported - " + path(i) & file)
                end if    
            end if
            file = dir(@attrib)
        wend
        i += 1
    wend
    
    return maxfiles
    end function

function getcurrentlistitem(listtype as string, filename as string) as integer
dim itemnr as integer = -1

    for i as integer = 0 to ubound(listrec.listfile)
        with listrec
            itemnr += 1
            if listrec.listtype(i) = listtype and listrec.listfile(i) = filename then
                exit for
            end if
        end with
    next i
    
    return itemnr
    end function

sub setsequence(currentitem as integer)
dim as string lt = listrec.listtype(currentitem)
dim as integer maxseq = 0
' get highest sequence number for listtype
for i as integer = 0 to ubound(listrec.listfile)
if listrec.listtype(i) = lt then
if listrec.listseqh(i) > maxseq then
maxseq = listrec.listseqh(i)
end if
end if
next
listrec.listseqh(currentitem) = maxseq + 1
end sub

sub clearseq(listtype as string)
for i as integer = 0 to ubound(listrec.listfile)
if listrec.listtype(i) = listtype then
listrec.listseqh(i) = 0
end if
next
end sub

function listshuffle(listtype as string) as integer
dim as integer candidates(0 to ubound(listrec.listfile))
dim as integer count = 0
dim as integer selected = -1
dim as integer i

    ' unplayed items (listseqh = 0)
    for i = 0 to ubound(listrec.listfile)
        if listrec.listtype(i) = listtype and listrec.listseqh(i) = 0 then
            candidates(count) = i
            count += 1
        end if
    next
    ' reset sequences listtype
    if count = 0 then
        for i = 0 to ubound(listrec.listfile)
            if listrec.listtype(i) = listtype then
                listrec.listseqh(i) = 0
            end if
        next
        ' rebuild list
        count = 0
        for i = 0 to ubound(listrec.listfile)
            if listrec.listtype(i) = listtype and listrec.listseqh(i) = 0 then
                candidates(count) = i
                count += 1
            end if
        next
    end if
    
    ' get unplayed item
    if count > 0 then
        dim as integer rndidx = int(rnd * count)
        selected = candidates(rndidx)
    end if
    
    return selected
    end function

function listnext(listtype as string, playtype as string, currentitem as integer) as integer
dim as integer nextidx = -1
dim as integer i, shuffleidx

    if lcase(playtype) = "shuffle" then
        shuffleidx = listshuffle(listtype)
        setsequence(shuffleidx)
        return shuffleidx
    end if
    ' linear
    for i = currentitem + 1 to ubound(listrec.listfile)
        if listrec.listtype(i) = listtype then
            nextidx = i
            exit for
        end if
    next
    ' wrap to first of same type
    if nextidx = -1 then
        for i = 0 to ubound(listrec.listfile)
            if listrec.listtype(i) = listtype then
                nextidx = i
                exit for
            end if
        next
    end if
    
    return nextidx
    end function

function listprevious(listtype as string, playtype as string, currentitem as integer) as integer
dim as integer i, previdx = -1

    if lcase(playtype) = "shuffle" then
        dim as integer currseq = listrec.listseqh(currentitem)
        dim as integer maxseq = 0
        dim as integer targetseq = 0
    
        ' get maximum sequence (for wrap)
        for i = 0 to ubound(listrec.listfile)
            if listrec.listtype(i) = listtype then
                if listrec.listseqh(i) > maxseq then maxseq = listrec.listseqh(i)
            end if
        next
        targetseq = currseq - 1
        if targetseq < 1 then targetseq = maxseq
        for i = 0 to ubound(listrec.listfile)
            if listrec.listtype(i) = listtype and listrec.listseqh(i) = targetseq then
                previdx = i
                exit for
            end if
        next
    
        return previdx
    end if
    
    ' linear
    for i = currentitem - 1 to 0 step -1
        if listrec.listtype(i) = listtype then
            return i
        end if
    next
    ' wrap
    for i = ubound(listrec.listfile) to 0 step -1
        if listrec.listtype(i) = listtype then
            return i
        end if
    next
    
    return -1
    end function

function liststate(listtype as string, playtype as string, action as string) as integer
dim currentitem as integer

    select case action
        case "init"
            currentitem = listnext(listtype, playtype, 0)
            ' do media related actions
            if lcase(playtype) = "linear" then
                clearseq(listtype)
            end if
        case "next"
            currentitem = listnext(listtype, playtype, 0)
            ' do media related actions
        case "prev"
            currentitem = listprevious(listtype, playtype, 0)
            ' do media related actions
    end select
    return currentitem
    end function

' main
dim media        as string
dim currentitem  as integer
'dim maxitemslist as integer
dim playtype     as string
dim listtype     as string

print "image "; createlist("g:\data\images\classical paintings", ".jpg", "image")
print "music "; createlist("g:\data\mp3\beatless", ".mp3", "music")
print "music "; createlist("g:\data\mp3\classic", ".mp3", "music")

'print "slide "; createlist("g:\data\images\flickr\winter mixed", ".jpg", "slide")
'print "video "; createlist("g:\data\aerialtv", ".mp4", "video")
'print "shade "; createlist("f:\osd\media\glsl", ".gls", "shade")
print
print "total "; ubound(listrec.listfile) + 1

'init playback get first item
playtype     = "linear"
listtype     = "image"
currentitem  = listnext(listtype, playtype, 0)
' todo relation with list type is ambigous
'maxitemslist = getmaxitemslist(listtype)
'if lcase(playtype) = "linear" then
'    clearseq(listtype)
'end if
sleep
Do
Dim As String key = lCase(Inkey)
Select Case key
Case "."
' play next media
currentitem = listnext(listtype, playtype, currentitem)
cls
Case ","
' play previous media
currentitem = listprevious(listtype, playtype, currentitem)
cls
Case "l"
' toggle playtype
select case playtype
case "linear"
playtype = "shuffle"
case "shuffle"
playtype = "linear"
clearseq(listtype)
end select
cls
Case Chr(27)
Exit Do
end select

    ' ascii interface
    Locate 7, 1
    Print "| list demonstration"
    print listtype + " selected " & listrec.listfile(currentitem)
    dim as integer displayedindex = 0
    for i as integer = 0 to currentitem
        if listrec.listtype(i) = listtype then displayedindex += 1
    next i
    print "name           " & listrec.listname(currentitem)
    print "current nr     " & displayedindex & " of " & getmaxitemslist(listtype)
    print "sequence       " & listrec.listseqh(currentitem)
    print "playtype       " & playtype
    print "listtype       " & listtype
    print
    print "[navigation]"
    print ".   period next item"
    print ",   comma  previous item"
    print "l   toggle shuffle / linear"
    print "esc quit"
    sleep(50)
    loop

end

`liststate` can be made “one‑liner per call” if you move the *current index* into data that is keyed by `listtype`, instead of into separate `currentsong`, `currentimage`, etc. The usual trick is: keep a small side table that maps `listtype` → current index, and let `liststate` read/update that table.

Because external references are required, the explanation below follows the documented behavior of FreeBASIC dynamic arrays and common playlist patterns.[^4_1]

## Problem in current `liststate`

Right now:

```basic
function liststate(listtype as string, playtype as string, action as string) as integer
    dim currentitem as integer

    select case action
        case "init"
            currentitem = listnext(listtype, playtype, 0)
            if lcase(playtype) = "linear" then
                clearseq(listtype)
            end if
        case "next"
            currentitem = listnext(listtype, playtype, 0)
        case "prev"
            currentitem = listprevious(listtype, playtype, 0)
    end select
    return currentitem
end function
```

- `currentitem` is local and always starts from 0.
- For `"next"`/`"prev"` you always call `listnext/listprevious(..., 0)`, so you *don’t* use the last position; external code must track it separately.

That is why you end up with `currentimage`, `currentsong`, etc. per media type.

## Strategy: store “current per type”

Add one more dynamic array to `lrec` for the *current index per element* **or** a separate structure that holds per‑type state.[^4_2]

### Option A: per‑type current index in a separate table

Define a small helper type:

```basic
type liststate_rec
    as string  listtype
    as integer currentidx
end type

dim shared liststate_tab() as liststate_rec
```

Utility to get or create an entry:

```basic
function get_state_index(listtype as string) as integer
    for i as integer = 0 to ubound(liststate_tab)
        if liststate_tab(i).listtype = listtype then return i
    next
    ' not found: append
    dim as integer n
    if (len(liststate_tab) = 0) then
        redim liststate_tab(0)
        n = 0
    else
        n = ubound(liststate_tab) + 1
        redim preserve liststate_tab(0 to n)
    end if
    liststate_tab(n).listtype = listtype
    liststate_tab(n).currentidx = -1
    return n
end function
```

Then rewrite `liststate`:

```basic
function liststate(listtype as string, playtype as string, action as string) as integer
    dim idxstate as integer = get_state_index(listtype)
    dim currentitem as integer = liststate_tab(idxstate).currentidx

    select case lcase(action)
        case "init"
            currentitem = listnext(listtype, playtype, -1)
            if lcase(playtype) = "linear" then
                clearseq(listtype)
            end if

        case "next"
            currentitem = listnext(listtype, playtype, currentitem)

        case "prev"
            currentitem = listprevious(listtype, playtype, currentitem)
    end select

    liststate_tab(idxstate).currentidx = currentitem
    return currentitem
end function
```

Now the *caller* never needs to store `currentsong`, `currentimage`, etc.:

```basic
currentitem = liststate("image", playtype, "init")
...
currentitem = liststate("image", playtype, "next")
...
currentitem = liststate("music", playtype, "next")
```

Each `listtype` remembers its own current index via `liststate_tab`, so switching between types is trivial.

### Option B: store current per list element

If you really want **one** array only, you can piggy‑back on `listseqh` or add another array like `listcurrent(any) As Integer` and mark the current item per type by a flag (for example `1 = current, 0 = not`), then `liststate` would:

- Find the element where `listtype = ...` and `listcurrent = 1` as current.
- Compute next/previous index.
- Clear old flag, set new flag.

But this requires scanning the whole list for “current == 1” every call, which is less efficient and more cumbersome than the small side table.

## About not using `Erase` (your concern)

Your current `refreshlist` keeps the arrays allocated and compacts them by moving non‑matching entries and `ReDim Preserve` to shrink. That is perfectly valid; the `UBound` logic in `createlist` (starting from previous `UBound`, adding new items) matches that layout.[^4_1]

So:

- If you like this design, you can keep it and **do not** use `Erase`.
- Just be consistent: `UBound(listrec.listfile)` always gives the last global index, and *all* per‑type logic (current, sequence, shuffle) filters by `listtype`, which your code already does.

The only missing piece is “current index per listtype,” and the side table approach gives you that without resorting to many `currentX` globals.

<div align="center">⁂</div>

[^4_1]: https://www.freebasic.net/wiki/wikka.php?wakka=ProPgArrays

[^4_2]: https://documentation.help/FreeBASIC/TutDynamicArrays.html


---

# Oooh that -1 thing again gracias though, currentitem  = listnext(listtype, playtype, -1) instead on currentitem  = listnext(listtype, playtype, 0) to init. So with option A get the current song / image / video / etv its the return value of get_state_index(listtype) ?

`-1` is just a sentinel meaning “no current item yet”, so using `listnext(..., -1)` for init is exactly to say “start *before* the first item, then move to the first valid one.” This matches how your linear code already uses `currentitem + 1` as the next search start.

## What `get_state_index` returns

In option A:

```basic
type liststate_rec
    as string  listtype
    as integer currentidx
end type

dim shared liststate_tab() as liststate_rec
```

`get_state_index(listtype)` returns the **index inside `liststate_tab()`**, not the current song/image/video index itself. Think of it as:

- `liststate_tab(k).listtype`  → `"music"`, `"image"`, `"video"`, etc.
- `liststate_tab(k).currentidx` → the current element index *in your big `listrec` arrays* for that type.

So the flow in `liststate` is:

```basic
function liststate(listtype as string, playtype as string, action as string) as integer
    dim idxstate    as integer = get_state_index(listtype)
    dim currentitem as integer = liststate_tab(idxstate).currentidx

    select case lcase(action)
        case "init"
            currentitem = listnext(listtype, playtype, -1)   ' start before first
            if lcase(playtype) = "linear" then
                clearseq(listtype)
            end if

        case "next"
            currentitem = listnext(listtype, playtype, currentitem)

        case "prev"
            currentitem = listprevious(listtype, playtype, currentitem)
    end select

    ' store new current for that listtype
    liststate_tab(idxstate).currentidx = currentitem

    return currentitem
end function
```

- Externally, **the value you care about** (the current song/image/video) is the **return value of `liststate`**, i.e. `currentitem`.
- Internally, `get_state_index` just tells you *which slot* in `liststate_tab()` belongs to this `listtype`, so you can read/write its `currentidx` field.

Example usage:

```basic
' init image playlist
dim as integer curImage = liststate("image", "linear", "init")

' later, user hits "next image"
curImage = liststate("image", "linear", "next")

' separately, music:
dim as integer curSong = liststate("music", "shuffle", "init")
curSong = liststate("music", "shuffle", "next")
```

No `currentimage`, `currentsong` globals needed; each type’s current index is stored in `liststate_tab(k).currentidx` for its own `listtype`.
<span style="display:none">[^5_1][^5_10][^5_2][^5_3][^5_4][^5_5][^5_6][^5_7][^5_8][^5_9]</span>

<div align="center">⁂</div>

[^5_1]: https://documentation.help/FreeBASIC/TutIntroArrays.html

[^5_2]: https://www.freebasic.net/forum/viewtopic.php?t=29234

[^5_3]: https://www.freebasic.net/forum/viewtopic.php?t=25809

[^5_4]: https://www.freebasic.net/forum/viewtopic.php?t=26210

[^5_5]: https://www.freebasic.net/wiki/wikka.php?wakka=ExtLibTOC

[^5_6]: https://www.freebasic.net/forum/viewtopic.php?t=31752

[^5_7]: https://www.freebasic.net/forum/viewtopic.php?t=26256

[^5_8]: https://www.facebook.com/groups/2057165187928233/posts/3653731158271620/

[^5_9]: https://babyprogrammer.com/blog/best-of-freebasic-ides-tools-libraries-resources-and-more/

[^5_10]: https://www.freebasic.net/forum/viewtopic.php?t=27987


---

# I have situations I just need the current <media> type song, image, etc without manipulating aka no calling liststate so does get_state_index(listtype) return the current element / idx / ?

`get_state_index(listtype)` does **not** return the current media index; it returns the slot in the small side table where that media type’s state is stored. The actual “current song/image/etc.” index is the `currentidx` field in that slot.[^6_6]

## What `get_state_index` gives you

With:

```basic
type liststate_rec
    as string  listtype
    as integer currentidx
end type

dim shared liststate_tab() as liststate_rec
```

- `get_state_index("music")` → e.g. `0`
- `get_state_index("image")` → e.g. `1`

Those are **indices into `liststate_tab()`**, not into `listrec.listfile()`.[^6_8]

## How to get the current item without changing it

When you just want “what is the current item for this type?”:

```basic
function getcurrent_for_type(listtype as string) as integer
    dim idxstate as integer = get_state_index(listtype)
    return liststate_tab(idxstate).currentidx
end function
```

Usage:

```basic
dim as integer curImage = getcurrent_for_type("image")
dim as integer curSong  = getcurrent_for_type("music")
```

This does **not** advance or modify anything; it only reads the stored index.

## Where that `currentidx` is set

Inside your `liststate` function (from the previous design):

```basic
liststate_tab(idxstate).currentidx = currentitem
return currentitem
```

So:

- To *change* or navigate: call `liststate(...)` and use its return value.
- To *inspect* the current item without navigation: call a helper like `getcurrent_for_type` that returns `liststate_tab(get_state_index(listtype)).currentidx`.
<span style="display:none">[^6_1][^6_10][^6_2][^6_3][^6_4][^6_5][^6_7][^6_9]</span>

<div align="center">⁂</div>

[^6_1]: https://github.com/freebasic/fbc/blob/master/src/compiler/fbc.bas

[^6_2]: https://documentation.help/FreeBASIC/documentation.pdf

[^6_3]: http://www.wildgardenseed.com/RQDP/FreeBasic/FBhelp/hiRef.htm

[^6_4]: https://freebasic.net/forum/viewtopic.php?t=740

[^6_5]: https://www.freebasic.net/forum/viewtopic.php?p=144554

[^6_6]: https://documentation.help/FreeBASIC/ProPgReturnValue.html

[^6_7]: http://www.fredshack.com/docs/freebasic.html

[^6_8]: https://users.freebasic-portal.de/tjf/Projekte/fbc_doc/html/functions_vars_0x79.html

[^6_9]: http://www.wildgardenseed.com/RQDP/FreeBasic/FBhelp/uvwxyzRef.htm

[^6_10]: http://29v7zb3.257.cz/freebasic/keypgsub.html


---

# Will need some reflection on this it comes across as a bit convoluted (though maybe needed) ... you mentioned 'Option B: store current per list element' using listseqh this has crossed my mind but I'm afraid it interfere with the shuffle mode plus there is clearseq which resets listseqh per listtype but only when initializing in linear or toggling from shuffle to linear...

Using `listseqh` for both “shuffle history” and “current item” is technically possible but becomes fragile for exactly the reasons you describe: shuffling, wrapping, and `clearseq` will all be touching the same field.

### Why mixing them is risky

- Shuffle relies on `listseqh = 0` meaning “not yet played this shuffle round” and `> 0` as a play order counter.
- `clearseq(listtype)` sets all `listseqh` for that type back to 0 when you re‑init linear or switch from shuffle to linear.
- If you also try to encode “this is the current item” into `listseqh` (for example by a special value), every place that:
    - increments the sequence,
    - resets it,
    - or scans for min/max sequence
must now *also* respect that special meaning and not accidentally clear or move it.

That turns a simple numeric “history counter” into a multipurpose state machine, which is error‑prone.

### Cleaner separation of roles

Conceptually there are three independent things:

1. **Membership**: which entries belong to a given `listtype` (you already have `listtype()` for that).
2. **Shuffle history**: which entries of that type have been played this shuffle round, and in what order (`listseqh()` is already doing that well).
3. **Current pointer**: for each `listtype`, which index in `listrec.*` is the one currently “active”.

When 2 and 3 are separate:

- Shuffle history can be freely cleared or rebuilt without losing “where you are” in linear mode.
- Linear navigation is trivial: `currentidx` just moves to the next/prev by type; `listseqh` is only consulted if `playtype = "shuffle"`.
- You do not need to reason about “is `listseqh(i) = 0` because it’s never played, or because it’s current and we used 0 to mean that, or because we cleared it?”


### A lighter variant of option A

If the side table felt convoluted, you can simplify its API so it’s mostly invisible:

```basic
type liststate_rec
    as string  listtype
    as integer currentidx
end type

dim shared liststate_tab() as liststate_rec
```

Utility to get current index *and* auto‑init if needed:

```basic
function get_currentidx_ref(listtype as string) byref as integer
    ' Find or create entry
    for i as integer = 0 to ubound(liststate_tab)
        if liststate_tab(i).listtype = listtype then
            return liststate_tab(i).currentidx
        end if
    next

    ' Not found → append
    dim as integer n
    if len(liststate_tab) = 0 then
        redim liststate_tab(0)
        n = 0
    else
        n = ubound(liststate_tab) + 1
        redim preserve liststate_tab(0 to n)
    end if
    liststate_tab(n).listtype = listtype
    liststate_tab(n).currentidx = -1
    return liststate_tab(n).currentidx
end function
```

Then `liststate` becomes:

```basic
function liststate(listtype as string, playtype as string, action as string) as integer
    dim byref currentitem = get_currentidx_ref(listtype)

    select case lcase(action)
        case "init"
            currentitem = listnext(listtype, playtype, -1)
            if lcase(playtype) = "linear" then
                clearseq(listtype)
            end if

        case "next"
            currentitem = listnext(listtype, playtype, currentitem)

        case "prev"
            currentitem = listprevious(listtype, playtype, currentitem)
    end select

    return currentitem
end function
```

And when you *only* want to know “current image/song/etc.” without changing it:

```basic
function current_for_type(listtype as string) as integer
    dim byref cur = get_currentidx_ref(listtype)
    return cur          ' -1 means “not initialized yet”
end function
```

This keeps:

- `listseqh` purely as shuffle/play‑order history.
- A separate `currentidx` per type with minimal code and no extra globals like `currentimage`, `currentsong`, etc.

So, in terms of complexity:

- Overloading `listseqh` will look simpler at first but forces every shuffle/linear/clear function to handle edge‑cases.
- A small per‑type `currentidx` holder adds a few lines once, then makes the rest of the code straightforward and less surprising.

---

# Yeah I was afraid of this I think for now using listseqh is a no no.. An other option is to add     as integer listhist(any) to listrec (actually phased it out but in hindsight...) and did something like listrec.listhist(currentitem) = currentitem

print "history itemnr " \& listrec.listhist(currentitem)
which is a bit superfluous but maybe say getcurrentitem(listtype) > get highest nr in listrec.listhist > return current song / image / etc?

Using a separate `listhist(any)` is much safer than overloading `listseqh`, but storing the index as its own value (`listhist(i) = i`) is redundant. A small tweak makes it both simple and useful.

## Better use of `listhist`

Instead of `listhist(currentitem) = currentitem`, use `listhist(currentitem)` as a **monotonic counter** (like a timestamp):

- On each “play” of an item of a given type, bump a global counter and store it in `listhist(currentitem)`.
- The *current* item for that `listtype` is the one with the **highest `listhist`** among that type.

You already have a similar pattern with `listseqh` for shuffle; this is the same idea but dedicated purely to “last selected” tracking.

### Data

Add:

```basic
type lrec
    as string  listname(any)
    as string  listfile(any)
    as string  listtype(any)
    as integer listseqh(any)
    as integer listhist(any)
end type

dim shared listrec as lrec
dim shared listhist_counter as integer = 0
```


### Update history whenever you “move” to an item

Wherever you decide that `currentitem` has become the active one (e.g. inside `liststate` or right after calling `listnext/listprevious`):

```basic
sub mark_current(currentitem as integer)
    if currentitem < 0 then exit sub
    listhist_counter += 1
    listrec.listhist(currentitem) = listhist_counter
end sub
```

Call `mark_current(currentitem)` right after you compute the new current index.

## Getting the current item per type

Now `getcurrentitem(listtype)` can be:

```basic
function getcurrentitem(listtype as string) as integer
    dim as integer bestidx = -1
    dim as integer besthist = 0

    for i as integer = 0 to ubound(listrec.listfile)
        if listrec.listtype(i) = listtype then
            if listrec.listhist(i) > besthist then
                besthist = listrec.listhist(i)
                bestidx  = i
            end if
        end if
    next i

    return bestidx   ' -1 means: never selected for this listtype yet
end function
```

This gives you:

- No interference with shuffle: `listseqh` remains purely shuffle history.
- No separate globals like `currentimage`, `currentsong`.
- A simple read‑only query: “what is the last active item for this type?” via `getcurrentitem("music")`, `getcurrentitem("image")`, etc., without changing any state.

If you sometimes want “first item if nothing was ever played”, you can handle `-1` from `getcurrentitem` by falling back to `listnext(listtype, playtype, -1)`.

---

# Hmm tempting so refreshlist() and createlist() will need some tweaking what would you suggest for the array blocks in those two functions?

For `listhist` to work cleanly with your existing code, it just needs to stay in sync with the other arrays and be initialized to 0 for all valid entries. Everything else (the history logic) can sit outside `refreshlist` / `createlist`.

Below are minimal, concrete tweaks for both functions.

## Changes in the type and general invariant

Add `listhist(any)`:

```basic
type lrec
    as string  listname(any)
    as string  listfile(any)
    as string  listtype(any)
    as integer listseqh(any)
    as integer listhist(any)   ' new: history / last-active marker
end type
```

Invariant you want to keep:

- All arrays: `listname`, `listfile`, `listtype`, `listseqh`, `listhist` always have the **same bounds** (`0 to ubound(listrec.listfile)`).

FreeBASIC’s `ReDim Preserve` on parallel arrays supports this pattern well.[^9_1]

***

## `createlist` changes

You just need to include `listhist` in the `ReDim Preserve` block and initialize it to 0 for new entries.

Current part:

```basic
if instr(1, filterext, fileext) > 0 and len(fileext) > 3 then 
    listnr += 1
    redim preserve listrec.listname(0 to listnr)
    redim preserve listrec.listfile(0 to listnr)
    redim preserve listrec.listtype(0 to listnr)
    redim preserve listrec.listseqh(0 to listnr)
    listrec.listname(listnr) = file
    listrec.listfile(listnr) = path(i) & file
    listrec.listtype(listnr) = listtype
    listrec.listseqh(listnr) = 0
    maxfiles += 1
end if
```

Change to:

```basic
if instr(1, filterext, fileext) > 0 and len(fileext) > 3 then 
    listnr += 1
    redim preserve listrec.listname(0 to listnr)
    redim preserve listrec.listfile(0 to listnr)
    redim preserve listrec.listtype(0 to listnr)
    redim preserve listrec.listseqh(0 to listnr)
    redim preserve listrec.listhist(0 to listnr)   ' new

    listrec.listname(listnr)  = file
    listrec.listfile(listnr)  = path(i) & file
    listrec.listtype(listnr)  = listtype
    listrec.listseqh(listnr)  = 0                  ' shuffle state
    listrec.listhist(listnr) = 0                  ' never “current” yet

    maxfiles += 1
end if
```

That’s all `createlist` needs.

***

## `refreshlist` changes

`refreshlist` compacts the arrays by *removing* entries of a specific `listtype`. For the remaining entries, you want to:

- Move `listhist` along with the others when compacting.
- ReDim it with the same new bounds when shrinking.

Current relevant part (compacting):

```basic
for i as integer = lbound(listrec.listfile) to ubound(listrec.listfile)
    if listrec.listtype(i) <> listtype then
        newcount += 1
        if i <> newcount then
            listrec.listname(newcount) = listrec.listname(i)
            listrec.listfile(newcount) = listrec.listfile(i)
            listrec.listtype(newcount) = listrec.listtype(i)
            listrec.listseqh(newcount) = listrec.listseqh(i)
        end if
    end if
next i
```

Add `listhist` to the copy:

```basic
for i as integer = lbound(listrec.listfile) to ubound(listrec.listfile)
    if listrec.listtype(i) <> listtype then
        newcount += 1
        if i <> newcount then
            listrec.listname(newcount)   = listrec.listname(i)
            listrec.listfile(newcount)   = listrec.listfile(i)
            listrec.listtype(newcount)   = listrec.listtype(i)
            listrec.listseqh(newcount)   = listrec.listseqh(i)
            listrec.listhist(newcount)   = listrec.listhist(i)   ' new
        end if
    end if
next i
```

Current shrink block:

```basic
if newcount < ubound(listrec.listfile) then
    redim preserve listrec.listname(lbound(listrec.listname) to newcount)
    redim preserve listrec.listfile(lbound(listrec.listfile) to newcount)
    redim preserve listrec.listtype(lbound(listrec.listtype) to newcount)
    redim preserve listrec.listseqh(lbound(listrec.listseqh) to newcount)
end if
```

Extend it:

```basic
if newcount < ubound(listrec.listfile) then
    redim preserve listrec.listname (lbound(listrec.listname)  to newcount)
    redim preserve listrec.listfile (lbound(listrec.listfile)  to newcount)
    redim preserve listrec.listtype (lbound(listrec.listtype)  to newcount)
    redim preserve listrec.listseqh (lbound(listrec.listseqh)  to newcount)
    redim preserve listrec.listhist(lbound(listrec.listhist) to newcount) ' new
end if
```

Because you’re already compacting by copying only “kept” elements over each other, you do **not** need special handling for `listhist`: its current values just follow the item they belong to.

***

## Where to hook history

With these changes:

- `createlist` creates new entries with `listhist = 0`.
- `refreshlist` preserves whatever history you had for all remaining items.

You then add the separate helper discussed earlier:

```basic
dim shared listhist_counter as integer = 0

sub mark_current(currentitem as integer)
    if currentitem < 0 then exit sub
    listhist_counter += 1
    listrec.listhist(currentitem) = listhist_counter
end sub
```

And call `mark_current(currentitem)` whenever you effectively “move to” an item (after `listnext`, `listprevious`, or `listshuffle` result).

`getcurrentitem(listtype)` then only *reads* `listhist` and does not need any adjustment to `refreshlist` or `createlist` beyond those array‑sync tweaks.

<div align="center">⁂</div>

[^9_1]: https://documentation.help/FreeBASIC/TutIntroArrays.html


---

# dim shared listhist_counter as integer ? and a helper? why not do that in liststate() ?

`listhist_counter` and the helper are just one way to organize it; you absolutely can keep both *inside* `liststate` if you prefer.

## Minimal version inside `liststate`

You only need:

- One shared counter.
- No separate helper; just bump and write in `liststate` whenever you change `currentitem`.

Example sketch:

```basic
dim shared listhist_counter as integer = 0
```

```basic
function liststate(listtype as string, playtype as string, action as string) as integer
    static currentidx() as integer   ' or use the per-type table we discussed
    dim currentitem as integer

    select case lcase(action)
        case "init"
            currentitem = listnext(listtype, playtype, -1)
            if lcase(playtype) = "linear" then
                clearseq(listtype)
            end if

        case "next"
            currentitem = listnext(listtype, playtype, currentitem)

        case "prev"
            currentitem = listprevious(listtype, playtype, currentitem)
    end select

    ' mark history here
    if currentitem >= 0 then
        listhist_counter += 1
        listrec.listhist(currentitem) = listhist_counter
    end if

    return currentitem
end function
```

So:

- The **counter** needs to be shared (or `static`) somewhere so it survives between calls; putting it near `liststate` is fine.
- The **helper** is optional. It was just to avoid repeating the “increment + assign” pattern. If the logic is only used in one place (`liststate`), inlining it there is simpler.

`getcurrentitem(listtype)` then only scans `listhist` for the highest value for that `listtype` and returns the index, without ever modifying anything.

---

# Hmm I don't know dim shared listhist_counter as integer this is listtype agnostic each listtype has it's own current item I don't quite get the need of the counter?

The counter is not about *which* listtype, it is about *time order* (“what was the last item I moved to?”). Each listtype still has its own current item; they just share one global timeline.

Because tool calls are currently unavailable, citations refer to general FreeBASIC documentation and common array/state‑management patterns in similar code.[^11_1]

## Why a shared counter works

Think of `listhist` as a timestamp:

- `listhist(i) = 0`  → never selected.
- Higher value      → selected later.

The shared `listhist_counter` is just “the next timestamp.” Each time *any* listtype changes current item:

```basic
listhist_counter += 1
listrec.listhist(currentitem) = listhist_counter
```

This does **not** mix listtypes logically, because when you ask:

```basic
getcurrentitem("music")
getcurrentitem("image")
```

each function only looks at entries where `listrec.listtype(i) = "music"` or `"image"` respectively, and among those it picks the highest `listhist`. So you still have:

- One current **music** index (highest `listhist` among `type = "music"`).
- One current **image** index (highest `listhist` among `type = "image"`).
- Etc.

They just share a counter so that:

- You never reuse the same history value.
- “More recent” is simply “larger number”.


## Why not one counter per listtype?

You *could* keep a separate counter per listtype (e.g. a small table like earlier). That would also work, but then you need more state:

- One `music_counter`, one `image_counter`, …
- Or a map `listtype → counter`.

The single global counter is the smallest, simplest piece of state that still lets each listtype be independent when you filter on `listtype` during the scan.

If you prefer to keep things conceptually separated, you can absolutely do:

```basic
type liststate_rec
    as string  listtype
    as integer currentidx
    as integer hist_counter
end type
```

and then:

- On each change of current for that listtype:
    - `hist_counter += 1`
    - `listhist(currentitem) = hist_counter`

This makes the “time axis” per listtype instead of global, while the logic of “highest listhist within this type = current item” stays exactly the same.

<div align="center">⁂</div>

[^11_1]: https://documentation.help/FreeBASIC/TutIntroArrays.html


---

# Don't want to come across as fussy but keep in mind the listrec array shrinks and expands via refreshlist() I'm having misgivings about a separate counter keeping tabs ...

The shrinking/expanding of `listrec` is exactly why a *per‑element* value like `listhist(i)` is safer than a “position‑based” scheme, and why the counter itself doesn’t need to “track the array” at all.[^12_1]

## What survives `refreshlist`

In your `refreshlist(listtype)`:

- You compact by copying **kept** entries down:

```basic
if listrec.listtype(i) <> listtype then
    newcount += 1
    if i <> newcount then
        listrec.listname(newcount) = listrec.listname(i)
        listrec.listfile(newcount) = listrec.listfile(i)
        listrec.listtype(newcount) = listrec.listtype(i)
        listrec.listseqh(newcount) = listrec.listseqh(i)
        listrec.listhist(newcount) = listrec.listhist(i)  ' <- add this
    end if
end if
```

- Then you `ReDim Preserve` all arrays down to `newcount`.

Result: every remaining item brings its own `listhist` value with it. The **absolute index** changes, but the **relative history order** encoded in `listhist` is preserved.

The global counter (or per‑type counter) is only used when you *assign* a new history value; it does not depend on current indices and does not need to be synchronized with `refreshlist`. It just keeps increasing: 1, 2, 3, … regardless of how the array is compacted.

## Why this is still consistent

- When you remove items of some `listtype`, their `listhist` values disappear with them; nothing else needs updating.
- For remaining items, `listhist` keeps whatever it had; “largest value within this type” is still the latest one.
- The counter doesn’t care that index 10 moved to 7; it only cares that “next time something becomes current, use value 42”.

So shrinking/expanding does **not** break the scheme, as long as:

- You always copy `listhist` with its item in `refreshlist`.
- You always `ReDim Preserve` `listhist` together with the other arrays.

The only real constraint is: treat `listhist` like `listseqh`—just another parallel array that follows its item when you compact or resize.

<div align="center">⁂</div>

[^12_1]: https://documentation.help/FreeBASIC/TutIntroArrays.html


---

# Ok I think I can see the reasoning but isn't listrec.listhist(currentitem) already the counter? I mean  while through listrec get the highest number per listtype add 1 and shove it in the next element?

Yes, you can use `listrec.listhist(currentitem)` itself as the “counter source” and derive the next value from a scan, without a separate global counter. The idea is: history is stored *only* in the array, and you recompute “next history value” by finding the current maximum.

Because external references are temporarily unavailable, this is based on standard FreeBASIC array patterns and your existing code structure.[^13_1]

## How to use `listhist` without a separate counter

1. **When marking a current item:**

```basic
sub mark_current(listtype as string, currentitem as integer)
    if currentitem < 0 then exit sub

    dim as integer maxhist = 0

    ' find max history for this listtype
    for i as integer = 0 to ubound(listrec.listfile)
        if listrec.listtype(i) = listtype then
            if listrec.listhist(i) > maxhist then
                maxhist = listrec.listhist(i)
            end if
        end if
    next i

    ' assign next value
    listrec.listhist(currentitem) = maxhist + 1
end sub
```

    - No global counter.
    - `maxhist` is “largest history value for this type at this moment”.
    - The new current item gets `maxhist + 1`.
2. **When you want “current item per listtype”:**

```basic
function getcurrentitem(listtype as string) as integer
    dim as integer bestidx = -1
    dim as integer besthist = 0

    for i as integer = 0 to ubound(listrec.listfile)
        if listrec.listtype(i) = listtype then
            if listrec.listhist(i) > besthist then
                besthist = listrec.listhist(i)
                bestidx  = i
            end if
        end if
    next i

    return bestidx      ' -1 → never marked for this type
end function
```

This is exactly the “get highest number per listtype” that you described.
3. **Hook into `liststate` (or your navigation code):**

Right after you decide on the new `currentitem`:

```basic
currentitem = listnext(listtype, playtype, currentitem)
mark_current(listtype, currentitem)
```

or in `liststate`:

```basic
currentitem = listnext(listtype, playtype, currentitem)
mark_current(listtype, currentitem)
return currentitem
```


## Why this works with shrinking/expanding

- `refreshlist` copies `listhist` along with each kept entry and shrinks with `ReDim Preserve`, so the history values stay attached to their items even if indexes change.
- When you later call `mark_current`, it rescans only the current contents to compute a new “max + 1”; removed items are gone, so their history is naturally ignored.

The trade‑off is:

- **Pros:**
    - No global/shared counter.
    - All information lives in the arrays themselves.
- **Cons:**
    - Each `mark_current` call does an O(n) scan over `listrec` (filtered by `listtype`). For your playlist sizes this is usually fine; if it ever becomes a hotspot, then a small per‑type counter cache becomes attractive again.

But conceptually you are correct: treating `listrec.listhist()` as the only source of history and deriving “next” as “max + 1 per listtype” is a valid and consistent design.

<div align="center">⁂</div>

[^13_1]: https://documentation.help/FreeBASIC/TutIntroArrays.html


---

# Excellent good that we can see it both ways. So three options, well actually two because using listseqh is not advisable, nice many thanks for offering insights and the benefits and pitfalls of them. I'm going to reflect a bit on these I'll drop by at a later date. Also thanks for -1 tip I completely overlooked it with the init (first song / image / etc) ...

Glad it helped, and the back‑and‑forth on the design made sense.

- Using `listseqh` for shuffle only and a **separate** mechanism for “current per listtype” is the safest route; whether that’s:
    - a small per‑type state table, or
    - the `listhist` “max + 1 per listtype” pattern you described,
both are valid trade‑offs.[^14_1]
- The `-1` as “no current yet” fits your `listnext` / `listprevious` logic naturally, since your linear path already starts from `currentitem + 1`, so `-1` means “before first element”.[^14_2]

Reflecting a bit before wiring everything in is a good idea. When you come back, if you have a concrete version of `liststate` or `getcurrentitem` you want sanity‑checked, just paste it and it can be walked through step by step.

<div align="center">⁂</div>

[^14_1]: https://documentation.help/FreeBASIC/TutIntroArrays.html

[^14_2]: http://www.wildgardenseed.com/RQDP/FreeBasic/FBhelp/uvwxyzRef.htm

