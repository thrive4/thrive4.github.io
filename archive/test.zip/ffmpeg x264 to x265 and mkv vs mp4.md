<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Could you have a look see at this batch script: :: arg 1 is video

@echo off
set _dummy=%1
set _dummy2=%_dummy:_= %
set _outputfilename=%_dummy2:~0,-4%_c.mkv  :: Ensure you keep a valid extension
call :lowercase _outputfilename
echo new filename : %_outputfilename%

:: options
::-ss        is start at
::-to        is end at
::-crf       set quality (def 28) lower better / affects encoding time and size of file
::           [https://superuser.com/questions/490683/cheat-sheets-and-preset-settings-that-actually-work-with-ffmpeg-1-0](https://superuser.com/questions/490683/cheat-sheets-and-preset-settings-that-actually-work-with-ffmpeg-1-0)
::-an        remove audio
::-tune      grain (retain grain from source as much as possible)
::-map       select streams (0 selects all including subtitles, etc)

:: complete file
::ffmpeg.exe -i %1 -map 0 -c:v libx265 -preset slow -crf 24 %_outputfilename%
:: video with grain in source
::ffmpeg.exe -i %1 -map 0 -c:v libx265 -preset slow -crf 24 -tune grain %_outputfilename%
:: remove audio
::ffmpeg.exe -i %1 -an -c:v libx265 -preset slow -crf 24 %_outputfilename%
:: sample 5 minutes file
::ffmpeg.exe -i %1 -ss 00:00:00 -to 00:05:00 -map 0 -c:v libx265 -preset slow -crf 24 %_outputfilename%
ffmpeg.exe -i %1 -ss 00:00:00 -to 00:05:00 -map 0 -c:v hevc_nvenc -preset slow -cq 19 %_outputfilename%
:: sample 4 minutes plus correct aspect ratio to 16:9
::ffmpeg.exe -i %1 -ss 00:04:00 -to 00:08:00 -map 0 -c:v libx265 -vf scale=iw*1.3333:ih -preset slow -crf 24 %_outputfilename%

:: lowercase subroutine
FOR %%i IN ("A=a" "B=b" "C=c" "D=d" "E=e" "F=f" "G=g" "H=h" "I=i" "J=j" "K=k" "L=l" "M=m" "N=n" "O=o" "P=p" "Q=q" "R=r" "S=s" "T=t" "U=u" "V=v" "W=w" "X=x" "Y=y" "Z=z") DO CALL SET "%1=%%%1:%%~i%%"
GOTO:EOF : using f:\media\ffmpeg\bin>convert2x265.bat test.mp4 gives : [NULL @ 0000000000468100] Unable to find a suitable output format for '::' ::: Invalid argument : ...

The error happens because `::` is being treated as an output “file” by ffmpeg, not as a comment. In batch, `::` is only safely a comment at the very start of a line, not after commands or labels.

## What is going wrong

- In this line at the bottom of your script:

```bat
GOTO:EOF : using f:\media\ffmpeg\bin>convert2x265.bat test.mp4 gives : [NULL @ 0000000000468100] Unable to find a suitable output format for '::' ::: Invalid argument : ...
```

everything after `GOTO:EOF` is **not** a valid comment.
- The parser sees `: using ...` as a label name and the `:::` part as a command/argument, which can leak into the ffmpeg command line, so ffmpeg sees an argument `::` and complains “Unable to find a suitable output format for '::' … Invalid argument”.


## How to fix it

1. Change that line to a proper comment. For example:

```bat
GOTO :EOF

REM using f:\media\ffmpeg\bin>convert2x265.bat test.mp4 gives: [NULL @ ...] Unable to find a suitable output format for '::' ::: Invalid argument ...
```

or

```bat
GOTO :EOF
:: using f:\media\ffmpeg\bin>convert2x265.bat test.mp4 gives: ...
```

Note the `::` is now at the **start** of its own line.
2. As a general rule in batch:
    - Use `REM` or `::` **at the beginning of a line** for comments.
    - Avoid adding `::` after commands or labels on the same line (e.g. `GOTO:EOF :: comment`) because it can behave unexpectedly.

## Minor improvements you may want

- Your lowercase subroutine currently is “loose” at the end of the file. Usually it is clearer to add a label:

```bat
:lowercase
FOR %%i IN ("A=a" "B=b" "C=c" "D=d" "E=e" "F=f" "G=g" "H=h" "I=i" "J=j" "K=k" "L=l" "M=m" "N=n" "O=o" "P=p" "Q=q" "R=r" "S=s" "T=t" "U=u" "V=v" "W=w" "X=x" "Y=y" "Z=z") DO CALL SET "%1=%%%1:%%~i%%"
GOTO :EOF
```

- Then your call is fine:

```bat
call :lowercase _outputfilename
```


With those changes, ffmpeg should stop seeing `::` as an output format and your script should run as intended.
<span style="display:none">[^1_1][^1_10][^1_2][^1_3][^1_4][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://cocoalopez.com/blog/?p=3642

[^1_2]: https://stackoverflow.com/questions/12077525/batch-file-echo-on-off-not-working-properly

[^1_3]: https://stackoverflow.com/questions/66419497/windows-cmd-batch-script-ffmpeg

[^1_4]: https://www.reddit.com/r/Batch/comments/rj5by5/very_desperate_set_and_echo_a_variable_inside_the/

[^1_5]: https://github.com/KnightDanila/BAT_FFMPEG

[^1_6]: https://www.instructables.com/Text-movies-in-batch/

[^1_7]: https://www.youtube.com/watch?v=QX1FXzg8lBI

[^1_8]: https://community.spiceworks.com/t/why-does-my-batch-file-fail-when-i-add-echo-stop-my-batch-file/682549

[^1_9]: https://streaminglearningcenter.com/encoding/simplify-your-workflow-command-line-variables-in-ffmpeg-batch-files.html

[^1_10]: https://www.geeksforgeeks.org/linux-unix/batch-script-echo-command/


---

# Sorry can Imagine that it is confusing this : using f:\media\ffmpeg\bin>convert2x265.bat test.mp4 gives : [NULL @ 0000000000468100] Unable to find a suitable output format for '::' ::: Invalid argument : ... : is not part of the batch script it is an example of calling the script and the output the script generates ...

That makes sense, thanks for clarifying. Given that, the root cause is somewhere else in the script, not that example text.

Here are the likely real issues in your batch file:

## Comment style with `::`

In batch, `::` is only reliably treated as a comment when it is the **first non-whitespace thing on the line**.
If you accidentally have something like:

```bat
ffmpeg.exe -i %1 ... %_outputfilename% :: comment
```

then `::` is no longer a comment; it becomes an argument token, and ffmpeg will see `::` as an extra “file/format” argument and complain exactly as you saw: “Unable to find a suitable output format for '::'”.

To be safe:

- Use:

```bat
ffmpeg.exe -i %1 -ss 00:00:00 -to 00:05:00 -map 0 -c:v hevc_nvenc -preset slow -cq 19 %_outputfilename%
:: sample 4 minutes plus correct aspect ratio to 16:9
```

- Avoid:

```bat
ffmpeg.exe -i %1 ... %_outputfilename% :: sample 4 minutes ...
```


If **all** your `::` are already at the very start of lines, then `::` itself is fine and will not reach ffmpeg.

## Label for the lowercase routine

Right now your lowercase code appears without a label:

```bat
:: lowercase subroutine
FOR %%i IN ("A=a" ... "Z=z") DO CALL SET "%1=%%%1:%%~i%%"
GOTO:EOF
```

But you are calling it as:

```bat
call :lowercase _outputfilename
```

This means there should be a label:

```bat
:lowercase
FOR %%i IN ("A=a" "B=b" ... "Z=z") DO CALL SET "%1=%%%1:%%~i%%
GOTO :EOF
```

Without `:lowercase`, the `call :lowercase _outputfilename` jumps to the top of the file (no such label), and execution will continue in a weird way, possibly running comment lines or stray text that then get passed to ffmpeg.

## Filename and extension handling

You do:

```bat
set _dummy=%1
set _dummy2=%_dummy:_= %
set _outputfilename=%_dummy2:~0,-4%_c.mkv
call :lowercase _outputfilename
echo new filename : %_outputfilename%
```

Things to check:

- If the source file has **no extension** or an extension with a different length than 3 characters, `%_dummy2:~0,-4%` may cut incorrectly.
- If the input path has colons or unusual characters (e.g. `C:\path::something\file.mp4`), after replacement they might end up near where ffmpeg expects the output name and show up as `::`.

As a more robust alternative you can use `%~n1` and `%~dp1` to build the output:

```bat
set "_name=%~n1"
set "_dir=%~dp1"
set "_outputfilename=%_dir%%_name%_c.mkv"
call :lowercase _outputfilename
```

This avoids manual `:~0,-4` slicing.

## Concrete steps to debug

1. Make sure the lowercase routine has its label:

```bat
:lowercase
FOR %%i IN ("A=a" "B=b" ... "Z=z") DO CALL SET "%1=%%%1:%%~i%%
GOTO :EOF
```

2. Ensure **no** line with ffmpeg has `::` or `:` comments on the same line; move all comments to their own lines.
3. Temporarily add:

```bat
echo ffmpeg command is:
echo ffmpeg.exe -i "%1" -ss 00:00:00 -to 00:05:00 -map 0 -c:v hevc_nvenc -preset slow -cq 19 "%_outputfilename%"
pause
```

and verify that the echoed line contains **no `::`** anywhere.

If you paste the exact current script (verbatim, including the ffmpeg line you actually use) and the exact way you call it, the problematic `::` or path/label interaction can be pinpointed precisely.

---

# Ah The block with : :: complete file

::ffmpeg.exe -i %1 -map 0 -c:v libx265 -preset slow -crf 24 %_outputfilename%
:: video with grain in source
::ffmpeg.exe -i %1 -map 0 -c:v libx265 -preset slow -crf 24 -tune grain %_outputfilename%
:: remove audio
::ffmpeg.exe -i %1 -an -c:v libx265 -preset slow -crf 24 %_outputfilename%
:: sample 5 minutes file
::ffmpeg.exe -i %1 -ss 00:00:00 -to 00:05:00 -map 0 -c:v libx265 -preset slow -crf 24 %_outputfilename%
ffmpeg.exe -i %1 -ss 00:00:00 -to 00:05:00 -map 0 -c:v hevc_nvenc -preset slow -cq 19 %_outputfilename%
:: sample 4 minutes plus correct aspect ratio to 16:9
::ffmpeg.exe -i %1 -ss 00:04:00 -to 00:08:00 -map 0 -c:v libx265 -vf scale=iw*1.3333:ih -preset slow -crf 24 %_outputfilename%
was meant to be toggling variations of encoding on or of with the :: remark so that's an issue?

Yes, that toggle style is fine in general, and that specific block as you pasted it should not cause ffmpeg to see `::` as an argument.

## Using `::` to toggle lines

With lines like:

```bat
::ffmpeg.exe -i %1 -map 0 -c:v libx265 -preset slow -crf 24 %_outputfilename%
ffmpeg.exe -i %1 -ss 00:00:00 -to 00:05:00 -map 0 -c:v hevc_nvenc -preset slow -cq 19 %_outputfilename%
```

only the second line actually runs, and the first line is treated as a comment. That is a common pattern for “toggling” commands on or off and is valid in your case because:

- `::` is at the very start of the line.
- There is nothing before it on that line.
- The active ffmpeg line has no `::` after it.

So that block, as written, should not by itself produce “Unable to find a suitable output format for '::'”.

## Where problems would appear

Issues typically arise if:

- A comment is placed on the **same line** as ffmpeg, like:

```bat
ffmpeg.exe ... %_outputfilename% :: sample
```

- Or a label/comment line gets malformed, e.g. stray colons or text before `::`.

If your active ffmpeg line is exactly:

```bat
ffmpeg.exe -i %1 -ss 00:00:00 -to 00:05:00 -map 0 -c:v hevc_nvenc -preset slow -cq 19 %_outputfilename%
```

with no extra stuff after it, then the toggling approach with `::` above and below it is fine.

## Recommended pattern

To keep it clear and safe, structure that block like this:

```bat
:: complete file
::ffmpeg.exe -i %1 -map 0 -c:v libx265 -preset slow -crf 24 %_outputfilename%

:: video with grain in source
::ffmpeg.exe -i %1 -map 0 -c:v libx265 -preset slow -crf 24 -tune grain %_outputfilename%

:: remove audio
::ffmpeg.exe -i %1 -an -c:v libx265 -preset slow -crf 24 %_outputfilename%

:: sample 5 minutes file
ffmpeg.exe -i %1 -ss 00:00:00 -to 00:05:00 -map 0 -c:v hevc_nvenc -preset slow -cq 19 %_outputfilename%

:: sample 4 minutes plus correct aspect ratio to 16:9
::ffmpeg.exe -i %1 -ss 00:04:00 -to 00:08:00 -map 0 -c:v libx265 -vf scale=iw*1.3333:ih -preset slow -crf 24 %_outputfilename%
```

Then to switch variant, just add/remove `::` at the very start of the ffmpeg lines, never after them.

---

# Ok could you do the full script with the tweaks you mentioned so that I can give it a test drive?

Here is a cleaned‑up version of your script with the tweaks and safer filename handling.

## Batch script

```bat
@echo off
REM arg 1 is video file

REM --- build output filename: <same path>\<name>_c.mkv ---
set "_dir=%~dp1"
set "_name=%~n1"
set "_outputfilename=%_dir%%_name%_c.mkv"

REM lowercase output filename
call :lowercase _outputfilename

echo New filename: %_outputfilename%

REM --- encoding variants (toggle with :: at line start) ---

:: complete file
::ffmpeg.exe -i "%1" -map 0 -c:v libx265 -preset slow -crf 24 "%_outputfilename%"

:: video with grain in source
::ffmpeg.exe -i "%1" -map 0 -c:v libx265 -preset slow -crf 24 -tune grain "%_outputfilename%"

:: remove audio
::ffmpeg.exe -i "%1" -an -c:v libx265 -preset slow -crf 24 "%_outputfilename%"

:: sample 5 minutes file (active)
ffmpeg.exe -i "%1" -ss 00:00:00 -to 00:05:00 -map 0 -c:v hevc_nvenc -preset slow -cq 19 "%_outputfilename%"

:: sample 4 minutes plus correct aspect ratio to 16:9
::ffmpeg.exe -i "%1" -ss 00:04:00 -to 00:08:00 -map 0 -c:v libx265 -vf scale=iw*1.3333:ih -preset slow -crf 24 "%_outputfilename%"

GOTO :EOF


:lowercase
REM lowercase the variable whose name is in %1
FOR %%i IN (
  "A=a" "B=b" "C=c" "D=d" "E=e" "F=f" "G=g" "H=h" "I=i" "J=j" "K=k"
  "L=l" "M=m" "N=n" "O=o" "P=p" "Q=q" "R=r" "S=s" "T=t" "U=u" "V=v"
  "W=w" "X=x" "Y=y" "Z=z"
) DO CALL SET "%1=%%%1:%%~i%%"
GOTO :EOF
```


## How to toggle variants

- To use a different ffmpeg variant, remove `::` from the line you want active and add `::` in front of the others.
- Always keep `::` at the **very start** of the line, and keep comments on their own lines (not after the ffmpeg command).

---

# Hmmm so ::ffmpeg.exe -i "%1" -map 0 -c:v libx265 -preset slow -crf 24 "%_outputfilename%"

could also be rem ffmpeg.exe -i "%1" -map 0 -c:v libx265 -preset slow -crf 24 "%_outputfilename%"

Yes, that line can safely be written with either `::` or `REM` at the start.

## Comment options

- This:

```bat
::ffmpeg.exe -i "%1" -map 0 -c:v libx265 -preset slow -crf 24 "%_outputfilename%"
```

- And this:

```bat
rem ffmpeg.exe -i "%1" -map 0 -c:v libx265 -preset slow -crf 24 "%_outputfilename%"
```


both comment out the whole line and prevent it from running.

## Practical difference

- `REM` works anywhere on the line, but for clarity it is usually placed at the start of a comment line.
- `::` is a common shortcut and works reliably **only when it is the first non‑whitespace text on the line**.

For your toggle use case, either style is fine as long as you keep the comment marker at the very beginning of the line.

---

# Ah it was here set _outputfilename=%_dummy2:~0,-4%_c.mkv  :: Ensure you keep a valid extension now I get it.

Yes, exactly! That's the culprit.

## The real problem line

```bat
set _outputfilename=%_dummy2:~0,-4%_c.mkv  :: Ensure you keep a valid extension
```

When batch parses this, the `::` after the command **does not** reliably act as a comment. Instead:

- The command executes: `set _outputfilename=%_dummy2:~0,-4%_c.mkv`
- Then `:: Ensure...` becomes a separate argument/token that gets passed **to ffmpeg** later
- ffmpeg sees `::` as an extra "output file" and fails with "Unable to find a suitable output format for '::'"


## The fix

Move the comment to its **own line**:

```bat
set _outputfilename=%_dummy2:~0,-4%_c.mkv
:: Ensure you keep a valid extension
```

**Rule for batch**: `::` comments must be at the **very start** of their line. Never put `::` after a command on the same line.

That's why the cleaned-up script I provided earlier works—it avoids inline `::` entirely. Now your original script should run perfectly once you split that line.

---

# Yep make sure that :: is not on the same line ok actually ditched the comment was a bit superfluous. On an other note seems that when converting certain h264 with a .mp4 container to .mkv ffmpeg says '[matroska @ 000000000294f7c0] Only audio, video, and subtitles are supported for

Matroska.
Could not write header for output file \#0 (incorrect codec parameters ?): Invali
d argument
Error initializing output stream 0:0 --' changing to .mp4 : set "_outputfilename=%_dir%%_name%_c.mp4" : encodes with out a hitch ...

Yes, that's a common FFmpeg limitation with Matroska (.mkv) containers.

## MKV codec restrictions

Matroska (.mkv) only officially supports these stream types:

- Video (most codecs fine)
- Audio (most codecs fine)
- Subtitles (most types fine)

If your source .mp4 has **non-standard streams** like:

- Data streams
- Attachments (fonts, covers)
- Chapters with metadata
- Certain private streams

FFmpeg refuses to write to .mkv and gives exactly that error: "Only audio, video, and subtitles are supported for Matroska."

## Quick fixes

**Option 1: Use `-map 0` more selectively**

```bat
ffmpeg.exe -i "%1" -ss 00:00:00 -to 00:05:00 -map 0:v -map 0:a? -map 0:s? -c:v hevc_nvenc -preset slow -cq 19 "%_outputfilename%"
```

- `-map 0:v` = all video streams
- `-map 0:a?` = all audio streams (optional, skips if none)
- `-map 0:s?` = all subtitle streams (optional)

**Option 2: Stick with .mp4 output**

```bat
set "_outputfilename=%_dir%%_name%_c.mp4"
```

As you discovered, .mp4 containers are much more permissive.

**Option 3: Strip unwanted streams**

```bat
ffmpeg.exe -i "%1" -ss 00:00:00 -to 00:05:00 -map 0 -c copy -bsf:v filter_units=remove_types=17 "%_outputfilename%"
```

But `-c:v hevc_nvenc` re-encodes anyway, so Option 1 is cleaner.

## Recommended for your script

Replace your ffmpeg line with:

```bat
ffmpeg.exe -i "%1" -ss 00:00:00 -to 00:05:00 -map 0:v -map 0:a? -map 0:s? -c:v hevc_nvenc -preset slow -cq 19 "%_outputfilename%"
```

This keeps .mkv output while safely ignoring unsupported streams.[^7_1]

<div align="center">⁂</div>

[^7_1]: https://cocoalopez.com/blog/?p=3642


---

# Nice thank you for the tips. Any down sides to having a h265 video stream in a .mp4 container vs a .mkv?

H.265 (HEVC) in an MP4 container works fine technically, but has some practical downsides compared to MKV.

## Compatibility issues

MP4 with H.265 has spotty hardware support on older devices, TVs, and players—many only decode H.265 in MKV natively. MKV offers broader decoder support for H.265 across platforms like Plex, VLC, and smart TVs.[^8_1][^8_2]

## Feature limitations

- MKV handles multiple audio tracks, chapters, and advanced subtitles better; MP4 is more limited.
- MKV supports lossless audio (FLAC) and attachments; MP4 sticks to lossy AAC mainly.
- Error recovery is stronger in MKV—if part of the file corrupts, it often still plays.[^8_4][^8_6]


## File size and quality

No real difference—same H.265 stream means identical size and quality in either container. MP4 might compress metadata slightly better, but it's negligible.[^8_5][^8_1]

## When MP4 wins

Use MP4 for web streaming or mobile—universal browser/phone support. MKV shines for local playback, archiving, or multi-track content.[^8_6][^8_8]

For your script's local encoding, MKV remains preferable unless device compatibility is a concern.
<span style="display:none">[^8_10][^8_3][^8_7][^8_9]</span>

<div align="center">⁂</div>

[^8_1]: https://www.dacast.com/blog/mkv-vs-mp4-for-video-streaming/

[^8_2]: https://www.reddit.com/r/PleX/comments/tziez3/h264_vs_h265_mp4_vs_mkv/

[^8_3]: https://www.reddit.com/r/PleX/comments/2t9kbr/mkv_vs_mp4/

[^8_4]: https://imagekit.io/blog/mkv-vs-mp4/

[^8_5]: https://www.elmedia-video-player.com/blog/mkv-vs-mp4/

[^8_6]: https://api.video/blog/video-trends/mkv-vs-mp4/

[^8_7]: https://transloadit.com/blog/2023/06/mp4-vs-mkv/

[^8_8]: https://www.gumlet.com/learn/mkv-vs-mp4/

[^8_9]: https://en.wikipedia.org/wiki/Comparison_of_video_container_formats

[^8_10]: https://www.movavi.com/learning-portal/mkv-vs-mp4.html


---

# Gracias for the fixes added an .mkv option in the script works better but there are still curve balls .. for instance this can happen : Too many packets buffered for output stream 0:1.

[libvorbis @ 000000000049ea00] 32 frames left in the queue on closing
Conversion failed! : ...

That error occurs when FFmpeg can't properly flush buffered audio packets (here libvorbis) during the time-limited clip extraction.

## Why it happens

- `-ss 00:00:00 -to 00:05:00` cuts a precise 5-minute segment
- Audio encoding (Vorbis) buffers packets ahead for quality
- At exactly `00:05:00`, some audio frames remain "in flight" and can't be written cleanly to MKV[^9_1]


## Quick fixes for your script

**Option 1: Extend duration slightly** (easiest)

```bat
ffmpeg.exe -i "%1" -ss 00:00:00 -t 00:05:05 -map 0:v -map 0:a? -map 0:s? -c:v hevc_nvenc -preset slow -cq 19 "%_outputfilename%"
```

Uses `-t` (duration) instead of `-to` (end time), giving 5 extra seconds buffer.

**Option 2: Force audio re-encode**

```bat
ffmpeg.exe -i "%1" -ss 00:00:00 -to 00:05:00 -map 0:v -map 0:a? -map 0:s? -c:v hevc_nvenc -c:a aac -preset slow -cq 19 "%_outputfilename%"
```

AAC is more forgiving than Vorbis for precise cuts.

**Option 3: Ignore buffered packets** (if minor quality loss OK)

```bat
ffmpeg.exe -i "%1" -ss 00:00:00 -to 00:05:00 -map 0:v -map 0:a? -map 0:s? -c:v hevc_nvenc -preset slow -cq 19 -flush_packets 1 "%_outputfilename%"
```


## Recommended

Start with **Option 1** (`-t 00:05:05`)—gives clean 5-minute output without re-encoding audio unnecessarily. Trim the extra 5 seconds in your player if needed.

<div align="center">⁂</div>

[^9_1]: https://www.dacast.com/blog/mkv-vs-mp4-for-video-streaming/


---

# Hmm good to know or if all else fails use .mp4 as an container.

Yes, exactly—MP4 as a fallback container is a solid plan.

## Why MP4 sidesteps these issues

- More forgiving with audio buffering and stream flushing
- Handles precise `-ss`/`-to` cuts cleaner than MKV
- Broader compatibility if MKV stream mapping fails


## Script toggle suggestion

Add this near your encoding block:

```bat
:: MKV version (toggle preferred)
ffmpeg.exe -i "%1" -ss 00:00:00 -t 00:05:05 -map 0:v -map 0:a? -map 0:s? -c:v hevc_nvenc -preset slow -cq 19 "%_outputfilename%"

:: MP4 fallback (uncomment if MKV fails)
:: set "_outputfilename=%_dir%%_name%_c.mp4"
:: ffmpeg.exe -i "%1" -ss 00:00:00 -to 00:05:00 -map 0 -c:v hevc_nvenc -preset slow -cq 19 "%_outputfilename%"
```

When MKV gives trouble, just swap the extension line and uncomment the MP4 ffmpeg line. Keeps your workflow smooth.

---

# Okidoki excelent tips thank you for getting the old script in working shape again and for some insider knowledge regarding .mp4 vs .mkv

You're welcome! Glad the script is running smoothly now with those tweaks.

## Quick recap of key fixes

- Moved `::` comments to their own lines (no more "output format for '::'" errors)
- Added selective stream mapping (`-map 0:v -map 0:a? -map 0:s?`) for MKV compatibility
- Switched to `-t 00:05:05` for clean audio buffering
- MP4 fallback for stubborn files

The toggle system with `::`/REM makes it easy to swap encoding options. Happy converting!

