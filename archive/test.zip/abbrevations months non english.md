<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# I sit possible to translate the following to spanish? (just the months and days) : [language-en month]

m1  = january
m2  = february
m3  = march
m4  = april
m5  = may
m6  = june
m7  = july
m8  = august
m9  = september
m10 = oktober
m11 = november
m12 = december

[language-en day]
d0 = sunday
d1 = monday
d2 = tuesday
d3 = wednesday
d4 = thurseday
d5 = friday
d6 = saturday

Here are the Spanish translations for the months and days you listed. I’ve corrected a couple of English typos (e.g., oktober → oktober is corrected to octubre, and thurseday → jueves).

Months
m1  = enero
m2  = febrero
m3  = marzo
m4  = abril
m5  = mayo
m6  = junio
m7  = julio
m8  = agosto
m9  = septiembre
m10 = octubre
m11 = noviembre
m12 = diciembre

Days
d0 = domingo
d1 = lunes
d2 = martes
d3 = miércoles
d4 = jueves
d5 = viernes
d6 = sábado

If you want the list in a specific formatting (e.g., JSON, YAML, CSV), tell me and I’ll adapt it.

---

# No thank you this is fine. By the by do french, german, spanish and dutch use the same convetion of the first three letters of the month as an abbreviation of the month example december is dec in english ...

French, German, Spanish, and Dutch do use abbreviations for months, but they do *not* all follow the “first three letters” rule as strictly as English does.[^2_1][^2_4]

## General pattern

- All four languages have standard short forms for months used in calendars, tables, etc.[^2_4][^2_1]
- These abbreviations are often close to the first three letters, but many add or drop letters, or include a period, depending on the language.[^2_1]


## French

- Common abbreviations: janv., févr., mars, avr., mai, juin, juil., août, sept., oct., nov., déc.[^2_1]
- Only some are exactly three letters (like *mai*), while others are longer (e.g., *janv.* for janvier, *déc.* for décembre).[^2_1]


## German

- Common abbreviations: Jan., Feb., März, Apr., Mai, Juni, Juli, Aug., Sept., Okt., Nov., Dez.[^2_2][^2_1]
- Several are three letters (Jan., Feb., Apr.), but others are four or more (Sept., März, Oktober → Okt.).[^2_2][^2_1]


## Spanish

- Common forms: enero, feb., marzo, abr., mayo, jun., jul., agosto, sept./set., oct., nov., dic.[^2_1]
- Some are three letters (feb., abr., jun., jul.), but others differ (sept./set., dic.).[^2_1]


## Dutch

- Common abbreviations: jan, feb, mrt, apr, mei, jun, jul, aug, sep, okt, nov, dec.[^2_4][^2_1]
- Many are three letters (jan, feb, apr), but *mrt* (maart) and *okt* (oktober) show that it’s not always the “first three letters” mechanically.[^2_4]

So overall, the convention is “short recognizable forms,” often around three letters, but each language has its own standard set rather than a strict “first three letters” rule.[^2_1]
<span style="display:none">[^2_3][^2_5][^2_6][^2_7][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://web.library.yale.edu/cataloging/months

[^2_2]: https://study.com/academy/lesson/german-months-of-the-year-their-abbreviations.html

[^2_3]: https://www.reddit.com/r/AskEurope/comments/61kyvh/how_do_you_translate_the_name_of_every_month_in/

[^2_4]: https://preply.com/en/blog/months-in-dutch/

[^2_5]: https://www.nexusdb.com/forums/showthread.php?t=4223

[^2_6]: https://greenwichmeantime.com/articles/calendars/months/

[^2_7]: https://en.wikipedia.org/wiki/List_of_date_formats_by_country

[^2_8]: https://www.facebook.com/groups/1725972127657416/posts/2918219485099335/

[^2_9]: https://www.youtube.com/watch?v=LUUnYt9dgok


---

# Hmm so I guess this was a bit optimistic :             case "short"

                ddatetime = left(langenday(fd.wDayOfWeek), 3) + ", " & day(now) & " " + left(langenmonth(month(datetime)), 3) & " " & year(datetime)
    Yes, that approach is too optimistic if you want correct abbreviations in French, German, Spanish, and Dutch, because many standard short forms are **not** just the first three letters.

Since tools are unavailable this turn, a generic suggestion is all that can be given without precise, sourced lists. For a robust solution you should:

- Define explicit lookup tables per language for:
    - Full month name → correct short month name.
    - Full weekday name → correct short weekday name.
- Then rewrite your code to use those tables instead of `Left(..., 3)`.

Conceptually something like:

```vb
Function ShortMonthName(lang As String, m As Integer) As String
    ' lookup in a language-specific array or dictionary
End Function

Function ShortDayName(lang As String, w As Integer) As String
    ' lookup in a language-specific array or dictionary
End Function
```

And then:

```vb
ddatetime = ShortDayName(lang, fd.wDayOfWeek) & ", " & Day(Now) & " " & _
            ShortMonthName(lang, Month(Date)) & " " & Year(Date)
```

That way you can keep the same formatting logic while ensuring each language uses its proper abbreviations instead of just the first three letters.

---

# Ah an list / dictionary yes that makes sense gracias. By the by 'but mrt (maart) and okt (oktober) show' with dutch march I get oktober to okt that's just the first three letters right?

In Dutch, *okt* for *oktober* is indeed just the first three letters, so that one happens to match your original “take 3 letters” idea.

The interesting one is *mrt* for *maart*:

- If you took the first three letters mechanically, you would get *maa*, not *mrt*.
- So for Dutch, some months work fine with `Left(..., 3)` (jan, feb, apr, okt, etc.), but others (like maart → mrt) don’t follow that pattern and really need a defined abbreviation rather than a substring.

Because of cases like *mrt* (and the various quirks in French, German, and Spanish), the lookup table/dictionary approach is still the safest if you care about matching real-world abbreviations.

---

# Right so english and dutch (with exception of march) are ok the other three not so much hmm might add an : [language-es monthabbrv] : (per language) ... localization always full of surprises ...

English and Dutch are mostly fine with the “first three letters” rule, with Dutch *maart → mrt* as the notable exception. Spanish, French, and German diverge enough that a simple `Left(..., 3)` will not give natural abbreviations.

Because tools are not available this turn, exact, sourced lists cannot be restated, but standard usage in those three languages includes things like French *janv.* for janvier and German *Okt.* for Oktober, which already shows they do not simply cut at three letters.[^5_1]

Defining something like `[language-es monthabbrv]`, `[language-fr monthabbrv]`, etc., is a very good idea:

- Add separate month-abbreviation and day-abbreviation blocks per language (en, es, fr, de, nl).
- Use explicit string values instead of deriving them, so you can adjust later without touching formatting code.
- Keep your formatting function language-agnostic: it just consumes “short day” + “short month” from the dictionary.

Localization does tend to hide these small traps, so your dictionary approach is exactly what robust multilingual code usually does.[^5_1]

<div align="center">⁂</div>

[^5_1]: https://web.library.yale.edu/cataloging/months


---

# Yep thank you for the tips.

Glad it helped; de nada / graag gedaan.

There is no new factual content to add here, so no external sources are needed for this closing note.

