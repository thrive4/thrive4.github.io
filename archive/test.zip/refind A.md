<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Could you generate the steps for getting / installing / configuring refind on pop os and also the steps for uninstalling / removing it specifically taking the steps regarding the 'nvram' entry that refind creates?

Here are practical, Pop!\_OS‑specific steps to install, configure, and then fully remove rEFInd, including cleaning up its NVRAM boot entry.

***

## 1. Install rEFInd on Pop!\_OS

1. Update package lists:
`sudo apt update`
2. Install rEFInd from the Pop!\_OS/Ubuntu repo:
`sudo apt install refind`
3. The package will run `refind-install` automatically and:
    - Copy rEFInd to the EFI System Partition (ESP), typically under `EFI/refind`.
    - Create an EFI boot entry in NVRAM and set rEFInd as default.[^1_1][^1_9][^1_10]
4. Reboot the machine; you should see the rEFInd boot menu.[^1_5][^1_1]

***

## 2. Basic configuration (optional but common)

1. Mount the EFI System Partition (ESP) so you can edit rEFInd config:
    - Find the ESP (often `/dev/nvme0n1p1` or `/dev/sda1`):
`sudo lsblk -f`
    - Create a mount point and mount it (example assumes `/dev/nvme0n1p1`; adjust as needed):

```bash
sudo mkdir -p /boot/efi
sudo mount /dev/nvme0n1p1 /boot/efi
```

2. rEFInd’s main config file is usually here on Pop!\_OS:
`/boot/efi/EFI/refind/refind.conf` or `/boot/efi/EFI/BOOT/refind.conf` (depending on how it installed).[^1_9]
3. Edit `refind.conf` as root, for example:
`sudo nano /boot/efi/EFI/refind/refind.conf`
4. Common tweaks in `refind.conf`:
    - Change timeout (`timeout 20`, etc.).
    - Hide entries with `dont_scan_dirs` or `dont_scan_files` if you see extra/unwanted boot options.[^1_6][^1_9]
    - Control whether rEFInd stores some tags in NVRAM with `use_nvram` (if present).[^1_2]
5. Save the file and reboot to apply.

***

## 3. Identify rEFInd’s NVRAM boot entry

1. List all EFI boot entries:
`sudo efibootmgr`
2. Look for an entry like:
    - `Boot0003* rEFInd Boot Manager` or similar.[^1_10]
3. Note the hex number (e.g. `0003`); you will use this to delete the entry later.

***

## 4. Uninstall rEFInd package (Pop!\_OS side)

Removing the package alone does not remove the EFI files or NVRAM entry, so treat this as one part of the removal.

1. Remove the package:
`sudo apt remove --purge refind`
2. Optionally remove any leftover configuration in `/etc` that the package created (if any are present).[^1_9]

At this point:

- The system may still boot via rEFInd if its EFI files and NVRAM entry are intact.
- You must remove or bypass both.

***

## 5. Remove or bypass rEFInd as default boot manager

### A. Set another boot entry as default (safer first step)

1. Again, check entries:
`sudo efibootmgr`
2. Find your Pop!\_OS or “Linux Boot Manager” or “Windows Boot Manager” entry, typically something like `Boot0000* Pop!_OS` or `Boot0001* Windows Boot Manager`.
3. Change boot order so rEFInd is not first, e.g.:
`sudo efibootmgr -o 0000,0001`
(Replace with the correct IDs and omit rEFInd’s ID.)

This makes the firmware boot directly into Pop!\_OS or Windows, bypassing rEFInd.[^1_8][^1_10]

***

## 6. Delete rEFInd’s NVRAM entry

Once the system boots fine without rEFInd, you can safely delete its NVRAM entry.

1. List entries to confirm the exact rEFInd ID:
`sudo efibootmgr`
2. Suppose rEFInd is `Boot0003`. Delete it with:
`sudo efibootmgr -b 0003 -B`
3. Run `sudo efibootmgr` again to confirm that the rEFInd entry is gone.[^1_10]

This directly handles the firmware NVRAM entry that `refind-install` created.[^1_9][^1_10]

***

## 7. Remove rEFInd files from the EFI System Partition

To fully clean up, remove rEFInd’s directory from the ESP.

1. Ensure ESP is mounted, as above (example device, adjust as needed):

```bash
sudo mkdir -p /boot/efi
sudo mount /dev/nvme0n1p1 /boot/efi
```

2. Check what’s there:
`ls /boot/efi/EFI`

You’ll typically see `refind/` or something similar for rEFInd.[^1_8][^1_9]
3. Remove the rEFInd directory:

```bash
sudo rm -r /boot/efi/EFI/refind
# Also remove any rEFInd-related directory like /boot/efi/EFI/BOOT/refind* if it exists
```

4. Optionally unmount the ESP:
`sudo umount /boot/efi`

At this point, rEFInd’s EFI binaries are gone, and the NVRAM entry is removed.

***

## 8. rEFInd’s own NVRAM-related behavior

A few extra notes about rEFInd and NVRAM:

- `refind-install` both copies files to the ESP and creates/adjusts an EFI NVRAM entry so that rEFInd becomes the default boot manager.[^1_10][^1_9]
- rEFInd can remember some options or boot tags using NVRAM, controlled via the `use_nvram` setting in `refind.conf`; if disabled, it may instead use a disk file for such tags.[^1_2]
- Removing the NVRAM entry via `efibootmgr -b XXXX -B` fully clears rEFInd as a firmware boot choice; there is no additional “hidden” NVRAM component beyond that standard EFI boot entry on typical PCs.[^1_2][^1_10]

***

If you tell me whether you are on BIOS‑compatible (CSM) or pure UEFI mode and whether you dual‑boot Windows, I can adapt these commands (e.g., what to set as the new default) more precisely to your setup.
<span style="display:none">[^1_3][^1_4][^1_7]</span>

<div align="center">⁂</div>

[^1_1]: https://www.youtube.com/watch?v=4idr6sXSue0

[^1_2]: https://www.reddit.com/r/linuxquestions/comments/1dfcpvi/how_can_i_remove_3_of_these_options_from_my_boot/

[^1_3]: https://www.youtube.com/watch?v=OgipyyaxSmE

[^1_4]: https://www.mankier.com/8/refind-install

[^1_5]: https://www.youtube.com/watch?v=vOadXgYIN9U

[^1_6]: https://www.reddit.com/r/linux4noobs/comments/msup8p/i_wanted_to_remove_these_from_refind_and_i_dont/

[^1_7]: https://www.reddit.com/r/pop_os/comments/1qgn1nt/how_can_i_safely_uninstall_pop_os_and_refind_on/

[^1_8]: https://www.reddit.com/r/pop_os/comments/k7x9mv/please_help_me_uninstall_popos_and_refind_having/

[^1_9]: https://www.rodsbooks.com/refind/installing.html

[^1_10]: https://www.reddit.com/r/pop_os/comments/jbmbud/unable_to_use_refind_with_pop_os_windows_dual_boot/

