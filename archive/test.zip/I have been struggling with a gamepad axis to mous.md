<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# I have been struggling with a gamepad axis to mouse pointer snippet for a couple of days (in freebasic) I have : 'spritecursor absolute mouse movement

Sub spritesetcursorpos(x As Long, y As Long)
dim cx_screen as long
dim cy_screen as long
dim real_x as long
dim real_y as long

    cx_screen = GetSystemMetrics(SM_CXSCREEN) - 1
    cy_screen = GetSystemMetrics(SM_CYSCREEN) - 1
    real_x    = CLng(x * (65535.0 / cx_screen))
    real_y    = CLng(y * (65535.0 / cy_screen))
    
    dim mi(0) as INPUT_
    mi(0).type           = INPUT_MOUSE
    mi(0).mi.dx          = real_x
    mi(0).mi.dy          = real_y
    mi(0).mi.dwFlags     = MOUSEEVENTF_MOVE or MOUSEEVENTF_ABSOLUTE or MOUSEEVENTF_VIRTUALDESK
    mi(0).mi.mouseData   = 0
    mi(0).mi.time        = 0
    mi(0).mi.dwExtraInfo = 0
    SendInput(1, @mi(0), sizeof(INPUT_))
    End Sub
: it works with a number of older adventure games but some have erratic movement of the mouse pointer (pointer warps to locations) ... I think I have pinpointed this to :     cx_screen = GetSystemMetrics(SM_CXSCREEN) - 1
cy_screen = GetSystemMetrics(SM_CYSCREEN) - 1
real_x    = CLng(x * (65535.0 / cx_screen))
real_y    = CLng(y * (65535.0 / cy_screen))
: Is there an alternative for GetSystemMetrics or otherwise to :   dim mi(0) as INPUT_
mi(0).type           = INPUT_MOUSE
: ?

The erratic movement is not caused by `GetSystemMetrics` itself, but by how absolute mouse input coordinates are scaled and interpreted by some games. Many older games do not use the standard “0–65535 over the virtual desktop” convention that `SendInput` with `MOUSEEVENTF_ABSOLUTE` expects, so they react badly when fed those values.

## Why the current scaling can misbehave

Windows’ absolute mouse mode expects `dx`/`dy` in the range 0–65535, mapped over the entire virtual desktop width/height, not per‑monitor client areas or game viewports. When you do

```basic
cx_screen = GetSystemMetrics(SM_CXSCREEN) - 1
cy_screen = GetSystemMetrics(SM_CYSCREEN) - 1
real_x    = CLng(x * (65535.0 / cx_screen))
real_y    = CLng(y * (65535.0 / cy_screen))
```

you are mapping a logical pixel coordinate `(x,y)` into that 0–65535 range. That is correct for Windows’ expectations, but many older games either:

- Ignore absolute mouse packets and instead track relative motion only, or
- Clamp or re‑scale cursor position internally, which can lead to “warps” when values reach extremes or when the game runs a different resolution than the desktop.

Some games also reset or recenter the mouse every frame (typical for 3D/first‑person titles), which conflicts with absolute positioning and produces jumps.

## Alternatives to GetSystemMetrics and absolute mode

Instead of changing `GetSystemMetrics`, consider changing how you send mouse input:

1. **Use relative movement instead of absolute**
For games that treat the mouse as an infinite “look” device, relative deltas are much more reliable. That means:
    - Remove `MOUSEEVENTF_ABSOLUTE` and `MOUSEEVENTF_VIRTUALDESK`.
    - Provide `mi(0).mi.dx` and `mi(0).mi.dy` as small signed deltas per frame based on how far the gamepad has moved from center.
    - Tune a sensitivity factor (e.g., multiply axis value by some scalar) instead of mapping to screen pixels.

Conceptually:

```basic
' axisX, axisY in range -1.0 to +1.0
dim sens as double = 10.0
dim dx as long = CLng(axisX * sens)
dim dy as long = CLng(axisY * sens)

mi(0).type       = INPUT_MOUSE
mi(0).mi.dx      = dx
mi(0).mi.dy      = dy
mi(0).mi.dwFlags = MOUSEEVENTF_MOVE
```

This approach matches what many joystick‑to‑mouse mappers do for FPS or older titles and usually eliminates warping because there is no absolute coordinate for the game to fight against.
2. **If absolute mode is required, use 0–65535 directly**
If you really must position the cursor absolutely (e.g., point‑and‑click adventures that respect OS cursor position), you can skip `GetSystemMetrics` entirely and treat your x/y input as normalized 0–1 values:

```basic
' xNorm, yNorm are in [0,1]
real_x = CLng(xNorm * 65535.0)
real_y = CLng(yNorm * 65535.0)

mi(0).mi.dx      = real_x
mi(0).mi.dy      = real_y
mi(0).mi.dwFlags = MOUSEEVENTF_MOVE or MOUSEEVENTF_ABSOLUTE
```

Then ensure:
    - Your game runs on the primary monitor.
    - You do **not** use `MOUSEEVENTF_VIRTUALDESK` unless you really want multi‑monitor behavior.
    - `xNorm` and `yNorm` are clamped to.[^1_1]

This removes off‑by‑one and inconsistent screen‑size issues, though some older games will still ignore absolute packets.

## About the INPUT structure

The `INPUT_` type and `INPUT_MOUSE` are correct for `SendInput`; you generally do not need a different structure or type. Problems almost always come from:

- Flags not matching what the target program expects (absolute vs relative).
- Values not being scaled to the semantic range that `SendInput` expects for those flags.

So there is no better alternative “type” for `mi(0).type = INPUT_MOUSE` for this task; the fix is in flags and scaling, not in the structure itself.

## Practical recommendations

- For adventure games that track the real system cursor, try absolute mode with 0–65535 coordinates and no `MOUSEEVENTF_VIRTUALDESK`, and ensure your input values are normalized, not raw pixels.
- For games where the camera or view jumps or spins unpredictably, switch to relative movement (`MOUSEEVENTF_MOVE` only) and send per‑frame deltas derived from the gamepad axis, with a tunable sensitivity and deadzone.

This combination usually makes gamepad‑to‑mouse control stable across a wide range of older titles.
<span style="display:none">[^1_10][^1_2][^1_3][^1_4][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://www.autohotkey.com/boards/viewtopic.php?t=24431

[^1_2]: https://flylib.com/books/en/3.67.1.68/1/

[^1_3]: https://www.youtube.com/watch?v=Cs8MYIew7FE

[^1_4]: https://www.freebasic.net/forum/viewtopic.php?t=21361

[^1_5]: https://learn.microsoft.com/en-us/answers/questions/4012925/how-to-fix-mouse-pointer-moving-inversely-proporti

[^1_6]: https://freebasic.net/forum/viewtopic.php?t=6319

[^1_7]: https://steamcommunity.com/app/392160/discussions/0/1743353164083784333/?ctp=18

[^1_8]: https://stackoverflow.com/questions/43438615/setcursor-sometimes-fails-during-rapid-mouse-movements

[^1_9]: https://www.reddit.com/r/AlienwareAlpha/comments/52cwy9/psahow_to_fix_your_controller_from_acting_like_a/

[^1_10]: https://freebasic.net/forum/viewtopic.php?t=31586


---

# Hmm the x,y pos is derived from     GetCursorPos(@axis2mouse.vpoint)

at first I thought that it was causing the issue but after some debugging it is reporting the mouspointer correctly in the window where the game is running... so @axis2mouse.vpoint ends up in : ' simulate mouse pointer movement or keyboard with stick left and right
sub axis(byref axis2mouse as mouseinit, byref axisx as single, byref axisy as single, stick as string)
Dim As Long hWnd, curscreenw, curscreenh
Dim rect As RECT

    hWnd = GetForegroundWindow()
    If GetClientRect(hWnd, @rect) Then
        curscreenw = rect.right - rect.left
        curscreenh = rect.bottom - rect.top
    Else
        ' fallback to desktop if failed
        curscreenw = GetSystemMetrics(SM_CXSCREEN)
        curscreenh = GetSystemMetrics(SM_CYSCREEN)
    End If
    'Print "Client area width:  "; curscreenw
    'Print "Client area height: "; curscreenh
    
    dim accelx as single ptr, accely as single ptr
    if stick = "left" then
        accelx = @axis2mouse.mouseacclx
        accely = @axis2mouse.mouseaccly
    else
        accelx = @axis2mouse.mouseaccrx
        accely = @axis2mouse.mouseaccry
    end if
    ' radial magnitude of stick input
    dim mag as single = sqr(axisx * axisx + axisy * axisy)
    ' screensize factor
    dim scf as long   = max(0.2, (1.1 - (curscreenh / curscreenw)))
    if mag > axis2mouse.deadzone then
        ' normalize input vector to preserve direction
        dim normX as single = axisx / mag
        dim normY as single = axisy / mag
        ' normalize magnitude to [0..1] range ignoring deadzone
        dim normMag as single = (mag - axis2mouse.deadzone) / (1.0 - axis2mouse.deadzone)
        ' scale normalized vector by normalized magnitude
        dim scaledX as single = normX * normMag
        dim scaledY as single = normY * normMag
    
        *accelx = (abs(scaledX) ^ 2.2) * axis2mouse.acceleratex
        *accely = (abs(scaledY) ^ 2.2) * axis2mouse.acceleratey
    
        axis2mouse.vpoint.x += sgn(scaledX) * *accelx
        axis2mouse.vpoint.y += sgn(scaledY) * *accely
    else
        ' decrease acceleration
        *accelx *= 0.03 * scf
        *accely *= 0.03 * scf
    end if
    
    if axis2mouse.vpoint.x < 0 then axis2mouse.vpoint.x = 0
    if axis2mouse.vpoint.y < 0 then axis2mouse.vpoint.y = 0
    if axis2mouse.vpoint.x > curscreenw - 1 then axis2mouse.vpoint.x = curscreenw - 1
    if axis2mouse.vpoint.y > curscreenh - 1 then axis2mouse.vpoint.y = curscreenh - 1
    if axis2mouse.spritecursor then
       spritesetcursorpos(axis2mouse.vpoint.x, axis2mouse.vpoint.y)
    else
       SetCursorPos(axis2mouse.vpoint.x, axis2mouse.vpoint.y)
    end if
    end sub
: spritesetcursorpos is fed axis2mouse.vpoint.x, axis2mouse.vpoint.y and look ok with : Sub spritesetcursorpos(x As Long, y As Long)
print x, y freaky enough some the older games behave correctly alas some just don't ...

Some older games are very picky about how mouse input is delivered. What you are seeing is not that your `axis2mouse.vpoint` is wrong, but that the way it is converted and sent as *absolute* `SendInput` coordinates conflicts with what the game is doing internally.[^2_1][^2_2]

## Where the mismatch comes from

You are doing three different things at once:

- You compute a “virtual” cursor (`axis2mouse.vpoint`) in *client* coordinates based on the gamepad.
- You clamp that to the client area width/height from `GetClientRect`.
- You sometimes feed it to `SetCursorPos` (desktop, absolute pixels) and sometimes to `SendInput` with `MOUSEEVENTF_ABSOLUTE` using a 0–65535 transform.

The issues:

- `GetClientRect` returns client‑area coordinates, not screen coordinates, and they are relative to the window, not the desktop. Many older games render at a smaller resolution inside a letterboxed/fullscreen area, so client size and screen size differ in subtle ways.[^2_4]
- `SendInput` with `MOUSEEVENTF_ABSOLUTE` expects `dx`/`dy` in the 0–65535 range mapped over the entire virtual desktop, not over the game’s client rect. If you scale client coords to 0–65535 but the game is interpreting mouse messages differently (or recentering the mouse each frame), the visible cursor can “warp” or jump.[^2_2]

That explains why some games behave and others do not: they handle the OS cursor and absolute packets differently.

## Two concrete changes to try

### 1. Use *relative* movement for the “problem” games

For any game that recenters or otherwise manipulates the mouse every frame (common in 3D or some older titles), absolute positioning is the enemy. Instead:

- Keep computing `axis2mouse.vpoint` for your own logic if you like, but do **not** send its absolute value to `SendInput`.
- Compute per‑frame deltas from the joystick and send only relative moves:

```basic
' Axis values in [-1.0, 1.0]
dim sens as single = 8.0
dim dx as long = CLng(axisx * sens)
dim dy as long = CLng(axisy * sens)

dim mi(0) as INPUT_
mi(0).type       = INPUT_MOUSE
mi(0).mi.dx      = dx
mi(0).mi.dy      = dy
mi(0).mi.mouseData   = 0
mi(0).mi.time        = 0
mi(0).mi.dwExtraInfo = 0
mi(0).mi.dwFlags = MOUSEEVENTF_MOVE   ' no ABSOLUTE, no VIRTUALDESK
SendInput(1, @mi(0), sizeof(INPUT_))
```

Here you do **not** transform by screen size at all; `dx`/`dy` are just small signed steps each frame.[^2_3][^2_1]
You can still maintain `axis2mouse.vpoint` for your own overlay or UI, but let the game see relative motion only.

### 2. If you need absolute positioning, normalize differently

For point‑and‑click games that really want the OS cursor in a specific spot, use one consistent mapping:

- Always work in **screen** coordinates when you talk to `SendInput`, not client coordinates. If you base movement on the client rect, convert to screen with `ClientToScreen` before sending.
- When using `MOUSEEVENTF_ABSOLUTE`, skip `GetClientRect` and use desktop metrics, or even better, normalized values:

```basic
' x,y are *screen* pixel coordinates
dim scrW as long = GetSystemMetrics(SM_CXSCREEN)
dim scrH as long = GetSystemMetrics(SM_CYSCREEN)

dim real_x as long = CLng( x * 65535.0 / (scrW - 1) )
dim real_y as long = CLng( y * 65535.0 / (scrH - 1) )

mi(0).type       = INPUT_MOUSE
mi(0).mi.dx      = real_x
mi(0).mi.dy      = real_y
mi(0).mi.mouseData   = 0
mi(0).mi.time        = 0
mi(0).mi.dwExtraInfo = 0
mi(0).mi.dwFlags = MOUSEEVENTF_MOVE or MOUSEEVENTF_ABSOLUTE
' Often *without* MOUSEEVENTF_VIRTUALDESK for single‑monitor games
SendInput(1, @mi(0), sizeof(INPUT_))
```

Key points:

- Use the same `GetSystemMetrics(SM_CXSCREEN/SM_CYSCREEN)` pair when computing the 0–65535 transform.
- Avoid mixing client coordinates (`curscreenw/curscreenh`) with this transform; that mismatch is a common cause of wrong click locations and jumps.[^2_4]


## About `spritesetcursorpos` vs `SetCursorPos`

Given the above:

- The fact that `print x, y` shows sensible values just means your logic and `GetCursorPos` are fine; the problem is further down at “how does this get injected into the system/game”.
- For desktop and for many older 2D games, `SetCursorPos` is often more predictable than `SendInput` absolute coordinates; it sets the cursor in screen pixels directly.[^2_3]
- For the titles that misbehave, try:
    - First: switch them to the *relative* `SendInput` approach, ignore absolute.
    - Only if you truly need precise clicking in menus and relative fails, go back to absolute but ensure you are using screen coordinates and desktop size in the transform, not the client area.


## Summary of what to change in your code

- Keep your `axis()` acceleration logic and clamping; that part looks fine.
- For problematic games, **do not call** `spritesetcursorpos` and do not send `MOUSEEVENTF_ABSOLUTE`; instead, send `MOUSEEVENTF_MOVE` with small deltas derived from the stick.
- Where you *do* use absolute, make sure the coordinates you pass into `spritesetcursorpos` are in desktop pixel space, and scale only against `SM_CXSCREEN` / `SM_CYSCREEN`, not the client rect width/height.

That should eliminate the warping while keeping the behavior that already works in the better‑behaved games.
<span style="display:none">[^2_10][^2_5][^2_6][^2_7][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://github.com/nut-tree/libnut/issues/26

[^2_2]: https://stackoverflow.com/questions/31621712/sendinput-mouse-movement-simulation

[^2_3]: https://www.daniweb.com/programming/software-development/threads/165261/mouse-move

[^2_4]: https://cplusplus.com/forum/general/101920/

[^2_5]: https://learn.microsoft.com/en-us/answers/questions/255509/send-mouse-wheel-click-properly-(sendinput-mouseev

[^2_6]: https://www.freebasic.net/forum/viewtopic.php?t=24728

[^2_7]: https://www.freebasic.net/forum/viewtopic.php?t=32310

[^2_8]: https://www.freebasic.net/forum/viewtopic.php?t=21361

[^2_9]: https://www.freebasic.net/forum/viewtopic.php?p=90241

[^2_10]: https://freebasic.net/forum/viewtopic.php?t=19532


---

# 'Compute per‑frame deltas from the joystick and send only relative moves:' ok ... but that's going to be quite a thing this is used to translate the axis ... :     ' gamepad axis handeld by sdl can deal with xinput / dinput toggle

    lsx = lerp(0, SDL_GameControllerGetAxis(controller, SDL_CONTROLLER_AXIS_LEFTX),  0.000032767f)
    lsy = lerp(0, SDL_GameControllerGetAxis(controller, SDL_CONTROLLER_AXIS_LEFTY),  0.000032767f)
    rsx = lerp(0, SDL_GameControllerGetAxis(controller, SDL_CONTROLLER_AXIS_RIGHTX), 0.000032767f)
    rsy = lerp(0, SDL_GameControllerGetAxis(controller, SDL_CONTROLLER_AXIS_RIGHTY), 0.000032767f)
    ' start polling left and right stick if axis value is larger than sdl deadzone
    if rsx * rsx + rsy * rsy > axis2mouse.deadzone or lsx * lsx + lsy * lsy > axis2mouse.deadzone then
        ' get deadzone per axis
        ' lstick_left_2keyaw
        gpmapaxis2key.axisdir(1) = iif (lsx < -ax2mdzk, true, false)
        ' lstick_right_2key
        gpmapaxis2key.axisdir(2) = iif (lsx >  ax2mdzk, true, false)
        '  lstick_up_2key
        gpmapaxis2key.axisdir(3) = iif (lsy < -ax2mdzk, true, false)
        ' lstick_down_2key
        gpmapaxis2key.axisdir(4) = iif (lsy >  ax2mdzk, true, false)
        ' rstick_left_2key
        gpmapaxis2key.axisdir(5) = iif (rsx < -ax2mdzk, true, false)
        ' rstick_right_2key
        gpmapaxis2key.axisdir(6) = iif (rsx >  ax2mdzk, true, false)
        ' rstick_up_2key
        gpmapaxis2key.axisdir(7) = iif (rsy < -ax2mdzk, true, false)
        ' rstick_down_2key
        gpmapaxis2key.axisdir(8) = iif (rsy >  ax2mdzk, true, false)
        
        ' left axis mapped to mouse pointer or keys
        if gpmap.axl2mouse then
            axis(axis2mouse, lsx, lsy, "left")
        else
            ' lstick_left_2key
            lsx = axis2key(1, lsx, gpmapaxis2key)
            ' lstick_right_2key
            lsx = axis2key(2, lsx, gpmapaxis2key)
            '  lstick_up_2key
            lsy = axis2key(3, lsy, gpmapaxis2key)
            ' lstick_down_2key
            lsy = axis2key(4, lsy, gpmapaxis2key)
        end if
    
        ' right axis mapped to mouse pointer or keys
        if gpmap.axr2mouse then
            axis(axis2mouse, rsx, rsy, "right")
        else
            ' rstick_left_2key
            rsx = axis2key(5, rsx, gpmapaxis2key)
            ' rstick_right_2key
            rsx = axis2key(6, rsx, gpmapaxis2key)
            ' rstick_up_2key
            rsy = axis2key(7, rsy, gpmapaxis2key)
            ' rstick_down_2key
            rsy = axis2key(8, rsy, gpmapaxis2key)
        end if
    end if
    ' reset acceleration
    if rsx * rsx + rsy * rsy < axis2mouse.deadzone then
        axis2mouse.mouseaccrx = 0
        axis2mouse.mouseaccry = 0
    end if
    if lsx * lsx + lsy * lsy < axis2mouse.deadzone then
        axis2mouse.mouseacclx = 0
        axis2mouse.mouseaccly = 0
    end if
    You already have almost everything needed for relative movement; only the last step (actually sending deltas instead of an absolute cursor) has to change. The SDL axis handling and your `axis()` function can stay nearly as‑is.[^3_3][^3_4]

## What you already have

- `lsx, lsy, rsx, rsy` are normalized stick values (roughly $-1..1$) from `SDL_GameControllerGetAxis` and your `lerp` scale.[^3_4][^3_3]
- `axis(axis2mouse, axisx, axisy, "left"/"right")` takes one of those and produces `axis2mouse.vpoint.x/y` plus acceleration, clamping, etc.
- At the end of `axis()` you either:
    - Use `SetCursorPos` (screen‑relative, absolute), or
    - Use `spritesetcursorpos`, which converts to 0–65535 and calls `SendInput` with `MOUSEEVENTF_ABSOLUTE`.

The proposal is: **keep all the SDL and `axis()` logic, but, for problem games, stop using absolute positioning and send only small deltas.**

## Minimal change: add a “relative mode”

Add a flag (config option) that says whether to drive the OS cursor absolutely (your current way) or relatively. Then:

1. **Keep computing `axis2mouse.vpoint` as you do now** for acceleration/feel so you don’t have to redesign that math.
2. **Derive a delta from the stick and send it as relative movement**, ignoring `vpoint` when actually talking to the system.

For example, inside `axis()` you could do something like this when using relative mode:

```basic
' axisx, axisy are your lsx/lsy or rsx/rsy in [-1,1]
dim sens as single = 8.0  ' tune per game
dim dx as long = CLng(axisx * sens)
dim dy as long = CLng(axisy * sens)

if dx <> 0 or dy <> 0 then
    dim mi(0) as INPUT_
    mi(0).type           = INPUT_MOUSE
    mi(0).mi.dx          = dx
    mi(0).mi.dy          = dy
    mi(0).mi.mouseData   = 0
    mi(0).mi.time        = 0
    mi(0).mi.dwExtraInfo = 0
    mi(0).mi.dwFlags     = MOUSEEVENTF_MOVE   ' **no ABSOLUTE, no VIRTUALDESK**
    SendInput(1, @mi(0), sizeof(INPUT_))
end if
```

In this mode:

- Do **not** call `SetCursorPos` or `spritesetcursorpos` at all for these games.
- Let the game’s own mouse handling interpret the relative deltas; that avoids warping in titles that recenter the cursor or work in a hidden “raw” mode.[^3_5][^3_6]

You can still maintain `axis2mouse.vpoint` and the acceleration values for consistency with your existing code, but they no longer need to be mapped to screen coordinates for these specific games.

## How to select which path to use

Given you already have config like `gpmap.axl2mouse` / `gpmap.axr2mouse`:

- Add something like `axis2mouse.useRelative = TRUE/FALSE`.
- In `axis()`:

```basic
if axis2mouse.useRelative then
    ' send relative deltas (snippet above)
else
    ' your current code:
    if axis2mouse.spritecursor then
        spritesetcursorpos(axis2mouse.vpoint.x, axis2mouse.vpoint.y)
    else
        SetCursorPos(axis2mouse.vpoint.x, axis2mouse.vpoint.y)
    end if
end if
```

Then, for the “nice” adventure games that respect the OS cursor, leave `useRelative = FALSE` and keep the old behavior. For the games where the cursor jumps or warps, enable `useRelative = TRUE` so only relative motion is injected.[^3_11][^3_12]

## Why this avoids a big rewrite

- SDL axis reading and deadzone handling remain unchanged.
- Your stick‑to‑velocity/acceleration math in `axis()` remains unchanged.
- Only the **final injection step** switches between absolute and relative.

This keeps your existing mapping logic but sidesteps the fragile part (absolute 0–65535 mapping) for the troublesome games.
<span style="display:none">[^3_1][^3_10][^3_2][^3_7][^3_8][^3_9]</span>

<div align="center">⁂</div>

[^3_1]: https://wiki.libsdl.org/SDL3/SDL_GamepadBinding

[^3_2]: https://github.com/TheJosh/SDL_input

[^3_3]: https://ncot.uk/blog-posts/easier-game-controller-input-in-sdl-with-sdl_gamecontroller/

[^3_4]: https://www.reddit.com/r/sdl/comments/1i43xqk/multiple_joysticks/

[^3_5]: https://wiki.libsdl.org/SDL3/EnvironmentVariables

[^3_6]: https://www.gamedev.net/forums/topic/687451-continous-movement-for-sdl-2-joysticks/

[^3_7]: https://www.youtube.com/watch?v=ptJLU0w0ZwU

[^3_8]: https://discourse.libsdl.org/t/how-to-make-a-robust-input-system-for-a-game/53975

[^3_9]: https://stackoverflow.com/questions/50022316/what-is-sdl-joystick-and-what-is-sdl-gamecontroller-what-are-the-relationships

[^3_10]: https://github.com/nsensfel/relabsd

[^3_11]: https://github.com/nut-tree/libnut/issues/26

[^3_12]: https://stackoverflow.com/questions/31621712/sendinput-mouse-movement-simulation


---

# Gob smacked .... wow .. it works plus love the axis2mouse.useRelative (useRelative as attribute) I'll get into that in a mo but many kudos for this.

Great to hear the relative mode fixed the warping—many older games just can't handle absolute `SendInput` packets reliably.[^4_1][^4_2]

## Implementing `useRelative` as attribute

In FreeBASIC, add it to your `mouseinit` UDT like this:

```basic
type mouseinit
    ' ... your existing fields ...
    useRelative as boolean
end type
```

Then in `axis()`:

```basic
' ... your acceleration/clamping logic stays the same ...

if axis2mouse.useRelative then
    ' Relative mode: send deltas directly from stick input
    dim sens as single = 8.0  ' tune via config per game/stick
    dim dx as long = CLng(scaledX * sens)  ' reuse your scaledX/Y
    dim dy as long = CLng(scaledY * sens)
    
    if dx <> 0 or dy <> 0 then
        dim mi(0) as INPUT_
        mi(0).type = INPUT_MOUSE
        mi(0).mi.dx = dx
        mi(0).mi.dy = dy
        mi(0).mi.dwFlags = MOUSEEVENTF_MOVE
        mi(0).mi.mouseData = 0
        mi(0).mi.time = 0
        mi(0).mi.dwExtraInfo = 0
        SendInput(1, @mi(0), sizeof(INPUT_))
    end if
else
    ' Absolute mode: your existing code
    if axis2mouse.spritecursor then
        spritesetcursorpos(axis2mouse.vpoint.x, axis2mouse.vpoint.y)
    else
        SetCursorPos(axis2mouse.vpoint.x, axis2mouse.vpoint.y)
    end if
end if
```


## Quick tuning tips

- **Sensitivity**: Start with `sens = 6.0` to `12.0`; higher feels faster but twitchier. Make it per-stick (`leftSens`, `rightSens`) or even per-game via config.[^4_3]
- **Per-game switching**: Detect game window title with `GetWindowText(hWnd)` and set `axis2mouse.useRelative` based on known-good/bad titles, or add a hotkey/config toggle.
- **Hybrid mode**: For some games, use relative for right stick (look/camera) and absolute for left stick (menu navigation).

This gives you the best of both worlds without breaking what already works.[^4_4]

<div align="center">⁂</div>

[^4_1]: https://github.com/nut-tree/libnut/issues/26

[^4_2]: https://stackoverflow.com/questions/31621712/sendinput-mouse-movement-simulation

[^4_3]: https://ncot.uk/blog-posts/easier-game-controller-input-in-sdl-with-sdl_gamecontroller/

[^4_4]: https://www.gamedev.net/forums/topic/687451-continous-movement-for-sdl-2-joysticks/


---

# Nice I have exteralized some stuff already (a map either by game or genre) snippet : [general]

mapversion          = 1.1
settimerduration    = 2.5
settimeron          = btback
' set deadzone gamepad [0 - 256] default 128
deadzone            = 64
acceleratex         = 14.5
acceleratey         = 12.5
' set to true alternative method of moving mousepointer
' use for some older games by nobilis, kheops, etc default false
spritecursor        = false
: I could / probably will add the sens there excellent tip. So speaking of the bad titles they also do not respond to : function mouseclick(byref axis2mouse as mouseinit, button as string, press as boolean) as boolean

    select case button
        case "mouse left"
            if press then
                mouse_event(MOUSEEVENTF_LEFTDOWN, axis2mouse.vpoint.x, axis2mouse.vpoint.y, 0, 0)
            else
                mouse_event(MOUSEEVENTF_LEFTUP, axis2mouse.vpoint.x, axis2mouse.vpoint.y, 0, 0)
            end if
        case "mouse right"
            if press then
                mouse_event(MOUSEEVENTF_RIGHTDOWN, axis2mouse.vpoint.x, axis2mouse.vpoint.y, 0, 0)
            else
                mouse_event(MOUSEEVENTF_RIGHTUP, axis2mouse.vpoint.x, axis2mouse.vpoint.y, 0, 0)
            end if
    end select
    
    return true    
    end function
: most likely mouse_event ... so I guess an other sendinput could do the trick but then for the left / right mouse click ?

Yes, switching from `mouse_event` to `SendInput` for buttons is the right move, especially for those “difficult” titles. `mouse_event` is legacy and some games (or input wrappers/overlays) only hook the newer input path used by `SendInput`.[^5_1][^5_2]

## Basic mouse button via SendInput

You can keep your `mouseclick` API and just change the implementation to build an `INPUT_` with mouse flags:

```basic
function mouseclick(byref axis2mouse as mouseinit, button as string, press as boolean) as boolean
    dim mi(0) as INPUT_

    mi(0).type           = INPUT_MOUSE
    mi(0).mi.dx          = 0          ' 0 for button events
    mi(0).mi.dy          = 0
    mi(0).mi.mouseData   = 0
    mi(0).mi.time        = 0
    mi(0).mi.dwExtraInfo = 0

    select case button
        case "mouse left"
            if press then
                mi(0).mi.dwFlags = MOUSEEVENTF_LEFTDOWN
            else
                mi(0).mi.dwFlags = MOUSEEVENTF_LEFTUP
            end if

        case "mouse right"
            if press then
                mi(0).mi.dwFlags = MOUSEEVENTF_RIGHTDOWN
            else
                mi(0).mi.dwFlags = MOUSEEVENTF_RIGHTUP
            end if

        ' optional: middle, X1, X2, wheel later
    end select

    if mi(0).mi.dwFlags <> 0 then
        SendInput(1, @mi(0), sizeof(INPUT_))
    end if

    return TRUE
end function
```

Important details:

- For pure button events you normally leave `dx`/`dy` at 0 and **do not** set `MOUSEEVENTF_MOVE`. The click happens at the current OS cursor position, which your movement code has already positioned.[^5_2]
- No absolute/relative flags are needed; only the button down/up flags.


## Ensuring the click lands where you expect

For the “bad” titles that require relative movement:

- Move the cursor using relative `SendInput` (as discussed) so the game’s internal mouse state matches the visible cursor.
- Then send button events **without** changing position (no move flags, `dx=dy=0`). This ensures the game sees “click at current position” in its own coordinate system, instead of at some absolute position it doesn’t track correctly.[^5_1]

If you want maximum safety, you can still keep `axis2mouse.vpoint` in sync by occasionally calling `SetCursorPos` in absolute-friendly games, but for the picky ones, rely entirely on relative movement + button events.

## Config idea: per‑game click method

Just like `spritecursor` and future `sens`, you can add something like:

```ini
use_sendinput_buttons = true
```

Then:

- Old/default: `mouse_event` for buttons (for compatibility if ever needed).
- Problem titles: enable `use_sendinput_buttons` and `useRelative` together so both movement and clicks go through `SendInput`.

That combination tends to hit the broadest set of older engines that otherwise ignore or mishandle legacy mouse injection.[^5_2][^5_1]

<div align="center">⁂</div>

[^5_1]: https://github.com/nut-tree/libnut/issues/26

[^5_2]: https://stackoverflow.com/questions/31621712/sendinput-mouse-movement-simulation


---

# Excellent just checked it the finicky / difficult titles now also respond to the right / left mouse click again kudos. Note thanks for the config idea I'll keep it in mind. Just for clarity whats so different about mouse_event(MOUSEEVENTF_LEFTDOWN, axis2mouse.vpoint.x, axis2mouse.vpoint.y, 0, 0) compared to                 mi(0).mi.dwFlags = MOUSEEVENTF_LEFTDOWN

via sendinput it's the same event ...

The events `mouse_event(MOUSEEVENTF_LEFTDOWN, x, y, 0, 0)` and `SendInput` with `mi(0).mi.dwFlags = MOUSEEVENTF_LEFTDOWN` look similar but differ importantly under the hood, affecting how games receive and interpret them.

## Differences between `mouse_event` and `SendInput`

1. **API age and support**
    - `mouse_event` is an older, legacy API dating back to Windows 95, intended for synthesizing mouse input in a simple way.
    - `SendInput` is a newer, more robust API introduced in Windows 2000 that sends input events at a lower level and is favored by modern applications and games.[^6_1][^6_2]
2. **Driver and game hooking**
    - Many newer games and middleware hook directly into the `SendInput` stream for better performance and security, ignoring or handling `mouse_event` events differently or not at all.
    - Some anti-cheat systems also monitor `SendInput` but may block or filter `mouse_event`, or vice versa, meaning one might work where the other does not.
3. **Coordinate behavior**
    - `mouse_event` takes absolute coordinates `(x, y)` parameters, which historically set the mouse position as part of the event; however, many games ignore these parameters for button events and instead use the OS cursor position.
    - `SendInput` mouse events for button presses ignore the `dx`, `dy` fields when no move flag is set; thus, the click happens at the current cursor position. This is more consistent and reliable across games.
4. **Thread and event timing**
    - `SendInput` batches events and integrates better with Windows input queues, reducing risks of event loss, timing issues, or priority inversion that can happen with `mouse_event`.

## Practical effect

Because some older games expect event injection via `SendInput` to detect clicks properly, using `mouse_event` can cause missed or unrecognized clicks, especially when combined with relative mouse movement simulation. Conversely, some very old titles might only respond to `mouse_event`.

To summarize:


| Aspect | mouse_event | SendInput |
| :-- | :-- | :-- |
| Age | Legacy (Windows 95 era) | Modern (Windows 2000+) |
| Coordinates for button events | Takes x, y but often ignored for clicks | dx, dy ignored if no move flag |
| Game and driver hooking | Less widely supported today | Widely supported, used by modern games |
| Input queue integration | Older input injection method | Better synchronization and batching |
| Reliability in games | Sometimes unreliable in new games | More reliable in most games |

This explains why switching to `SendInput` fixed your issues with finicky games recognizing clicks while keeping the same visible mouse button behavior.[^6_2][^6_1]

<div align="center">⁂</div>

[^6_1]: https://github.com/nut-tree/libnut/issues/26

[^6_2]: https://stackoverflow.com/questions/31621712/sendinput-mouse-movement-simulation


---

# Ah ... mouse_event takes absolute coordinates (x, y) parameters, and I am passing coordinates to the wrong location,  that makes sense because if mouse_event is legacy then in this case it would be better suited for these older games I am having issues with ... also we are using     mi(0).mi.dx          = 0          ' 0 for button events

    mi(0).mi.dy          = 0
    which probably helps sendinput to work ... well at least I think whats happening .. microsoft lear : 'The dx and dy parameters contain normalized absolute coordinates. If not set, those parameters contain relative data: the change in position since the last reported position.' : [https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-mouse_event](https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-mouse_event) : ...

Exactly. The `mouse_event` function uses the `dx` and `dy` parameters differently depending on the flags, and because it is legacy, games often expect these values as absolute screen coordinates when moving, and still expect click events based on the current cursor position. Passing inaccurate or out-of-bounds coordinates there can cause unexpected behavior.

In contrast, `SendInput` separates movement from button events clearer:

- For relative or absolute movement, `dx` and `dy` have defined meanings and must be set properly.
- For button events (mouse down/up), `dx` and `dy` are typically zero because the click occurs at the current cursor position rather than moving the cursor.

Microsoft’s documentation clarifies this distinction: `mouse_event`’s `dx` and `dy` are either absolute or relative based on the flags, while `SendInput` uses them strictly per event type. Passing zero for `dx`/`dy` in button events for `SendInput` aligns with expected behavior and ensures the click triggers at wherever the cursor currently is.

This explains why:

- For `mouse_event`, passing `axis2mouse.vpoint.x` and `.y` might cause clicks to register incorrectly or unpredictably in games that expect absolute coordinates but may treat them differently.
- For `SendInput`, zeroing `dx` and `dy` on button events is correct, as position is already set or moved separately.

So your use of zero `dx/dy` in `SendInput` ensures reliable clicks relative to the current cursor position, matching how modern games process these events.[^7_1]

<div align="center">⁂</div>

[^7_1]: https://stackoverflow.com/questions/31621712/sendinput-mouse-movement-simulation


---

# Ok so effectively I could drop mouse_event and in stead use the sendinput method and have a pretty broad coverage game wise?

Yes, using only `SendInput` for both mouse movement and button clicks will give you broader and more reliable compatibility across a wide variety of games, including both modern and older titles. `SendInput` is the preferred method in Windows for synthesizing input because it integrates better with the system and is recognized by more games and input hooks than the older `mouse_event` API.

Key reasons to prefer `SendInput` exclusively:

- More robust and consistent input injection recognized by most games and applications, including tricky older titles.
- Clear separation of mouse movement and button events handling, reducing ambiguities in how coordinates and flags are interpreted.
- Better support for relative and absolute movement modes, allowing you to customize for different game behaviors without switching APIs.
- Simpler maintenance since you avoid mixing legacy and modern input methods in your codebase.[^8_1][^8_2]

So consolidating to just `SendInput` for all mouse input (movement and buttons) while implementing the relative/absolute switch for movement as you already did is an excellent approach. This should maximize game compatibility and simplify your input handling long-term.

<div align="center">⁂</div>

[^8_1]: https://github.com/nut-tree/libnut/issues/26

[^8_2]: https://stackoverflow.com/questions/31621712/sendinput-mouse-movement-simulation


---

# Well good advice heeded. Not that it would be a killer reduction for movement it's just one line for 'regular' games :        SetCursorPos(axis2mouse.vpoint.x, axis2mouse.vpoint.y)

but he ...

If your user base or target includes mostly “regular” games that handle the OS cursor normally, keeping `SetCursorPos` for absolute cursor positioning remains a very simple and effective solution. It directly sets the cursor position in screen coordinates without needing complicated translation to 0–65535, and those games respond well to it.

The cost of keeping `SetCursorPos` alongside your relative `SendInput` approach for problem titles is minimal—just an if-condition or config flag to decide which method to call. This dual approach gives you:

- Simple, precise absolute positioning for well-behaved games.
- Flexible, robust relative movement plus `SendInput` clicks for finicky or legacy-intolerant games.

So yes, keeping `SetCursorPos` as a fallback or default for “regular” games is sensible and keeps things straightforward. You gain broad compatibility with minimal overhead or complexity added to your input path.[^9_1][^9_2]

<div align="center">⁂</div>

[^9_1]: https://cplusplus.com/forum/general/101920/

[^9_2]: https://www.daniweb.com/programming/software-development/threads/165261/mouse-move


---

# Hmmm yep I will probably do that, all though gamers can mope a lot about latency so keeping haptic input routines tight is one of those extra considerations to keep in account ...

Absolutely, latency is a critical factor in input responsiveness, especially for gamers sensitive to even small delays. Using `SetCursorPos` is typically very fast and straightforward because it directly updates the OS cursor position, minimizing overhead. However, `SendInput`, while slightly more layered, is designed for low-latency input injection and is generally performant enough for real-time game input including relative movement and clicks.

Key considerations to keep haptic input tight and low latency:

- **Minimize processing overhead** in your axis scaling, acceleration, and event generation routines.
- **Batch or throttle input events** efficiently to avoid flooding the input queue while keeping responsiveness high.
- **Use high-priority threads or timers** for input polling and injection if possible.
- **Avoid unnecessary conversions or API calls** in the hot path. For example, only call `SetCursorPos` or `SendInput` when there is meaningful movement or button state change.
- Keep `SendInput` usage consistent and tested, as it’s optimized by Windows for smooth input simulation.[^10_1][^10_2]

Balancing all this with your dual absolute/relative approach is a solid strategy—it gives you both compatibility and the ability to fine-tune responsiveness per game or genre.

If you want, I can help with tips or code snippets on how to optimize input routines further to reduce latency.

<div align="center">⁂</div>

[^10_1]: https://github.com/nut-tree/libnut/issues/26

[^10_2]: https://stackoverflow.com/questions/31621712/sendinput-mouse-movement-simulation


---

# Thank you for offering but I am quite happy with what we have achieved in this session most excellent indeed. So many thanks for know I'll drop by after I have tided up the code and added userelative neatly in the configuration files.

You're welcome! Glad the relative mode and `SendInput` fixes resolved the erratic movement and click issues across those tricky games. Looking forward to hearing how the `useRelative` config integration works out. Happy coding![^11_1][^11_2]

<div align="center">⁂</div>

[^11_1]: https://github.com/nut-tree/libnut/issues/26

[^11_2]: https://stackoverflow.com/questions/31621712/sendinput-mouse-movement-simulation

