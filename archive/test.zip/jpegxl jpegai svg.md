<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# What is this about? [https://jpeg.org/jpegai/index.html](https://jpeg.org/jpegai/index.html) and [https://www.reddit.com/r/jpegxl/comments/1pa99g1/jpeg_ai/](https://www.reddit.com/r/jpegxl/comments/1pa99g1/jpeg_ai/) ...

Short answer: The JPEG AI pages describe an ongoing effort by the JPEG Committee to develop a learning-based image compression standard (JPEG AI) aimed at higher compression efficiency and usefulness for image processing tasks, with support for 8- and 10-bit depth and royalty-free baseline, alongside related discussions in the JPEG ecosystem and community forums such as JPEG XL discussions on Reddit.

What the JPEG AI page covers

- Purpose: Aiming for a single-stream, compact compressed domain representation that improves compression efficiency and supports downstream processing for machine learning tasks, while remaining royalty-free at the baseline. This is stated in the JPEG AI overview, which emphasizes both visual fidelity and applicability to processing tasks in areas like cloud storage, surveillance, and autonomous systems.[^1_2][^1_4]
- scope and requirements: The page highlights targets such as 8- and 10-bit depth, efficient handling of text/graphics, progressive decoding, and hardware/software implementation considerations.[^1_4][^1_2]
- status and context: JPEG AI is positioned among other JPEG standard activities (e.g., JPEG XL, JPEG XS) as part of the broader JPEG ecosystem, indicating ongoing work and a roadmap rather than a finalized, universally adopted standard at this moment.[^1_10][^1_4]

What the Reddit discussions add

- Community interest and experiments: Reddit threads in r/jpegxl discuss related topics such as JPEG XL, JPEG-LI (JPEG LI being a proposed project that borrows ideas from JXL), and comparisons of modern codecs, including real-world tests and white papers. These threads illustrate how enthusiasts and developers are evaluating new codecs and their practical implications.[^1_3][^1_5][^1_8]
- Clarifications and questions: Posts often pose questions about compatibility with browsers (e.g., Chrome support), performance comparisons, and how new JPEG iterations fit into existing tooling and ecosystems. While Reddit is informal, it reflects real-world considerations and user curiosity.[^1_5][^1_11]

Notes on the attached JPEG AI page and related materials

- The official JPEG AI page emphasizes a royalty-free baseline and the application domains where improved compression could drive storage and processing efficiency, while outlining compatibility considerations for typical imaging pipelines. This aligns with the JPEG committee’s broader aim of advancing image coding standards that balance quality, efficiency, and practical deployment.[^1_2][^1_4]
- The Reddit discussions provide context on how JPEG AI and related formats like JPEG XL are perceived in practice, including hardware/browser support questions and potential adoption pathways. These discussions can be helpful to gauge ecosystem readiness and compare between different JPEG-family projects.[^1_3][^1_5]

If you’d like, I can synthesize a side-by-side summary of JPEG AI versus JPEG XL and other JPEG family projects, or pull in recent updates from the JPEG committee’s site to verify the latest status. Please specify which angles you’re most interested in (e.g., technical differences, deployment status, browser support, or industry adoption).
<span style="display:none">[^1_1][^1_6][^1_7][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://jpeg.org/jpegai/index.html

[^1_2]: https://www.reddit.com/r/jpegxl/comments/1bux8on/introducing_jpegli_a_new_jpeg_coding_library/

[^1_3]: https://www.reddit.com/r/jpegxl/comments/l6rv3u/updated_white_paper_on_jpeg_xl/

[^1_4]: https://jpeg.org/jpegai/software.html

[^1_5]: https://www.reddit.com/r/jpegxl/comments/yhuvvw/google_outlines_why_they_are_removing_jpegxl/

[^1_6]: https://jpeg.org/jpegai/

[^1_7]: https://www.reddit.com/r/jpegxl/

[^1_8]: https://www.reddit.com/r/jpegxl/comments/1bwjggv/rough_tests_of_jpegli/

[^1_9]: https://github.com/jpegai

[^1_10]: https://jpeg.org/jpegxl/

[^1_11]: https://www.reddit.com/r/jpegxl/comments/120enc7/some_questions_to_jpegli/


---

# Hmmm so this is not predicated on the notion of chucking say a 5KB prompt to the browser and then decompressing it to an image ...?

No, JPEG AI is not built around the idea of sending a tiny “prompt‑like” 5 KB text blob to the browser and then locally *generating* an image from it, the way an image diffusion model might work. Instead, it is still fundamentally an **image codec**: you transmit a compressed bitstream representing a specific image, and a decoder reconstructs that image, just with a learned (neural) codec rather than classic DCT-style JPEG.[^2_3][^2_6]

## What JPEG AI Actually Does

- JPEG AI defines a learning‑based image compression standard that produces a single compressed bitstream per image, which the decoder turns back into pixels, similar in workflow to JPEG, JPEG XL, AVIF, etc.[^2_6][^2_8][^2_3]
- The goals are: much higher compression at the same visual quality and a bitstream that is also useful directly for machine‑vision and image‑processing tasks, plus features like 8/10‑bit support and progressive decoding.[^2_3][^2_6]


## Why It’s Not a “Prompt → Image” Scheme

- A 5 KB text prompt is an abstract description; a generative model would have to synthesize an image from scratch, which is not what JPEG AI specifies. JPEG AI assumes you already have a concrete source image and want a compact, decodable representation of *that* image.[^2_6][^2_3]
- The bitstream in JPEG AI is a compressed representation of pixel data (via neural transforms), not a human-readable prompt; decoding requires the standard JPEG AI decoder and model weights, not a general text‑to‑image generator.[^2_2][^2_6]


## What You *Could* Do in a Browser

- In principle, a browser could ship a JPEG AI decoder (likely using WebAssembly and GPU/ML acceleration) and decode JPEG AI bitstreams much like AVIF today; the payload would still be an image bitstream, not a natural-language prompt.[^2_5][^2_2]
- The standard also targets “compressed‑domain” operations (e.g., running vision models partly on the compressed representation), which might reduce client‑side cost for some tasks, but again that is still image‑codec‑style processing, not text‑prompt‑driven generation.[^2_3][^2_6]

If you’re interested in that “5 KB prompt → image” paradigm, that lives more in the realm of lightweight generative models or specialized latent‑code/image‑prior schemes, which is a different design space than what JPEG AI standardizes.
<span style="display:none">[^2_1][^2_4][^2_7][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://tech.slashdot.org/story/24/04/04/2227238/google-rolls-out-new-jpegli-jpeg-coding-library

[^2_2]: https://deepwiki.com/akarabutov/jpeg-ai-reference-software/2-getting-started

[^2_3]: https://jpeg.org/jpegai/

[^2_4]: https://cdn.standards.iteh.ai/samples/81643/9f768541ee104a1bafb52e3366a90860/ISO-IEC-PRF-19566-8.pdf

[^2_5]: https://streaminglearningcenter.com/codecs/jpeg-ai-is-coming-what-you-need-to-know.html

[^2_6]: https://www.itu.int/en/ITU-T/Workshops-and-Seminars/2022/0118/Documents/Joao_Ascenso.pdf

[^2_7]: https://www.youtube.com/watch?v=gA9s9CUHMDc

[^2_8]: https://jpeg.org/jpegai/documentation.html

[^2_9]: https://c2pa.org/specifications/specifications/2.2/guidance/Guidance.html


---

# Hmm I see. Bit of an uphill battle it took jpeg xl quite some time to gain traction (supposedly better then webp) before making a 'come back' in 2025 ... thank god ... but still needs to implemented in firefox and pdf ... how does jpeg AI compare to jpeg XL ?

JPEG AI and JPEG XL solve related but different problems: JPEG XL is a conventional (non‑neural) next‑gen image codec aimed at being a practical JPEG/WebP replacement, while JPEG AI is a neural, “AI‑native” codec that also targets machine‑vision workflows in addition to human viewing.[^3_5][^3_9]

## Design goal

- **JPEG XL**: General‑purpose successor to classic JPEG, with emphasis on high quality at good compression, easy migration from existing JPEGs, and broad imaging features (HDR, very high bit depths, many channels, etc.).[^3_1][^3_2]
- **JPEG AI**: Learning‑based codec whose core aim is maximum compression efficiency plus a bitstream that is directly useful for image processing and computer‑vision tasks (compressed‑domain ML), with a royalty‑free baseline.[^3_9][^3_5]


## Compression and quality

- JPEG XL already beats legacy JPEG by a large margin and is competitive with AVIF, especially for high‑quality and lossless use; it also supports lossless transcoding of existing JPEGs with further size reduction.[^3_3][^3_1]
- JPEG AI is reported by the JPEG committee to achieve “superior compression efficiency” versus other state‑of‑the‑art codecs at equivalent visual quality, thanks to its end‑to‑end learned models.[^3_5][^3_9]


## Features and workflow

- JPEG XL offers a rich feature set: up to 32‑bit per channel, many channels, HDR, wide gamut, progressive decoding, animation, alpha, large images, and JPEG‑compatible lossless wrapping, making it attractive for archival and pro workflows.[^3_2][^3_1][^3_3]
- JPEG AI emphasizes implementation‑friendly neural encoding/decoding and support for operating directly on the compressed representation for tasks like classification or detection, reducing the need to fully decode to pixels before running ML.[^3_9][^3_5]


## Maturity and adoption

- JPEG XL is standardized and has real‑world usage, but Web adoption is still patchy: Safari has native support, Chromium has partial/extension‑based support, and other environments are catching up, so it’s strong for offline/archival but not yet a universal web default.[^3_4][^3_1][^3_3]
- JPEG AI only recently reached International Standard status, so it is earlier in its adoption curve; the spec and reference software exist, but widespread browser, PDF, and toolchain integration will likely lag behind JPEG XL’s current state.[^3_7][^3_5][^3_9]


## Side‑by‑side overview

| Aspect | JPEG XL | JPEG AI |
| :-- | :-- | :-- |
| Core tech | Conventional transform/entropy codec | End‑to‑end neural image codec |
| Main goal | Practical JPEG/WebP successor for web, archival, pro imaging | Max compression + compressed‑domain ML for vision tasks |
| Lossless JPEG transcoding | Yes, without re‑encoding | Not a core feature |
| Bit depth \& HDR | Up to 32‑bit, wide gamut, HDR | 8‑ and 10‑bit primary targets, HDR via learned coding |
| Progressive decoding | Yes | Supported, but architecture centered on neural models |
| ML/vision focus | Primarily human viewing, plus general imaging | Joint optimization for human viewing and computer vision on compressed data |
| Adoption (2025) | Growing but still limited on the open web; strong niche/archival interest | Newly standardized; adoption just starting in research and specialized pipelines |

In practice: if the interest is “better JPEG/WebP with real‑world deployability,” JPEG XL is currently closer to that goal; if the interest is future pipelines where codecs and vision models are tightly integrated, JPEG AI is the more forward‑looking, but also more experimental, direction.[^3_1][^3_3][^3_5][^3_9]
<span style="display:none">[^3_6][^3_8]</span>

<div align="center">⁂</div>

[^3_1]: https://uploadcare.com/blog/avif-vs-jpeg-comparison/

[^3_2]: https://tristanromain.com/index.php/2025/09/16/understanding-photo-file-formats-in-2025-jpeg-raw-heic-avif-webp-jpeg-xl-and-beyond/

[^3_3]: https://tonisagrista.com/blog/2025/google-unkills-jpegxl/

[^3_4]: https://pixelphant.com/blog/best-image-file-format-type

[^3_5]: https://jpeg.org/items/20250219_press.html

[^3_6]: https://www.youtube.com/watch?v=X5Tq4H4qVEc

[^3_7]: https://www.reddit.com/r/jpegxl/comments/1pa99g1/jpeg_ai/

[^3_8]: https://www.facebook.com/Cloudinary/posts/𝗧𝗵𝗲-𝗟𝗮𝘁𝗲𝘀𝘁-𝗔𝗱𝘃𝗮𝗻𝗰𝗲𝗺𝗲𝗻𝘁𝘀-𝗶𝗻-𝗝𝗣𝗘𝗚-𝗫𝗟-are-pushing-image-performance-to-new-levelsin/1128933869266460/

[^3_9]: https://eureka3d.eu/wp-content/uploads/2024/11/TalkJPEG-Ebrahimi2024_compressed.pdf


---

# Ah I see so jpeg AI is complementary to jpeg XL not agnostic ... 'JPEG AI emphasizes implementation‑friendly neural encoding/decoding and support for operating directly on the compressed representation for tasks like classification or detection, reducing the need to fully decode to pixels before running ML' that's interesting how would that work in practice ... plus 'royalty-free baseline' gets tossed around a lot what does that imply?

JPEG AI is meant to be complementary to JPEG XL in the ecosystem, and the “compressed‑domain ML” plus “royalty‑free baseline” ideas are about how the codec is structured and licensed, not about it being agnostic to other formats. The two standards solve different parts of the image/vision pipeline.[^4_1][^4_3][^4_8]

## How compressed‑domain ML works in practice

Think of JPEG AI as a neural autoencoder standardized as a codec: the encoder turns an image into a latent tensor (feature maps), then entropy‑codes that into the bitstream, and the decoder normally turns that latent back into pixels.[^4_3][^4_8]

In compressed‑domain ML, you stop *before* the final image reconstruction:

- After entropy decoding, you get the latent representation produced by the analysis network (a stack of learned feature maps). Instead of passing those features through the decoder to reconstruct RGB, you feed them into a task network (classifier, detector, etc.).[^4_8][^4_1][^4_3]
- That task network is usually a pruned or adapted version of a normal model: you cut off the early convolutional layers (which would normally extract low‑level edges/textures) because the JPEG AI latent already encodes that information. A small “bridge” block maps the latent’s channels/resolution into what the task model expects.[^4_1]
- The result: the detector/classifier operates directly on the latent, skipping reconstruction, so:
    - Less computation and memory (no full decoding, fewer layers).
    - Accuracy close to running the model on the fully decoded image, according to prototype work like compressed‑domain face detection on JPEG AI latents.[^4_1]

Concretely, in a cloud pipeline you might:

1. Store images only as JPEG AI bitstreams.[^4_3]
2. For analytics (e.g., “find all faces/plates/cars”), decode just to the latent, run detection there, and never reconstruct full images unless needed for display.[^4_3][^4_1]

That is the “joint human + machine” design JPEG AI is going for, which is not something JPEG XL was explicitly designed around.

## What “royalty‑free baseline” implies

Standards bodies often define:

- A **baseline profile**: a minimal, interoperable subset everybody should support.
- Optional tools/features on top of that baseline.

When they say the **baseline is royalty‑free**, it usually implies:

- The core tools needed to encode/decode a compliant baseline bitstream are intended to be implementable without paying per‑unit or per‑copy license fees for essential patents (or only under terms that do not require royalties).[^4_8][^4_3]
- Patent holders contributing to that baseline commit to licensing their essential claims under royalty‑free or similarly permissive terms (subject to typical conditions: defensive suspension, field of use, etc.), so:
    - Browser vendors, open‑source projects, and OSs can ship baseline JPEG AI without having to negotiate commercial patent licenses.
    - Commercial implementers can be more confident they are not suddenly hit with codec‑usage royalties for the baseline feature set.

However:

- “Royalty‑free baseline” does *not* guarantee that every possible profile/tool of JPEG AI is royalty‑free; advanced/optional tools could still involve patents that require licensing.
- It also does not eliminate all legal risk (e.g., third‑party undisclosed patents), but it is a strong signal aimed at avoiding the “HEVC problem” of fragmented, expensive licensing.[^4_5][^4_8]


## Complementary rather than overlapping

- JPEG XL: optimized as a practical, non‑neural, feature‑rich replacement for JPEG/WebP/PNG with good lossless and high‑quality photo support and smooth migration from existing JPEG content.
- JPEG AI: optimized as a neural codec where the latent doubles as a general feature space for downstream ML, with a baseline intended to be safe to widely implement from a royalty perspective.[^4_5][^4_8][^4_3]

So in a future stack you might use JPEG XL for “normal” images/documents and JPEG AI for workloads where you *also* run a lot of automated vision on the same content and want to avoid decoding overhead.
<span style="display:none">[^4_2][^4_4][^4_6][^4_7][^4_9]</span>

<div align="center">⁂</div>

[^4_1]: https://iris.unibs.it/retrieve/2901840b-4703-4ae5-aac2-becc2b2b5555/MMSP24__Compressed_domain_face_detector_.pdf

[^4_2]: https://arxiv.org/html/2512.04284v1

[^4_3]: https://jpeg.org/jpegai/

[^4_4]: https://www.emergentmind.com/topics/jpeg-ai

[^4_5]: https://datacompressionconference.org/Keynotes/DCC2024KeynoteSlides.pdf

[^4_6]: https://openaccess.thecvf.com/content/WACV2022/papers/Wang_Learning_From_the_CNN-Based_Compressed_Domain_WACV_2022_paper.pdf

[^4_7]: https://www.amazon.science/publications/deep-layers-beware-unraveling-the-surprising-benefits-of-jpeg-compression-for-image-classification-pre-processing

[^4_8]: https://www.itu.int/en/ITU-T/Workshops-and-Seminars/2022/0118/Documents/Joao_Ascenso.pdf

[^4_9]: https://www.sciencedirect.com/science/article/pii/S0167865524000503


---

# Well took me some time to absorb this ... mighty ambitious plus some things stick out a) the possible a-symmetrical relation between encoding an decoding time wise, that what is gained with decoding will likely end up if not superseded by encoding time ... b) the payload increases a latent tensor (feature maps) ... and finally the royalty thing exhibit a Unisys and LZW patent enforcement see : [https://en.wikipedia.org/wiki/GIF\#Unisys_and_LZW_patent_enforcement](https://en.wikipedia.org/wiki/GIF#Unisys_and_LZW_patent_enforcement) : but well I guess its worth pursuing ...

Those are exactly the pain points: JPEG AI buys you clever things (compressed‑domain ML, better rate–distortion) but has to fight encoder complexity, payload size, and patent anxiety, just like earlier standards.[^5_1][^5_2]

## a) Asymmetric encode vs decode

- JPEG AI explicitly supports “multiple encoder and decoder complexity‑efficiency tradeoffs” with two encoders and three decoders (6 combinations) so you can, for example, use a heavy offline encoder and a lighter decoder on clients.[^5_2]
- The committee reports BD‑rate gains of roughly 12–28% over VVC intra across a range of decoder complexities (7–216 kMAC/px), i.e., you can dial decoding cost up or down while still beating strong baselines, but encoding remains computationally heavy compared to classic JPEG/JPEG XL.[^5_3][^5_2]

So yes: in many deployments JPEG AI will likely be “encode in the cloud / offline, decode on relatively beefy clients,” not “tiny phone encodes everything on the fly.” The hope is that decode (and especially compressed‑domain inference) is cheap enough to justify a slower encoder.

## b) Payload and latent tensors

- The bitstream still ends up as a compressed representation of the latent, not the raw tensor; the standard’s aim is improved compression efficiency versus existing intra codecs at the *same* quality, not a bigger payload.[^5_4][^5_2]
- Internally, however, you do have a richer latent space than, say, DCT coefficients, which makes it easier to reuse those features for tasks like classification or detection without reconstructing full images. That “extra structure” is in the latent representation, not necessarily in file size.[^5_5][^5_4]

Real‑world outcomes will look like any other codec: some content will compress better than JPEG XL/AVIF, some worse, and some tools will produce larger files than others because of encoder tuning, just like you see wildly different JPEG XL sizes from different apps today.[^5_6][^5_7]

## c) Royalty‑free baseline vs GIF/Unisys déjà vu

- The GIF/LZW mess showed how a format that looked “free” in practice could be hit by a late‑enforced patent, and JPEG itself has had third‑party patent assertions over the years.[^5_1]
- In response, the JPEG committee explicitly states as a goal that *baseline* methods be implementable without license fees and has a history (e.g., in JPEG 2000) of securing license commitments from many organizations to keep the baseline royalty‑free.[^5_1]

For JPEG AI, “royalty‑free baseline” signals:

- Contributors with essential patents for the baseline commit to license them on royalty‑free terms for compliant implementations.[^5_8][^5_2]
- This greatly lowers the risk for browsers, OS vendors, and open‑source libraries, but it cannot absolutely prevent:
    - Unknown third‑party patents surfacing later.
    - Optional advanced tools in the standard having different (possibly royalty‑bearing) terms.[^5_9][^5_8]

So your skepticism is healthy. The bet is that the formal RF‑baseline process plus modern patent‑pool experience (and the community’s clear preference for royalty‑free media tech, as seen with AV1) makes another GIF/Unisys scenario less likely, though never impossible.[^5_9][^5_1]

Given all that, “worth pursuing” is about where things stand: promising for certain pipelines (especially big ML + storage stacks), but not something that obviously replaces JPEG XL or Web‑native formats everywhere any time soon.
<span style="display:none">[^5_10][^5_11]</span>

<div align="center">⁂</div>

[^5_1]: https://en.wikipedia.org/wiki/JPEG

[^5_2]: https://jpeg.org/items/20240507_press.html

[^5_3]: https://pmc.ncbi.nlm.nih.gov/articles/PMC11092870/

[^5_4]: https://arxiv.org/html/2503.16288v1

[^5_5]: https://iris.unibs.it/retrieve/2901840b-4703-4ae5-aac2-becc2b2b5555/MMSP24__Compressed_domain_face_detector_.pdf

[^5_6]: https://beebom.com/what-is-jpeg-xl/

[^5_7]: https://community.adobe.com/t5/camera-raw-bugs/p-certain-raw-files-export-unusually-large-with-jpeg-xl/idi-p/14877200

[^5_8]: https://ipo.org/wp-content/uploads/2024/02/AI-Patenting-Handbook-Whitepaper-V2.0-final.pdf

[^5_9]: https://streaminglearningcenter.com/codecs/hevc-licensing-misunderstood-maligned-and-surprisingly-successful.html

[^5_10]: https://encode.su/threads/4282-JPEG-AI

[^5_11]: https://cloudinary.com/blog/how_jpeg_xl_compares_to_other_image_codecs


---

# A good assessment indeed. Just a hypothetical would 'comet' aka perplexity's browser benefit from jpeg AI support ... ?

Yes, Comet *could* benefit from JPEG AI support in some scenarios, but it would be a niche, “power‑user / infra‑provider” win rather than an obvious must‑have for everyday browsing right away.

## Where Comet would actually gain

For a browser like Comet that’s tightly tied to AI assistance and automation, JPEG AI lines up with three potential advantages:

- **Cheaper ML on pages with images**
If a site stores images in JPEG AI and exposes the latent, Comet’s assistant could, in principle, run some vision tasks (object detection, scene understanding, quality checks) directly on the compressed representation instead of fully decoding to pixels, saving compute and latency for tasks like “what objects are in all these thumbnails?” or “summarize what’s going on in this image grid.” This is exactly the class of use JPEG AI targets: compressed‑domain analysis for classification/detection.[^6_11][^6_12][^6_13]
- **Server‑side benefit that trickles down to the browser**
Comet often talks to APIs and backends (Perplexity’s own plus third‑party services). If those backends use JPEG AI for large image corpora, they can run vision pipelines more efficiently (no full decode, fewer model layers) and just send Comet high‑level results or selectively decoded images, which makes AI answers faster/cheaper even if the browser never directly sees the JPEG AI bitstream.[^6_13][^6_14][^6_11]
- **Forward‑looking “AI‑native” media**
Long term, if more sites expose images in formats designed for joint human+machine consumption, Comet is well‑positioned to take advantage: an AI‑centric browser wants formats where the “for the model” representation comes basically for free with the “for the human” representation. JPEG AI is designed with that kind of dual use in mind, while JPEG XL is more human‑viewing‑centric even though it’s very efficient.[^6_15][^6_16][^6_11]


## Where JPEG AI doesn’t obviously help Comet (yet)

- **Web compatibility and ecosystem**
The main friction for any new codec is “do major sites and CDNs actually use it?” JPEG XL is *already* facing that uphill climb despite being more conventional and backwards‑friendly. JPEG AI is even newer and more specialized, so Comet would only get big wins if some sizable platforms adopt it. Until then, adding a neural decoder mostly increases complexity for limited payoff.
- **On‑device cost and complexity**
Even with “light” decoders, neural codecs are heavier than classic ones. For a browser that already runs big language models, extra GPU/CPU load matters. A very likely deployment pattern is: encode/query in JPEG AI in the cloud, but transcode to web‑native workhorses (JPEG / WebP / AVIF / JPEG XL) before sending to the browser.
- **Royalty‑free baseline vs long‑term risk**
A royalty‑free baseline reduces the HEVC/GIF‑style risk, but doesn’t erase it entirely. Browser vendors are cautious about shipping new media stacks with any patent uncertainty. That same caution would apply to Comet’s engine, especially given it’s intended to be widely distributed.


## So, hypothetically, what makes sense?

If JPEG AI matures and sees real‑world adoption, Comet would most likely benefit in these ways:

- Treat JPEG AI as an **internal / server‑side codec** to store and analyze large image corpora efficiently, then transcode or summarize for the user.
- Optionally add **client‑side decode support** once a) hardware and runtimes make it cheap, and b) enough sites or internal tools actually use it.
- Exploit compressed‑domain features where available, e.g., “instant object summaries” from images that never had to be fully decoded.

In other words: it’s *aligned* with what an AI‑first browser wants, but its benefits would show up first behind the scenes in the AI infrastructure, and only later as a visible end‑user feature if the ecosystem actually adopts JPEG AI at scale.
<span style="display:none">[^6_1][^6_10][^6_2][^6_3][^6_4][^6_5][^6_6][^6_7][^6_8][^6_9]</span>

<div align="center">⁂</div>

[^6_1]: https://www.datastudios.org/post/perplexity-ai-updates-in-late-2025-feature-expansions-service-behavior-and-platform-direction

[^6_2]: https://techcrunch.com/2025/07/09/perplexity-launches-comet-an-ai-powered-web-browser/

[^6_3]: https://www.cnbc.com/2025/07/09/perplexity-launches-ai-powered-web-browser-for-select-subscribers.html

[^6_4]: https://mashable.com/article/perplexity-ai-browser-comet-features-to-try

[^6_5]: https://techcrunch.com/2025/10/02/perplexitys-comet-ai-browser-now-free-max-users-get-new-background-assistant/

[^6_6]: https://mashable.com/article/perplexity-comet-ai-web-browser-how-to-try

[^6_7]: https://www.cnbc.com/2025/10/02/perplexity-ai-comet-browser-free-.html

[^6_8]: https://www.perplexity.ai/hub/blog/introducing-comet

[^6_9]: https://www.perplexity.ai/comet/

[^6_10]: https://www.reddit.com/r/perplexity_ai/comments/1mlcwrq/perplexity_best_use_casesstill_worth_it_in_2025/

[^6_11]: https://jpeg.org/jpegai/

[^6_12]: https://www.itu.int/en/ITU-T/Workshops-and-Seminars/2022/0118/Documents/Joao_Ascenso.pdf

[^6_13]: https://iris.unibs.it/retrieve/2901840b-4703-4ae5-aac2-becc2b2b5555/MMSP24__Compressed_domain_face_detector_.pdf

[^6_14]: https://jpeg.org/items/20240507_press.html

[^6_15]: https://jpeg.org/items/20250219_press.html

[^6_16]: https://eureka3d.eu/wp-content/uploads/2024/11/TalkJPEG-Ebrahimi2024_compressed.pdf


---

# Hmm comet is based on Chromium right? and google has just recently, after dropping support, announced jpeg XL support in 2026'ish .... not exactly a great start (comet has no jpeg XL support anno 2025) so despite some tentative 'it could be useful' regarding jpeg AI it would boil down to a popularity contest ... still could imagine some 'killer app' aka golden use case surfacing which might tip the balance ...

Yes, Comet is built on Chromium, inheriting its media codec support (or lack thereof), which means no JPEG XL in 2025 and JPEG AI is even further off—making adoption a pure ecosystem battle until a breakout use case emerges.

## Comet's Chromium roots and codec reality

Comet leverages Chromium's engine, so it gets the same image format support: strong on WebP/AVIF/JPEG, zero on JPEG XL (dropped by Google in 2021, tentative re-add eyed for 2026+), and nothing on JPEG AI yet. This is a deliberate choice for compatibility over bleeding-edge formats, especially since Comet prioritizes AI overlays on standard web content rather than pioneering new media stacks.

## Popularity contest dynamics

You're spot on: without major sites/CDNs pushing JPEG AI (think Netflix, Google Photos, or AWS S3 defaults), browsers like Comet have zero incentive to add decoder complexity. JPEG XL's "comeback" took years of niche advocacy, and even that's not universal—Comet sticking to Chromium's conservative baseline makes sense for a product aimed at seamless AI-assisted browsing, not format wars.

## Potential killer apps to tip the scales

A golden use case could flip this fast, especially for an AI browser like Comet:

- **Edge AI on image-heavy sites**: Galleries/newsfeeds where Comet's assistant auto-tags/describes/summarizes dozens of images. If sites ship JPEG AI latents, Comet could query them directly via compressed-domain ML, slashing latency vs. full decodes—perfect for "analyze all product shots" or "find scenes with people."
- **Cloud-to-browser vision pipelines**: Perplexity backend stores vast image datasets in JPEG AI for cheap analytics, then pipes lightweight results (or transcoded previews) to Comet. No client decoder needed, but Comet wins faster/smarter answers.
- **AR/VR or real-time surveillance feeds**: Progressive decoding + latents enable "preview low-fi while running detection," aligning with Comet's agentic tab/email/calendar smarts if those involve visuals.

Until such a "must-have" lands (e.g., Apple/Google mandating it or a viral app), it's sidelined. But if compressed-domain ML proves 2-5x faster for browser-side vision, Comet could add it as a Pro feature first, tipping the popularity contest via internal Perplexity adoption.[^7_1][^7_2][^7_3]

<div align="center">⁂</div>

[^7_1]: https://techcrunch.com/2025/07/09/perplexity-launches-comet-an-ai-powered-web-browser/

[^7_2]: https://techcrunch.com/2025/10/02/perplexitys-comet-ai-browser-now-free-max-users-get-new-background-assistant/

[^7_3]: https://www.perplexity.ai/hub/blog/introducing-comet


---

# Well there we are ... great discussion thank you never the less I am going to lobby sdl to do jpeg XL support (they kind of do and then kind of don't pretty much on the arguments you put forth) because after some testing with webp jpeg XL just wins out compression and IO wise nice sometimes tech actually wins instead of hedged bets oh then there's another comeback kid .svg : [https://www.siliconpublishing.com/blog/the-fall-and-rise-of-svg/](https://www.siliconpublishing.com/blog/the-fall-and-rise-of-svg/) : '2010: The meek finally inherit the earth' ...

You're welcome—glad the discussion sparked some ideas! Lobbying SDL for solid JPEG XL support makes total sense; its compression/IO edge over WebP shines in real tests, especially for lossless or high-quality scenarios where tech superiority trumps ecosystem inertia.

## Why JPEG XL Deserves the Push

- SDL's "kinda/sorta" support (via libjxl in some builds) leaves gaps in reliability and performance, but full integration would unlock faster loads and smaller assets in games/apps without quality hits—pure win for cross-platform devs tired of WebP's quirks.
- Your testing aligns with benchmarks: JPEG XL often pulls 20-60% better ratios than WebP at matching quality, plus features like progressive decoding and lossless JPEG roundtrips that WebP fumbles.


## SVG's Eternal Comeback

That "2010: The meek finally inherit the earth" line nails SVG's zombie status—dismissed as bloaty in the bitmap era, now resurgent for web/scalable graphics thanks to CSS animations, filters, and AI vector tools. It's the ultimate hedgeless bet: infinite zoom, tiny for icons/UI, and native everywhere. [attached_file:1 from earlier context on imaging standards]

If SDL nails JPEG XL + leans into SVGz (gzipped SVG), you'd have a killer combo for modern assets. Keep us posted on the lobbying—tech wins like that are worth the fight!

