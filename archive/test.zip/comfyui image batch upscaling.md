<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# is it possible to use comfyui as a batched image upscaler say similar to upscaly?

Yes, ComfyUI supports batched image upscaling similar to tools like Upscayl, using nodes like ImageUpscaleWithModelBatched for efficient processing of multiple images while managing VRAM.[^1_1][^1_3]

## Key Capabilities

ComfyUI's node-based workflows allow loading batches of images (via nodes like LoadImageFromFolder from custom extensions such as ComfyUI-N-Suite), applying upscale models (e.g., ESRGAN variants), and outputting high-resolution results without cropping or distortion.[^1_6][^1_7]

## Comparison to Upscayl

While Upscayl focuses on simple drag-and-drop batch upscaling, ComfyUI offers more flexibility with custom models, aspect ratio preservation, and parallel sub-batch processing (e.g., per_batch parameter adjustable from 1 to 4096).[^1_4][^1_1]

## Setup Steps

- Install ComfyUI and relevant custom nodes (e.g., KJNodes or N-Suite).
- Load an upscale model into models/upscale_models.
- Connect Load Images → Upscale node → Save Images, then queue the prompt.[^1_2][^1_9]
<span style="display:none">[^1_10][^1_5][^1_8]</span>

<div align="center">⁂</div>

[^1_1]: https://www.runcomfy.com/comfyui-nodes/ComfyUI-KJNodes/ImageUpscaleWithModelBatched

[^1_2]: https://stable-diffusion-art.com/comfyui/

[^1_3]: https://comfyai.run/documentation/ImageUpscaleWithModelBatched

[^1_4]: https://github.com/orgs/upscayl/discussions/623

[^1_5]: https://docs.comfy.org/tutorials/basic/upscale

[^1_6]: https://www.reddit.com/r/comfyui/comments/1pvcftf/is_there_any_upscaling_model_that_can_be_used/

[^1_7]: https://openart.ai/workflows/labradoodle_intentional_17/batch-upscale-without-cropping-keep-original-aspect-ratio/AZilXf6o5uAnja8V1gf4

[^1_8]: https://www.youtube.com/watch?v=_jO2MPrMiyA

[^1_9]: https://www.youtube.com/watch?v=zoRLrR0EMAI

[^1_10]: https://www.facebook.com/groups/comfyui/posts/840952745344094/


---

# Ok ... 'Load an upscale model into models/upscale_models.' could you give me some suggestions to which and where I can download them from?

Yes, ComfyUI works well for batched image upscaling with specific nodes and models. Popular upscale models like 4x-UltraSharp.pth and RealESRGAN_x4plus.pth are easy to download and drop into the `ComfyUI/models/upscale_models/` folder.[^2_1][^2_2][^2_4]

## Recommended Models

These are versatile, highly rated options for general photos, AI art, and prints:


| Model Name | Scale | Best For | Download Source [^2_2][^2_4][^2_6][^2_7] |
| :-- | :-- | :-- | :-- |
| 4x Remacri | 4x | Versatile all-purpose | Civitai or OpenModelDB |
| RealESRGAN x4plus | 4x | Photorealistic images | Hugging Face (search "RealESRGAN_x4plus.pth") |
| 4x-UltraSharp | 4x | Sharp details, anime | Hugging Face (philz1337x/upscaler) |
| 4x_NMKD-Siax_200k | 4x | General enhancement | Hugging Face (uwg/upscaler) |

## Download Steps

Visit OpenModelDB.info or Hugging Face for free .pth files—filter by "upscale" or "ESRGAN," click Download, and place in the folder. Restart ComfyUI or refresh models to see them in the Load Upscale Model node.[^2_6][^2_10][^2_1]
<span style="display:none">[^2_3][^2_5][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://docs.comfy.org/tutorials/basic/upscale

[^2_2]: https://comfyuiweb.com/resources/upscale-models

[^2_3]: https://www.youtube.com/watch?v=BRHodz0_Uc4

[^2_4]: https://github.com/greenzorro/comfyui-workflow-upscaler

[^2_5]: https://blog.comfy.org/p/upscaling-in-comfyui

[^2_6]: https://www.reddit.com/r/comfyui/comments/1hyjgtu/whats_the_best_upscale_model/

[^2_7]: https://huggingface.co/10xwithankit/ComfyUI-Models

[^2_8]: https://comfyui-wiki.com/en/resource/upscale-models

[^2_9]: https://comfyui.org/en/topazs-flagship-upscale-models-in

[^2_10]: https://docs.comfy.org/development/core-concepts/models


---

# 'Download, and place in the folder.' which folder? models/checkpoint ?

No, upscale models go in `ComfyUI/models/upscale_models`, not `models/checkpoints` which is for diffusion checkpoints like SDXL safetensors.[^3_1][^3_2][^3_3]

## Folder Structure

ComfyUI organizes models in the root `models/` subfolders:

- `models/checkpoints`: Stable Diffusion models (.safetensors, .ckpt).
- `models/upscale_models`: Upscalers (.pth files like 4x-UltraSharp.pth).[^3_4][^3_8]


## Quick Setup

Download .pth files to `ComfyUI/models/upscale_models`, then refresh your browser or restart ComfyUI. The UpscaleModelLoader node lists them automatically from there.[^3_3][^3_9]
<span style="display:none">[^3_10][^3_5][^3_6][^3_7]</span>

<div align="center">⁂</div>

[^3_1]: https://www.reddit.com/r/comfyui/comments/1hyev9z/where_to_put_upscaling_pth_files/

[^3_2]: https://comfyui-wiki.com/en/comfyui-nodes/loaders/upscale-model-loader

[^3_3]: https://docs.comfy.org/tutorials/basic/upscale

[^3_4]: https://docs.comfy.org/development/core-concepts/models

[^3_5]: https://www.reddit.com/r/StableDiffusion/comments/1534tr2/how_do_i_get_my_models_to_load_for_comfyui/

[^3_6]: https://github.com/comfyanonymous/ComfyUI/discussions/5015

[^3_7]: https://www.youtube.com/watch?v=34y7QBVyvzY

[^3_8]: https://www.runcomfy.com/comfyui-nodes/ComfyUI/UpscaleModelLoader

[^3_9]: https://comfyui-wiki.com/en/workflows/upscale-models

[^3_10]: https://www.viewcomfy.com/blog/build-a-stable-diffusion-upscaler-using-comfyui


---

# Hmm so download something like : [https://openmodeldb.info/models/4x-ESRGAN](https://openmodeldb.info/models/4x-ESRGAN) : put the RRDB_ESRGAN_x4.pth in /models/upscale_models (it's a python torch file ... but ok) and then?

Yes, that's correct—download RRDB_ESRGAN_x4.pth from OpenModelDB and place it directly in `ComfyUI/models/upscale_models`. It's a PyTorch model file (.pth), fully compatible with ComfyUI's UpscaleModelLoader.[^4_2][^4_4]

## Next Steps

Refresh your browser (or restart ComfyUI) to scan the folder and list the model in nodes.

Create a simple workflow:

1. Add **Load Upscale Model** (under Loaders) → select `RRDB_ESRGAN_x4.pth` from the dropdown → outputs UPSCALE_MODEL.
2. Add **Load Image** → upload your input image.
3. Add **Upscale Image (using Model)** (under Image/Upscaling) → connect image to `image` input, upscale_model to `upscale_model` input.
4. Add **Save Image** or **Preview Image** → connect the upscaled output.
5. Click **Queue Prompt** (or Ctrl+Enter) to process.[^4_1][^4_6][^4_2]

## Batch Processing

For Upscayl-style batches, install custom nodes like ComfyUI-N-Suite (via Manager), use **Load Images From Folder**, and connect to the upscale chain with a batch size parameter.[ from prior]
<span style="display:none">[^4_10][^4_3][^4_5][^4_7][^4_8][^4_9]</span>

<div align="center">⁂</div>

[^4_1]: https://www.runcomfy.com/comfyui-nodes/ComfyUI/UpscaleModelLoader

[^4_2]: https://docs.comfy.org/tutorials/basic/upscale

[^4_3]: https://www.reddit.com/r/StableDiffusion/comments/1534tr2/how_do_i_get_my_models_to_load_for_comfyui/

[^4_4]: https://comfyui-wiki.com/en/comfyui-nodes/loaders/upscale-model-loader

[^4_5]: https://www.youtube.com/watch?v=i8v9RbNy4Zw

[^4_6]: https://www.youtube.com/watch?v=8Yu7E_GApDc

[^4_7]: https://comfyui-wiki.com/en/tutorial/basic/upscale-image

[^4_8]: https://www.youtube.com/watch?v=BRHodz0_Uc4

[^4_9]: https://www.youtube.com/watch?v=34y7QBVyvzY

[^4_10]: https://www.youtube.com/watch?v=CxB47DMEyYQ


---

# Gracias will take a stab at it. Must say this stuff is bewildering : [https://openmodeldb.info/?t=general-upscaler\&sort=date-desc](https://openmodeldb.info/?t=general-upscaler&sort=date-desc) ....

¡De nada! OpenModelDB tiene una lista enorme de upscalers, lo cual puede ser abrumador al principio. Empieza con los más populares y probados para no complicarte.[^5_11][^5_12]

## Recomendaciones Simples

Elige solo 2-3 de estos (todos 4x, ideales para principiantes):


| Modelo | Tipo | Por Qué Usarlo |
| :-- | :-- | :-- |
| 4x-UltraSharp | Detalles nítidos | Excelente para fotos y arte AI |
| 4x-Remacri | Equilibrado | Buen todo-terreno |
| RealESRGAN_x4plus | Realista | Mejora fotos reales |

Descárgalos del sitio que mencionas, filtrando por "4x" y "general upscaler" → solo los .pth de la parte superior.

## Evita Sobrecarga

- No descargues más de 5 modelos al inicio.
- Prueba uno por workflow: carga imagen → upscale → guarda → ve resultados.
- Si algo falla, verifica que ComfyUI refresque (F5 o reinicio).[^5_2][^5_13]

¡Vas bien, paso a paso se hace fácil!
<span style="display:none">[^5_1][^5_10][^5_3][^5_4][^5_5][^5_6][^5_7][^5_8][^5_9]</span>

<div align="center">⁂</div>

[^5_1]: https://stable-diffusion-art.com/comfyui/

[^5_2]: https://comfyui-wiki.com/en/workflows/upscale-models

[^5_3]: https://docs.comfy.org/tutorials/utility/image-upscale

[^5_4]: https://www.youtube.com/watch?v=_jO2MPrMiyA

[^5_5]: https://comfyui-wiki.com/en/tutorial/basic/upscale-image

[^5_6]: https://blog.comfy.org/p/upscaling-in-comfyui

[^5_7]: https://www.youtube.com/watch?v=BRHodz0_Uc4

[^5_8]: https://www.youtube.com/watch?v=d3-Abg4uzqM

[^5_9]: https://www.youtube.com/watch?v=NpNagmQI4yg

[^5_10]: https://www.youtube.com/watch?v=CxB47DMEyYQ

[^5_11]: https://comfyuiweb.com/resources/upscale-models

[^5_12]: https://www.reddit.com/r/comfyui/comments/1hyjgtu/whats_the_best_upscale_model/

[^5_13]: https://docs.comfy.org/tutorials/basic/upscale


---

# Really need to cut down on my gracias ehhr could you do that in english please?

No problem, I'll stick to English from now on.

## Top Beginner Picks

From that OpenModelDB general upscaler list, prioritize these proven 4x models to avoid overwhelm—they're all .pth files, drop them straight into `ComfyUI/models/upscale_models/`:


| Model | Why It's Great |
| :-- | :-- |
| 4x-UltraSharp | Sharp details for photos/AI art |
| 4x-Remacri | Balanced all-purpose results |
| RealESRGAN_x4plus | Best for realistic images |

## Quick Tips

Sort by downloads/popularity on the site, grab just 2-3 to start. After placing files, hit refresh in ComfyUI (F5 or restart) so they appear in the UpscaleModelLoader dropdown. Test with a single image first before batching.[^6_1][^6_2]

<div align="center">⁂</div>

[^6_1]: https://comfyuiweb.com/resources/upscale-models

[^6_2]: https://docs.comfy.org/tutorials/basic/upscale


---

# Hmm : [https://openmodeldb.info/models/4x-UltraSharpV2](https://openmodeldb.info/models/4x-UltraSharpV2) : it's a .safetensor does it matter? Got this one : [https://openmodeldb.info/models/4x-Remacri](https://openmodeldb.info/models/4x-Remacri) and : [https://openmodeldb.info/models/4x-realesrgan-x4plus](https://openmodeldb.info/models/4x-realesrgan-x4plus) ....

.safetensors works fine for upscale models in ComfyUI—both .pth and .safetensors formats load via UpscaleModelLoader from `models/upscale_models/`. Great picks with 4x-UltraSharpV2, 4x-Remacri, and 4x-RealESRGAN_x4plus; they'll all show up in the dropdown after refresh.[^7_1][^7_2][^7_5]

## File Compatibility

| Format | Supported? | Notes |
| :-- | :-- | :-- |
| .pth | Yes | Traditional ESRGAN format |
| .safetensors | Yes | Safer, modern standard—same performance |

## Test Your Setup

1. Drop all three files into `ComfyUI/models/upscale_models/`.
2. Refresh browser (F5) or restart ComfyUI.
3. In workflow: Load Upscale Model → pick one (e.g., "4x-UltraSharpV2.safetensors") → Load Image → Upscale Image (using Model) → Preview/Save → Queue Prompt.

Start with UltraSharpV2 for crisp results on most images.[^7_5][^7_8]
<span style="display:none">[^7_10][^7_3][^7_4][^7_6][^7_7][^7_9]</span>

<div align="center">⁂</div>

[^7_1]: https://comfyui-wiki.com/en/comfyui-nodes/loaders/upscale-model-loader

[^7_2]: https://www.runcomfy.com/comfyui-nodes/ComfyUI/UpscaleModelLoader

[^7_3]: https://comfyai.run/documentation/UpscaleModelLoader

[^7_4]: https://comfyai.run/documentation/Upscale Model Loader

[^7_5]: https://docs.comfy.org/tutorials/basic/upscale

[^7_6]: https://www.youtube.com/watch?v=i8v9RbNy4Zw

[^7_7]: https://www.nextdiffusion.ai/tutorials/how-to-upscale-images-with-supir-in-comfyui

[^7_8]: https://comfyui-wiki.com/en/tutorial/basic/upscale-image

[^7_9]: https://docs.comfy.org/development/core-concepts/models

[^7_10]: https://comfyuiweb.com/resources/upscale-models


---

# ok merci now I'm prepped. Thank you for the info and guidance.

You're welcome! Glad the guidance helped get you set up—happy upscaling with ComfyUI.

