<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# With freebasic I'm trying to get the current volume from pipewire, using shell does not work it only returns true or false I need the value tried this : dummy = exec("wpctl, get-volume, @DEFAULT_AUDIO_SINK@") : but I'm getting an argument count error ...

`wpctl get-volume` takes the sink as a separate argument, so the command should be:

```bash
wpctl get-volume @DEFAULT_AUDIO_SINK@
```

The volume is printed as text, usually something like `Volume: 0.53`, so in FreeBASIC you need to capture stdout from the command rather than treating it like a boolean. `wpctl`’s `get-volume` command is documented with a single object ID argument, and `@DEFAULT_AUDIO_SINK@` is the special name for the current default sink.[^1_3]

## Why your call fails

This part is the problem:

```basic
exec("wpctl, get-volume, @DEFAULT_AUDIO_SINK@")
```

That looks like a single string with commas, but the command-line program expects separate arguments, not comma-separated text. Also, in FreeBASIC, `exec` is not the right choice if you want to capture command output; `exec` is for running programs, not for reading their stdout as a returned value.

## A working approach

Use `OPEN PIPE` to read the output:

```basic
dim f as integer
dim line as string

open pipe "wpctl get-volume @DEFAULT_AUDIO_SINK@" for input as #1
line input #1, line
close #1

print line
```

If the command returns more than one line on your system, loop until EOF.

## Extract the numeric value

If the output is like:

```text
Volume: 0.53
```

you can strip the text and parse the number:

```basic
dim s as string
dim vol as double

open pipe "wpctl get-volume @DEFAULT_AUDIO_SINK@" for input as #1
line input #1, s
close #1

s = trim(s)
s = replace(s, "Volume:", "")
vol = val(trim(s))

print vol
```

That gives you the current volume as a number, for example `0.53`. The `wpctl` manual shows `get-volume` as the correct command for querying sink volume.[^1_3]

## If you only need the shell text

A shell command version is:

```bash
wpctl get-volume @DEFAULT_AUDIO_SINK@
```

If your FreeBASIC runtime has a function that returns command output instead of just a success flag, use that one; otherwise, `OPEN PIPE` is the usual solution for this kind of task.
<span style="display:none">[^1_1][^1_10][^1_2][^1_4][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://gist.github.com/schauveau/b5a2d20c98e6bea8c8cd50410ff01253

[^1_2]: https://gist.github.com/baudneo/48d9fe4f2f6f13c7e22c4c5f4afab164

[^1_3]: https://linuxcommandlibrary.com/man/wpctl

[^1_4]: https://stackoverflow.com/questions/74189415/how-to-change-volume-of-a-specific-application-using-pipewire

[^1_5]: https://forum.manjaro.org/t/default-login-volume/168476

[^1_6]: https://wiki.archlinux.org/title/WirePlumber

[^1_7]: https://kowalcj0.github.io/2022/01/09/handy-pipewire-commands-and-tools/

[^1_8]: https://bbs.archlinux.org/viewtopic.php?id=307213

[^1_9]: https://man.archlinux.org/man/extra/wireplumber/wpctl.1.en

[^1_10]: https://www.reddit.com/r/swaywm/comments/w3llwx/getting_volume_level_from_pipewire/


---

# All right lot of things on my side but your code has pointed me in the right direction alas pipewire is stuck on mute now, think that : wpctl set-volume @DEFAULT_AUDIO_SINK@ 00% : has the same effect as : wpctl set-mute @DEFAULT_SINK@ 1 : and wpctl set-mute @DEFAULT_SINK@ 0 : doesn't unmute so will need to reboot / log off and hope pipewire resets it self. For kudos and thanks will drop by as soon as I get things sorted on my side.

Yep — `wpctl set-volume @DEFAULT_AUDIO_SINK@ 0%` can effectively silence the output, and depending on the device/backend it may look a lot like mute rather than just low volume. Also, `@DEFAULT_SINK@` is not the usual PipeWire target here; `@DEFAULT_AUDIO_SINK@` is the one to use for the default output device.[^2_1]

A couple of practical notes:

- `wpctl set-mute @DEFAULT_AUDIO_SINK@ 1` mutes the sink.
- `wpctl set-mute @DEFAULT_AUDIO_SINK@ 0` should unmute it, but if the session state is stuck, restarting the user audio session often clears it.
- After setting volume to `0%`, some setups behave as though the sink is muted until volume is raised again above zero.

If it stays stuck after logout/login, the usual reset paths are:

- raise volume again, for example `wpctl set-volume @DEFAULT_AUDIO_SINK@ 10%`
- unmute explicitly with `wpctl set-mute @DEFAULT_AUDIO_SINK@ 0`
- restart the user PipeWire/WirePlumber session instead of rebooting, if your desktop allows it

Thanks for the kudos — glad it pointed you in the right direction.

<div align="center">⁂</div>

[^2_1]: https://linuxcommandlibrary.com/man/wpctl

