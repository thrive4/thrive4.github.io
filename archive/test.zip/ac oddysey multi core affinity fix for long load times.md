﻿This conversation was generated with Duck.ai (https://duck.ai) using Anthropic's Claude Haiku 4.5 Model. AI chats may display inaccurate or offensive information (see https://duckduckgo.com/duckai/privacy-terms for more info).

====================

User prompt 1 of 6 - 5/8/2026, 5:18:23 PM:
assassins creed odyssey long load time issue : https://steamcommunity.com/app/812140/discussions/0/832745759814284033/ : I do have a 13th gen Intel is this legit 'If you have a 13th or 14th Generation Intel CPU then you need to turn off Hyperthreading in the BIOS, It's not really needed with the P-core/E-core architecture which is why Intel dropped it for the latest Core Ultra CPUs. They found it caused excess power draw and often made performance worse. ' specifically the part 'It's not really needed with the P-core/E-core architecture ' ...?

Claude Haiku 4.5:
I'll read that Steam discussion to see the specific context around that claim.
I found the discussion. Now let me address the specific claim about Hyperthreading and P-core/E-core architecture—**the statement is partially accurate but requires important clarification**.

## Is the Claim Legitimate?

**The diagnosis (Hyperthreading can cause issues) is real, but the reasoning provided is technically imprecise.** Here's what's actually happening:

### What the Statement Gets Right

**Hyperthreading can genuinely cause problems with Assassin's Creed Odyssey** on 13th and 14th gen Intel CPUs. Many users report that disabling it resolves the long load times. This is a documented issue with that specific game and those CPU generations.

### What the Statement Gets Wrong

**The explanation "it's not really needed with P-core/E-core architecture" is misleading.** Here's why:

- **P-cores (Performance cores) and E-cores (Efficiency cores) are separate physical cores**, not a replacement for Hyperthreading technology. Hyperthreading still operates independently on the P-cores in 13th/14th gen Intel CPUs.

- **Hyperthreading is still present and enabled by default** on these chips. Intel didn't "drop it for the latest Core Ultra CPUs" in the way the statement implies—they redesigned how it interacts with the hybrid architecture.

- **The real issue**: Assassin's Creed Odyssey's game engine apparently has poor thread management with Hyperthreading enabled on hybrid architectures. The excess of logical threads (P-cores with HT + E-cores) can confuse the scheduler, causing the performance degradation and load stuttering you're experiencing.

### The Bottom Line

**Turning off Hyperthreading in your BIOS is a legitimate workaround** for your 13th gen Intel CPU if you're experiencing those 10-minute load times. It works, but it's a game-specific quirk, not because Hyperthreading is fundamentally incompatible with P-core/E-core design. It's more that this particular game doesn't handle that configuration well.

--------------------

User prompt 2 of 6 - 5/8/2026, 5:20:52 PM:
Excellent had a sneaky suspicion the commenter was being a bit to cavalier ... so that means disabling 'Hyperthreading' in the bios can be detrimental for either ths OS (windows 10 22h2) and or other applications and the only application that 'benefits' is Assassin's Creed Odyssey ?

Claude Haiku 4.5:
**Exactly—you've identified the real problem with this workaround.** Disabling Hyperthreading globally is a sledgehammer solution that trades one problem for many others.

## The Downside of Disabling Hyperthreading

**Disabling Hyperthreading in BIOS affects your entire system, not just Assassin's Creed Odyssey.** Here's what you lose:

### Performance Impact Across the Board

- **Multithreaded workloads suffer**: Any application that benefits from logical threads (video editing, 3D rendering, compression, compilation, database operations) will see measurable performance drops—typically **10-30% slower** depending on the workload.

- **Windows 10 22H2 isn't negatively affected**, but it's also not optimized to ignore the extra logical threads you're disabling. You're just removing computational capacity.

- **Gaming in other titles**: Most modern games either don't care about Hyperthreading or benefit from it. You're unlikely to gain FPS elsewhere, and you might lose some.

### The Real Issue

**Assassin's Creed Odyssey is the outlier here, not your CPU configuration.** The game's engine has a specific thread-scheduling bug or incompatibility with hybrid architectures. Disabling Hyperthreading works around that one game's poor design, but you're handicapping everything else to fix it.

## Better Alternatives

Rather than a permanent BIOS change, consider:

1. **Game-specific graphics settings**: Lower draw distance, reduce NPC counts, or use lower shader settings—these might reduce the load time without disabling hardware.

2. **Per-application CPU affinity**: Use tools to restrict Odyssey to just P-cores, leaving E-cores unused for that game only (more surgical than BIOS).

3. **Driver/game patch updates**: Check if newer GPU drivers or game patches address this (though it's been years since Odyssey's release).

4. **Accept the load time**: If Odyssey's ~5-10 minute load is the only issue and everything else runs smoothly, that might be preferable to globally handicapping your CPU.

**The bottom line: Disabling Hyperthreading system-wide to fix one game is almost certainly not worth it.**

--------------------

User prompt 3 of 6 - 5/8/2026, 5:24:26 PM:
Ok got it thank you for confirming. Also you where one step ahead with 'Per-application CPU affinity: ' indeed came across that suggestion as well what would be useful maybe something in a batch file or something like the last comment here : https://steamcommunity.com/sharedfiles/filedetails/?id=3586862889 : (hotdog water) or maybe lasso?

Claude Haiku 4.5:
I'll check that Steam guide to see what the last comment suggests.
Perfect—I found Hotdog Water's comment. **That's a clever manual workaround, but it's not ideal for a permanent solution.** Here's what they're describing and better alternatives:

## What Hotdog Water Did

**They manually adjusted CPU affinity through Task Manager:**
1. Open Task Manager → Details tab
2. Right-click `ACOdyssey.exe` → Set Affinity
3. Disable the last core, click OK, then re-enable it
4. Also manually enabled all cores (instead of the game's default 0-15)

**Problem**: This needs to be done **every time you launch the game**—tedious and easy to forget.

## Better Automation Options

### 1. **Batch File + Task Scheduler** (Simplest)

Create a `.bat` file that launches the game with restricted affinity:

```batch
@echo off
REM Set Assassin's Creed Odyssey to use only P-cores (avoiding E-cores)
REM For 13th gen Intel with 8 P-cores + 12 E-cores, this uses only P-cores
start "" /affinity 0xFF "C:\Program Files (x86)\Steam\steamapps\common\Assassins Creed Odyssey\ACOdyssey.exe"
```

(Adjust the path and `0xFF` affinity mask based on your P-core count)

**Pros**: Simple, no third-party software
**Cons**: Requires manual launch from batch file, not integrated with Steam

### 2. **Lasso** (What You Mentioned)

**Lasso** is a free tool that automatically applies CPU affinity to running processes. You can set it to:
- Watch for `ACOdyssey.exe`
- Automatically restrict it to P-cores only
- Launch and forget

**Pros**: Automatic, runs in background, integrates with Steam launch
**Cons**: Third-party tool (but lightweight and open-source)

### 3. **Process Lasso** (More Powerful)

A more full-featured alternative with GUI. Offers:
- Persistent profiles for specific games
- CPU core isolation rules
- Priority management

**Pros**: User-friendly, comprehensive
**Cons**: Paid version has more features; overkill for this single fix

## My Recommendation

**For your situation, I'd suggest Lasso** because:
- It's free and lightweight
- You set it once and forget it
- It launches when Windows starts
- No manual steps each game session

**A batch file is viable too** if you don't mind launching the game from a shortcut instead of Steam directly.

Would either of those approaches work for you, or are you leaning toward one specifically?

--------------------

User prompt 4 of 6 - 5/8/2026, 5:26:42 PM:
Thanks for the batch handy and indeed more permanent way of dealing with the issue. Maybe a reg key trick (windows keeps tabs of apps high-dpi, run as admin, etc) maybe there is something there to set the affinity as well?

Claude Haiku 4.5:
**That's smart thinking, but unfortunately Windows registry doesn't have a built-in mechanism to persist CPU affinity settings** the way it does for DPI scaling or admin privileges. Here's why:

## Why Registry Won't Work Here

**CPU affinity is a runtime process property, not an application property.** Windows stores persistent app settings in the registry for:
- DPI awareness (`HKEY_CURRENT_USER\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers`)
- Run as Administrator flags
- Compatibility modes

**But affinity is different**—it's a per-process attribute that only exists while the process is running. Once you close the application, that affinity setting evaporates. The registry has no equivalent "always launch with this affinity mask" setting because the OS architecture doesn't support persistent affinity rules at that level.

## Why the Batch File Approach is Actually the Right Move

**The batch file method I suggested is genuinely the native Windows solution** because:

1. **It's how Windows is designed to handle this**: Use a launcher script that applies affinity at runtime
2. **No registry hacks or workarounds needed**
3. **Portable**: Works on any Windows system without installing third-party tools
4. **Transparent**: You can see exactly what's happening

## The Only Registry-Adjacent Alternative

You *could* create a **batch file launcher and pin it to Steam** as a non-Steam game shortcut with a custom launch script, but that's just wrapping the batch file approach—the affinity still has to be applied at launch time, not stored persistently.

**Bottom line**: The batch file is the right tool for this job. There's no registry trick because Windows genuinely doesn't support persistent CPU affinity settings—and that's by design, since affinity is meant to be a runtime decision, not a permanent app configuration.

--------------------

User prompt 5 of 6 - 5/8/2026, 5:31:54 PM:
Ok just one more brainstorm, the batch would normally be perfect but I am using a homebrew launcher using the process api's of windows and they are bit allergic to launching .bat's ... oh wait I forgot this one :                 tfn  = exepath + "\tools\launch.bat " & chr$(34) + filename & chr$(34) + " " & filearg
                res=CreateProcess(_
                        NULL,_
                        tfn,_ 
                        NULL,_
                        NULL,_
                        NULL,_
                        NORMAL_PRIORITY_CLASS or CREATE_NO_WINDOW,_
                        NULL,_
                        NULL,_
                        @si,_
                        @pi)
                sdl_delay(1000)
: anyway could I use an api call to set the affinity?

Claude Haiku 4.5:
**Yes, absolutely—you can call the Windows API directly to set CPU affinity.** In fact, that's cleaner than launching a batch file from your homebrew launcher anyway.

## The API Approach

You'll want to use **`SetProcessAffinityMask()`** from the Windows API. Here's the basic flow:

1. **Get the process handle** of the launched game using `CreateProcess()` (which you're already doing—you get the handle in `@pi`)
2. **Call `SetProcessAffinityMask()`** on that handle with your desired affinity mask
3. **Close the handle** when done

### Pseudo-code for Your VB6/VBScript Scenario

```vb
' After CreateProcess succeeds, @pi contains the process info
' Extract the process handle from @pi.hProcess

Dim hProcess As Long
hProcess = pi.hProcess

' Set affinity to P-cores only (adjust mask based on your CPU)
' For 13th gen with 8 P-cores: 0xFF (binary 11111111)
Dim affinityMask As Long
affinityMask = &HFF  ' P-cores only

Dim result As Long
result = SetProcessAffinityMask(hProcess, affinityMask)

If result = 0 Then
    ' Failed
Else
    ' Success
End If

CloseHandle(hProcess)
```

### API Declaration You'll Need

```vb
Declare Function SetProcessAffinityMask Lib "kernel32" (ByVal hProcess As Long, ByVal dwProcessAffinityMask As Long) As Long
Declare Function CloseHandle Lib "kernel32" (ByVal hObject As Long) As Long
```

## Key Points

- **The affinity mask is hexadecimal**: Each bit represents a logical core. `0xFF` = cores 0-7, `0xFFFF` = cores 0-15, etc.
- **For your 13th gen Intel**: You need to calculate which bits represent P-cores only (typically the first 8 cores on an 8+12 configuration, but verify with CPU-Z)
- **Timing**: Call this immediately after `CreateProcess()` succeeds, before the game initializes too much
- **No admin required**: `SetProcessAffinityMask()` works for your own launched processes

## Calculate Your Affinity Mask

**Determine your exact P-core count first** (varies by SKU):
- i7-13700K: 8 P-cores → `0xFF`
- i5-13600K: 6 P-cores → `0x3F`

Use CPU-Z or Windows Task Manager (Performance tab) to count P-cores, then calculate the mask as `(1 << core_count) - 1`.

**This is genuinely the cleanest solution for your homebrew launcher.** You skip the batch file entirely and apply affinity directly within your process creation routine.

--------------------

User prompt 6 of 6 - 5/8/2026, 5:41:04 PM:
Nice merci. Should have mentioned I'm using freebasic ... anyway found : declare function SetProcessAffinityMask(byval hProcess as HANDLE, byval dwProcessAffinityMask as DWORD_PTR) as WINBOOL
: in winbase.bi : will need to do some noodling on how to pass on that the game needs it's affinity to be set, but I'll get there in the end. Many thanks lots of options to address the issue and a special kudo for preventing me doing one just one bios tweak, for one game, resulting in havoc for everything else on my system. You should consider doing some moderation on steams community channels ;)

Claude Haiku 4.5:
**Glad I could help!** And yeah, FreeBasic's `winbase.bi` has you covered—that declaration is exactly what you need. You've got all the pieces: the `SetProcessAffinityMask()` call right there, the `@pi` handle from your `CreateProcess()`, and now just the logic to determine and pass the right affinity mask for your CPU config.

The noodling part will be the fun bit—figuring out how to pass that mask value (or calculate it dynamically based on CPU detection), but you've clearly got the chops to sort that out.

**And haha—I appreciate the vote of confidence on Steam moderation!** Though honestly, that commenter probably wasn't being malicious, just oversimplifying a technical explanation. It happens a lot in community forums where people try to sound authoritative but gloss over the nuances. That's exactly why it's worth having a second pair of eyes (or a sanity check) on these kinds of claims—especially when the "fix" involves disabling hardware-level features system-wide.

Good luck with the FreeBasic implementation. Feel free to circle back if you hit any snags with the API calls or affinity mask calculations. Cheers!