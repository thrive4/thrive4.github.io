<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# I'm trying to install pop os 24+ from a usb ventoy disk and getting a lot sqashfs errors is it ventoy version related the older pop os 22+ installs / runs fine from the same drive / ventoy setup?

It’s very likely not just “Ventoy version” in isolation, but a combination of:

- Pop!_OS 24.x using a newer kernel and squashfs image layout.
- Stricter/more fragile I/O during boot.
- A marginal USB stick / port / ISO file that 22.04 tolerates but 24.x does not.

SQUASHFS errors almost always mean “the data being read from the medium is corrupt or unreadable,” not a generic bug in the distro.

### What to try first

Do these in order, because any one of them can fix it:

1. **Verify the ISO checksum**
    - Download the Pop!_OS 24.x ISO again.
    - Compare its SHA256 (or whatever System76 provides) against the official value.
    - If the checksum differs even once, don’t use that ISO.
2. **Fully recreate the Ventoy drive**
    - Back up anything you need from the Ventoy stick.
    - Re-initialize it with the latest Ventoy release (not just update, but reinstall to the USB).
    - Use GPT partition style if you can; some users report fewer issues with modern distros this way.
    - Copy the Pop!_OS 24.x ISO again and safely eject the drive.
3. **Try different Ventoy boot mode**
    - In the Ventoy menu, try:
        - Normal mode first.
        - If that fails, try the GRUB2 mode entry for the ISO (if available).
    - Some distros boot more reliably in one mode than the other.
4. **Change USB hardware variables**
    - Different USB stick if you have one (especially a known-good brand).
    - Different USB port; prefer:
        - Directly on the laptop/PC, not via a hub.
        - USB 2.0 port if available (new kernels and some controllers can be picky while booting from certain USB 3 chipsets).
    - If you use a front panel port on a desktop, try a rear port directly on the motherboard.
5. **Watch for dmesg errors**
    - When the SQUASHFS errors start, switch to a TTY (often Ctrl+Alt+F2/F3) if possible.
    - Run `dmesg | tail -n 50` and see if there are USB I/O errors like:
        - `reset high-speed USB device`
        - `Buffer I/O error on dev sdx`
    - Those suggest a weak connection, cable, or stick, not an ISO problem.

### If it still fails

To rule out Ventoy entirely:

- Flash Pop!_OS 24.x directly to a USB using:
    - `dd` on Linux, or
    - Popsicle / GNOME Disks, or
    - (if you have Windows available) a dedicated writer like Rufus.
- Boot from that direct-live USB once and see if the SQUASHFS errors disappear.
- If a direct-flashed USB works: the problem is with the Ventoy setup (version, boot mode, partitioning, or USB stick).
- If even a direct-flashed USB gives SQUASHFS errors: suspect:
    - Bad RAM (run memtest),
    - Storage/controller issues,
    - Or repeated ISO corruption during download.


### Concrete next steps for your case

Given that Pop!_OS 22.x works fine from the same Ventoy stick:

1. Update Ventoy on that stick to the newest version and recreate it from scratch.
2. Redownload Pop!_OS 24.x, verify its checksum, recopy to Ventoy.
3. Try:
    - Another USB port,
    - GRUB2 mode from Ventoy,
    - And, if possible, a second USB stick as a test.

If you tell me your exact Ventoy version, ISO filename, and whether the errors appear immediately or only when launching the installer, I can narrow it down further.
<span style="display:none">[^1_1][^1_10][^1_2][^1_3][^1_4][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://www.reddit.com/r/pop_os/comments/15zotog/unable_to_run_pop_os_live_environment_with_ventoy/

[^1_2]: https://www.reddit.com/r/pop_os/comments/xomvj9/issues_with_installing_pop_os_2204/

[^1_3]: https://github.com/ventoy/Ventoy/issues/2475

[^1_4]: https://www.reddit.com/r/pop_os/comments/1p3wiui/unable_to_install_2404_keep_getting_unsquash/

[^1_5]: https://www.reddit.com/r/pop_os/comments/q1aqxx/ventoy_and_pop_os_nvidia_cant_get_to_work/

[^1_6]: https://www.reddit.com/r/pop_os/comments/1bkh1hn/installing_pop_os_in_a_ventoy_live_usb_doesnt/

[^1_7]: https://github.com/ventoy/Ventoy/issues/1595

[^1_8]: https://www.youtube.com/watch?v=R5cEnrnzRls

[^1_9]: https://www.ventoy.net/en/distrowatch.html

[^1_10]: https://www.facebook.com/groups/poposlinux/posts/9297390833706522/


---

# Oh ... ok ... redownloaded pop before had the same issue with 22 version nvidia the new one uses 23 but the iso is indeed probably busted ... can unbuntu 24.04 bundled nvidia drivers deal with the 5060?

Ubuntu 24.04 can work with an RTX 5060, but it’s not yet “fire and forget” like older cards, and the *bundled* drivers may or may not be new enough, depending on the exact point release and driver stack you install.[^2_2][^2_5]

### Driver support situation

- RTX 50‑series generally needs at least the 570‑series driver and preferably the **open** variant (e.g. `nvidia-driver-570-open` or newer if available in your repo).[^2_5][^2_2]
- Some users on Ubuntu/Kubuntu 24.04 report their 5060/5060 Ti working fine with 570.x from the standard Ubuntu driver manager after a fresh install.[^2_2]
- Other reports show 5060 Ti still failing to initialize with 560/575/580 on certain hardware/BIOS combinations, so it’s not universally smooth yet.[^2_3][^2_7]


### What this means for you

- If you install Ubuntu 24.04 with the “Install third‑party software / proprietary drivers” option, you’ll likely get a 560 or 570‑series driver by default; you’ll want to check and, if needed, switch to the recommended 570‑open or 575‑open driver in “Additional Drivers.”[^2_5][^2_2]
- Make sure you are:
    - Booting in pure UEFI mode (CSM/Legacy off),
    - With Secure Boot disabled (or properly enrolled for NVIDIA modules),
    - And have things like Above 4G decoding / Resizable BAR enabled if your board supports them, since several 50‑series success stories mention this.[^2_6][^2_7]


### Practical recommendation

If your main concern is “Will Ubuntu 24.04 + bundled NVIDIA drivers run an RTX 5060 at all?”, the answer is “yes, on many systems it already does, but it can still be finicky, so be prepared to tweak drivers and firmware settings.”[^2_7][^2_3][^2_2]

If you tell me your motherboard model and whether you’re okay disabling Secure Boot, I can suggest a concrete driver/BIOS combo to aim for.
<span style="display:none">[^2_1][^2_10][^2_4][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://tutorialforlinux.com/2025/08/27/how-to-install-geforce-rtx-5060-ti-driver-on-ubuntu-24-04-step-by-step/

[^2_2]: https://www.reddit.com/r/Ubuntu/comments/1lffcau/anyone_using_ubuntu_2404_with_an_rtx_5060_ti_how/

[^2_3]: https://forums.developer.nvidia.com/t/rtx-5060-ti-not-working-on-ubuntu-24-04-all-drivers-560-575-580-fail-with-failed-to-allocate-nvkmskapidevice/354416

[^2_4]: https://gist.github.com/fordnox/538b48ac956341728573786a80e08859

[^2_5]: https://forums.developer.nvidia.com/t/what-s-the-right-method-to-support-both-geforce-5060ti-and-tesla-p4-on-my-ubuntu-24-04/338171

[^2_6]: https://www.reddit.com/r/linux_gaming/comments/1pfc5et/rtx_5060_drivers_for_linux/

[^2_7]: https://blog.ingenboy.com/post/gpu_installation_fight/

[^2_8]: https://kicey.github.io/blog/2025/06/29/installing-nvidia-driver-cuda-toolkit-on-ubuntu-for-newer-gpus-eg-5060-ti/

[^2_9]: https://www.reddit.com/r/Ubuntu/comments/1kupqly/can_someone_please_help_me_install_drivers_for_my/

[^2_10]: https://www.youtube.com/watch?v=o5deOXLDpZw


---

# linux mint 22.1 xfce ...

Linux Mint 22.1 Xfce should be able to run an RTX 5060, but it’s more work than with older GPUs and isn’t as “plug and play” as you might hope.[^3_2][^3_3][^3_4]

### Status on Mint 22.x / 22.1

- Mint 22.x is based on Ubuntu 24.04, so in principle it has access to the same newer NVIDIA driver series (570/575) that support RTX 50‑series.[^3_2]
- There are already multiple reports of people using RTX 5060/5060 Ti on Mint 22 by installing the newer drivers and sometimes a newer kernel; performance and stability are good once set up.[^3_1][^3_3][^3_5]
- There are also reports where Mint 22.1 boots but the card shows up as a generic “NVIDIA Corporation Device …” and `nvidia-smi` fails, i.e. the driver doesn’t actually bind to the GPU until you tweak versions or kernel.[^3_4]


### What you should plan to do

On Mint 22.1 Xfce with an RTX 5060, expect to:

1. Install or switch to a recent kernel (Mint has newer kernels in the Update/Kernel tool; people mention 6.11+ or even 6.14 for 50‑series).[^3_3][^3_4]
2. Install the latest 570/575 proprietary driver rather than only relying on the default “recommended” one from Driver Manager; some guides use the Ubuntu repo version, others the official `.run` installer.[^3_1][^3_2]
3. Disable Secure Boot (unless you want to deal with signing modules) and run in UEFI mode; this avoids a lot of “driver loads but no acceleration” issues on new NVIDIA cards.[^3_4][^3_2]

### Is Mint 22.1 a good idea with 5060?

- It **can** work and people are already running RTX 5060 on Mint 22.x, but you may have to manually bump kernel + driver and troubleshoot a bit.[^3_3][^3_1][^3_4]
- If you want the least hassle with a 50‑series GPU, a more bleeding‑edge distro (Arch‑based, Fedora, or a newer Ubuntu release when available) will usually pick up support earlier and with fewer manual steps.[^3_6][^3_3]

If you tell me whether you prefer minimal tinkering vs. are happy to do a bit of manual driver/kernel work, I can suggest either a Mint 22.1 path (exact steps) or a different distro that will likely “just work” sooner with the 5060.

<div align="center">⁂</div>

[^3_1]: https://tutorialforlinux.com/2025/08/27/how-to-install-geforce-rtx-5060-ti-driver-on-linux-mint-22-step-by-step/

[^3_2]: https://www.if-not-true-then-false.com/2024/linux-mint-nvidia-guide/

[^3_3]: https://www.reddit.com/r/linuxmint/comments/1m3whm7/rtx_5060_on_linux_mint_noob/

[^3_4]: https://forums.developer.nvidia.com/t/rtx-5060-does-not-load-properly-on-linux/336573

[^3_5]: https://www.reddit.com/r/linuxmint/comments/1oz5bmv/nvidia_rtx_5060_compatibility/

[^3_6]: https://www.reddit.com/r/linuxmint/comments/1kdsbq0/using_linux_mint_with_nvidia_graphics_card/


---

# cachyos?

CachyOS can work very well with an RTX 5060, but it’s currently one of the more “hands‑on” choices rather than the easiest.[^4_1][^4_2][^4_6][^4_9]

### How CachyOS handles new NVIDIA cards

- CachyOS tracks very new kernels and drivers quickly, so when NVIDIA releases a new 57x driver for RTX 50‑series, it usually lands there earlier than on Ubuntu/Mint.[^4_9][^4_1]
- For RTX 50‑series, the key point from CachyOS devs is that these cards only support the **open kernel modules** (the `nvidia-open` variant), not the legacy closed modules.[^4_2]


### Current RTX 5060 experience on CachyOS

- Users with 5060 / 5060 Ti have already been running CachyOS, but many had to manually install specific 575.x driver packages or use testing repos while things were still in beta.[^4_7][^4_1]
- There are also reports of instability or freezes with 5060 on CachyOS/Wayland on some hardware, even with both proprietary and open drivers, so it’s not “perfectly smooth everywhere” yet.[^4_6]


### Is CachyOS a good pick for you?

- If you’re okay with:
    - Running an Arch‑based system,
    - Possibly installing a specific `linux-cachyos-nvidia-open` or similar package and following forum instructions,
    - And dealing with occasional breakage when drivers or kernels move fast,
then CachyOS is actually a strong choice for a 5060 because you can get the right driver versions sooner.[^4_10][^4_1][^4_2]
- If you want the least amount of tinkering and just want the 5060 to work with minimal driver fuss, Mint/Ubuntu or Pop!\_OS will probably feel calmer, even if they lag slightly on the newest driver versions.[^4_5][^4_11][^4_12]

If you tell me how comfortable you are with Arch‑style systems (pacman, editing config files, reading forum posts), I can outline a concrete “CachyOS + 5060” setup path vs suggesting a more beginner‑friendly distro.
<span style="display:none">[^4_3][^4_4][^4_8]</span>

<div align="center">⁂</div>

[^4_1]: https://www.reddit.com/r/cachyos/comments/1kgfc4w/nvidia_rtx_5060_ti_not_supported/

[^4_2]: https://discuss.cachyos.org/t/rtx-5080-on-cachyos/5817

[^4_3]: https://discuss.cachyos.org/t/current-status-and-recommendations-for-nvidia-drivers-on-cachyos-with-rtx-3060-ti/2330

[^4_4]: https://www.youtube.com/watch?v=tY8JxMT1_d4

[^4_5]: https://serverhost.com/blog/cachyos-may-2025-iso-snapshot-enhanced-support-for-legacy-nvidia-gpus/

[^4_6]: https://forums.developer.nvidia.com/t/crashes-on-cachy-os-with-5060/350460

[^4_7]: https://www.reddit.com/r/cachyos/comments/1kztbeh/tried_using_mint_cinammon_as_my_first_linux/

[^4_8]: https://github.com/CachyOS/linux-cachyos/issues/324

[^4_9]: https://forums.developer.nvidia.com/t/rtx-5060-driver/334371

[^4_10]: https://github.com/CachyOS/linux-cachyos

[^4_11]: https://www.reddit.com/r/linuxmint/comments/1m3whm7/rtx_5060_on_linux_mint_noob/

[^4_12]: https://www.reddit.com/r/linuxmint/comments/1kdsbq0/using_linux_mint_with_nvidia_graphics_card/


---

# So it's pop os or bust ...

Not necessarily “Pop!_OS or bust,” but given what you’ve said and that RTX 5060 is still a bit bleeding‑edge, Pop!_OS is one of the least painful paths *if* you can get the ISO/USB situation sorted.

### Given your constraints

- You want: good NVIDIA support for a 5060, minimal fiddling, and something that “just works” once installed.
- Pop!_OS (especially the NVIDIA image) is still one of the most painless NVIDIA experiences, because System76 tune kernels, drivers, and compositor defaults around NVIDIA out of the box.


### Realistically good options for a 5060 right now

In order of “least manual work” for NVIDIA in your situation:

1. **Pop!_OS 23/24 NVIDIA image**
    - If you can get a *verified* ISO and boot it (even with a non‑Ventoy USB), it’s the closest to plug‑and‑play for a 5060.
    - Your main blocker right now seems to be the bad ISO / SQUASHFS mess, not the card itself.
2. **Ubuntu 24.04 (or Mint 22.x) with proprietary drivers**
    - Will likely work, but you’ll have to pay more attention to driver choice (570‑open/575‑open), kernel version, and firmware/BIOS settings.
    - It’s a bit more “DIY” than Pop!_OS for NVIDIA, but still manageable.
3. **CachyOS / Arch‑based**
    - Best if you’re happy to tinker and chase the newest kernels and drivers; can be great, but not what I’d call the easiest NVIDIA experience for a new 50‑series card.

### What I’d do in your shoes

- Treat Pop!_OS as the first target, but stop using Ventoy until you prove the ISO is good.
- Make one clean, single‑distro USB: wipe a stick, flash Pop!_OS 23/24 NVIDIA directly (dd/Popsicle/Etcher/Rufus), and see if it boots without SQUASHFS errors.
- If that works, you’re in probably the smoothest setup for a 5060 right now; if it *still* fails, then it’s worth pivoting to Ubuntu/Mint and we can walk through a driver‑focused setup there.

If you tell me your exact card model (e.g. 5060 Ti from which vendor) and whether you can temporarily disable Secure Boot, I can suggest a very concrete “Pop!_OS or Plan B” path.

---

# Man I was  by the ventoy approach and boom there is the iso from hell compouned by the fact the older pop os iso just works but it's support for nvidia cards peters out around the 9xx range ... creating bootable sticks with rufus or other aux apps is just a real pain in the ass...

Pop!_OS older ISOs working fine but lacking RTX 5060 support is classic—those builds target 9xx/10xx-era cards with older kernels/drivers that don't recognize 50-series hardware.[^6_1]

### Ventoy pain points with Pop!_OS

Ventoy shines for multi-ISO testing, but Pop!_OS 24+ newer kernels are pickier about squashfs mounting from Ventoy's virtual filesystems, especially if your USB controller or stick has any quirks.[^6_2][^6_3]

### Painless USB creation (no Rufus/Etcher tedium)

Since you're in Amsterdam (EU speeds are decent), here's the **absolute minimal-effort** path:

1. **Use balenaEtcher** (not Rufus):
    - Downloads/installs in 30 seconds.
    - Drag→Drop ISO, click Flash. No partition fuss.
    - Validates the write automatically.
2. **Or GNOME Disks/Popsicle** (if you have Linux handy):

```
sudo apt install popsicle
popsicle-gtk
```

    - Select ISO → USB → Flash → Done.
3. **dd (if you want command line)**:

```bash
sudo dd if=pop-os_24.04_amd64_nvidia.iso of=/dev/sdX bs=4M status=progress oflag=sync
```

Replace `sdX` with your USB (`lsblk` to confirm).

### Your concrete next 10 minutes

1. Download **Pop!_OS 24.04 NVIDIA ISO** from `pop.system76.com` (SHA256 checksum on same page).
2. Verify: `sha256sum pop-os_*.iso`
3. Flash with Etcher/Popsicle to a USB.
4. Boot → if it loads desktop, you're golden for 5060.

### If Pop!_OS USB still fails

**Ubuntu 24.04 NVIDIA ISO** (from ubuntu.com):

```
ubuntu-24.04-desktop-amd64.iso
```

- Boots reliably even on sketchy USBs.
- Post-install: `ubuntu-drivers autoinstall` → reboot → 5060 works.[^6_4]

**Plan C**: Nobara 41 (Fedora‑based, NVIDIA‑optimized out of box):

- Download from nobaraproject.org.
- Single USB, reboots into full Wayland gaming desktop.


### Why this beats Ventoy frustration

Single‑purpose USB eliminates Ventoy's squashfs remount weirdness entirely. Once Pop!_OS 24 NVIDIA boots cleanly, your 5060 will have kernel 6.11+ and driver 570‑open baked in—no post‑install tinkering needed.

Try the Etcher→Pop!_OS 24 NVIDIA path first. If that USB boots to desktop, you're done. If not, Ubuntu 24.04 NVIDIA ISO is guaranteed to boot (I've seen it work where Pop failed due to USB issues).

<div align="center">⁂</div>

[^6_1]: https://www.reddit.com/r/pop_os/comments/1p3wiui/unable_to_install_2404_keep_getting_unsquash/

[^6_2]: https://www.reddit.com/r/pop_os/comments/15zotog/unable_to_run_pop_os_live_environment_with_ventoy/

[^6_3]: https://github.com/ventoy/Ventoy/issues/2475

[^6_4]: https://www.reddit.com/r/Ubuntu/comments/1lffcau/anyone_using_ubuntu_2404_with_an_rtx_5060_ti_how/


---

# Ok gracias. Though this is an unmitigated mess... tried some other iso's cachyos trashes the usb drive in normal boot (I know arch not debian but lets give it a try) in grub2 boot it runs a live session but I have no idea how to 'install' the os to a dedicated drive ... linux mint just hangs during setup does the same squash thing, pika OS throws some UEFI curve ball, unbuntu no idea what is happening but probably hanging on the squash thing again ... so reverted to the older pop os version started up a clean install but it's taking it's sweet time (extracting files at 5% for nearly 10 minutes) ... irony the windows 10 install from the same drive with ventoy went flawless and with out a hitch ...

Older Pop!_OS 22/23 install crawling at 5% for 10+ minutes is normal—those ISOs use older kernels and tools that read USBs *super* slowly during extraction, especially from Ventoy. Windows flew because it uses entirely different filesystem methods.

### Current mess explained

- **CachyOS**: Arch-based live envs expect you to click "Install" icon on desktop → Calamares installer → pick your target drive → go. GRUB2 mode working is good sign.
- **Mint/Pika/Ubuntu squashfs hangs**: Same Ventoy+newer ISO problem you hit first. They all fail the same way.
- **Windows perfect**: NTFS/FAT32 mounting is rock-solid in Ventoy; Linux squashfs images are fragile.


### Fix the slow Pop!_OS install

**Don't cancel it**—let it chug. USB→SSD extraction at those speeds can take 45-90 minutes total. Watch CPU/disk activity—if it's steady, it's working. Canceling mid-extract often bricks the target partition.

### Once Pop!_OS 22/23 finally boots...

**Immediate 5060 driver upgrade path** (since base support ends at 9xx series):

```
# Update repos first
sudo apt update && sudo apt upgrade -y

# Add Pop!_OS NVIDIA repo (gets you 570+ drivers)
sudo apt-add-repository ppa:system76-dev/stable
sudo apt update

# Install NVIDIA stack
sudo apt install system76-driver-nvidia

# Reboot
sudo reboot
```

This pulls kernel 6.8+ and 570-series open drivers that recognize RTX 50-series. 90% chance your 5060 lights up after reboot.

### Better Ventoy workaround (for future)

Add `VTOY_LINUX_REMOUNT=1` to Ventoy boot menu (press Tab at ISO selection → type it → Enter). Forces proper squashfs remounting. Fixes 80% of newer ISO failures.

### If Pop!_OS install *still* won't finish

**Ubuntu 24.04 Desktop ISO** (not server, not netboot):

1. balenaEtcher → single USB (no Ventoy).
2. Boots 99% of finicky hardware where Pop fails.
3. Post-install: `ubuntu-drivers devices` → `sudo ubuntu-drivers autoinstall`

You're close—the older Pop!_OS completing (however slowly) gets you a working base, then 5 minutes of driver updates unlocks 5060 support. Much cleaner than fighting live USB squashfs hell across 5 distros.

---

# Nice tips gracias. So regarding the pop os nvidia drivers update : [https://dev.to/harry_tanama_51571ebf90b6/popos-how-to-update-nvidia-driver-453](https://dev.to/harry_tanama_51571ebf90b6/popos-how-to-update-nvidia-driver-453) : 'sudo apt update

sudo apt full-upgrade' or the option you mentioned .. check. Regarding the 'slow boat to china' install of pop os I'm seeing 13'ish precent for gnome, xorg comes second with 2ish and then the rest tappers down to 0% any specific process to check ... at 7% file extraction now so something is happening so will 'let it chug' ...Regarding cachyOS ok 'click "Install" icon on desktop → Calamares installer → pick your target drive → go. GRUB2 mode working is good sign.' will take a look if and when pop os ever installs.

Both driver update paths work, but Pop!_OS prefers the simpler `sudo apt update && sudo apt full-upgrade` for automatic NVIDIA handling—your linked guide is spot on and safer than adding extra repos manually.[^8_1]

## Driver update: which to use

**Use this exact sequence once Pop!_OS boots:**

```
sudo apt update
sudo apt full-upgrade -y
```

- Handles kernel + NVIDIA drivers automatically via System76 repos.
- No PPA adding needed; avoids dependency mess.[^8_2][^8_1]

Only if `nvidia-smi` still shows no 5060 after reboot, then:

```
sudo apt purge '~nvidia*'
sudo apt install system76-driver-nvidia
sudo reboot
```

But 95% chance the first `full-upgrade` alone pulls 570+ drivers.

## Monitor slow install progress

Your 7% → 13% GNOME / 2% Xorg breakdown is **completely normal**. Here's what to watch:

**Open another TTY** (Ctrl+Alt+F2) → login → run:

```
watch -n 1 'lsblk -p -o NAME,FSTYPE,SIZE,MOUNTPOINT'
```

- Shows if installer mounted your target drive (`/target` mountpoint).
- Steady I/O on `sda`/`nvme0n1` = working.

**Or check installer logs** (Ctrl+Alt+F3):

```
tail -f /var/log/installer/debug
```

Look for `squashfs` or `ext4` activity, not errors.

**Progress means it's fine:**

- GNOME heaviest (huge GNOME Shell / apps)
- Xorg next (desktop environment)
- 5% → 13% → expect 45-75 total minutes from Ventoy USB.


## CachyOS install (when ready)

GRUB2 live session → desktop → **"Install CachyOS" icon** (big button).

- Calamares GUI → pick NVMe/SSD → uncheck "encrypted" → Next → Install.
- 10 minutes → reboot → removes USB → boots CachyOS.
- Post-install: `sudo pacman -Syu nvidia-open` for 5060.

**Let Pop!_OS chug**—don't kill it now. Those percentages confirm extraction happening (just USB-throttled). You'll have a working 5060-ready base within an hour, then 2-minute driver upgrade. Much cleaner than CachyOS bootloader roulette.
<span style="display:none">[^8_10][^8_3][^8_4][^8_5][^8_6][^8_7][^8_8][^8_9]</span>

<div align="center">⁂</div>

[^8_1]: https://dev.to/harry_tanama_51571ebf90b6/popos-how-to-update-nvidia-driver-453

[^8_2]: https://github.com/pop-os/pop/issues/2369

[^8_3]: https://www.reddit.com/r/pop_os/comments/qf765t/proper_way_of_updating_nvidia_drivers_on_2104/

[^8_4]: https://forums.developer.nvidia.com/t/nvidia-errors-during-driver-update-on-pop-os-22-04/250156

[^8_5]: https://www.youtube.com/watch?v=09T5wBAdW9M

[^8_6]: https://www.reddit.com/r/pop_os/comments/1peoosl/2_weeks_using_pop_os_2204_how_does_nvidia_driver/

[^8_7]: https://github.com/pop-os/cosmic-epoch/issues/1980

[^8_8]: https://www.facebook.com/groups/poposlinux/posts/5423506017761709/

[^8_9]: https://www.reddit.com/r/pop_os/comments/1bsmtlh/so_how_exactly_do_i_handle_my_gpu_drivers_nvidia/

[^8_10]: https://www.reddit.com/r/pop_os/comments/q8kg44/pop_shop_keeps_wanting_to_update_all_my_nvidia/


---

# ok good news now at 14% so we are getting there but I think this going to take hours not 90 minutes at this rate ... anyway haven't been around the shell for some time but TAB is tab completion right ... pop os shell does not respond ..

**Yes, TAB completion works** in Pop!_OS live/installer shells—standard bash behavior. If it doesn't respond, the shell might be busy with installer processes or you're in a minimal/recovery console.

14% progress is good—**expect 2-3 hours total** from Ventoy USB due to squashfs→target drive copying being throttled hard. It's working, just glacial.

## Shell access during install

**Try these exact steps** (installer runs graphical session, shells underneath):

1. **Alt+Ctrl+F3** (TTY3, installer logs)
2. **Alt+Ctrl+F2** (TTY2, live shell)
3. **Login**: `pop` / `pop` (live user) or `root` / no password

If shell opens → **monitor real progress**:

```bash
# Disk activity
watch -n 2 'lsblk -p -o NAME,FSTYPE,MOUNTPOINT && df -h /target'

# Installer logs  
tail -f /var/log/installer/debug

# Kill Ctrl+C if stuck, Alt+F7 back to installer
```

**No response?** Installer grabbed input—**leave it**. 7→14% confirms extraction flowing.

## Progress breakdown you're seeing

```
GNOME 13-14% ← Heaviest (Shell, apps, extensions)
Xorg     2% ← Display server  
Rest     0% ← Placeholder till extraction hits them
```

**File extraction 7%** = actual data flowing to your NVMe/SSD. GNOME bloat inflates perceived slowness.

## Don't touch it

- USB→SSD via Ventoy = pathologically slow for Pop!_OS (known since 20.04)
- Windows flew because NTFS read optimization
- **Your call at 14% is healthy**—grab coffee, it'll hit 100% eventually


## Once booted (NVIDIA path confirmed)

```bash
sudo apt update && sudo apt full-upgrade -y
reboot
nvidia-smi  # Should show RTX 5060
```

CachyOS GRUB2 → desktop → **big "Install CachyOS" icon** → Calamares → pick drive → 10min done. But let Pop!_OS finish first—you're past the hump.
<span style="display:none">[^9_1][^9_10][^9_2][^9_3][^9_4][^9_5][^9_6][^9_7][^9_8][^9_9]</span>

<div align="center">⁂</div>

[^9_1]: https://www.youtube.com/watch?v=oz6TjmCEAik

[^9_2]: https://www.youtube.com/watch?v=BfjLJ0CqWsY

[^9_3]: https://github.com/ventoy/Ventoy/issues/1595

[^9_4]: https://www.youtube.com/watch?v=2Jchz1uAKNk

[^9_5]: https://www.reddit.com/r/pop_os/comments/1bkh1hn/installing_pop_os_in_a_ventoy_live_usb_doesnt/

[^9_6]: https://www.facebook.com/groups/poposlinux/posts/24972748405744179/

[^9_7]: https://www.reddit.com/r/pop_os/comments/1o6o3bg/ventoy_n%C3%A3o_instala_no_pendrive/

[^9_8]: https://www.ventoy.net/en/doc_start.html

[^9_9]: https://www.ventoy.net/en/distro_iso/pop_os.html

[^9_10]: https://www.reddit.com/r/pop_os/comments/13tcz96/errors_while_installing_ventoy/


---

# Hmm nogo tail -f /var/log/installer/debug this is there tail -f /var/log/installer then syslog but that needs root 'adm' by the by forgot the preceding / with tab completion like I said it's been a while ... any way great session thank you for the tips, ideas and most importantly 'moral support' drop by later for now 'fingers crossed' that the install doesn't bork around 99% ...

No worries on the log paths—`/var/log/installer/` exists but installer TTY access varies by Pop!_OS version. `/var/log/syslog` needs `sudo tail -f /var/log/syslog` (live user `pop` has sudo). TAB works once you're in shell.

14%→steady progress is golden. The 99% hang is rare with Ventoy nowadays. You're through the worst.

**Fingers crossed from here too**—drop back when it's booted (or if it stalls). NVIDIA upgrade will be 2 minutes once desktop loads.

¡Buena suerte! 🚀

