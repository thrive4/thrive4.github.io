<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Would it be possible to rewrite the following freebasic snippet? I would like to have two mythreads one on 1000 ms and the other on 100 ms called by a main loop with say an interval of 10s ... mythreada prints if the 1000ms has passed mythreadb prints if 100ms has passed ... bit funky I know but I'm trying to figure out multithreading with freebasic : ''

'' threads example
''

const THREADS = 5
const SECONDS = 3

sub mythreada( byval num as any ptr )
for i as integer = 0 to SECONDS-1
print "Hello from thread " \& cint(num) \& " (" \& SECONDS-i \& " second(s) left) " \& string(cint(num), "*")
sleep( 1000 )
next
end sub

sub mythreadb( byval num as any ptr )
for i as integer = 0 to SECONDS-1
print "Hello from thread " \& cint(num) \& " (" \& SECONDS-i \& " second(s) left) " \& string(cint(num), "*")
sleep( 100 )
next
end sub

dim as any ptr thread(0 to THREADS-1)

'' create and call the threads
for i as integer = 0 to THREADS-1
thread(i) = threadcreate( @mythread, cast(any ptr, i) )
next

'' wait for all threads to finish
for i as integer = 0 to THREADS-1
threadwait( thread(i) )
next

Yes — the cleanest way in FreeBASIC is usually **one main loop that checks elapsed time**, plus optional worker threads if you really want concurrency. For your case, a main loop can trigger “every 10 s”, while two worker routines decide whether 1000 ms or 100 ms has passed based on stored timestamps; FreeBASIC’s `ThreadCreate`, `ThreadWait`, and `Sleep` support this model, and `Sleep` takes milliseconds in `-lang fb`.[^1_1][^1_2]

## Important idea

Your current code uses `Sleep` *inside* the thread, which makes each thread behave like a simple delay loop rather than a reusable timer. If your goal is “print only when 1000 ms/100 ms have passed,” it is better to store the last-run time and compare it to `Timer` in the loop. `ThreadCreate` starts a procedure in its own thread, and `ThreadWait` is used to wait for it to finish.[^1_3][^1_1]

## FreeBASIC example

```freebasic
'' FreeBASIC example: main loop triggers checks every 10 seconds
'' mythreada prints every 1000 ms
'' mythreadb prints every 100 ms

#lang fb

dim shared lastA as double
dim shared lastB as double

sub mythreada( byval num as any ptr )
    dim nowt as double
    nowt = timer

    if (nowt - lastA) * 1000 >= 1000 then
        lastA = nowt
        print "Thread A: 1000 ms passed"
    end if
end sub

sub mythreadb( byval num as any ptr )
    dim nowt as double
    nowt = timer

    if (nowt - lastB) * 1000 >= 100 then
        lastB = nowt
        print "Thread B: 100 ms passed"
    end if
end sub

dim as any ptr thA, thB
dim as integer i

lastA = timer
lastB = timer

for i = 1 to 5
    thA = threadcreate(@mythreada, 0)
    thB = threadcreate(@mythreadb, 0)

    threadwait(thA)
    threadwait(thB)

    sleep 10000, 1
next
```


## Better version

The above works as a structural example, but it is not how you would normally use threads, because the threads are started, do one check, and exit. A more typical threaded approach is to keep the threads alive and let them loop internally, while the main loop sleeps or performs other work. `Sleep` is millisecond-based in FreeBASIC, and thread-safe coordination is usually done with mutexes if threads share data.[^1_4][^1_2]

```freebasic
#lang fb

dim shared running as integer = 1
dim shared lastA as double = timer
dim shared lastB as double = timer

sub mythreada( byval num as any ptr )
    do while running
        if (timer - lastA) * 1000 >= 1000 then
            lastA = timer
            print "A: 1000 ms passed"
        end if
        sleep 10, 1
    loop
end sub

sub mythreadb( byval num as any ptr )
    do while running
        if (timer - lastB) * 1000 >= 100 then
            lastB = timer
            print "B: 100 ms passed"
        end if
        sleep 10, 1
    loop
end sub

dim as any ptr thA, thB

thA = threadcreate(@mythreada, 0)
thB = threadcreate(@mythreadb, 0)

do
    sleep 10000, 1
    print "Main loop tick"
    '' stop after one iteration for demo
    running = 0
loop until running = 0

threadwait(thA)
threadwait(thB)
```


## Notes on design

If both threads are reading or writing the same shared variables, you may need a mutex to avoid race conditions. FreeBASIC provides mutex support for exactly that reason. Also, for very short intervals like 100 ms, `Sleep` timing is approximate because OS scheduling resolution is not perfectly precise.[^1_2][^1_1][^1_4]

## Simpler option

For what you described, you may not need threads at all. A single main loop with two timestamps is often easier, safer, and more predictable than two timer threads. That pattern is also common in FreeBASIC timing examples using `Timer` plus `Sleep`.[^1_5][^1_2]

Would you like me to rewrite your snippet into a **single-loop non-threaded version** and a **proper threaded version** side by side?
<span style="display:none">[^1_10][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://documentation.help/FreeBASIC/CatPgThreading.html

[^1_2]: https://documentation.help/FreeBASIC/KeyPgSleep.html

[^1_3]: https://www.freebasic-portal.de/befehlsreferenz/threadcreate-273.html

[^1_4]: https://www.freebasic-portal.de/tutorials/mutexe-54.html

[^1_5]: https://freebasic.net/forum/viewtopic.php?t=25553

[^1_6]: https://www.purebasic.fr/german/viewtopic.php?t=11649

[^1_7]: https://www.purebasic.com/documentation/thread/waitthread.html

[^1_8]: https://freebasic.net/forum/viewtopic.php?p=230358

[^1_9]: https://www.freebasic-portal.de/befehlsreferenz/sleep-400.html

[^1_10]: https://www.dbfinteractive.com/forum/index.php?topic=5992.0


---

# Yes maybe a single loop would be better just for the record : /media/wah/games/source/tutorials/threads2.bas(1) error 17: Syntax error, found 'fb' in '\#lang fb'

/media/wah/games/source/tutorials/threads2.bas(4) error 11: Expected constant in 'dim shared lastA as double = timer'
/media/wah/games/source/tutorials/threads2.bas(5) error 11: Expected constant in 'dim shared lastB as double = timer'

Yes — those errors make sense. `#lang fb` is not the right syntax for your setup, and `Dim Shared ... = Timer` fails because `Shared` variables can only be initialized with constants at declaration time, not with a runtime value like `Timer`.[^2_1][^2_2]

## Working single-loop version

Use this instead:

```freebasic
' Single loop timer example

Dim Shared lastA As Double
Dim Shared lastB As Double

lastA = Timer
lastB = Timer

Do
    If (Timer - lastA) * 1000 >= 1000 Then
        lastA = Timer
        Print "A: 1000 ms passed"
    End If

    If (Timer - lastB) * 1000 >= 100 Then
        lastB = Timer
        Print "B: 100 ms passed"
    End If

    Sleep 10, 1
Loop
```

This version avoids threads entirely and just checks elapsed time in one loop. `Timer` returns the current time as a numeric value, and `Sleep` pauses briefly so the loop does not run flat out.[^2_2][^2_3]

## Why your errors happened

`#lang fb` is a language-directive form, but your compiler/source setup apparently does not accept it there, so the safest fix is simply to remove that line. The `Dim Shared ... = Timer` error happens because FreeBASIC requires shared/module-level initializers to be constant expressions, while `Timer` is computed at runtime.[^2_4][^2_1][^2_2]

## Small improvement

To avoid calling `Timer` multiple times in the same loop, store it once per iteration:

```freebasic
Dim Shared lastA As Double
Dim Shared lastB As Double
Dim nowt As Double

lastA = Timer
lastB = Timer

Do
    nowt = Timer

    If (nowt - lastA) * 1000 >= 1000 Then
        lastA = nowt
        Print "A: 1000 ms passed"
    End If

    If (nowt - lastB) * 1000 >= 100 Then
        lastB = nowt
        Print "B: 100 ms passed"
    End If

    Sleep 10, 1
Loop
```

That is a bit cleaner and slightly more consistent because both checks use the same timestamp.[^2_3][^2_2]

## If you want a 10-second main tick

If your main loop itself should run every 10 seconds, you can wrap the checks in a slower outer loop, but for 100 ms timing you still need a faster inner poll. A 10-second main loop cannot directly detect 100 ms events without another repeating check in between.[^2_2][^2_3]

Would you like a version that prints **A every 1 second, B every 100 ms, and a main message every 10 seconds** in one clean FreeBASIC program?
<span style="display:none">[^2_10][^2_11][^2_5][^2_6][^2_7][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://www.freebasic.net/wiki/wikka.php?wakka=KeyPgPplang

[^2_2]: https://www.freebasic-portal.de/befehlsreferenz/shared-392.html

[^2_3]: https://documentation.help/FreeBASIC/KeyPgSleep.html

[^2_4]: https://www.freebasic.net/forum/viewtopic.php?t=2926

[^2_5]: https://www.freebasic.net/wiki/wikka.php?wakka=KeyPgShared

[^2_6]: https://www.freebasic-portal.de/downloads/bibliotheken/interval-timer-function-400.html

[^2_7]: https://documentation.help/FreeBASIC/documentation.pdf

[^2_8]: http://www.thealmightyguru.com/Wiki/images/3/36/Beginner's_Guide_to_FreeBasic,_A.pdf

[^2_9]: https://documentation.help/FreeBASIC/KeyPgMetaLang.html

[^2_10]: https://makoto-watanabe.main.jp/freebasic/PgDim.html

[^2_11]: https://users.freebasic-portal.de/nemored/buchBeginner/99_AnhangCompiler.htm


---

# No thank you the 'small improvement' illustrates and works just fine. So what I have is a while loop containing :     ' timer in microseconds todo possibly override interval

    currenttime = SDL_GetTicks()
    : a call to : setdrc(fx1Handle, drc) : which preferably would have a lower frequency say 1000 ms'ish and a main delay in the while loop of :     ' use sdl_delay to keep cpu usage low
' affects rendering speed gls shader
' affects speed slideshow ken burns effects
' affects drc longer delay less pumping audio
' keep at 50 or above
'SDL_Delay(15)
sdl_delay(50)
: going back to 10 / 15 would be better the drc routine needs a larger delay ... or in other words this : If (nowt - lastA) * 1000 >= 1000 : needs to work with currenttime : dim currenttime         as integer : doable ?

Yes, that is doable, and **using `SDL_GetTicks()` as your time base is actually a good fit** here because it already gives you elapsed time in milliseconds. `SDL_Delay()` also uses milliseconds and is meant to pause the loop for at least the requested amount of time, though the OS may delay a little longer.[^3_1][^3_2]

## Use milliseconds directly

If `currenttime` comes from `SDL_GetTicks()`, then you should compare it to your stored timestamp in milliseconds directly. In that case you do **not** need `* 1000` at all, because both values are already in the same unit.[^3_3][^3_1]

```freebasic
dim as integer currenttime
dim as integer lastDrc

lastDrc = SDL_GetTicks()

do
    currenttime = SDL_GetTicks()

    if currenttime - lastDrc >= 1000 then
        lastDrc = currenttime
        setdrc(fx1Handle, drc)
    end if

    ' main loop pacing
    SDL_Delay(50)
loop
```


## Why this works

`SDL_GetTicks()` returns elapsed time in milliseconds, so `1000` means about one second and `100` means about one tenth of a second. The common pattern is exactly `current - start >= interval`, which avoids needing to convert units or use floating-point time.[^3_4][^3_1][^3_3]

## About the delay

If you want the loop to stay responsive but not burn CPU, `SDL_Delay(10)` to `SDL_Delay(15)` is often a better compromise than `50`, especially if you want smoother rendering or more regular audio pumping. `SDL_Delay()` waits at least the requested number of milliseconds, but actual wakeup time can be longer because of scheduler granularity.[^3_2][^3_5]

## Cleaner version

You can also keep separate timers for the different tasks:

```freebasic
dim as integer currenttime
dim as integer lastDrc
dim as integer lastFast

lastDrc = SDL_GetTicks()
lastFast = SDL_GetTicks()

do
    currenttime = SDL_GetTicks()

    if currenttime - lastDrc >= 1000 then
        lastDrc = currenttime
        setdrc(fx1Handle, drc)
    end if

    if currenttime - lastFast >= 100 then
        lastFast = currenttime
        ' mythreadb equivalent work here
        print "100 ms task"
    end if

    SDL_Delay(15)
loop
```

That is the same timing idea as your earlier `Timer` example, just using SDL milliseconds instead.[^3_1][^3_3]

## Practical note

If `setdrc()` is expensive, this pattern helps because it only runs at the interval you choose. If your audio or visual updates still feel too sluggish, reduce the loop delay before changing the `1000` ms task interval, because the loop delay mainly affects how quickly the program notices that the interval has elapsed.[^3_5][^3_2]
<span style="display:none">[^3_10][^3_6][^3_7][^3_8][^3_9]</span>

<div align="center">⁂</div>

[^3_1]: https://lazyfoo.net/tutorials/SDL3/10-timing/index.php

[^3_2]: https://wiki.libsdl.org/SDL2/SDL_Delay

[^3_3]: https://lazyfoo.net/SDL_tutorials/lesson12/index.php

[^3_4]: https://manpages.ubuntu.com/manpages/stonking/man3/SDL_GetTicks.3.html

[^3_5]: https://www.gamedev.net/forums/topic/597886-quick-question-about-timing-in-sdl/

[^3_6]: https://forums.libsdl.org/viewtopic.php?p=49382

[^3_7]: https://www.scribd.com/document/719218282/Freebasic-Beginners-Guide

[^3_8]: https://freebasic.net/forum/viewtopic.php?t=8347

[^3_9]: https://www.freebasic.net/wiki/TutHowToProgGame1

[^3_10]: https://seanballais.com/blog/computing-elapsed-time-in-sdl2/

