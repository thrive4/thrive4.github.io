<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# I have downloaded ComfyUI_windows_portable_nvidia.zip what do I need in terms of models sd, flux, etc (I would like to manually add those) ...

You need to add at least one base model (SD, Flux, etc.) plus its required “companion” files into the correct ComfyUI folders before you’ll see anything usable in the UI.[^1_8]

Below is the minimal, practical setup for the most common choices.

***

## 1. Folder locations you’ll use

Inside your `ComfyUI_windows_portable_nvidia` folder you should see a `ComfyUI\models` directory with subfolders like:[^1_6][^1_8]

- `ComfyUI\models\checkpoints` – classic Stable Diffusion 1.x/2.x and SDXL checkpoints (`*.safetensors`, `*.ckpt`)
- `ComfyUI\models\vae` – VAE files (`*.safetensors`, `*.pt`, sometimes `*.sft`)
- `ComfyUI\models\unet` – UNet-only models such as FLUX[^1_6]
- `ComfyUI\models\clip` or `ComfyUI\models\text_encoders` – text encoders (CLIP, T5, etc.)[^1_4][^1_6]
- `ComfyUI\models\loras` – LoRA / LyCORIS, if you plan to use them

You will manually drop model files into these folders, then restart ComfyUI so it detects them.[^1_6]

***

## 2. Easiest starting point: SD 1.5

If you just want to get generating images quickly, add a Stable Diffusion 1.5 model:

1. Download an SD 1.5 checkpoint (e.g. “v1-5-pruned-emaonly.safetensors”) from a reputable source (Hugging Face, Civitai).
2. Put it in:
`ComfyUI\models\checkpoints\your_sd15_model.safetensors`.[^1_6]
3. (Optional) Download a matching SD 1.5 VAE (e.g. “vae-ft-mse-840000-ema-pruned.safetensors”) and place it in:
`ComfyUI\models\vae\your_sd15_vae.safetensors`.[^1_9]

With just that, you can use any basic SD1.5 workflow in ComfyUI.[^1_9]

***

## 3. Using SDXL instead of SD 1.5

If your GPU has ≥8 GB VRAM (12 GB recommended), you can add SDXL:[^1_9]

1. Download an SDXL base model (e.g. `sdxl_base_1.0.safetensors`).
2. Put it in:
`ComfyUI\models\checkpoints\sdxl_base_1.0.safetensors`.[^1_9]
3. Download an SDXL VAE (often bundled or separate) and place it in:
`ComfyUI\models\vae\sdxl_vae.safetensors`.[^1_9]

Many SDXL ComfyUI workflows expect the base in `checkpoints` and will let you choose the VAE node explicitly.[^1_6]

***

## 4. Adding FLUX models (Flux.1)

Flux is more modular: you need a UNet, text encoders, and a VAE.[^1_4][^1_6]

Typical setup (for Flux.1 “dev” or “schnell”):

1. **UNet (main Flux model)**
    - Download a Flux model file, e.g. `flux1-dev.safetensors` or `flux1-schnell.safetensors` (from Black Forest Labs or mirrored repos).[^1_4][^1_6]
    - Put it in:
`ComfyUI\models\unet\flux1-dev.safetensors`.[^1_6]
2. **Text encoders (CLIP + T5)**
    - Download Flux text encoder files such as `clip_l.safetensors` and `t5xxl_fp16.safetensors` or fp8 variants, from a Flux text-encoder repo.[^1_4]
    - Put them in:
`ComfyUI\models\text_encoders\` or, in some older guides, `models\clip\` (check the workflow’s node names; the official examples now prefer `text_encoders`).[^1_4][^1_6]
3. **VAE**
    - Download the VAE (often a file named `ae.sft` or similar).[^1_4][^1_6]
    - Place it in:
`ComfyUI\models\vae\ae.sft`.[^1_4]
4. Load a Flux-compatible workflow (from the official ComfyUI Flux examples or tutorial authors), and in the nodes:
    - Select your Flux UNet in the “Flux / Low Diffusion” node.[^1_4]
    - Select the text encoders in the dual-CLIP/Text Encoder node.
    - Select the VAE node pointing to `ae.sft`.[^1_4]

***

## 5. Optional: LoRAs, embeddings, etc.

Once SD or Flux works, you can optionally add:

- **LoRAs** – put them in `ComfyUI\models\loras\`, then use a LoRA loader node in the workflow.
- **Textual inversions/embeddings** – usually go under `models\embeddings` if used by your workflow.

Paths can differ slightly between packs, but the `models` subfolders above are the standard layout for ComfyUI.[^1_8][^1_6]

***

## 6. What you specifically “need”

At absolute minimum, to make images:

- One **base model**:
    - Either SD 1.5 or SDXL (single checkpoint in `checkpoints`)[^1_9]
    - Or a Flux model (UNet in `unet` + text encoders + VAE)[^1_6][^1_4]
- A **workflow** that matches that model type (SD workflow vs Flux workflow).[^1_6]

If you tell me:

- Your GPU model and VRAM size, and
- Whether you prefer SD (more models, lighter) or Flux (newer, heavier),

I can give you a very concrete, step‑by‑step “download this, place it here, use this workflow” tailored to your setup.
<span style="display:none">[^1_1][^1_10][^1_2][^1_3][^1_5][^1_7]</span>

<div align="center">⁂</div>

[^1_1]: https://docs.comfy.org/installation/system_requirements

[^1_2]: https://www.youtube.com/watch?v=Xvss-1CclBw

[^1_3]: https://github.com/comfyanonymous/ComfyUI/wiki/Which-GPU-should-I-buy-for-ComfyUI

[^1_4]: https://www.youtube.com/watch?v=P1uDOhUTrqw

[^1_5]: https://docs.comfy.org/installation/desktop/windows

[^1_6]: https://stable-diffusion-art.com/flux-comfyui/

[^1_7]: https://www.youtube.com/watch?v=xgn8H60bbDg

[^1_8]: https://docs.comfy.org/installation/comfyui_portable_windows

[^1_9]: https://comfyui-wiki.com/en/install/install-comfyui/gpu-buying-guide

[^1_10]: https://www.reddit.com/r/StableDiffusion/comments/1eiowqp/quick_windows_instructions_for_using_flux_offline/


---

# MSI GeForce RTX 5060 8G VENTUS 2X OC lets start with something that is relatively easy to add

With an RTX 5060 8 GB, the easiest and most forgiving starting point is classic Stable Diffusion 1.5 at 512×512 or 768×768.[^2_2]

### What to install first

1. **Base model: SD 1.5**
    - Download a clean SD 1.5 checkpoint (e.g. `v1-5-pruned-emaonly.safetensors`) from a reputable source (Hugging Face / Civitai).
    - Put it in:
`ComfyUI_windows_portable_nvidia\ComfyUI\models\checkpoints\sd15.safetensors`.
SD 1.5 is specified as needing only 6–8 GB VRAM, which matches your card well.[^2_2]
2. **VAE for SD 1.5 (optional but recommended)**
    - Download a matching VAE, for example `vae-ft-mse-840000-ema-pruned.safetensors`.
    - Put it in:
`ComfyUI_windows_portable_nvidia\ComfyUI\models\vae\sd15_vae.safetensors`.
The same reference lists a separate VAE for SD models and notes better quality with a good VAE.[^2_2]
3. **Use a simple SD1.5 workflow**
    - Start ComfyUI, open a basic SD 1.5 text‑to‑image workflow (the default examples or any simple community one).
    - In the checkpoint loader node, select `sd15.safetensors`.
    - If there is a VAE node, select `sd15_vae.safetensors`.

### Settings that will “just work” on 8 GB

- Resolution: **512×512** or **640×640** to start; 768×768 is usually still fine on 8 GB.[^2_5][^2_2]
- Batch size: 1.
- Steps: 20–30.
- Sampler: anything basic (Euler, DPM++ 2M, etc.).

This will give you stable, fast generations and is much less fiddly than starting with Flux or SDXL on 8 GB.[^2_4][^2_2]

***

If you like, next step after this works smoothly would be:

- Add **SDXL base** (heavier but still feasible on 8 GB with moderate resolutions), or
- A **Flux “schnell” / low‑VRAM variant**, but we’ll need more careful settings there.[^2_2]
Tell me once SD 1.5 is running, and I can walk you through “next level” models tailored to your 8 GB card.
<span style="display:none">[^2_1][^2_10][^2_3][^2_6][^2_7][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://www.youtube.com/watch?v=n4vEshC9EO4

[^2_2]: https://comfyui-wiki.com/en/install/install-comfyui/gpu-buying-guide

[^2_3]: https://www.reddit.com/r/comfyui/comments/1ltjo2y/5060_ti_16gb_for_starter_gpu/

[^2_4]: https://www.youtube.com/watch?v=cqBwhpcNGF0

[^2_5]: https://www.reddit.com/r/comfyui/comments/1m07yq7/rtx_5060_8gb/

[^2_6]: https://docs.comfy.org/installation/system_requirements

[^2_7]: https://www.youtube.com/watch?v=hcIw4Btk3Cw

[^2_8]: https://github.com/comfyanonymous/ComfyUI/discussions/6643

[^2_9]: https://github.com/Comfy-Org/ComfyUI/discussions/6643

[^2_10]: https://www.facebook.com/groups/comfyui/posts/721736477265722/


---

# So download this : [https://huggingface.co/stablediffusiontutorials/stable-diffusion-v1.5/blob/main/v1-5-pruned-emaonly.safetensors](https://huggingface.co/stablediffusiontutorials/stable-diffusion-v1.5/blob/main/v1-5-pruned-emaonly.safetensors) : and this : [https://huggingface.co/stabilityai/sd-vae-ft-mse-original/blob/main/vae-ft-mse-840000-ema-pruned.safetensors](https://huggingface.co/stabilityai/sd-vae-ft-mse-original/blob/main/vae-ft-mse-840000-ema-pruned.safetensors) ?

Yes, those two files are exactly what you want for an easy SD 1.5 setup.

Here’s what to do step‑by‑step:

1. **Download the base model**
    - URL you pasted (v1‑5‑pruned‑emaonly.safetensors) is a correct SD 1.5 checkpoint.
    - Save it as (name doesn’t really matter, just keep the `.safetensors` extension):
`ComfyUI_windows_portable_nvidia\ComfyUI\models\checkpoints\v1-5-pruned-emaonly.safetensors`.[^3_5][^3_6]
2. **Download the VAE**
    - URL you pasted (vae‑ft‑mse‑840000‑ema‑pruned.safetensors) is the standard SD 1.5 VAE.
    - Save it to:
`ComfyUI_windows_portable_nvidia\ComfyUI\models\vae\vae-ft-mse-840000-ema-pruned.safetensors`.[^3_4][^3_5]
3. **Restart ComfyUI and select them**
    - Start ComfyUI (or restart if it was open).
    - Open a simple SD 1.5 text‑to‑image workflow.
    - In the **CheckpointLoader** node, pick `v1-5-pruned-emaonly.safetensors` from the dropdown.
    - In the **VAE** node (if present), select `vae-ft-mse-840000-ema-pruned.safetensors`.

After that you can generate at 512×512 with batch size 1 and it should work fine on your RTX 5060 8G.[^3_4][^3_5]
<span style="display:none">[^3_1][^3_10][^3_2][^3_3][^3_7][^3_8][^3_9]</span>

<div align="center">⁂</div>

[^3_1]: https://github.com/comfyanonymous/ComfyUI/discussions/7837

[^3_2]: https://github.com/comfyanonymous/ComfyUI/issues/7049

[^3_3]: https://forum.comfy.org/t/the-latest-comfyui-cannot-load-sd1-5-how-to-solve-it/929

[^3_4]: https://comfyui.dev/docs/guides/Checkpoints/v1-5-pruned-emaonly-fp16-safetensors/

[^3_5]: https://www.reddit.com/r/StableDiffusion/comments/1ab6yrn/comfyui_doesnt_work_am_i_missing_something/kjn49pj/

[^3_6]: https://github.com/Comfy-Org/ComfyUI/issues/7049

[^3_7]: https://huggingface.co/Comfy-Org/stable-diffusion-v1-5-archive/blob/main/v1-5-pruned-emaonly-fp16.safetensors

[^3_8]: https://www.reddit.com/r/StableDiffusion/comments/1ab6yrn/comfyui_doesnt_work_am_i_missing_something/

[^3_9]: https://www.youtube.com/watch?v=SfeCRrcLVNU

[^3_10]: https://www.reddit.com/r/comfyui/comments/1k2mv4p/can_someone_please_make_a_comparison_of/

