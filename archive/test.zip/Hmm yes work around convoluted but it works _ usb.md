<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Hmm yes work around convoluted but it works : ' use .m3u or .pls

if instr(dummy, ".m3u") <> 0 or instr(dummy, ".pls") <> 0 then
if FileExists(dummy) then
'nop
else
logentry("fatal", dummy + " file does not exist or possibly use full path to file")
end if
listnr = getmp3playlist(dummy, listtype)
logentry("notice", "parsing and playing playlist " + filename)
end if

' search with query and export .m3u hybrid nix windows
'if instr(dummy, ":") <> 0 and len(command(2)) <> 0  then
' might work needs validation
'if len(dummy) <> 0 and len(command(2)) <> 0 then
if instr(command(2), ".m3u") = 0 and instr(command(2), ".pls") = 0 then
if (left(dummy, 1) = "/" or instr(dummy, ":") <> 0) and len(command(2)) <> 0 then
select case command(2)
case "artist"
case "title"
case "album"
case "year"
case "genre"
case else
logentry("fatal", "unknown tag '" \& command(2) \& "' valid tags artist, title, album, genre and year")
end select
' scan and search nr results overwritten by getmp3playlist
listnr = exportm3u(dummy, "*.mp3", "m3u", "exif", command(2), command(3))
if listnr < 2 then
logentry("fatal", "no matches found for " + command(3) + " in " + command(2))
else
listnr = getmp3playlist(exepath + pathchar + command(3) + ".m3u", listtype)
end if
end if
end if

Your latest guard is much closer, but there are still two portability traps in it: `COMMAND()` argument parsing and using `instr()` to detect file types by substring. FreeBASIC’s `COMMAND()` returns shell-split arguments, and quoted text is preserved as one argument, so any space or shell expansion can still shift positions unexpectedly.[^1_1][^1_2]

## What your code is doing well

Using:

```basic
if instr(dummy, ".m3u") <> 0 or instr(dummy, ".pls") <> 0 then
```

is a practical way to branch into playlist mode, and `FileExists(dummy)` is the right kind of check for a concrete file path. Also, checking `left(dummy, 1) = "/" or instr(dummy, ":") <> 0` is a reasonable cross-platform heuristic for “looks like an absolute path”.[^1_2][^1_3][^1_4]

## The remaining weakness

This part is still fragile:

```basic
if instr(command(2), ".m3u") = 0 and instr(command(2), ".pls") = 0 then
```

because `command(2)` is not guaranteed to be the tag argument in every invocation, especially if the shell or wrapper script changes the argument layout. In your own debug example, the parser clearly saw `command(2) = "/"`, which means the positional interpretation has already drifted.[^1_1][^1_2]

## Better structure

You’ll get more reliable behavior if you classify the input once, then branch:

- If `dummy` ends in `.m3u` or `.pls`, treat it as a playlist file.
- Else, treat `dummy` as a source directory and `command(2)` as the tag only if it matches one of the allowed tags.
- Do not reuse `command(2)` as both “tag” and “file test subject” in different branches.

A cleaner pattern is:

```basic
dim as string arg1 = command(1)
dim as string arg2 = command(2)
dim as string arg3 = command(3)

if right(lcase(dummy), 4) = ".m3u" or right(lcase(dummy), 4) = ".pls" then
    if FileExists(dummy) then
        listnr = getmp3playlist(dummy, listtype)
        logentry("notice", "parsing and playing playlist " + dummy)
    else
        logentry("fatal", dummy + " file does not exist or possibly use full path to file")
    end if
else
    select case lcase(arg2)
    case "artist", "title", "album", "year", "genre"
        if (left(dummy, 1) = "/" or instr(dummy, ":") <> 0) then
            listnr = exportm3u(dummy, "*.mp3", "m3u", "exif", arg2, arg3)
            if listnr < 2 then
                logentry("fatal", "no matches found for " + arg3 + " in " + arg2)
            else
                listnr = getmp3playlist(exepath + pathchar + arg3 + ".m3u", listtype)
            end if
        end if
    case else
        logentry("fatal", "unknown tag '" & arg2 & "' valid tags artist, title, album, genre and year")
    end select
end if
```


## One important improvement

Use `right(lcase(dummy), 4)` or `right(lcase(dummy), 3)` instead of `instr()` for extensions. `instr()` matches anywhere in the string, so a path like `"/tmp/pls_backup/music"` could falsely look like a playlist. Extension checks are more precise and make the logic easier to reason about.[^1_3][^1_4]

## Recommended rule

Treat path detection, file-type detection, and tag validation as three separate checks. That keeps Windows/Unix compatibility intact and avoids the “special commandline parsing” problem you’re seeing from accidental argument reuse.[^1_2][^1_1]
<span style="display:none">[^1_10][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://freebasic.net/wiki/KeyPgCommand

[^1_2]: https://documentation.help/FreeBASIC/KeyPgCommand.html

[^1_3]: https://documentation.help/FreeBASIC/KeyPgFileexists.html

[^1_4]: https://www.freebasic.net/wiki/wikka.php?wakka=KeyPgFileexists

[^1_5]: https://www.autoitscript.com/forum/topic/178477-fileexists-like-function-that-returns-the-actual-path/

[^1_6]: https://www.freebasic.net/forum/viewtopic.php?t=12134

[^1_7]: https://ribbit.konomi.app/en/vba/dir-function/

[^1_8]: https://www.freebasic-portal.de/befehlsreferenz/command-101.html

[^1_9]: https://learn.microsoft.com/en-us/dotnet/api/microsoft.visualbasic.filesystem.dir?view=net-10.0

[^1_10]: https://users.freebasic-portal.de/freebasicru/helprus/KeyPgCommand.html


---

# You are right I need to rethink my soft drink command line parsing really is quite a thing .... your remarks are noted in an other app I went down this route (just a snippet it's quite elaborate) : ' parse if commandline options are present

while i < __FB_ARGC__
select case left(command(i), 1)
case "-"
select case command(i)
case "-h", "-help", "--help", "-man"
displayhelp(locale)
logentry("terminate", "normal temination ")
case "-v", "-ver"
print appname + " version " + exeversion
' todo odd jumps to line 472 and resumes execution disregarding end
logentry("terminate", "normal temination ")
case else
logentry("fatal", "invalid switch '" \& command(i) \& "'")
end select
:  but that means a bit of re-write this is currently my first app that I'm converting from windows to linux there are so many issues that I want to keep things fluffy for now

That approach is sensible for a first Windows-to-Linux conversion. You’re keeping the parser simple, and the `__FB_ARGC__` / `COMMAND()` pattern is the standard FreeBASIC way to inspect arguments.[^2_1][^2_2]

## What is solid

Your switch handling is fine in principle:

```basic
select case command(i)
case "-h", "-help", "--help", "-man"
case "-v", "-ver"
case else
end select
```

That matches FreeBASIC’s command-line model, where arguments are already split and you iterate over them by index. Also, using `END` or a terminating function after help/version output is valid if you want to stop normal execution; FreeBASIC documents `END` as exiting the program with an optional return code.[^2_3][^2_4][^2_2][^2_1]

## One thing to watch

If you are looping over arguments with `i < __FB_ARGC__`, remember that `COMMAND(0)` is the program name, so your option scan usually starts at `i = 1`. That avoids misclassifying the executable path as a switch.[^2_5][^2_1]

## Why the rewrite feels large

What you’re bumping into is not just a syntax issue; it is a command-line design issue. On Windows, your inputs may have been more forgiving, but on Linux the shell makes argument boundaries stricter and paths more varied, so heuristics like “contains `:`” or “contains `.m3u`” become brittle. The result is that a small parser can work for a while, but a more explicit one will save you trouble later.[^2_2][^2_1]

## A pragmatic middle path

For now, keep it **fluffy** as you said, but separate concerns:

- First pass: detect global switches like `-h` and `-v`.
- Second pass: interpret the remaining positional arguments.
- Third pass: branch into playlist mode or search/export mode based on the actual file extension, ideally with `right(lcase(arg), 4)` instead of `instr()`.[^2_6][^2_7]

That lets you avoid a full rewrite while making the behavior much more predictable.

## About exiting cleanly

If your debug note says execution “resumes” after a termination log, then the log routine itself may not actually stop the program. In FreeBASIC, `END` exits the program, while a logging function by itself will not. So if you want a help/version branch to stop immediately, do the stop explicitly after logging.[^2_4][^2_3]

Your current direction is good: incremental cleanup, not a big-bang rewrite. The parser just needs one more layer of structure so Windows-style assumptions stop leaking into the Linux path flow.[^2_1][^2_2]
<span style="display:none">[^2_10][^2_11][^2_12][^2_13][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://www.freebasic.net/wiki/KeyPgDdfbargc

[^2_2]: https://documentation.help/FreeBASIC/KeyPgCommand.html

[^2_3]: https://freebasic.net/wiki/KeyPgEnd

[^2_4]: https://documentation.help/FreeBASIC/KeyPgEnd.html

[^2_5]: https://documentation.help/FreeBASIC/KeyPgDdfbargc.html

[^2_6]: https://documentation.help/FreeBASIC/KeyPgFileexists.html

[^2_7]: https://www.freebasic.net/wiki/wikka.php?wakka=KeyPgFileexists

[^2_8]: https://fossies.org/linux/FreeBASIC/doc/manual/cache/KeyPgDdfbargv.wakka

[^2_9]: http://29v7zb3.257.cz/freebasic/

[^2_10]: https://www.freebasic.net/wiki/wikka.php?wakka=CompilerCmdLine

[^2_11]: https://www.freebasic.net/forum/viewtopic.php?t=23429

[^2_12]: https://www.freebasic.net/forum/viewtopic.php?t=29571

[^2_13]: https://www.freebasic.net/forum/viewtopic.php?t=26145

