---
created: 2026-02-12T19:37:21 (UTC +01:00)
tags: []
source: https://nmilosev.svbtle.com/running-fedora-off-a-usb-flash-drive-performance-tips
author: 
---

# Running Fedora off a USB flash drive (performance tips)

> ## Excerpt
> I wanted to try running Fedora outside of chroot on my Chromebook. Because I didn’t want to mess with the complicated ChromeOS partition structure I decided to install Fedora to a USB flash drive. The USB drive # I wanted to get a nice and quick... | nmilosev | This Little Maneuver’s Gonna Cost Us 51 Years.

---
March 5, 2016

## [Running Fedora off a USB flash drive (performance tips)](https://nmilosev.svbtle.com/running-fedora-off-a-usb-flash-drive-performance-tips)

I wanted to try running Fedora outside of chroot on my Chromebook. Because I didn’t want to mess with the complicated ChromeOS partition structure I decided to install Fedora to a USB flash drive.

## The USB drive [#](https://nmilosev.svbtle.com/running-fedora-off-a-usb-flash-drive-performance-tips#the-usb-drive_1)

I wanted to get a nice and quick USB3 flash drive which had low-enough profile so it doesn’t stick too much out of my Chromebook’s USB port. Sadly there aren’t that many options, there is the [SanDisk Ultra Fit](https://www.sandisk.com/home/usb-flash/ultra-fit-usb) drive and [Kingston DataTraveler micro 3.1](http://www.amazon.com/Kingston-Digital-Ultra-Compact-DTMC3-32GB/dp/B00ZRHX7GK). I went with the Kingston drive because it was available in my country while SanDisk wasn’t. It’s made of metal and it sticks about a centimeter out of the USB port, so it doesn’t get in the way at all. The performance is mostly as advertised, I am getting about 95MB/s reads and around 15MB/s writes which is mostly fine for running Fedora. The drive gets a bit hot under load but nowhere near uncomfortable. It’s also worth mentioning that you will do just fine with a 16GB drive. I went for the 32GB version, and I created one 8GB fat32 partition which gets recognized first if I put the drive into a Windows machine.

## Installation [#](https://nmilosev.svbtle.com/running-fedora-off-a-usb-flash-drive-performance-tips#installation_1)

You have many ways to do this. You could install Fedora from an existing Fedora machine with dnf with the command like this:

```
sudo dnf --releasever=23 --installroot=/mnt/usb-drive-you-mounted-here groupinstall "Fedora Workstation"
```

but then you have to setup GRUB, the kernel, users, fstab all manually. While this is fun, and I will definitely try it in the future, much easier way is to use Fedora’s installer Anaconda. You can also run it from an existing Fedora installation or from another USB drive (which I did). Now, I strongly, strongly advise that you use the netinstall ISO. Writing on the drive is slow, and updates will take hours, so it is much better to use netinstall ISO image from another USB drive (even 512MB one will do) so you don’t have to update it immediately. Also, be careful about which architecture you choose. If you want maximum compatibility then better choose the i686 image since it will work anywhere. Anaconda on the netinstall image will also ask you what package groups you want, and it will obviously set everything up for you so it is much easier this way. Since the write speeds are low, don’t expect the installation to be done quickly. It took about 90 minutes on my USB drive. Be sure to choose ext4 file system for your root partition, as we will be doing some performance tweaks later on. After installation is done, you can boot your Chromebook into legacy boot mode (see the Chromium wiki for model specific instructions) and it will boot from the USB drive straight into Fedora without any further tweaks or modifications.

## Performance [#](https://nmilosev.svbtle.com/running-fedora-off-a-usb-flash-drive-performance-tips#performance_1)

It’s not that bad. Obviously Crouton will work much faster because it is running in the included, much faster SSD. Boot-time is very fast (10 seconds at most) and the system is responsive and works nicely after that. It’s also very important that you choose a light desktop environment.

## XFCE4 [#](https://nmilosev.svbtle.com/running-fedora-off-a-usb-flash-drive-performance-tips#xfce4_1)

Why oh why, haven’t I tried XFCE earlier. The ease of customization is unbelievable. It’s fast, it looks pretty, it’s compatible with everything. You can run GNOME programs, KDE programs, whatever. The amount of available widgets (be sure to tick the XFCE goodies checkbox in the installer) is huge. The Whisker menu looks and works great! I absolutely love it!

## Optimizing [#](https://nmilosev.svbtle.com/running-fedora-off-a-usb-flash-drive-performance-tips#optimizing_1)

While the performance isn’t half bad, you will run into some bottlenecks because of the USB drive speed. There is some stuff you can do.

**FAIR WARNING: These instructions and parameters assume you will never lose power or abruptly pull the USB drive out. Data loss or file system corruption in a scenario like this is probable.**

___

## Kernel paramters [#](https://nmilosev.svbtle.com/running-fedora-off-a-usb-flash-drive-performance-tips#kernel-paramters_2)

```
elevator=noop
```

is said to improve SSD performance so be sure to add it to your kernel parameter list. Personally I haven’t noticed a big difference after applying this in day to day use. There is also another scheduler `elevator=deadline` which is also used often with solid drives, so you can try it.

## fstab [#](https://nmilosev.svbtle.com/running-fedora-off-a-usb-flash-drive-performance-tips#fstab_2)

This is mostly where we will be doing performance tweaks. After applying these tweaks there was a big boost in system speed, however again, please be careful with these parameters and sudden power loss. You can edit the `/etc/fstab` file with any text editor. We will be adding parameters only for our root partition, after the `defaults parameter`, so for example my `fstab` looks like this:

```
... / ext4 defaults,noatime,commit=15,data=writeback,barrier=0 1 1
...  /boot ext4    defaults        1 2
...  swap swap    defaults        0 0
none /tmp tmpfs        defaults      0 0
```

### Move `/tmp` to RAM [#](https://nmilosev.svbtle.com/running-fedora-off-a-usb-flash-drive-performance-tips#move-code-classprettyprinttmpcode-to-ram_3)

This is done by adding the line:

```
none       /tmp      tmpfs        defaults      0 0
```

to the end of the `/etc/fstab` file. This obviously depends on the amount of RAM your machine has, and of your use-cases where `/tmp` gets used a lot. It definitely improves performance and responsiveness of the system greatly.

### Use `noatime` [#](https://nmilosev.svbtle.com/running-fedora-off-a-usb-flash-drive-performance-tips#use-code-classprettyprintnoatimecode_3)

By adding this parameter to the `fstab`, you will tell Fedora that it doesn’t have to store the “last accessed time” for files and folders. Do this only if you can do without this information and only with created/modified time-stamps.

### Set `commit=15` [#](https://nmilosev.svbtle.com/running-fedora-off-a-usb-flash-drive-performance-tips#set-code-classprettyprintcommit15code_3)

Commit data every 15 seconds, instead of the default 5 second time. Reduces load at the risk of losing data if power goes out, which isn’t a concern with a laptop.

### Set `barrier=0` [#](https://nmilosev.svbtle.com/running-fedora-off-a-usb-flash-drive-performance-tips#set-code-classprettyprintbarrier0code_3)

Write barriers enforce proper ordering of writes. We can safely improve performance by disabling this because there are no risks of a sudden power loss in a laptop.

### Set `data=writeback` [#](https://nmilosev.svbtle.com/running-fedora-off-a-usb-flash-drive-performance-tips#set-code-classprettyprintdatawritebackcode_3)

Definitely the biggest performance increase. This will tell ext4 to only do metadata journals. Before applying this parameter you will have to somehow mount your root filesystem as read-only (or put the flash drive into another machine) and do the following:

```
sudo tune2fs -o journal_data_writeback /dev/sdxN
sudo tune2fs -O ^has_journal /dev/sdxN
sudo e2fsck -f /dev/sdxN 
```

where x is your drive number and N is your partition number, for example `/dev/sda1`. This parameter will improve performance greatly and you will definitely notice the difference.

## Conclusion [#](https://nmilosev.svbtle.com/running-fedora-off-a-usb-flash-drive-performance-tips#conclusion_1)

It’s not that hard to setup Fedora onto a USB drive. Performance is OK, especially after doing these tweaks which also reduce the number of writes which will make you USB drive happier and healthier for a longer time. Great thing about running it of the USB drive is that you can take it with you and plug it anywhere you want to use it.

As far as the Crouton vs. this method, I’m sticking with Crouton but will definitely use the USB drive aswell.

Happy tinkering!

[](https://nmilosev.svbtle.com/running-fedora-off-a-usb-flash-drive-performance-tips#kudo)

78

Kudos

[](https://nmilosev.svbtle.com/running-fedora-off-a-usb-flash-drive-performance-tips#kudo)

78

Kudos
