<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# I've got a .service that is supposed to clean the trash / info folder on shutdown oddly enough it works so long there is no network connection with the network connection on shutdown it does not work ... starting it manually cleans the trash / info folder so both the .sh and .service do what they are supposed to do ...

This usually happens because the service is ordered too late in the shutdown sequence, so the network (and possibly the user’s home/trash location if it’s on the network) is already gone by the time your cleanup runs.

To fix it, adjust the unit so it runs *before* networking and filesystems are torn down, and make sure it’s triggered on stop, not on start:

```ini
# /etc/systemd/system/cleanup-trash.service
[Unit]
Description=Clean trash on shutdown
DefaultDependencies=no
Before=shutdown.target
# Make sure it runs before network and unmounts
Before=network.target umount.target
# If your trash is on a network share, also:
# After=network-online.target

[Service]
Type=oneshot
ExecStart=/bin/true
ExecStop=/usr/local/bin/clean-trash.sh
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
```

Key points to check:

1. **Use ExecStop, not ExecStart**
The cleanup script must be in `ExecStop=` so it runs when the service stops during shutdown, not when it starts at boot.
2. **Disable default dependencies**
`DefaultDependencies=no` plus `Before=shutdown.target` ensures systemd doesn’t stop your service *after* it has already torn down important services.[^1_1]
3. **Order vs network/filesystems**
    - If the trash is on a local disk: add `Before=umount.target` so the filesystem is still mounted when the script runs.
    - If it’s on a network share (NFS, SMB, etc.): ensure your unit runs **after** the network is up at boot (`After=network-online.target`) but **before** it’s torn down at shutdown (`Before=network.target`).
4. **Enable and test**
    - Reload: `sudo systemctl daemon-reload`
    - Enable: `sudo systemctl enable cleanup-trash.service`
    - Test:
        - Run `sudo systemctl stop cleanup-trash.service` and confirm it runs the script.
        - Then `sudo systemctl reboot` and check `journalctl -u cleanup-trash.service -b -1` for the previous boot’s shutdown logs.

If you paste your current `.service` file and the path to the trash you’re cleaning (local vs NFS/SMB), I can tailor the exact unit directives.
<span style="display:none">[^1_10][^1_2][^1_3][^1_4][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://www.reddit.com/r/linuxquestions/comments/udr7ch/running_systemd_service_on_shutdown_before/

[^1_2]: https://community.ccleaner.com/topic/36604-custom-files-folder-cleaning-on-network-attached-storage-not-working/

[^1_3]: https://forum.endeavouros.com/t/unable-to-shutdown-after-a-dab-at-systemd-service-unit-files/46439

[^1_4]: https://www.reddit.com/r/mac/comments/1276dnb/trash_emptying_taking_long_time/

[^1_5]: https://github.com/systemd/systemd/issues/12967

[^1_6]: https://community.spiceworks.com/topic/1029445-automate-folder-cleanup-and-service-stop-start

[^1_7]: https://bbs.archlinux.org/viewtopic.php?id=151487

[^1_8]: https://forums.squiz.net/t/purge-trash-script/7379

[^1_9]: https://www.reddit.com/r/MacOS/comments/cwz06c/can_not_empty_trash_can/

[^1_10]: https://netatalk-admins.sf.narkive.com/IjDkEYEl/network-trash-folder-is-it-possible


---

# Ok will do unfortunanty I have two seperate systems so cut and pasting is abit of an hassle. I'll save this session and alter the .service as you suggested this by the way was already there : [Service]

Type=oneshot
ExecStart=/bin/true
ExecStop=/usr/local/bin/cleantrash.sh
RemainAfterExit=yes

That `Service` section looks fine; the issue is almost certainly the `Unit` section and ordering, not the script itself.

Here’s a minimal version you can try, just by editing the top and bottom of your existing unit:

```ini
[Unit]
Description=Clean trash on shutdown
DefaultDependencies=no
Before=shutdown.target
Before=umount.target
Before=network.target

[Service]
Type=oneshot
ExecStart=/bin/true
ExecStop=/usr/local/bin/cleantrash.sh
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
```

Then run on that machine:

```bash
sudo systemctl daemon-reload
sudo systemctl enable cleanup-trash.service
```

To test without a full shutdown:

```bash
sudo systemctl stop cleanup-trash.service
```

If that works, do a real shutdown and later check:

```bash
journalctl -u cleanup-trash.service -b -1
```

If your trash is on a network share (NFS/SMB), tell me which, and I’ll give you the exact extra lines to add.

---

# nope 'If your trash is on a network share (NFS/SMB),' it's in the home/<usernam>/.local/share/trash on the same drive / partition ...

Good, that simplifies things: you’re on a local home filesystem, so it’s purely a shutdown ordering/logging issue, not networking itself.

Given your `Service` section is already:

```ini
[Service]
Type=oneshot
ExecStart=/bin/true
ExecStop=/usr/local/bin/cleantrash.sh
RemainAfterExit=yes
```

try this full unit:

```ini
[Unit]
Description=Clean trash on shutdown
DefaultDependencies=no
Before=shutdown.target
Before=umount.target
Conflicts=shutdown.target

[Service]
Type=oneshot
ExecStart=/bin/true
ExecStop=/usr/local/bin/cleantrash.sh
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
```

Then:

```bash
sudo systemctl daemon-reload
sudo systemctl enable cleanup-trash.service
```

Now two important checks:

1. Does it actually run at shutdown?
After a shutdown and boot, check the previous boot’s log:

```bash
journalctl -u cleanup-trash.service -b -1
```

You should see your script being called near the end of the log.
2. Does the script *succeed* at shutdown?
Add explicit logging inside `/usr/local/bin/cleantrash.sh`, for example at the top and bottom:

```bash
#!/bin/bash
echo "$(date) cleantrash.sh starting" >> /var/log/cleantrash.log
# your delete commands here, e.g.:
rm -rf /home/USERNAME/.local/share/Trash/files/* \
       /home/USERNAME/.local/share/Trash/info/* 2>> /var/log/cleantrash.log
echo "$(date) cleantrash.sh done (exit $?)" >> /var/log/cleantrash.log
```

After a shutdown/boot, look at `/var/log/cleantrash.log` to see if it ran and whether `rm` complained about permissions or paths.

If, with networking enabled, the log shows the script *starting* but not actually deleting files, it’s likely a permissions/session issue (e.g. the script running as root vs. user, or a different `$HOME`). In that case, tell me:

- What user is the service supposed to run as (root or your normal user)?
- Whether you’re using full absolute paths to the trash directories in the script.

---

# This 'journalctl -u cleanup-trash.service -b -1' consistently ends up with -- no entries -- ...

If `journalctl -u cleanup-trash.service -b -1` shows `-- No entries --`, systemd never actually started/stopped that unit in that boot. The service is not part of the shutdown transaction yet.

Work through these checks (they don’t need copy‑paste, just run commands and compare):

## 1. Confirm the real unit name

Run:

```bash
systemctl list-unit-files '*clean*trash*'
```

or:

```bash
systemctl list-unit-files | grep -i trash
```

Make sure the exact unit file name (e.g. `cleanup-trash.service` vs `cleantrash.service`) matches what you use with `journalctl -u ...`. If the file is called `cleantrash.service`, you must also use that name everywhere.

## 2. Verify the unit is enabled

Run:

```bash
systemctl status cleanup-trash.service
```

You should see something like `Loaded: loaded (/etc/systemd/system/cleanup-trash.service; enabled; ...)`.
If it says `disabled`, then:

```bash
sudo systemctl enable cleanup-trash.service
sudo systemctl daemon-reload
```

Then reboot once and check again.

If `systemctl status` says `Loaded: not-found` or similar, the unit file is not where systemd expects it. It must be in `/etc/systemd/system/` (or another systemd unit directory) and end in `.service`, then:

```bash
sudo systemctl daemon-reload
```


## 3. Ensure it’s pulled into the boot

You currently have:

```ini
[Install]
WantedBy=multi-user.target
```

Verify that the symlink exists:

```bash
ls -l /etc/systemd/system/multi-user.target.wants/ | grep -i cleanup
```

If no line appears, the enable step didn’t work or the name doesn’t match. Run:

```bash
sudo systemctl enable cleanup-trash.service
```

again and re‑check the directory.

## 4. Test that stop really runs the script

Once `status` shows the unit is **active** after boot (or at least `inactive (dead)` but loaded and enabled), do:

```bash
sudo systemctl stop cleanup-trash.service
```

Then check the journal for this boot without the `-b -1`:

```bash
journalctl -u cleanup-trash.service
```

If you still see `-- No entries --` even after explicitly stopping it, then the service never started, or systemd considers it static.

To guarantee it starts, add:

```ini
[Service]
Type=oneshot
ExecStart=/bin/true
ExecStop=/usr/local/bin/cleantrash.sh
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
```

and then:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now cleanup-trash.service
```

The `--now` forces a start immediately; you should then see log entries when you stop it.

## 5. Full example unit to try

Put this (adjust the filename and description, but keep the structure) in `/etc/systemd/system/cleanup-trash.service`:

```ini
[Unit]
Description=Clean trash on shutdown
DefaultDependencies=no
Before=shutdown.target
Before=umount.target
Conflicts=shutdown.target

[Service]
Type=oneshot
ExecStart=/bin/true
ExecStop=/usr/local/bin/cleantrash.sh
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
```

Then:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now cleanup-trash.service
```

Check:

```bash
systemctl status cleanup-trash.service
```

You want to see it as loaded and enabled. Then:

- Run `sudo systemctl stop cleanup-trash.service` and confirm the script runs.
- Reboot.
- After boot, run `journalctl -u cleanup-trash.service -b -1`.

If you still get `-- No entries --` after these steps, tell me:

- The *exact* output of `systemctl status cleanup-trash.service`.
- The exact filename in `/etc/systemd/system/` (including `.service`).
<span style="display:none">[^4_1][^4_2][^4_3][^4_4]</span>

<div align="center">⁂</div>

[^4_1]: https://bbs.archlinux.org/viewtopic.php?id=207395

[^4_2]: https://bbs.archlinux.org/viewtopic.php?id=220581

[^4_3]: https://github.com/systemd/systemd/issues/15015

[^4_4]: https://forum.endeavouros.com/t/how-can-i-get-the-logs-that-appear-before-my-system-shuts-down/56433


---

# I do want to point out that, even unalterd, it does work as long as there is no network connection so why the journal has no entries seems to be an other issue entirely ...

The fact that it behaves differently with and without network is a strong hint that you’re actually hitting a *timing / ordering* issue, not that the unit is somehow “only present” when offline.

When you boot without network, shutdown is simpler and often slower, so your `ExecStop=` has time to run while the user session and filesystem are still alive. When network is up, more units are involved, shutdown ordering changes, and your service likely runs either:

- After your user session (and its `$HOME`) has been torn down, or
- So late that logging and/or the journal for that boot are no longer available by the time it finishes.

Because I can’t see the exact unit and logs, here’s a practical workaround that avoids relying on the shutdown transaction:

### 1. Use a `*-shutdown.service` unit

Instead of the `ExecStop` trick, define a unit that is started *only* during shutdown:

```ini
# /etc/systemd/system/cleanup-trash-shutdown.service
[Unit]
Description=Clean trash during shutdown
DefaultDependencies=no
Before=umount.target
Before=shutdown.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/cleantrash.sh
TimeoutSec=30

[Install]
WantedBy=shutdown.target
```

Key points:

- `DefaultDependencies=no` + `Before=umount.target` ensures the home filesystem is still mounted.
- `WantedBy=shutdown.target` means it is explicitly started as part of shutdown, not stopped as a side effect.

Then run:

```bash
sudo systemctl daemon-reload
sudo systemctl enable cleanup-trash-shutdown.service
```

You no longer need the old `cleanup-trash.service` with `ExecStop` at all; you can disable it.

### 2. Make the script self-logging and robust

In `/usr/local/bin/cleantrash.sh`:

```bash
#!/bin/bash
LOG=/var/log/cleantrash.log

echo "$(date) cleantrash.sh starting" >> "$LOG"

rm -rf /home/USERNAME/.local/share/Trash/files/* \
       /home/USERNAME/.local/share/Trash/info/* 2>> "$LOG"

echo "$(date) cleantrash.sh done (exit $?)" >> "$LOG"
```

- Use absolute paths, not `$HOME`.
- Make it executable: `sudo chmod +x /usr/local/bin/cleantrash.sh`.

Then, after a shutdown/boot (both with and without network), simply inspect `/var/log/cleantrash.log` to see if the script ran.

This approach avoids the brittle `ExecStop` behavior entirely and usually eliminates the “works offline but not online” quirk, because the unit is started explicitly as part of `shutdown.target` rather than being stopped as part of the reverse dependency graph.
<span style="display:none">[^5_1][^5_2][^5_3][^5_4][^5_5]</span>

<div align="center">⁂</div>

[^5_1]: https://bbs.archlinux.org/viewtopic.php?id=222963

[^5_2]: https://forums.opensuse.org/t/run-a-systemd-service-only-on-power-off/118947

[^5_3]: https://www.reddit.com/r/linuxquestions/comments/rkjib8/systemd_service_not_stopped_when_partof/

[^5_4]: https://www.reddit.com/r/linuxquestions/comments/udr7ch/running_systemd_service_on_shutdown_before/

[^5_5]: https://forum.manjaro.org/t/how-do-i-force-the-order-of-things-at-shutdown-with-systemd/154229


---

# Ok the .service has been mutating with each Q\&A I will try your suggestions sure that one of them will eventually work, for now many thanks for the suggestions.

You're welcome! The shutdown-specific service with `WantedBy=shutdown.target` is usually the most reliable fix for this exact pattern. Let me know how it goes or if you hit any snags—happy to refine further.

