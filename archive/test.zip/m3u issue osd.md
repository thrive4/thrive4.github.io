<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Could you have a look at the following freebasic snippet I am having issues with .m3u and .pls handling plus I think the instr conditions on '.' and ':' are overlapping maybe do to way the path is resolved... if command(1) <> "" then

    ' show help
    select case true
        case instr(command(1), "/?") > 0 or instr(command(1), "-h") > 0
            displayhelp(locale)
            logentry("terminate", "normal termination " + appname)
        case instr(command(1), "-v") > 0 or instr(command(1), "-ver") > 0
            consoleprint appname + " version " & exeversion 
            logentry("terminate", "normal termination " + appname)
        case instr(command(1), ".m3u") > 0 or instr(command(1), ".pls") > 0
            logentry("fatal", " not supported valid form osd.exe audioplayer <filename.m3u or .pls>")
    end select
    
    ' odd higher up causes wstr inssues issue with logging in resolvepath
    resolved = resolvepath (command(2))
    
    ' search mp3 on tag create .m3u and then play
    if command(1) = "audioplayer" and instr(resolved, ":") <> 0 and len(command(3)) <> 0 and instr(resolved, ".m3u") = 0 and instr(resolved, ".pls") = 0 then
        select case command(3)
            case "artist"
            case "title"
            case "album"
            case "year"
            case "genre"
            case else
                logentry("fatal", "unknown tag '" & command(3) & "' valid tags artist, title, album, genre and year")
        end select
        ' scan and search nr results overwritten by getmp3playlist
        maxitems = exportm3u(resolved, "*.mp3", "m3u", "exif", command(3), command(4))
        if maxitems < 2 then
            logentry("fatal", "no matches found for " + command(4) + " in " + command(3))
        else
            maxitems = getmp3playlist(exepath + "\media\playlist\" + command(4) + ".m3u", "music")
        end if
        launch = "audioplayer"
    else
        if command(1) = "desktop" or command(1) = "gamebrowser" then
            launch = command(1)
        else
            if command(1) = "imageview" or command(1) = "slideshow" or _
               command(1) = "videoplayer" or command(1) = "audioplayer" or command(1) = "shadertoy" then
                launch = command(1)
                if instr(resolved, ".") <> 0 then
                    dummy = ""
                    filename = resolved
                    imagefolder = left(resolved, instrrev(resolved, "\") - 1)
                    fileext = lcase(mid(filename, instrrev(filename, ".")))
                    select case true
                        case instr(1, audiotypes, fileext) > 0 and len(fileext) > 3
                            dummy = "music"
                            if instr(resolved, ".m3u") <> 0 or instr(resolved, ".pls") <> 0 then
                                maxitems = getmp3playlist(command(2), dummy)
                                if maxitems > 1 then ' m3u or pls
    '                                    musicstate = true
'                                    musicplay  = true
'                                    currentitem = listnext(dummy, playtype, 1)
'                                    if playtype = "shuffle" then
'                                        setsequence(currentitem)
'                                    end if
'                                    currentsong = getcurrentlistitem(dummy, filename)
'playmedia(currentsong, "music")
filename = listrec.listfile(1)
else
' if zero assume mp3 file
end if
'                            else
'                                chk = createlist(imagefolder, audiotypes, dummy)
end if

'                            currentsong = getcurrentlistitem(dummy, filename)

                        case instr(1, imagetypes, fileext) > 0 and len(fileext) > 3
                            dummy = "imageview"
                            chk = createlist(imagefolder, imagetypes, dummy)
                            currentimage = getcurrentlistitem(dummy, filename)
                        case instr(1, videotypes, fileext) > 0 and len(fileext) > 3
                            dummy = "video"
                            chk = createlist(imagefolder, videotypes, "video")
                        case instr(1, shadertypes, fileext) > 0 and len(fileext) > 3
                            dummy = "shader"
                            chk = createlist(imagefolder, shadertypes, "shader")
                            currentshader = getcurrentlistitem(dummy, filename)
                        case else
                            logentry("warning", "unknown filetype " + filename + " browsetype switched to filelist")
                            launch = "filelist"
                    end select            
                else
                    if instr(resolved, ":") <> 0 then
                        imagefolder = resolved
                        if checkpath(imagefolder) = false then
                            logentry("fatal", " path not found " + imagefolder)
                        else
                            select case command(1)
                                case "imageview"
                                    dummy = "image"
                                    chk = createlist(imagefolder, imagetypes, dummy)
                                    playmedia(1, dummy)
                                case "audioplayer"
                                    dummy = "music"
                                    chk = createlist(imagefolder, audiotypes, dummy)
                                case "slideshow"
                                    dummy = "slideshow"
                                    chk = createlist(imagefolder, imagetypes, dummy)
                                case "videoplayer"
                                    dummy = "video"
                                    chk = createlist(imagefolder, videotypes, dummy)
                                    playmedia(1, dummy)
                                case "shadertoy"
                                    dummy = "shader"
                                    chk = createlist(imagefolder, shadertypes, dummy)
                                    playmedia(1, dummy)
                                    ' hack for activating gl
                                    screensavetype   = "shader"
                                    screensaveactive = true
                                case else
                                    logentry("fatal", "unknown browsertype " + command(1))
                            end select
                            ' no images or incorrect path    
                            if chk = 0 then
                                logentry("error", "no usable files found in " + imagefolder)
                                launch = "filelist"
                            end if
                        end if
                    end if
                end if    
            else
                logentry("fatal", "unknown browsertype " + command(1))
                'launch = "filelist"
            end if
        end if
    end if
    print "wah"
print lbound(listrec.listfile)
print currentsong
print filename
end if

The core problems are:

- `.m3u` / `.pls` are rejected up front, so they never reach the later handling.
- The `.` vs `:` checks are not conflicting, but the `.m3u/.pls` checks are duplicated and slightly inconsistent.
- `resolved = resolvepath(command(2))` will be wrong if you actually pass the playlist as `command(2)` earlier, because you first tested `command(1)` for `.m3u/.pls`.

Below is a cleaned‑up structure and what to change.

## High‑level fixes

- Treat **playlists as valid input** instead of “fatal not supported”.
- Centralize the **file type / extension** handling so `.m3u` and `.pls` follow the same code path as audio files.
- Use one consistent rule: “if it has a dot, treat as file; if not but has a drive colon, treat as folder”.


### 1. Fix the initial `.m3u/.pls` case

Right now you do:

```basic
case instr(command(1), ".m3u") > 0 or instr(command(1), ".pls") > 0
    logentry("fatal", " not supported valid form osd.exe audioplayer <filename.m3u or .pls>")
```

If the intended usage is:

```text
osd.exe audioplayer myplaylist.m3u
```

then it is `command(2)` that contains the `.m3u`, not `command(1)`. Also, if you *want* to support playlists, this fatal is wrong. A more consistent pattern:

```basic
if command(1) <> "" then
    select case true
        case instr(command(1), "/?") > 0 or instr(command(1), "-h") > 0
            displayhelp(locale)
            logentry("terminate", "normal termination " + appname)

        case instr(command(1), "-v") > 0 or instr(command(1), "-ver") > 0
            consoleprint appname + " version " & exeversion 
            logentry("terminate", "normal termination " + appname)

        ' do NOT test .m3u/.pls here any more
    end select
end if
```

Remove the “fatal not supported” branch entirely and let playlist handling happen in the main logic.

## 2. Resolve the correct argument

You currently do:

```basic
resolved = resolvepath(command(2))
```

That assumes command layout like:

- `command(1)` = mode (`audioplayer`, `imageview`, …)
- `command(2)` = file or folder (or playlist)
- `command(3)` = tag (artist/title/…)
- `command(4)` = tag query

So a tag‑search call looks like:

```text
osd.exe audioplayer C:\Music artist "Beatles"
```

and a playlist call like:

```text
osd.exe audioplayer C:\media\playlist\rock.m3u
```

If that is your convention, `resolvepath(command(2))` is correct; just make sure you *never* check for `.m3u/.pls` in `command(1)` but in `resolved` / `command(2)` only.

## 3. Separate “tag search” from “playlist” more clearly

The tag‑search condition:

```basic
if command(1) = "audioplayer" _
   and instr(resolved, ":") <> 0 _
   and len(command(3)) <> 0 _
   and instr(resolved, ".m3u") = 0 _
   and instr(resolved, ".pls") = 0 then
```

This already excludes `.m3u/.pls` from the tag‑search branch, which is correct. The overlapping feeling comes from having *another* `.m3u/.pls` logic later inside the generic file handler.

You can make the intent clearer by splitting early:

```basic
dim isPlaylist as integer = (instr(resolved, ".m3u") <> 0) or (instr(resolved, ".pls") <> 0)

if command(1) = "audioplayer" and len(command(3)) <> 0 _
   and instr(resolved, ":") <> 0 and isPlaylist = 0 then
    ' --- TAG SEARCH branch ---
    ' exportm3u, then load that m3u
elseif command(1) = "audioplayer" and isPlaylist <> 0 then
    ' --- PLAYLIST AS DIRECT INPUT branch ---
    maxitems = getmp3playlist(resolved, "music")
    if maxitems > 1 then
        launch = "audioplayer"
    else
        ' consider logging: empty playlist
    end if
else
    ' fall through to generic “launcher + path or file” logic
end if
```

That way, direct playlist usage is explicit and you do not rely on the later `case instr(1, audiotypes, fileext)` branch for `.m3u/.pls`.

## 4. Clarify the “has dot / has colon” checks

This part is logically fine:

```basic
if instr(resolved, ".") <> 0 then
    ' treat as file (has extension)
    ...
else
    if instr(resolved, ":") <> 0 then
        ' treat as folder/path (drive:)
        ...
    end if
end if
```

Potential issues:

- A folder like `C:\music.v1\` contains a dot and will be treated as a file, which will later fall into the `case else` and cause a warning.
- A UNC path `\\server\share\music` has no colon; your colon test will fail and the code will treat it as neither file nor folder.

If you only care about “file vs folder” on local drives, this is acceptable. To avoid misclassifying a path like `C:\music.v1\` you could instead check for a trailing backslash or rely on `checkpath` before assuming “file”.

Minimal improvement that keeps your overall structure:

```basic
dim dotPos as integer = instrrev(resolved, ".")
dim slashPos as integer = instrrev(resolved, "\")

' Only treat as file if the last dot comes after the last backslash
if dotPos <> 0 and dotPos > slashPos then
    ' file
else
    ' folder (then check colon or use checkpath)
end if
```

This prevents folder names containing dots from being mis‑detected as files.

## 5. Unify `.m3u/.pls` handling inside the file branch

Inside your launcher block:

```basic
if instr(resolved, ".") <> 0 then
    filename = resolved
    imagefolder = left(resolved, instrrev(resolved, "\") - 1)
    fileext = lcase(mid(filename, instrrev(filename, ".")))

    select case true
        case instr(1, audiotypes, fileext) > 0 and len(fileext) > 3
            dummy = "music"
            if instr(resolved, ".m3u") <> 0 or instr(resolved, ".pls") <> 0 then
                maxitems = getmp3playlist(command(2), dummy)
                if maxitems > 1 then
                    filename = listrec.listfile(1)
                else
                    ' zero => assume mp3 file
                end if
            end if
```

Potential issues here:

- `audiotypes` probably **does not** include `.m3u` / `.pls`; they are not audio files. So for playlists, `instr(1, audiotypes, fileext)` will be 0 and the audio case will be skipped entirely.
- You then *re‑check* `.m3u/.pls` inside the audio case, which will never fire for real playlists.

Two ways to fix:

1. **Explicit playlist case** before audio/images/video:
```basic
select case true
    case lcase(fileext) = ".m3u" or lcase(fileext) = ".pls"
        dummy = "music"
        maxitems = getmp3playlist(filename, dummy)
        if maxitems > 1 then
            filename = listrec.listfile(1)
            launch = "audioplayer"
        else
            logentry("warning", "empty playlist " + filename)
        end if

    case instr(1, audiotypes, fileext) > 0 and len(fileext) > 3
        ' regular audio file handling
```

2. **Or** add `.m3u` / `.pls` to `audiotypes` and keep the inner playlist check, but that semantically mixes “files you can play directly” with “playlist containers”. The explicit playlist case is cleaner.

Also, for consistency, use `filename` (which already equals `resolved`) in the playlist loader:

```basic
maxitems = getmp3playlist(filename, dummy)
```

instead of `command(2)`.

## 6. About overlapping conditions

With the above changes, the logic becomes:

1. Handle global help/version.
2. Resolve `command(2)` into `resolved`.
3. If `audioplayer` with tag arguments and `resolved` is not a playlist → create `.m3u`, then later load that playlist file.
4. Else if `audioplayer` and `resolved` is a playlist → load playlist directly.
5. Else, general “launch + path” code:
    - If `resolved` looks like a file (last dot after last backslash) → get extension and:
        - playlist case,
        - audio case,
        - image case,
        - video case,
        - shader case,
        - else “unknown filetype”.
    - Else if `resolved` looks like a folder (has colon / passes `checkpath`) → create list for that folder etc.

In that structure, the conditions are no longer conceptually overlapping, just layered.

***

If you paste how `audiotypes`, `imagetypes`, and `getmp3playlist` are defined and what exact command line you run (with parameters), it is possible to suggest a minimal patch that will make `.m3u` and `.pls` behave as expected in your current code layout.
<span style="display:none">[^1_1][^1_10][^1_2][^1_3][^1_4][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://github.com/thrive4/app.fb.audioplayer-bass/blob/main/README.md

[^1_2]: https://www.reddit.com/r/PowerShell/comments/ifi0a4/amateur_scripter_read_nested_folders_of_mp3flac/

[^1_3]: https://www.freebasic.net/forum/viewtopic.php?t=8578

[^1_4]: https://www.reddit.com/r/musichoarder/comments/10tiri5/need_some_help_with_m3u/

[^1_5]: https://www.freebasic.net/forum/viewtopic.php?t=32091

[^1_6]: https://www.reddit.com/r/kodi/comments/kr70vr/music_playlist_m3u_does_not_playfind_all_of_its/

[^1_7]: http://help.nchsoftware.com/help/en/switch/mac/help.pdf

[^1_8]: https://github.com/MusicPlayerDaemon/MPD/issues/1831

[^1_9]: https://www.freebasic.net/forum/viewtopic.php?t=26256

[^1_10]: http://www.scvi.net/pls.htm


---

# Switching logic is really a thing I'll take your advice to heart but at the moment the crux of the issue resolves around audio related files and getmp3playlist :         ' scan and search nr results overwritten by getmp3playlist

        maxitems = exportm3u(resolved, "*.mp3", "m3u", "exif", command(3), command(4))
        if maxitems < 2 then
            logentry("fatal", "no matches found for " + command(4) + " in " + command(3))
        else
            listnr = getmp3playlist(exepath + "\media\playlist\" + command(4) + ".m3u", "music")
        end if
        launch = "audioplayer"
    else
        if command(1) = "desktop" or command(1) = "gamebrowser" then
            launch = command(1)
        else
            if command(1) = "imageview" or command(1) = "slideshow" or _
               command(1) = "videoplayer" or command(1) = "audioplayer" or command(1) = "shadertoy" then
                launch = command(1)
                if instr(resolved, ".") <> 0 then
                    dummy = ""
                    filename = resolved
                    imagefolder = left(resolved, instrrev(resolved, "\") - 1)
                    fileext = lcase(mid(filename, instrrev(filename, ".")))
                    select case true
                        case instr(1, audiotypes, fileext) > 0 and len(fileext) > 3
                            dummy = "music"
                            if instr(resolved, ".m3u") <> 0 or instr(resolved, ".pls") <> 0 then
                                listnr = getmp3playlist(command(2), dummy)
                            else
    '                                chk = createlist(imagefolder, audiotypes, dummy)
end if
: it's beginning to work but the variations coming from the command line make testing and debugging quite a chore, ...

The key is to make `getmp3playlist` usage and the `.m3u/.pls` logic consistent and to avoid doing *different* things depending on whether you came from the tag‑search branch or the direct‑file branch. Since the command‑line variations are what make debugging painful, you want to normalize to a single “playlist path + mode” before calling `getmp3playlist`.

Below is a minimal restructuring that keeps your current design but reduces surprises.

## 1. Normalize the playlist path

Right now you call `getmp3playlist` with two different arguments:

- Tag search:

```basic
listnr = getmp3playlist(exepath + "\media\playlist\" + command(4) + ".m3u", "music")
```

- Direct playlist:

```basic
listnr = getmp3playlist(command(2), dummy)
```


This means:

- In one case you use a constructed path under `exepath\media\playlist\`.
- In the other you use exactly what the user passed as `command(2)`.

To make behavior predictable, build a single `playlistPath` variable and reuse it:

```basic
dim playlistPath as string

' Tag search branch
maxitems = exportm3u(resolved, "*.mp3", "m3u", "exif", command(3), command(4))
if maxitems < 2 then
    logentry("fatal", "no matches found for " + command(4) + " in " + command(3))
else
    playlistPath = exepath + "\media\playlist\" + command(4) + ".m3u"
    listnr = getmp3playlist(playlistPath, "music")
end if
launch = "audioplayer"
```

Then, in the “direct playlist” case:

```basic
case instr(1, audiotypes, fileext) > 0 and len(fileext) > 3
    dummy = "music"

    ' playlist detection
    if instr(filename, ".m3u") <> 0 or instr(filename, ".pls") <> 0 then
        playlistPath = filename   ' already resolved
        listnr = getmp3playlist(playlistPath, dummy)
        launch = "audioplayer"
    else
        ' normal audio file handling
        'chk = createlist(imagefolder, audiotypes, dummy)
    end if
```

Using `filename` (which equals `resolved`) instead of `command(2)` removes one more source of confusion.

## 2. Make playlist detection independent of `audiotypes`

Your current code:

```basic
case instr(1, audiotypes, fileext) > 0 and len(fileext) > 3
    dummy = "music"
    if instr(resolved, ".m3u") <> 0 or instr(resolved, ".pls") <> 0 then
        listnr = getmp3playlist(command(2), dummy)
    else
        '...
    end if
```

This assumes `.m3u` / `.pls` are part of `audiotypes`. If they are not, the `case` is never taken for playlists, so the inner `.m3u/.pls` block will never execute.

Two options:

- Add `.m3u;.pls;` to `audiotypes`, or
- Better: add an explicit playlist case before audio:

```basic
select case true
    case lcase(fileext) = ".m3u" or lcase(fileext) = ".pls"
        dummy = "music"
        playlistPath = filename
        listnr = getmp3playlist(playlistPath, dummy)
        launch = "audioplayer"

    case instr(1, audiotypes, fileext) > 0 and len(fileext) > 3
        dummy = "music"
        ' non‑playlist audio handling

    ' ... images, video, shaders ...
end select
```


That prevents subtle bugs where playlists never enter the audio branch because `audiotypes` does not contain them.

## 3. Reduce command‑line variation pain

To make tests reproducible:

- Decide on **one** calling convention for each major mode and stick to it:
    - Direct audio file:
`osd.exe audioplayer C:\Music\track.mp3`
    - Direct playlist:
`osd.exe audioplayer C:\Playlists\rock.m3u`
    - Tag search:
`osd.exe audioplayer C:\Music artist Beatles`
- Log what the program *thinks* it is doing right after parsing:

```basic
logentry("debug", "cmd1=" + command(1) + " cmd2=" + command(2) + " cmd3=" + command(3) + " cmd4=" + command(4))
logentry("debug", "resolved=" + resolved + " fileext=" + fileext + " launch=" + launch)
```


These small logs make it much easier to see where a given command line is going: tag‑search branch vs direct playlist vs simple file vs folder.

---

# Good advice gracias. I'm going to brood a bit on this for now thank you for the suggestions.

Glad it helped, and de nada.

If you later want to refactor the switching logic more systematically, sharing a few typical command lines plus expected behavior for each would make it easier to tighten the design and spot edge cases.

