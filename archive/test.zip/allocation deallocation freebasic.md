<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Could you have a look at the following freebasic snippet? It's part of  a loop I'm wondering  if the bass_channelgetinfo needs to be in the loop ... : Do

    Dim As String key = UCase(Inkey)
    sleeplength = 5
    
    ' ghetto attempt of dynamic range compression audio
    if drc = "true" then
    	'musiclevel = BASS_ChannelGetLevel(fx1Handle)
    	'minlevel = min(loWORD(musiclevel), HIWORD(musiclevel)) / 32768.0f
    	'maxlevel = max(loWORD(musiclevel), HIWORD(musiclevel)) / 32768.0f
    
    	Dim ci As BASS_CHANNELINFO
    	BASS_ChannelGetInfo(fx1Handle, @ci)
    	Dim levels As Single Ptr = CAllocate(ci.chans * SizeOf(Single))
    
    	BASS_ChannelGetLevelEx(fx1Handle, levels, 0.3, 0) ' def 0.08
    
    	' Access individual channel levels
    	minlevel = levels[0]
    	maxlevel = levels[0]
    
    	For i As Integer = 0 To ci.chans - 1
    		If levels[i] < minlevel Then minlevel = levels[i]
    		If levels[i] > maxlevel Then maxlevel = levels[i]
    	Next
    
    	Deallocate(levels)
    /'
musiclevel = BASS_ChannelGetLevel(fx1Handle)
minlevel   = csng(min(loWORD(musiclevel), HIWORD(musiclevel))) / 32768.0f
maxlevel   = csng(max(loWORD(musiclevel), HIWORD(musiclevel))) / 32768.0f

'/
'		const smoothfactor    = 0.1f 'def 0.5f
'		drcnorm = drcnorm * (1.0f - smoothfactor) + minlevel * smoothfactor
' invert quieter songs boost more, louder songs less
'		const targetlevel = 0.5f ' ~50% of max headroom
'		dim as single makeupgain = targetlevel / max(0.05f, drcnorm)		
' clamp safe range max(<reduce loud songs> min(<increase volume quiet songs
'		drcvolume = max(0.7f, min(3.3f, makeupgain)) * sourcevolume

    	const as single smoothfactor    = 0.185f 'def 0.5f
    	drcnorm = drcnorm * (0.925f - smoothfactor) + minlevel * smoothfactor
    	' invert quieter songs boost more, louder songs less
    	const as single targetlevel = 0.5f ' ~50% of max headroom
    	dim as single makeupgain = targetlevel / max(0.195f, drcnorm)		
    	' clamp safe range max(<reduce loud songs> min(<increase volume quiet songs
    	drcvolume = max(maxlevel, min(2.345f, makeupgain)) * sourcevolume
    
    	BASS_ChannelSetAttribute(fx1Handle, BASS_ATTRIB_VOL, drcvolume)
    else
    	BASS_ChannelSetAttribute(fx1Handle, BASS_ATTRIB_VOL, sourcevolume)
    end if
    Here's a concise check and some guidance on whether to call BASS_ChannelGetInfo inside the loop.

What your snippet does

- It reads a key and sets a loop-local sleeplength.
- If drc = "true", it:
    - Gets channel info for fx1Handle (BASS_ChannelGetInfo) into ci.
    - Allocates a levels buffer sized by ci.chans (one float per channel).
    - Calls BASS_ChannelGetLevelEx to fill levels with per-channel levels.
    - Finds minlevel and maxlevel across channels.
    - Deallocates the buffer.
    - Computes a new drcvolume and applies it to fx1Handle.
- If drc is not "true", it applies sourcevolume.

Key points

1) Do you need BASS_ChannelGetInfo in the loop?

- You only need BASS_ChannelGetInfo if ci.chans (the number of channels) or other channel properties can change during playback. For a typical FX chain, the number of channels and the fx handle configuration don’t change per frame. So calling GetInfo every iteration is unnecessary overhead.
- If fx1Handle or the chain is dynamic (e.g., you reconfigure the effect or bounce between mono/stereo or multi-channel routing), you might need to refresh info then. Otherwise, pull ci once, reuse it.

2) Per-loop cost

- BASS_ChannelGetInfo is cheap, but the dominant cost is BASS_ChannelGetLevelEx and the memory alloc/free for levels. Allocating and deallocating a buffer every loop adds overhead and can fragment memory if the loop runs fast.
- If the loop runs every frame (e.g., 60 Hz or more), consider:
    - Allocating levels once per channel count, reuse the buffer.
    - Checking ci.chans only if you suspect a change (e.g., on a format change event).

3) Potential pitfalls in your code

- You allocate levels with CAllocate and immediately deallocate with Deallocate. Ensure ci.chans is valid and non-zero; otherwise, you could allocate zero or crash.
- levels is declared as Single Ptr; in FreeBASIC, Single is 4 bytes, so levels[i] is a valid access when levels points to an array. Fine.
- You set minlevel and maxlevel to levels before looping; ensure ci.chans > 0 to avoid reading levels when the array is zero-length.
- When you compute drcvolume, you clamp with maxlevel in the expression: drcvolume = max(maxlevel, min(2.345f, makeupgain)) * sourcevolume
— This makes drcvolume depend on maxlevel, but maxlevel could be negative if levels contain negatives. Ensure your inputs are in the expected range and consider abs or proper normalization if needed.
- Be mindful of thread-safety and the fact that BASS_ChannelGetLevelEx returns levels in the range [-1.0, 1.0]? If so, you’re using them as-is. Verify the actual range for your version.

4) Suggested refactor (keep it efficient)

- Move BASS_ChannelGetInfo out of the per-iteration hot path, or guard it with a change-detection:
    - At startup (or when fx1Handle changes), fetch ci and allocate levelsbuf of ci.chans floats.
    - In the loop, call BASS_ChannelGetLevelEx and use the existing levels buffer.
    - Do not reallocate each iteration unless ci.chans has changed.
- Add a small guard to ensure ci.chans > 0 before accessing levels.

Example outline (pseudo-FreeBASIC)

Dim As String key = UCase(Inkey)
sleeplength = 5

static dim ci As BASS_CHANNELINFO
static dim levels() As Single

if firsttime then
BASS_ChannelGetInfo(fx1Handle, @ci)
if ci.chans <= 0 then ci.chans = 1
ReDim levels(ci.chans - 1)
firsttime = 0
end if

if drc = "true" then
BASS_ChannelGetLevelEx(fx1Handle, levels(0), 0.3, 0) ' fill levels array
minlevel = levels(0)
maxlevel = levels(0)
For i As Integer = 0 To ci.chans - 1
If levels(i) < minlevel Then minlevel = levels(i)
If levels(i) > maxlevel Then maxlevel = levels(i)
Next

     const as single smoothfactor = 0.185
     drcnorm = drcnorm * (0.925 - smoothfactor) + minlevel * smoothfactor
     const as single targetlevel = 0.5
     dim as single makeupgain = targetlevel / max(0.195, drcnorm)
     drcvolume = max(maxlevel, min(2.345, makeupgain)) * sourcevolume
    
     BASS_ChannelSetAttribute(fx1Handle, BASS_ATTRIB_VOL, drcvolume)
    else
BASS_ChannelSetAttribute(fx1Handle, BASS_ATTRIB_VOL, sourcevolume)
end if

Notes

- If you truly need to support format changes on the fly, you can add a small change-detection: recompute ci and resize levels only when a format change is detected.

Would you like me to tailor this to your exact FreeBASIC setup (Windows vs Linux, BASS version, and whether fx1Handle is a real-time effect or a mixer channel) and provide a minimal, copy-paste-ready snippet? Also, would you prefer keeping the CPU cost low by caching ci and levels or always reading fresh values per frame for safety?

---

# Oh boy ... ok first the allocation stuff : [https://freebasic.net/wiki/KeyPgDeallocate](https://freebasic.net/wiki/KeyPgDeallocate) : 'Calling Deallocate on a null pointer induces no action.' : [https://freebasic.net/wiki/KeyPgCallocate](https://freebasic.net/wiki/KeyPgCallocate) : If successful, the address of the start of the allocated memory is returned. Otherwise, the null pointer (0) is returned. so no problemos right ...?

You’re partially right, but there’s an important distinction: *freeing* a null pointer is safe, but *using* one is not.

What those docs guarantee

- `CAllocate(...)` returns `0` (null) on failure.
- `Deallocate(0)` does nothing and is safe.

Where the problem is

- Your code **dereferences** the pointer before freeing it:
    - `levels[0]`
    - `levels[i]`

If `CAllocate` fails (returns 0), then `levels[0]` is effectively dereferencing a null pointer → undefined behavior / crash.

So the safety only applies to this part:

- `Deallocate(levels)` ✅ always safe

But not this part:

- `levels[i]` ❌ unsafe if allocation failed

Practical takeaway
You should still guard against allocation failure if you're allocating inside the loop:

Example:

```
Dim levels As Single Ptr = CAllocate(ci.chans * SizeOf(Single))
If levels = 0 Then
    ' handle error (skip this iteration, fallback, etc.)
    Continue Do
End If
```

That said, the bigger issue is not safety—it’s efficiency:

- You’re allocating and freeing memory every loop iteration.
- Even if it “works,” it’s unnecessary overhead and can hurt performance over time.

Better pattern

- Allocate once.
- Reuse the buffer.
- Only reallocate if `ci.chans` changes.

One more subtle edge case

- If `ci.chans = 0`, then:
    - `CAllocate(0)` may return 0 or a valid pointer (implementation-dependent).
    - But `levels[0]` will still be invalid.

So also guard this:

```
If ci.chans <= 0 Then Continue Do
```

Bottom line

- “No problemos” for `Deallocate(0)` ✅
- Potential crash for `levels[0]` when allocation fails ❌
- And performance-wise, doing this every loop is still not a great idea

If you want, I can show a clean version that avoids both the allocation and the repeated `GetInfo` call entirely.

