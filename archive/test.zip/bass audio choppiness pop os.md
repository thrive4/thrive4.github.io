<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# What is your take on the following freebasic snippet the audio can be a bit choppy on when compiled 64 bit on pop os with pipewire : \#ifdef __FB_LINUX__

    ' Set BASS buffer size to match PipeWires quantum
    BASS_SetConfig(BASS_CONFIG_DEV_PERIOD, 512)    ' Match quantum
    BASS_SetConfig(BASS_CONFIG_DEV_BUFFER, 2048)   ' Total buffer
    \#endif
dim drccnt as integer = 0

Do
Dim As String key = UCase(Inkey)
sleeplength = 5

    ' ghetto attempt of dynamic range compression audio
    if drc = "true" then
    drccnt += 1	
    if drccnt >= 4 then  ' Update every 4 frames instead
        musiclevel      = BASS_ChannelGetLevel(fx1Handle)
        minlevel        = min(loWORD(musiclevel), HIWORD(musiclevel)) / 32768.0f
        maxlevel        = max(loWORD(musiclevel), HIWORD(musiclevel)) / 32768.0f
        drcvolume       = min(1.75f + (7.0f - maxlevel), max(0.0f, (1.55f - minlevel)) * (7.0f - maxlevel))
        drcvolume       = drcvolume * sourcevolume
        BASS_ChannelSetAttribute(fx1Handle, BASS_ATTRIB_VOL, drcvolume)
    	drccnt = 0
    : specific is introducing a cnt in the loop functional ...

Your buffer settings are in the right direction, but the bigger issue is probably that the audio thread is still being asked to do too much work too often. On PipeWire, choppiness usually improves when the app’s buffer/quantum matches the system’s actual quantum, and when per-frame audio polling is reduced.[^1_1][^1_3]

## What looks good

- `BASS_SetConfig(BASS_CONFIG_DEV_PERIOD, 512)` and `BASS_SetConfig(BASS_CONFIG_DEV_BUFFER, 2048)` are reasonable starting points if your PipeWire quantum is around 512 frames.[^1_1]
- Updating DRC only every 4 frames instead of every loop iteration is a sensible optimization, because it reduces how often you call `BASS_ChannelGetLevel` and `BASS_ChannelSetAttribute`.[^1_1]


## What may still cause choppiness

- `BASS_ChannelGetLevel` is relatively expensive, and calling it repeatedly from the main loop can add jitter, especially on Linux audio stacks where timing is sensitive.[^1_3][^1_5]
- `BASS_ChannelSetAttribute(..., BASS_ATTRIB_VOL, ...)` every few frames can also create small timing disturbances if the main loop is not stable.
- If the loop uses a fixed `sleeplength = 5`, that may still be too aggressive or too bursty depending on how the rest of the program is structured.


## DRC logic concerns

Your “ghetto attempt” DRC formula is very likely to produce abrupt gain changes. That can sound choppy even if playback itself is fine, because the volume is being pushed around with no smoothing or attack/release envelope.

A more stable approach would be:

- Read the level less often.
- Smooth the measured level with a low-pass filter or moving average.
- Change gain gradually instead of setting a new value immediately.
- Clamp the result to a safe range.

For example, if `drcvolume` jumps quickly between values, that alone can create audible pumping or roughness even without true buffer underruns.

## 64-bit angle

The fact that it shows up more in 64-bit on Pop!_OS does not automatically mean 64-bit is the cause. It more often points to timing, buffer sizing, or how often your loop touches audio state. If the 32-bit build behaves better, I would still suspect scheduling differences or compiler optimization effects rather than a pure architecture problem.

## Practical next steps

- Try increasing `BASS_CONFIG_DEV_BUFFER` first, for example to `4096` or `8192`, and see whether the choppiness disappears.[^1_3][^1_1]
- Keep `BASS_CONFIG_DEV_PERIOD` aligned with the PipeWire quantum, but verify the actual quantum on your system because 512 is only good if PipeWire is really running near that value.[^1_1]
- Move the DRC calculation to a timer-based update rather than the main render/input loop.
- Add smoothing so gain changes happen over several updates.
- Test with DRC disabled entirely; if the choppiness vanishes, the issue is likely your gain modulation rather than the BASS/PipeWire buffer setup.


## My take

The `cnt` idea is useful as a quick mitigation, but it is not the real fix. It lowers the frequency of expensive calls, which helps, yet the deeper problem is that your loop is doing real-time audio control in a very abrupt way. I would treat this as a timing-and-smoothing problem first, and only then as a PipeWire buffer tuning problem.[^1_5][^1_1]

Would you like me to rewrite that snippet into a smoother FreeBASIC DRC update loop?
<span style="display:none">[^1_10][^1_2][^1_4][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://forum.endeavouros.com/t/pipewire-guide-audio-crackling-popping-and-latency/69602

[^1_2]: https://www.reddit.com/r/pop_os/comments/1p9qm92/fixed_crackling_audio_under_high_cpu_load_eg/

[^1_3]: https://forum.manjaro.org/t/crackling-popping-sounds-with-pipewire/161123

[^1_4]: https://www.youtube.com/watch?v=SA5GAPKQOBk

[^1_5]: https://forum.manjaro.org/t/howto-troubleshoot-crackling-in-pipewire/82442

[^1_6]: https://github.com/mpv-player/mpv/issues/9992

[^1_7]: https://freebasic.net/forum/viewtopic.php?t=25841

[^1_8]: https://github.com/winyl-player/winyl/blob/master/Winyl/src/LibAudio.cpp

[^1_9]: http://www.un4seen.com/forum/?topic=8682.0

[^1_10]: https://www.freebasic.net/forum/viewtopic.php?t=28630


---

# Good advice there regarding the rewrite ... a bit tricky as you can see I've only passed a small part of the do .. loop nomraly that would be no issue but since the frequent nag screen thing with perplexity (log in etc) going in depth has been / is a chore ... never the less this might be an avenue I'll look into 'Move the DRC calculation to a timer-based update rather than the main render/input loop.' ... in terms of quick mitigation the cnt is nahh just delaying the issue of choppiness tried 8 then 3 not really improving much ... though it's very music type dependent .. nummers with loud drum beats go very choppy more classical music doesn't really have that ..

Yes — what you’re describing fits the pattern of **transient-heavy material exposing timing/buffer weakness** more than a simple “always broken” audio path. Loud drum beats have sharp peaks and fast level changes, so any level polling, gain modulation, or buffer underrun will show up there first, while classical music can mask it much better.[^2_1][^2_2]

## Why drums break first

Percussive music stresses the exact parts of your code that are most fragile: peak detection, sudden gain changes, and loop jitter. `BASS_ChannelGetLevel` is explicitly a peak-amplitude query, so it will react very strongly to those drum transients. If your DRC then recalculates gain from those peaks without smoothing, you can get audible pumping or roughness even when playback is technically “working.”[^2_2]

## Why `cnt` did not help much

If delaying the DRC update from every loop to every few loops only shifts the symptom, that suggests the main issue is not just call frequency. It also points to the gain algorithm itself and to buffer timing under load, because percussion can still push the playback path into underruns or abrupt gain swings even at lower polling rates. In other words, `cnt` can reduce CPU churn, but it cannot fix a gain curve that reacts too fast.[^2_3][^2_4]

## What I would change first

A timer-based update is the right direction because it decouples audio control from the render/input loop and makes timing more predictable. On the gain side, I would add smoothing or a simple attack/release envelope so the volume changes gradually instead of jumping straight to the new target. That is especially important for drums, where the raw peak level rises and falls too quickly for “instant” gain updates to sound natural.

## PipeWire side

Your current `512 / 2048` settings are plausible, but they are not guaranteed to match the real PipeWire quantum in use. PipeWire crackling guides consistently point to quantum sizing and minimum quantum as the big levers, and they recommend checking the live quantum rather than guessing. If this is system-wide choppiness, raising the minimum quantum can help; if it is mostly your app, then the app-side gain logic is more likely the culprit.[^2_5][^2_6][^2_7][^2_8]

## Practical diagnosis

The fastest way to separate the causes is:

- Disable the DRC path completely and replay the same drum-heavy track.
- If the choppiness mostly disappears, the problem is your dynamic gain logic.
- If it remains, the issue is likely buffer sizing, quantum mismatch, or scheduling jitter in the app or system.[^2_6][^2_4]

The “drums are worse than classical” detail strongly suggests your DRC is reacting to peaks too abruptly, so I would treat smoothing as the main fix and buffer tuning as the supporting fix.[^2_1][^2_2]

If you want, I can sketch a minimal FreeBASIC pattern for a timer-driven, smoothed DRC update without rewriting the whole loop.
<span style="display:none">[^2_10][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://www.reddit.com/r/pipewire/comments/uorvce/dynamic_range_compression_aka_loudness_equalizer/

[^2_2]: https://documentation.help/BASS/BASS_ChannelGetLevel.html

[^2_3]: http://www.un4seen.com/doc/bass/BASS_ATTRIB_BUFFER.html

[^2_4]: https://forum.manjaro.org/t/crackling-popping-sounds-with-pipewire/161123

[^2_5]: https://forum.endeavouros.com/t/pipewire-tweak-crackling-popping-fix/32860

[^2_6]: https://forum.endeavouros.com/t/pipewire-guide-audio-crackling-popping-and-latency/69602

[^2_7]: https://mango.vg/post/20

[^2_8]: https://bbs.archlinux.org/viewtopic.php?id=262981

[^2_9]: http://bass.radio42.com/help/html/ee4376c4-146b-e632-3ebb-6294db2e837d.htm

[^2_10]: https://discourse.ardour.org/t/ardour-pipewire-sound-stuttering-crackling-popping-when-adjusting-system-volume/109054

