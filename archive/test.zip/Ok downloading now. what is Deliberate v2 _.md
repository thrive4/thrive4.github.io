<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Ok downloading now. what is Deliberate v2 ?

Deliberate v2 is a custom Stable Diffusion 1.5–based checkpoint that’s been heavily fine‑tuned and merged to be a very strong “general‑purpose” SD 1.5 model for lots of styles (realistic, semi‑realistic, illustration, etc.).[^1_2][^1_4]

### Key points about Deliberate v2

- It’s still an SD 1.5 model under the hood, so you use it exactly like your v1.5 checkpoint: same resolutions (e.g. 512×512), same samplers, same general settings.[^1_4][^1_2]
- It was trained/merged using a huge curated dataset of high‑quality images (including generations from other models), which is why people like it as an “all‑rounder” that gives good results even with shorter prompts.[^1_2][^1_4]
- You download it as a single `.safetensors` / checkpoint file and drop it into the same `ComfyUI\models\checkpoints` folder as your SD 1.5 model, then just pick it in the checkpoint loader node instead of `v1-5-pruned-emaonly`.[^1_4]
- It’s popular for portraits, characters and general art because it tends to produce clean, detailed images with less effort on prompt engineering.[^1_2][^1_4]

If you want to try it after SD 1.5 is working, the process is:

1. Download a Deliberate v2 `.safetensors` checkpoint.[^1_4]
2. Put it in `ComfyUI_windows_portable_nvidia\ComfyUI\models\checkpoints\Deliberate_v2.safetensors`.
3. In your existing SD 1.5 workflow, just switch the checkpoint loader from `v1-5-pruned-emaonly` to `Deliberate_v2`.

Everything else (VAE, resolution, sampler) can stay the same at first.
<span style="display:none">[^1_1][^1_10][^1_3][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://www.reddit.com/r/StableDiffusion/comments/11buf3o/psa_deliberate_v2_has_been_released_today/

[^1_2]: https://www.diffusionai.art/deliberate-v2/

[^1_3]: https://huggingface.co/stablediffusionapi/deliberate-v2

[^1_4]: https://prompthero.com/ai-models/deliberate-download/v2

[^1_5]: https://www.facebook.com/groups/stablediffusion/posts/1435014520497352/

[^1_6]: https://stablediffusionapi.com/index.php/models/deliberate-v2?page=17

[^1_7]: https://www.comfy.org

[^1_8]: https://github.com/nod-ai/AMD-SHARK-Studio/issues/1138

[^1_9]: https://github.com/camenduru/comfyui-colab

[^1_10]: https://www.reddit.com/r/StableDiffusion/comments/18jfiqn/is_my_deliberate_v2_working_well/


---

# Hmmm : [https://huggingface.co/stablediffusionapi/deliberate-v2](https://huggingface.co/stablediffusionapi/deliberate-v2) : 'Get API key from [ModelsLab API](http://modelslab.com), No Payment needed.

Replace Key in below code, change model_id to "deliberate-v2"' plus : [https://huggingface.co/stablediffusionapi/deliberate-v2/tree/main](https://huggingface.co/stablediffusionapi/deliberate-v2/tree/main) : lot of seperate files ...

You’re looking at the wrong Deliberate v2 on Hugging Face for local use.

That `stablediffusionapi/deliberate-v2` repo is meant for their hosted API (ModelsLab), which is why you see: “Get API key… change model_id to deliberate-v2” and a lot of separate smaller files for their backend. Those are not what you want to drop into ComfyUI.

For **local ComfyUI**, you need a single SD1.5 checkpoint file (a `.safetensors` or `.ckpt`) of Deliberate v2, typically around 2–7 GB. That file goes straight into:

`ComfyUI_windows_portable_nvidia\ComfyUI\models\checkpoints\`

So the gist:

- Ignore that API‑style Deliberate repo with many little files.
- Instead, find a Deliberate v2 model download that is a single checkpoint (e.g. `Deliberate_v2.safetensors`).
- Put that file in `models\checkpoints`, then select it in your Load Checkpoint node like any other SD1.5 model.

Once you have SD 1.5 working, adding Deliberate is literally just “another checkpoint in the same folder, then pick it from the dropdown.” If you want, I can describe what the correct kind of download page/file will look like so you can double‑check before you grab it.
<span style="display:none">[^2_1][^2_10][^2_2][^2_3][^2_4][^2_5][^2_6][^2_7][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://lilys.ai/en/notes/comfyui-tutorial-20251031/install-and-use-comfyui-stable-diffusion

[^2_2]: https://comfyui-wiki.com/en/install/install-models/install-checkpoint

[^2_3]: https://www.youtube.com/watch?v=KTPLOqAMR0s

[^2_4]: https://www.youtube.com/watch?v=gNwg8HLMUuk

[^2_5]: https://www.youtube.com/watch?v=jXkXqzrQ8Ks

[^2_6]: https://www.reddit.com/r/StableDiffusion/comments/17iyu8v/what_happened_to_deliberate_and_reliberate_on/

[^2_7]: https://www.youtube.com/watch?v=u4o4u8dXQ1I

[^2_8]: https://www.facebook.com/groups/stablediffusion/posts/1435014520497352/

[^2_9]: https://stable-diffusion-art.com/comfyui/

[^2_10]: https://www.youtube.com/watch?v=koFcGquFvr8


---

# Ok like this? [https://huggingface.co/XpucT/Deliberate/blob/main/Deliberate_v2.safetensors](https://huggingface.co/XpucT/Deliberate/blob/main/Deliberate_v2.safetensors)

Yes, that's the correct Deliberate v2 checkpoint for local ComfyUI use—a single 2.13 GB `.safetensors` file from XpucT's official repo.[^3_1][^3_7]

### Quick install steps

1. On that page, click the **Download** button (or right-click the file name and "Save link as...") to get `Deliberate_v2.safetensors`.
2. Drop it into:
`ComfyUI_windows_portable_nvidia\ComfyUI\models\checkpoints\Deliberate_v2.safetensors`
3. Restart ComfyUI (or refresh the model list).
4. In your SD 1.5 workflow's **CheckpointLoader** node, select `Deliberate_v2.safetensors` from the dropdown (replacing `v1-5-pruned-emaonly` if you want).
5. Keep using your existing VAE, prompt, 512×512 resolution, etc.—it works identically as an SD 1.5 model.[^3_3][^3_7]

This one's popular because it needs minimal prompt fussing for strong results across styles. Once your base SD 1.5 is running, swap to this and compare outputs on the same prompt/seed.[^3_4][^3_7]
<span style="display:none">[^3_2][^3_5][^3_6][^3_8][^3_9]</span>

<div align="center">⁂</div>

[^3_1]: https://huggingface.co/XpucT/Deliberate/blob/main/Deliberate_v2.safetensors

[^3_2]: https://huggingface.co/XpucT/Deliberate/blame/e299e5bd08c5b7a3bdbef9370899a2aa114ed39e/Deliberate_v2.safetensors

[^3_3]: https://www.reddit.com/r/StableDiffusion/comments/18jfiqn/is_my_deliberate_v2_working_well/

[^3_4]: https://www.diffusionai.art/deliberate-v2/

[^3_5]: https://prompthero.com/ai-models/deliberate-download

[^3_6]: https://prompthero.com/ai-models/deliberate-download/v2

[^3_7]: https://huggingface.co/XpucT/Deliberate

[^3_8]: https://github.com/vladmandic/automatic/discussions/2579

[^3_9]: https://huggingface.co/XpucT/Deliberate/blob/b1410ac46dbfe5ee838c2116f2b282d5bd70f3b8/Deliberate_v2-inpainting.safetensors

