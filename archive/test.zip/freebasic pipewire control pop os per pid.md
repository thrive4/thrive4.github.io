<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# That's good news getting the pid is going to complicated ... I think so : wah@:/media/wah/games/source/audioplayer-bass\$ wpctl status

PipeWire 'pipewire-0' [1.5.85, wah@pop-os, cookie:3804764287]
└─ Clients:
33. WirePlumber                         [1.5.85, wah@pop-os, pid:1483]
37. pipewire                            [1.5.85, wah@pop-os, pid:1485]
47. WirePlumber [export]                [1.5.85, wah@pop-os, pid:1483]
59. cosmic-osd                          [1.5.85, wah@pop-os, pid:1610]
60. cosmic-osd                          [1.5.85, wah@pop-os, pid:1637]
61. cosmic-applets                      [1.5.85, wah@pop-os, pid:1923]
62. xdg-desktop-portal                  [1.5.85, wah@pop-os, pid:1911]
63. system76-scheduler                  [1.5.85, root@pop-os, pid:1388]
73. speech-dispatcher-dummy             [1.5.85, wah@pop-os, pid:11395]
74. PipeWire ALSA [audioplayer]         [1.5.85, wah@pop-os, pid:35130]
79. wpctl                               [1.5.85, wah@pop-os, pid:35273]
84. PipeWire ALSA [audioplayer]         [1.5.85, wah@pop-os, pid:35130] : somehow my app 'audioplayer' is one of them ...

Yes — that output is actually encouraging. Your app is showing up as `PipeWire ALSA [audioplayer]` with `pid:35130`, so you already have the PID you need to target app-specific volume control.

## What to use

For that app, the relevant command should be along the lines of:

```bash
wpctl set-volume --pid 35130 0.8
```

or to mute/unmute just that app:

```bash
wpctl set-mute --pid 35130 1
wpctl set-mute --pid 35130 0
```

That is the PipeWire equivalent of controlling a per-app channel rather than the master sink.

## In your case

Since the app is listed directly in `wpctl status`, you may not need any extra discovery logic at all. You can:

- scan the status output for `PipeWire ALSA [audioplayer]`,
- extract the PID in brackets,
- use that PID for `set-volume --pid ...`.

That should be much simpler than trying to map mixer-style channels the old Windows way.

## Important detail

Your app appears twice in the list, with the same PID. That usually means there may be multiple PipeWire nodes or streams tied to the same process, so PID-based control is the right level to start with. If the volume command affects both entries, that is expected.

## For FreeBASIC

A practical route is:

- run `wpctl status`,
- parse the line containing your app name,
- grab the PID value,
- store it,
- call `wpctl set-volume --pid <pid> ...` for app volume changes.

That should get you very close to the Windows mixer behavior without needing deep PipeWire internals.

