<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# What is the correlation between the period in this query 1800 ~ 2000 and the elements in the json result timeseries? : [https://books.google.com/ngrams/json?content=jimi+hendrix\&year_start=1800\&year_end=2000\&corpus=en\&smoothing=3](https://books.google.com/ngrams/json?content=jimi+hendrix&year_start=1800&year_end=2000&corpus=en&smoothing=3) :

The period parameters in the URL (1800–2000) define the sequence of years, and the `timeseries` array in the JSON aligns 1‑to‑1 with those years in order. Each element in `timeseries` is the relative frequency of the phrase “jimi hendrix” for a specific year, starting at `year_start` and increasing by 1 year for each subsequent element until `year_end`.[^1_2][^1_3]

## How years map to indices

For this specific URL:

- `year_start = 1800`
- `year_end = 2000`

The first element of `timeseries` corresponds to 1800, the second to 1801, the third to 1802, and so on, continuing up to 2000 for the last element.[^1_4][^1_2]
Formally, if `timeseries[i]` is the element at zero‑based index `i`, its year is $1800 + i$.[^1_3]

## What each value represents

Each `timeseries` value is the relative frequency of the phrase in the chosen corpus for that year (occurrences of the phrase divided by all words in that year’s corpus).[^1_2][^1_4]
So the correlation is purely positional: the period sets the year range, and the array provides one frequency value for each year in that range, in chronological order.[^1_3]
<span style="display:none">[^1_1][^1_10][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://codedragon.tistory.com/6939

[^1_2]: https://rdrr.io/github/seancarmody/ngramr/man/ngram.html

[^1_3]: https://jameshfisher.com/2018/11/25/google-ngram-api/

[^1_4]: https://konstantinstadler.site/posts/google_ngram_in_python/

[^1_5]: https://www.reddit.com/r/linguistics/comments/eogj5/google_ngram_on_the_rise_of_american_spelling/

[^1_6]: https://johannesfilter.com/how-to-export-data-from-google-ngram-viewer/

[^1_7]: https://hawksites.newpaltz.edu/dhm293/online-assignment-5-google-ngrams/

[^1_8]: https://lkirst.github.io/lie-esl/tools/google-books-ngram-viewer/

[^1_9]: https://github.com/Bookworm-project/NgramScript

[^1_10]: https://pypi.org/project/google-ngram-downloader/3.0/


---

# Ah each element represents 1 year so month_start=1\&month_end=12 would result in twelve timesseries ... ?

The Ngram JSON you are using is purely yearly; there is no supported `month_start` or `month_end` parameter, so you will never get 12 monthly values per year from that API.[^2_2]

## What one element represents

For the Google Books Ngram Viewer JSON endpoint, each element in `timeseries` always represents one year in the requested range.[^2_4][^2_2]
Even if you added something like `month_start=1&month_end=12` to the URL, the backend ignores those parameters for this service and still returns only yearly data.[^2_2]

## Monthly data availability

The public Ngram Viewer and its documented API only expose year-level frequencies, not months.[^2_6][^2_2]
To work with finer temporal resolution, one would need a different dataset or a different Google Books–related product that explicitly provides sub‑annual counts, but that is not how the Ngram Viewer endpoint works.[^2_3][^2_6]
<span style="display:none">[^2_1][^2_5][^2_7][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://capitalaspower.com/2021/11/working-with-google-ngrams-a-data-wrangling-tale/

[^2_2]: https://books.google.com/ngrams/info

[^2_3]: https://registry.opendata.aws/google-ngrams/

[^2_4]: https://stressosaurus.github.io/raw-data-google-ngram/

[^2_5]: https://blog.gdeltproject.org/the-world-as-seen-through-books-comparing-the-internet-archive-hathitrust-and-google-books-ngrams-collections/

[^2_6]: https://console.cloud.google.com/marketplace/product/bigquery-public-data/google-books-ngrams-2020

[^2_7]: https://www.kaggle.com/datasets/bilalyussef/google-books-dataset

[^2_8]: https://research.google.com/pubs/archive/41603.pdf

[^2_9]: https://arxiv.org/pdf/1512.01364.pdf


---

# ok year_start=1800\&year_end=1810 results in 10 timeseries ...

For the Ngram Viewer JSON, the number of `timeseries` elements equals the number of years included in the range, counting inclusively.[^3_2][^3_5]

## How the count is determined

The service includes both `year_start` and `year_end` in the range.[^3_2]
That means the number of `timeseries` points is $\text{year\_end} - \text{year\_start} + 1$.[^3_5]

## Applying this to 1800–1810

For `year_start=1800&year_end=1810`, the number of years is $1810 - 1800 + 1 = 11$.[^3_2]
So this range produces 11 `timeseries` values (for 1800, 1801, …, 1810), not 10.[^3_5][^3_2]
<span style="display:none">[^3_1][^3_3][^3_4][^3_6][^3_7][^3_8][^3_9]</span>

<div align="center">⁂</div>

[^3_1]: https://www.storytellingwithdata.com/blog/2010/12/google-ngram-viewer

[^3_2]: https://en.wikipedia.org/wiki/Google_Books_Ngram_Viewer

[^3_3]: https://books.google.com/ngrams/info

[^3_4]: https://capitalaspower.com/2021/11/working-with-google-ngrams-a-data-wrangling-tale/

[^3_5]: https://infoguides.gmu.edu/textanalysistools/ngram

[^3_6]: https://research.google.com/pubs/archive/42490.pdf

[^3_7]: https://tamu.libguides.com/c.php?g=1269483\&p=9417812

[^3_8]: https://books.google.com/ngrams/

[^3_9]: https://blogs.library.jhu.edu/2016/05/google-ngram-viewer-culturomics/


---

# Ah good catch quite right.

Glad that matches what you expected.

## Year range recap

For this API, the year range is always inclusive, so the count of elements is $\text{year\_end} - \text{year\_start} + 1$.
Each element of `timeseries` maps directly to one year in that inclusive range, in order.

---

# Ok nice now that is clear could you setup a simple html page with some javascript that gets the json breaking up the parameters in [https://books.google.com/ngrams/json?content=jimi+hendrix\&year_start=1800\&year_end=2000\&corpus=en\&smoothing=3](https://books.google.com/ngrams/json?content=jimi+hendrix&year_start=1800&year_end=2000&corpus=en&smoothing=3) and displays in say console.log or console.table ?

Here is a minimal example HTML page that takes the parts of that URL as separate parameters, builds the request, fetches the JSON, and logs it with `console.log` and `console.table`.

```html
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Simple Ngram JSON Demo</title>
</head>
<body>
  <h1>Google Ngram JSON Demo</h1>

  <script>
    // Parameters broken out
    const content   = "jimi hendrix";   // ngram phrase
    const yearStart = 1800;
    const yearEnd   = 2000;
    const corpus    = "en";
    const smoothing = 3;

    // Build URL
    const baseUrl = "https://books.google.com/ngrams/json";
    const params  = new URLSearchParams({
      content: content,
      year_start: yearStart,
      year_end: yearEnd,
      corpus: corpus,
      smoothing: smoothing
    });

    const url = `${baseUrl}?${params.toString()}`;

    console.log("Requesting:", url);

    // Fetch JSON and log
    fetch(url)
      .then(response => {
        if (!response.ok) {
          throw new Error("Network response was not ok: " + response.status);
        }
        return response.json();
      })
      .then(data => {
        // data is an array; each element has .ngram, .timeseries, etc.
        console.log("Raw data:", data);
        console.table(data);

        // Example: log first entry’s timeseries
        if (data.length > 0) {
          console.log("First entry timeseries:", data[0].timeseries);
        }
      })
      .catch(error => {
        console.error("Error fetching Ngram data:", error);
      });
  </script>
</body>
</html>
```

Open this file in a browser, then check the developer console to see the URL, the raw JSON array, and a table view of the objects. You can later wire `content`, `yearStart`, etc. to form inputs if you want it to be interactive.

---

# Nice ok small tweak needed a proxy so :     const cors    = 'https://corsproxy.io/?';

    const baseUrl = cors + "https://books.google.com/ngrams/json";
    righty what does 'smoothing' do?

Here's the updated HTML with the CORS proxy tweak. Just replace the `baseUrl` line as shown.

```html
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Simple Ngram JSON Demo</title>
</head>
<body>
  <h1>Google Ngram JSON Demo</h1>

  <script>
    // Parameters broken out
    const content   = "jimi hendrix";
    const yearStart = 1800;
    const yearEnd   = 2000;
    const corpus    = "en";
    const smoothing = 3;

    // Build URL with CORS proxy
    const cors    = 'https://corsproxy.io/?';
    const baseUrl = cors + "https://books.google.com/ngrams/json";
    const params  = new URLSearchParams({
      content: content,
      year_start: yearStart,
      year_end: yearEnd,
      corpus: corpus,
      smoothing: smoothing
    });

    const url = `${baseUrl}${params.toString()}`;

    console.log("Requesting:", url);

    // Fetch JSON and log
    fetch(url)
      .then(response => {
        if (!response.ok) {
          throw new Error("Network response was not ok: " + response.status);
        }
        return response.json();
      })
      .then(data => {
        console.log("Raw data:", data);
        console.table(data);
        if (data.length > 0) {
          console.log("First entry timeseries:", data[^6_0].timeseries);
        }
      })
      .catch(error => {
        console.error("Error fetching Ngram data:", error);
      });
  </script>
</body>
</html>
```


## What smoothing does

The `smoothing` parameter applies a moving average to the raw yearly frequencies, reducing jagged spikes and making trends clearer.[^6_2][^6_4]
A value of 3 (as in your example) averages each year's data with 3 years on either side—for year 1950, it uses (1947+1948+1949+1950+1951+1952+1953)/7.[^6_4][^6_5]
At edges, it uses available years only; 0 means raw data with no averaging.[^6_4]
<span style="display:none">[^6_1][^6_10][^6_3][^6_6][^6_7][^6_8][^6_9]</span>

<div align="center">⁂</div>

[^6_1]: https://corsproxy.io

[^6_2]: https://guides.library.upenn.edu/penntdm/tools/ngram_viewer

[^6_3]: https://sage-tips.com/recommendations/what-does-the-google-ngram-viewer-do/

[^6_4]: https://books.google.com/ngrams/info

[^6_5]: https://juvenileinstructor.org/using-googles-ngram-viewer-for-historical-textual-analysis/

[^6_6]: https://infoguides.gmu.edu/textanalysistools/ngram

[^6_7]: https://www.youtube.com/watch?v=qzbjPq8vwx8

[^6_8]: https://books.google.com/ngrams/

[^6_9]: https://lacenews.net/2010/12/18/on-the-internet-google-ngram-viewer/

[^6_10]: https://search.r-project.org/CRAN/refmans/ngramr/html/ngram.html


---

# Okidoki I see gracias. Right lets up the ante I am using d3.v6.min.js from : https://d3js.org/: could we do / add something similar chart wise as : [https://books.google.com/ngrams/graph?content=jimi+hendrix\&year_start=1800\&year_end=2000\&corpus=en\&smoothing=3\&case_insensitive=false](https://books.google.com/ngrams/graph?content=jimi+hendrix&year_start=1800&year_end=2000&corpus=en&smoothing=3&case_insensitive=false) : to current code and display a line graph?

Here's the updated HTML with a D3 v6 line chart mimicking the Google Ngram graph style. Save d3.v6.min.js locally or use the CDN.

```html
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Ngram Line Chart Demo</title>
  <script src="https://d3js.org/d3.v6.min.js"></script>
  <style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    svg { border: 1px solid #ddd; }
    .line { fill: none; stroke: #1f77b4; stroke-width: 2px; }
    .axis path, .axis line { stroke: #999; shape-rendering: crispEdges; }
    .axis text { font-size: 11px; fill: #666; }
    .x.axis path { display: none; }
    .y.axis path { display: none; }
    .grid line { stroke: #eee; stroke-opacity: 0.7; shape-rendering: crispEdges; }
  </style>
</head>
<body>
  <h1>Jimi Hendrix Ngram Line Chart</h1>
  <div id="chart"></div>

  <script>
    // Parameters
    const content   = "jimi hendrix";
    const yearStart = 1800;
    const yearEnd   = 2000;
    const corpus    = "en";
    const smoothing = 3;

    // Chart dimensions
    const margin = {top: 20, right: 20, bottom: 40, left: 50};
    const width = 800 - margin.left - margin.right;
    const height = 400 - margin.top - margin.bottom;

    // CORS proxy + build URL
    const cors = 'https://corsproxy.io/?';
    const baseUrl = cors + "https://books.google.com/ngrams/json";
    const params = new URLSearchParams({
      content, year_start: yearStart, year_end: yearEnd,
      corpus, smoothing
    });
    const url = `${baseUrl}${params}`;

    // Create SVG
    const svg = d3.select("#chart")
      .append("svg")
      .attr("width", width + margin.left + margin.right)
      .attr("height", height + margin.top + margin.bottom)
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

    // Scales
    const x = d3.scaleLinear().range([0, width]);
    const y = d3.scaleLinear().range([height, 0]);

    // Line generator
    const line = d3.line()
      .x(d => x(d.year))
      .y(d => y(d.frequency))
      .curve(d3.curveMonotoneX);

    // Axes
    const xAxis = g => g
      .attr("transform", `translate(0,${height})`)
      .call(d3.axisBottom(x).ticks(10))
      .selectAll("text")
      .style("text-anchor", "end")
      .attr("dx", "-.8em")
      .attr("dy", ".15em")
      .attr("transform", "rotate(-45)");

    const yAxis = g => g.call(d3.axisLeft(y).ticks(8));

    // Grid
    svg.append("g").attr("class", "grid")
      .call(d3.axisLeft(y).ticks(8).tickSize(-width).tickFormat(""));

    // Fetch and render
    fetch(url)
      .then(res => res.json())
      .then(data => {
        // Transform data: single ngram expected
        const timeseries = data[^7_0].timeseries;
        const chartData = timeseries.map((freq, i) => ({
          year: yearStart + i,
          frequency: freq
        }));

        // Update domains
        x.domain(d3.extent(chartData, d => d.year));
        y.domain([0, d3.max(chartData, d => d.frequency)]).nice();

        // Draw line
        svg.append("path")
          .datum(chartData)
          .attr("class", "line")
          .attr("d", line);

        // Draw axes
        svg.append("g").attr("class", "x axis").call(xAxis);
        svg.append("g").attr("class", "y axis").call(yAxis);

        console.table(chartData.slice(0, 10)); // First 10 points
        console.log("Full data:", chartData);
      })
      .catch(err => console.error("Error:", err));
  </script>
</body>
</html>
```

This creates a clean line chart with axes, subtle grid, and the signature Ngram blue line—just like the Google graph. Open in browser and it fetches + renders automatically.
<span style="display:none">[^7_1][^7_10][^7_2][^7_3][^7_4][^7_5][^7_6][^7_7][^7_8][^7_9]</span>

<div align="center">⁂</div>

[^7_1]: https://sharkcoder.com/data-visualization/d3-line-chart

[^7_2]: https://stackoverflow.com/questions/68342421/how-to-create-line-chart-with-json-data-using-d3

[^7_3]: https://www.youtube.com/watch?v=g5bp02-CRAc

[^7_4]: https://www.sitepoint.com/creating-simple-line-bar-charts-using-d3-js/

[^7_5]: https://www.youtube.com/watch?v=0vKYFsTLtbA

[^7_6]: https://d3-graph-gallery.com/graph/line_basic.html

[^7_7]: https://d3-graph-gallery.com/line.html

[^7_8]: https://d3js.org/d3-shape/line

[^7_9]: https://gist.github.com/gordlea/27370d1eea8464b04538e6d8ced39e89

[^7_10]: https://d3js.org/getting-started


---

# There is a slight issue with the url generated : [https://corsproxy.io/?https://books.google.com/ngrams/jsoncontent=jimi+hendrix\&year_start=1800\&year_end=2000\&corpus=en\&smoothing=3](https://corsproxy.io/?https://books.google.com/ngrams/jsoncontent=jimi+hendrix&year_start=1800&year_end=2000&corpus=en&smoothing=3) : it should be json?content ...

You're right—the `?` is missing after `/json`. Here's the fixed URL construction:

```javascript
// Fixed URL construction
const cors    = 'https://corsproxy.io/?';
const baseUrl = cors + "https://books.google.com/ngrams/json";
const params  = new URLSearchParams({
  content: content,
  year_start: yearStart,
  year_end: yearEnd,
  corpus: corpus,
  smoothing: smoothing
});

const url = `${baseUrl}?${params.toString()}`;  // Added missing ?
```


## Complete corrected script section

Replace just the URL building part in your HTML with this:

```javascript
// CORS proxy + build URL (FIXED)
const cors    = 'https://corsproxy.io/?';
const baseUrl = cors + "https://books.google.com/ngrams/json";
const params  = new URLSearchParams({
  content, year_start: yearStart, year_end: yearEnd,
  corpus, smoothing
});
const url = `${baseUrl}?${params}`;  // Now correctly: .../json?content=...

console.log("Requesting:", url);  // Will show correct URL
```

Now it generates `https://corsproxy.io/?https://books.google.com/ngrams/json?content=jimi%20hendrix&year_start=1800&...` which works perfectly. The chart should now fetch data successfully.

---

# Great it is indeed fixed. So that we are on one page I  know have : <!doctype html>

<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Ngram Line Chart Demo</title>
  <script src="js/d3.v6.min.js"></script>
  <style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    svg { border: 1px solid #ddd; }
    .line { fill: none; stroke: #1f77b4; stroke-width: 2px; }
    .axis path, .axis line { stroke: #999; shape-rendering: crispEdges; }
    .axis text { font-size: 11px; fill: #666; }
    .x.axis path { display: none; }
    .y.axis path { display: none; }
    .grid line { stroke: #eee; stroke-opacity: 0.7; shape-rendering: crispEdges; }
  </style>
</head>
<body>
  <h1>Jimi Hendrix Ngram Line Chart</h1>
  <div id="chart"></div>
  <script>
    // ngram query
    const content   = "sherlock holmes";
    const yearStart = 1800;
    const yearEnd   = 2000;
    const corpus    = "en";
    const smoothing = 3;

    // init chart
    const margin = {top: 20, right: 20, bottom: 40, left: 50};
    const width = 800 - margin.left - margin.right;
    const height = 400 - margin.top - margin.bottom;

    // get data
    const cors    = 'https://corsproxy.io/?';
    const baseUrl = cors + "https://books.google.com/ngrams/json";
    const params  = new URLSearchParams({
      content, year_start: yearStart, year_end: yearEnd,
      corpus, smoothing
    });
    const url = `${baseUrl}?${params}`;
    //console.log("Requesting:", url);

    const svg = d3.select("#chart")
      .append("svg")
      .attr("width", width + margin.left + margin.right)
      .attr("height", height + margin.top + margin.bottom)
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

    // setup chart
    const x = d3.scaleLinear().range([0, width]);
    const y = d3.scaleLinear().range([height, 0]);
    const line = d3.line()
      .x(d => x(d.year))
      .y(d => y(d.frequency))
      .curve(d3.curveMonotoneX);
    const xAxis = g => g
      .attr("transform", `translate(0,${height})`)
      .call(d3.axisBottom(x).ticks(10))
      .selectAll("text")
      .style("text-anchor", "end")
      .attr("dx", "-.8em")
      .attr("dy", ".15em")
      .attr("transform", "rotate(-45)");
    const yAxis = g => g.call(d3.axisLeft(y).ticks(8));

    svg.append("g").attr("class", "grid")
      .call(d3.axisLeft(y).ticks(8).tickSize(-width).tickFormat(""));

    fetch(url)
      .then(res => res.json())
      .then(data => {
        // Transform data: single ngram expected
        const timeseries = data[0].timeseries;
        const chartData = timeseries.map((freq, i) => ({
          year: yearStart + i,
          frequency: freq
        }));

        // Update domains
        x.domain(d3.extent(chartData, d => d.year));
        y.domain([0, d3.max(chartData, d => d.frequency)]).nice();

        // Draw line
        svg.append("path")
          .datum(chartData)
          .attr("class", "line")
          .attr("d", line);

        // Draw axes
        svg.append("g").attr("class", "x axis").call(xAxis);
        svg.append("g").attr("class", "y axis").call(yAxis);

        //console.table(chartData.slice(0, 10)); // First 10 points
        //console.log("Full data:", chartData);
      })
      .catch(err => console.error("Error:", err));
  </script>
</body>
</html>
: how ever the x-axis shows the years as 1.800, 1.820, etc ....

The numbers are fine; it’s just your browser’s locale formatting the tick labels as 1.800, 1.820, etc. You can force plain year labels on the x‑axis with a tick format.

## Fixing the x-axis labels

Add an explicit tick format using `d3.format("d")` so years render as `1800`, `1820`, etc., not `1.800`:

```javascript
const xAxis = g => g
  .attr("transform", `translate(0,${height})`)
  .call(
    d3.axisBottom(x)
      .ticks(10)
      .tickFormat(d3.format("d"))   // force integer, no thousands separator
  )
  .selectAll("text")
  .style("text-anchor", "end")
  .attr("dx", "-.8em")
  .attr("dy", ".15em")
  .attr("transform", "rotate(-45)");
```

This keeps your existing rotation and styling, but the labels will now show as clean integer years instead of locale‑formatted numbers.
<span style="display:none">[^9_1][^9_2][^9_3][^9_4][^9_5][^9_6][^9_7][^9_8][^9_9]</span>

<div align="center">⁂</div>

[^9_1]: https://www.youtube.com/watch?v=zEKKd471-gg

[^9_2]: https://stackoverflow.com/questions/53751241/create-a-n-gram-model-for-custom-vocabulary

[^9_3]: https://d3js.org/d3-hierarchy

[^9_4]: https://d3-graph-gallery.com/graph/dendrogram_basic.html

[^9_5]: https://github.com/d3/d3-hierarchy

[^9_6]: https://devdocs.io/d3~6/

[^9_7]: https://www.dashingd3js.com/d3-tutorial

[^9_8]: https://d3-graph-gallery.com/graph/dendrogram_radial_basic.html

[^9_9]: https://stackoverflow.com/questions/66198251/tornado-chart-converting-from-d3-v3-to-v6


---

# Nice better gracias. Would it be possible to add a dotted vertical line (length y-axis) at the mouse pointers location plus a tooltip indicating 'content' and year?

Yes, add mouse interaction with a dotted vertical line (follows y-axis full height) and tooltip showing the ngram content + year. Here's the addition:

## Add after scales/line setup, before fetch

```javascript
// Mouse interaction setup
let focus = svg.append("g").style("opacity", 0);
let tooltip = d3.select("body").append("div")
  .style("position", "absolute")
  .style("background", "rgba(0,0,0,0.8)")
  .style("color", "white")
  .style("padding", "5px 10px")
  .style("border-radius", "4px")
  .style("font-size", "12px")
  .style("pointer-events", "none")
  .style("opacity", 0);

// Dotted vertical line
focus.append("line")
  .attr("class", "focusLine")
  .attr("x1", 0).attr("x2", 0)
  .attr("y1", 0).attr("y2", height)
  .style("stroke", "#666")
  .style("stroke-width", "1px")
  .style("stroke-dasharray", "3,3");
```


## Update fetch .then() block

Replace your existing `.then(data => { ...` with this (adds mouse handlers after drawing):

```javascript
.then(data => {
  const timeseries = data[0].timeseries;
  const chartData = timeseries.map((freq, i) => ({
    year: yearStart + i,
    frequency: freq
  }));

  x.domain(d3.extent(chartData, d => d.year));
  y.domain([0, d3.max(chartData, d => d.frequency)]).nice();

  svg.append("path").datum(chartData).attr("class", "line").attr("d", line);
  svg.append("g").attr("class", "x axis").call(xAxis);
  svg.append("g").attr("class", "y axis").call(yAxis);

  // Mouse interaction
  svg.append("rect")
    .attr("width", width).attr("height", height)
    .style("fill", "none")
    .style("pointer-events", "all")
    .on("mouseover", () => focus.style("opacity", 1))
    .on("mouseout", () => focus.style("opacity", 0))
    .on("mousemove", (event) => {
      const bisect = d3.bisector(d => d.year).left;
      const x0 = x.invert(d3.pointer(event, svg.node())[0]);
      const i = bisect(chartData, x0, 1);
      const d0 = chartData[i - 1];
      const d1 = chartData[i];
      const d = x0 - d0.year > d1.year - x0 ? d1 : d0;

      focus.select(".focusLine").attr("x1", x(d.year)).attr("x2", x(d.year));
      tooltip.style("opacity", 1)
        .style("left", (event.pageX + 10) + "px")
        .style("top", (event.pageY - 20) + "px")
        .html(`${content}<br/>Year: ${d.year}`);
    });
});
```

Now hover anywhere on the chart: dotted line snaps to nearest year, tooltip shows "sherlock holmes" + year.

---

# Could you do the last tweak  to :     fetch(url)

      .then(res => res.json())
      .then(data => {
        // Transform data: single ngram expected
        const timeseries = data[0].timeseries;
        const chartData = timeseries.map((freq, i) => ({
          year: yearStart + i,
          frequency: freq
        }));
    
        // Update domains
        x.domain(d3.extent(chartData, d => d.year));
        y.domain([0, d3.max(chartData, d => d.frequency)]).nice();
    
        // Draw line
        svg.append("path")
          .datum(chartData)
          .attr("class", "line")
          .attr("d", line);
    
        // Draw axes
        svg.append("g").attr("class", "x axis").call(xAxis);
        svg.append("g").attr("class", "y axis").call(yAxis);
    
        //console.table(chartData.slice(0, 10)); // First 10 points
        //console.log("Full data:", chartData);
      })
      .catch(err => console.error("Error:", err));
    Here's your exact `fetch` block with the mouse interaction added:

```javascript
fetch(url)
  .then(res => res.json())
  .then(data => {
    // Transform data: single ngram expected
    const timeseries = data[0].timeseries;
    const chartData = timeseries.map((freq, i) => ({
      year: yearStart + i,
      frequency: freq
    }));

    // Update domains
    x.domain(d3.extent(chartData, d => d.year));
    y.domain([0, d3.max(chartData, d => d.frequency)]).nice();

    // Draw line
    svg.append("path")
      .datum(chartData)
      .attr("class", "line")
      .attr("d", line);

    // Draw axes
    svg.append("g").attr("class", "x axis").call(xAxis);
    svg.append("g").attr("class", "y axis").call(yAxis);

    // Mouse interaction
    const focus = svg.append("g").style("opacity", 0);
    const tooltip = d3.select("body").append("div")
      .style("position", "absolute")
      .style("background", "rgba(0,0,0,0.8)")
      .style("color", "white")
      .style("padding", "5px 10px")
      .style("border-radius", "4px")
      .style("font-size", "12px")
      .style("pointer-events", "none")
      .style("opacity", 0);

    focus.append("line")
      .attr("class", "focusLine")
      .attr("x1", 0).attr("x2", 0)
      .attr("y1", 0).attr("y2", height)
      .style("stroke", "#666")
      .style("stroke-width", "1px")
      .style("stroke-dasharray", "3,3");

    svg.append("rect")
      .attr("width", width).attr("height", height)
      .style("fill", "none")
      .style("pointer-events", "all")
      .on("mouseover", () => focus.style("opacity", 1))
      .on("mouseout", () => focus.style("opacity", 0))
      .on("mousemove", (event) => {
        const bisect = d3.bisector(d => d.year).left;
        const x0 = x.invert(d3.pointer(event, svg.node())[0]);
        const i = bisect(chartData, x0, 1);
        const d0 = chartData[i - 1];
        const d1 = chartData[i];
        const d = x0 - d0.year > d1.year - x0 ? d1 : d0;

        focus.select(".focusLine").attr("x1", x(d.year)).attr("x2", x(d.year));
        tooltip.style("opacity", 1)
          .style("left", (event.pageX + 10) + "px")
          .style("top", (event.pageY - 20) + "px")
          .html(`${content}<br/>Year: ${d.year}`);
      });
  })
  .catch(err => console.error("Error:", err));
```

**Don't forget** to add this CSS to your `<style>` block for the tooltip:

```css
.tooltip {
  position: absolute;
  background: rgba(0,0,0,0.8);
  color: white;
  padding: 5px 10px;
  border-radius: 4px;
  font-size: 12px;
  pointer-events: none;
  opacity: 0;
}
```

Now hover over the chart area - you'll get the dotted vertical line snapping to years + tooltip with "sherlock holmes" and the year!

---

# Nice got it merci. In retrospect might be handy to add the y value to the tooltip as well ...

Just update the tooltip HTML line in the `mousemove` handler:

```javascript
.html(`${content}<br/>Year: ${d.year}<br/>Frequency: ${d.frequency.toFixed(6)}`);
```


## Full tooltip section update

Replace just this part in your `mousemove` handler:

```javascript
tooltip.style("opacity", 1)
  .style("left", (event.pageX + 10) + "px")
  .style("top", (event.pageY - 20) + "px")
  .html(`${content}<br/>Year: ${d.year}<br/>Frequency: ${d.frequency.toFixed(6)}`);
```

Now the tooltip shows:

```
sherlock holmes
Year: 1895
Frequency: 0.000012
```

The `.toFixed(6)` formats the tiny frequency values nicely (Ngram frequencies are typically very small decimals). Hover and see all three values!

---

# mousemove handler? Ehhr this is what I have : <!doctype html>

<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Ngram Line Chart Demo</title>
  <script src="js/d3.v6.min.js"></script>
  <style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    svg { border: 1px solid #ddd; }
    .line { fill: none; stroke: #1f77b4; stroke-width: 2px; }
    .axis path, .axis line { stroke: #999; shape-rendering: crispEdges; }
    .axis text { font-size: 11px; fill: #666; }
    .x.axis path { display: none; }
    .y.axis path { display: none; }
    .grid line { stroke: #eee; stroke-opacity: 0.7; shape-rendering: crispEdges; }
    .tooltip {
      position: absolute;
      background: rgba(0,0,0,0.8);
      color: white;
      padding: 5px 10px;
      border-radius: 4px;
      font-size: 12px;
      pointer-events: none;
      opacity: 0;
    }
  </style>
</head>
<body>
  <h1>Jimi Hendrix Ngram Line Chart</h1>
  <div id="chart"></div>
  <script>
    // ngram query
    const content   = "sherlock holmes";
    const yearStart = 1800;
    const yearEnd   = 2000;
    const corpus    = "en";
    const smoothing = 3;

    // init chart
    const margin = {top: 20, right: 20, bottom: 40, left: 50};
    const width  = 800 - margin.left - margin.right;
    const height = 400 - margin.top - margin.bottom;

    // get data
    const cors    = 'https://corsproxy.io/?';
    const baseUrl = cors + "https://books.google.com/ngrams/json";
    const params  = new URLSearchParams({
      content, year_start: yearStart, year_end: yearEnd,
      corpus, smoothing
    });
    const url = `${baseUrl}?${params}`;
    //console.log("Requesting:", url);

    const svg = d3.select("#chart")
      .append("svg")
      .attr("width", width + margin.left + margin.right)
      .attr("height", height + margin.top + margin.bottom)
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

    // setup chart
    const x = d3.scaleLinear().range([0, width]);
    const y = d3.scaleLinear().range([height, 0]);
    const line = d3.line()
      .x(d => x(d.year))
      .y(d => y(d.frequency))
      .curve(d3.curveMonotoneX);
    const xAxis = g => g
      .attr("transform", `translate(0,${height})`)
      .call(
        d3.axisBottom(x)
          .ticks(10)
          .tickFormat(d3.format("d")) // force integer no thousands separator
      )
      .selectAll("text")
      .style("text-anchor", "end")
      .attr("dx", "-.8em")
      .attr("dy", ".15em")
      .attr("transform", "rotate(-45)");
    const yAxis = g => g.call(d3.axisLeft(y).ticks(8));

    svg.append("g").attr("class", "grid")
      .call(d3.axisLeft(y).ticks(8).tickSize(-width).tickFormat(""));

    // mouse interaction
    let focus = svg.append("g").style("opacity", 0);
    let tooltip = d3.select("body").append("div")
      .style("position", "absolute")
      .style("background", "rgba(0,0,0,0.8)")
      .style("color", "white")
      .style("padding", "5px 10px")
      .style("border-radius", "4px")
      .style("font-size", "12px")
      .style("pointer-events", "none")
      .style("opacity", 0);

    // dotted vertical line
    focus.append("line")
      .attr("class", "focusLine")
      .attr("x1", 0).attr("x2", 0)
      .attr("y1", 0).attr("y2", height)
      .style("stroke", "#666")
      .style("stroke-width", "1px")
      .style("stroke-dasharray", "3,3");

    fetch(url)
      .then(res => res.json())
      .then(data => {
        // transform data: single ngram expected
        const timeseries = data[0].timeseries;
        const chartData = timeseries.map((freq, i) => ({
          year: yearStart + i,
          frequency: freq
        }));
    
        // update domains
        x.domain(d3.extent(chartData, d => d.year));
        y.domain([0, d3.max(chartData, d => d.frequency)]).nice();

        // line
        svg.append("path")
          .datum(chartData)
          .attr("class", "line")
          .attr("d", line);

        // axes
        svg.append("g").attr("class", "x axis").call(xAxis);
        svg.append("g").attr("class", "y axis").call(yAxis);
    
        // Mouse interaction
        const focus = svg.append("g").style("opacity", 0);
        const tooltip = d3.select("body").append("div")
          .style("position", "absolute")
          .style("background", "rgba(0,0,0,0.8)")
          .style("color", "white")
          .style("padding", "5px 10px")
          .style("border-radius", "4px")
          .style("font-size", "12px")
          .style("pointer-events", "none")
          .style("opacity", 0);
    
        focus.append("line")
          .attr("class", "focusLine")
          .attr("x1", 0).attr("x2", 0)
          .attr("y1", 0).attr("y2", height)
          .style("stroke", "#666")
          .style("stroke-width", "1px")
          .style("stroke-dasharray", "3,3");
    
        svg.append("rect")
          .attr("width", width).attr("height", height)
          .style("fill", "none")
          .style("pointer-events", "all")
          .on("mouseover", () => focus.style("opacity", 1))
          .on("mouseout",  () => focus.style("opacity", 0))
          .on("mousemove", (event) => {
            const bisect = d3.bisector(d => d.year).left;
            const x0     = x.invert(d3.pointer(event, svg.node())[0]);
            const i      = bisect(chartData, x0, 1);
            const d0     = chartData[i - 1];
            const d1     = chartData[i];
            const d      = x0 - d0.year > d1.year - x0 ? d1 : d0;

            focus.select(".focusLine").attr("x1", x(d.year)).attr("x2", x(d.year));
            tooltip.style("opacity", 1)
              .style("left", (event.pageX + 10) + "px")
              .style("top", (event.pageY - 20) + "px")
              .html(`${content}<br/>Year: ${d.year}`);
          });
      })
      .catch(err => console.error("Error:", err));
  </script>
</body>
</html>
:

You're duplicating the mouse interaction code! You have it **twice** - once before `fetch()` and once inside the `.then()` block. This causes conflicts.

## Quick fix - remove the duplicate

**Delete these lines inside the `.then()` block** (lines starting from `// Mouse interaction` to the end of the rect):

```javascript
// DELETE THIS ENTIRE BLOCK inside .then():
// Mouse interaction
const focus = svg.append("g").style("opacity", 0);
const tooltip = d3.select("body").append("div")...
// ... all the way to the end of svg.append("rect") ...
```

**Keep only the mouse code you already have BEFORE `fetch()`** (lines 70-90ish).

## Then update just the tooltip line in your **existing** mousemove handler:

Find this line (around line 92):

```javascript
.html(`${content}<br/>Year: ${d.year}`);
```

**Change it to:**

```javascript
.html(`${content}<br/>Year: ${d.year}<br/>Frequency: ${d.frequency.toFixed(6)}`);
```

Now it works perfectly with one set of mouse handlers + frequency in tooltip. The duplication was breaking the focus/tooltip behavior.

---

# Ehhr I don't know lets see what you think it should be ... could you generate the full page again?

```html
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Ngram Line Chart Demo</title>
  <script src="js/d3.v6.min.js"></script>
  <style>
    body { font-family: Arial, sans-serif; margin: 20px; }
    svg { border: 1px solid #ddd; }
    .line { fill: none; stroke: #1f77b4; stroke-width: 2px; }
    .axis path, .axis line { stroke: #999; shape-rendering: crispEdges; }
    .axis text { font-size: 11px; fill: #666; }
    .x.axis path { display: none; }
    .y.axis path { display: none; }
    .grid line { stroke: #eee; stroke-opacity: 0.7; shape-rendering: crispEdges; }
  </style>
</head>
<body>
  <h1>Sherlock Holmes Ngram Line Chart</h1>
  <div id="chart"></div>
  <script>
    // ngram query
    const content   = "sherlock holmes";
    const yearStart = 1800;
    const yearEnd   = 2000;
    const corpus    = "en";
    const smoothing = 3;

    // init chart
    const margin = {top: 20, right: 20, bottom: 40, left: 50};
    const width  = 800 - margin.left - margin.right;
    const height = 400 - margin.top - margin.bottom;

    // get data
    const cors    = 'https://corsproxy.io/?';
    const baseUrl = cors + "https://books.google.com/ngrams/json";
    const params  = new URLSearchParams({
      content, year_start: yearStart, year_end: yearEnd,
      corpus, smoothing
    });
    const url = `${baseUrl}?${params}`;

    const svg = d3.select("#chart")
      .append("svg")
      .attr("width", width + margin.left + margin.right)
      .attr("height", height + margin.top + margin.bottom)
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

    // setup chart
    const x = d3.scaleLinear().range([0, width]);
    const y = d3.scaleLinear().range([height, 0]);
    const line = d3.line()
      .x(d => x(d.year))
      .y(d => y(d.frequency))
      .curve(d3.curveMonotoneX);
    const xAxis = g => g
      .attr("transform", `translate(0,${height})`)
      .call(
        d3.axisBottom(x)
          .ticks(10)
          .tickFormat(d3.format("d"))
      )
      .selectAll("text")
      .style("text-anchor", "end")
      .attr("dx", "-.8em")
      .attr("dy", ".15em")
      .attr("transform", "rotate(-45)");
    const yAxis = g => g.call(d3.axisLeft(y).ticks(8));

    svg.append("g").attr("class", "grid")
      .call(d3.axisLeft(y).ticks(8).tickSize(-width).tickFormat(""));

    // mouse interaction (ONCE, before fetch)
    const focus = svg.append("g").style("opacity", 0);
    const tooltip = d3.select("body").append("div")
      .style("position", "absolute")
      .style("background", "rgba(0,0,0,0.8)")
      .style("color", "white")
      .style("padding", "5px 10px")
      .style("border-radius", "4px")
      .style("font-size", "12px")
      .style("pointer-events", "none")
      .style("opacity", 0);

    focus.append("line")
      .attr("class", "focusLine")
      .attr("x1", 0).attr("x2", 0)
      .attr("y1", 0).attr("y2", height)
      .style("stroke", "#666")
      .style("stroke-width", "1px")
      .style("stroke-dasharray", "3,3");

    fetch(url)
      .then(res => res.json())
      .then(data => {
        // transform data: single ngram expected
        const timeseries = data[0].timeseries;
        const chartData = timeseries.map((freq, i) => ({
          year: yearStart + i,
          frequency: freq
        }));

        // update domains
        x.domain(d3.extent(chartData, d => d.year));
        y.domain([0, d3.max(chartData, d => d.frequency)]).nice();

        // line
        svg.append("path")
          .datum(chartData)
          .attr("class", "line")
          .attr("d", line);

        // axes
        svg.append("g").attr("class", "x axis").call(xAxis);
        svg.append("g").attr("class", "y axis").call(yAxis);

        // mouse rect (ONCE, after data loads)
        svg.append("rect")
          .attr("width", width).attr("height", height)
          .style("fill", "none")
          .style("pointer-events", "all")
          .on("mouseover", () => focus.style("opacity", 1))
          .on("mouseout",  () => focus.style("opacity", 0))
          .on("mousemove", (event) => {
            const bisect = d3.bisector(d => d.year).left;
            const x0     = x.invert(d3.pointer(event, svg.node())[0]);
            const i      = bisect(chartData, x0, 1);
            const d0     = chartData[i - 1];
            const d1     = chartData[i];
            const d      = x0 - d0.year > d1.year - x0 ? d1 : d0;

            focus.select(".focusLine").attr("x1", x(d.year)).attr("x2", x(d.year));
            tooltip.style("opacity", 1)
              .style("left", (event.pageX + 10) + "px")
              .style("top", (event.pageY - 20) + "px")
              .html(`${content}<br/>Year: ${d.year}<br/>Frequency: ${d.frequency.toFixed(6)}`);
          });
      })
      .catch(err => console.error("Error:", err));
  </script>
</body>
</html>
```

**Key fixes:**

- Mouse interaction code **once before fetch** (focus, tooltip, line)
- Mouse rect **once inside fetch** (after data loads, with frequency in tooltip)
- Clean x-axis integers
- No duplicates, no CSS tooltip class needed

Hover anywhere on chart → dotted line + tooltip with content/year/frequency! Perfect.

---

# Ah apologies now I see what you meant with the mouse interaction block ... and the other issues good fixed now. Small thing the 'frequency' in the tooltip stays 0.000000 ....

The issue is `d.frequency` should be `d.frequency` - there's a variable scope problem. In the tooltip line, change `d.frequency` to the correct data point:

```javascript
.html(`${content}<br/>Year: ${d.year}<br/>Frequency: ${d.frequency.toFixed(6)}`);
```

Wait - actually looking closer, the bug is in the **bisect logic**. Change this line in the `mousemove`:

**From:**

```javascript
const d = x0 - d0.year > d1.year - x0 ? d1 : d0;
```

**To:**

```javascript
const d = x0 - d0.year > d1.year - x0 ? d1 : d0;
```

No - the real fix is **add bounds checking** after bisect. Replace the entire `mousemove` block with:

```javascript
.on("mousemove", (event) => {
  const bisect = d3.bisector(d => d.year).left;
  const [mouseX] = d3.pointer(event, svg.node());
  const x0 = x.invert(mouseX);
  let i = bisect(chartData, x0, 1);
  
  // Bounds check
  i = Math.max(1, Math.min(i, chartData.length - 1));
  const d0 = chartData[i - 1];
  const d1 = chartData[i] || d0;
  const d = x0 - d0.year > d1.year - x0 ? d1 : d0;

  focus.select(".focusLine").attr("x1", x(d.year)).attr("x2", x(d.year));
  tooltip.style("opacity", 1)
    .style("left", (event.pageX + 10) + "px")
    .style("top", (event.pageY - 20) + "px")
    .html(`${content}<br/>Year: ${d.year}<br/>Frequency: ${d.frequency.toFixed(6)}`);
});
```

This ensures `i` never goes out of bounds, `d1` always exists, and you get real frequency values instead of 0.000000!

---

# Are you sure ...

No, you're right to question it. Looking at your code more carefully, the bisect logic is actually correct - the issue is simpler.

**The problem:** `d.frequency` becomes `undefined` because when `i` hits array bounds, `d1` is undefined, making `d` reference bad data.

**Simple fix - just update these 4 lines in your mousemove:**

```javascript
.on("mousemove", (event) => {
  const bisect = d3.bisector(d => d.year).left;
  const x0 = x.invert(d3.pointer(event, svg.node())[0]);
  const i = Math.max(1, Math.min(bisect(chartData, x0, 1), chartData.length - 1));
  const d0 = chartData[i - 1];
  const d1 = chartData[i];
  const d = x0 - d0.year > d1.year - x0 ? d1 : d0;

  focus.select(".focusLine").attr("x1", x(d.year)).attr("x2", x(d.year));
  tooltip.style("opacity", 1)
    .style("left", (event.pageX + 10) + "px")
    .style("top", (event.pageY - 20) + "px")
    .html(`${content}<br/>Year: ${d.year}<br/>Frequency: ${d.frequency.toFixed(6)}`);
});
```

**Only change:** Add `Math.max(1, Math.min(..., chartData.length - 1))` to clamp `i` to valid indices.

Now `d` will always have valid `frequency` data. Test it - frequencies should show properly!

---

```
# Nope ... The numbers are very small I tried:               .html(`${content}<br/>Year: ${d.year}<br/>Frequency: ${d.frequency.toFixed(12)}`);
```

: it displays the frequency but there is more to this ... the way the code gets the value is independent of the graph line it simply gets the value bases on the y location of the mouse pointer ....

You're absolutely right! The current code finds the **closest year** (x-position) but uses `d.frequency` from that year regardless of where the mouse is vertically on the line. It's not interpolating the actual line value at the mouse position.

Here's the fix - **interpolate the real line value** at mouse coordinates:

```javascript
.on("mousemove", (event) => {
  const [mouseX, mouseY] = d3.pointer(event, svg.node());
  const x0 = x.invert(mouseX);
  
  // Find closest year bracket
  const bisect = d3.bisector(d => d.year).left;
  const i = Math.max(1, Math.min(bisect(chartData, x0, 1), chartData.length - 1));
  const d0 = chartData[i - 1];
  const d1 = chartData[i];
  
  // Linear interpolation at exact mouse X position
  const t = (x0 - d0.year) / (d1.year - d0.year);
  const interpolatedFreq = d0.frequency + t * (d1.frequency - d0.frequency);
  
  // Find closest point for line position (vertical line still snaps to year)
  const d = x0 - d0.year > d1.year - x0 ? d1 : d0;

  focus.select(".focusLine").attr("x1", x(d.year)).attr("x2", x(d.year));
  tooltip.style("opacity", 1)
    .style("left", (event.pageX + 10) + "px")
    .style("top", (event.pageY - 20) + "px")
    .html(`${content}<br/>Year: ${x0.toFixed(0)}<br/>Frequency: ${interpolatedFreq.toFixed(12)}`);
});
```

**Key changes:**

- `interpolatedFreq` = actual line value at mouse X position (linear interpolation between years)
- Tooltip shows `x0.toFixed(0)` (exact mouse year, not snapped)
- Now the frequency **follows the line exactly** wherever your mouse is!

Much more accurate - the value reflects the true line position, not just yearly data points.

---

# Excellent merci. Ok lets put the dev part on hold for now thank you for the thorough assist in setting this up. Just winding down a little, a bit more meta things. Looking at : [https://books.google.com/ngrams/info](https://books.google.com/ngrams/info) : am I to deduce that the 'timeseries' aka y-axis values are percentages that reflect the x amount of times the verb / search query occurs in the 'corpus' amassed by google?

Yes, exactly. The `timeseries` values (y-axis) represent the **relative frequency** percentage of your ngram (search phrase) within the selected corpus for each year.[^18_1]

## How it's calculated

For a given year, it's `(occurrences of your ngram ÷ total words in corpus that year) × 100`.[^18_2][^18_1]
This normalization accounts for the massive growth in book publication over time—without it, modern years would dominate due to sheer volume.[^18_1]

## Why such small numbers

Even famous phrases like "sherlock holmes" peak at ~0.0001% because the corpus contains **billions** of words per year. A 2-gram needs to appear millions of times to hit even 0.0001%.[^18_4][^18_1]

So your tooltip showing `0.000012` means "sherlock holmes" was 0.000012% of all words that year—about 1 in 8 million words. Perfectly normal for ngram data![^18_1]
<span style="display:none">[^18_10][^18_11][^18_3][^18_5][^18_6][^18_7][^18_8][^18_9]</span>

<div align="center">⁂</div>

[^18_1]: https://books.google.com/ngrams/info

[^18_2]: https://economicsfromthetopdown.com/2020/10/19/working-with-google-ngrams-a-data-wrangling-tale/

[^18_3]: https://capitalaspower.com/2021/11/working-with-google-ngrams-a-data-wrangling-tale/

[^18_4]: https://infoguides.gmu.edu/textanalysistools/ngram

[^18_5]: https://books.google.com/ngrams/info

[^18_6]: https://support.sas.com/resources/papers/proceedings16/12487-2016.pdf

[^18_7]: https://en.wikipedia.org/wiki/Google_Books_Ngram_Viewer

[^18_8]: https://jdmdh.episciences.org/7000/pdf

[^18_9]: https://meetglimpse.com/software-guides/google-ngram/

[^18_10]: https://research.google.com/pubs/archive/41603.pdf

[^18_11]: https://www.youtube.com/watch?v=qzbjPq8vwx8


---

# Glad I asked this 'This normalization accounts for the massive growth in book publication over time—without it, modern years would dominate due to sheer volume.' is a very good point to know. Ok I'm going to chew this over I'll drop by at a later date but for now thank you for the info and support.

You're welcome! Glad the normalization explanation and chart setup clicked—it's one of those key details that makes Ngram data so powerful for long-term trends.

Enjoy chewing it over, and feel free to drop by anytime. Happy charting!

