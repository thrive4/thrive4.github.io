﻿This conversation was generated with Duck.ai (https://duck.ai) using Anthropic's Claude Haiku 4.5 Model. AI chats may display inaccurate or offensive information (see https://duckduckgo.com/duckai/privacy-terms for more info).

====================

User prompt 1 of 1 - 5/17/2026, 3:10:34 PM:
It seems something has changed regarding url's requesting an image at wikimedia I'm using : https://upload.wikimedia.org/wikipedia/commons/thumb/4/48/Jan_Lievens_-_Bookkeeper_at_His_Desk_-_JL-101_-_Leiden_Collection.jpg : but prefixed sizes are now prefered : https://www.mediawiki.org/wiki/Common_thumbnail_sizes/en : other wise I get : Error

Use thumbnail sizes listed on https://w.wiki/GHai : what is the correct way of specifying the url?

Claude Haiku 4.5:
I'll check the current Wikimedia documentation on thumbnail sizes to help you get the correct URL format.
## Wikimedia Image URL Format with Standard Sizes

The error you're encountering is due to **recent enforcement of standard thumbnail sizes** on Wikimedia servers. Direct hotlinking requests now must use one of the **approved standard sizes** to avoid the 429 error.

### Standard Sizes for Wikimedia

**You must use one of these exact widths:**
- **20px, 40px, 60px, 120px, 250px, 330px, 500px, 960px, 1280px, 1920px, 3840px**

### Correct URL Format

For your image, the correct URL structure should be:

```
https://upload.wikimedia.org/wikipedia/commons/thumb/4/48/Jan_Lievens_-_Bookkeeper_at_His_Desk_-_JL-101_-_Leiden_Collection.jpg/250px-Jan_Lievens_-_Bookkeeper_at_His_Desk_-_JL-101_-_Leiden_Collection.jpg
```

**Breaking down the format:**
- Base path: `https://upload.wikimedia.org/wikipedia/commons/thumb/`
- File hash path: `4/48/`
- **Filename with width prefix:** `250px-[original_filename].jpg`

The `250px` (or any standard size) goes directly before the hyphen in the filename at the end.

### Two Alternatives to Direct URLs

1. **Use the imageinfo API** — This is the recommended approach, as it automatically handles size rounding:
   ```
   https://commons.wikimedia.org/w/api.php?action=query&titles=File:Jan_Lievens_-_Bookkeeper_at_His_Desk_-_JL-101_-_Leiden_Collection.jpg&prop=imageinfo&iiprop=url&iiurlwidth=250&format=json
   ```
   The API will round your requested size up to the nearest standard size.

2. **Let PHP handle it** — If you're using InstantCommons or similar backend services, they automatically round requests to the closest standard size.

The changes referenced in the documentation (task T360589) from 2025-2026 enforce this standardization to reduce server load and storage overhead.