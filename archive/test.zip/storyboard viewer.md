<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# As a proof of concept is it possible to generate a html page that has a 'load storyboard' button (loads in a .json file) that iterates through the 'scenes' then display a list based on "scene": with if present a thumbnail image found in /sb folder.  The idea is that the list item can be clicked on to open a fullscreen modal that builds and displays the prompt in a edit box? ... example .json : {

"title": "My Storyboard",
"version": 1,
"lookup": "storyboardlkup.json",
"scenes": [
{
"scene": "B",
"weather": "misty",
"location": "mountain",
"entityA": "one wolf",
"poseA": "standing",
"descriptionA": "shaggy grey",
"entityB": "other wolf",
"poseB": "lying",
"descriptionB": "shaggy brown",
"style": "cinematic",
"renderstyle": "cinematic",
"camera": "high-angle",
"seed": "",
"updated": "2025-10-15T15:49:31.749Z",
"private": false
},
{
"scene": "C",
"weather": "fogy",
"location": "old town",
"entityA": "dog",
"poseA": "standing",
"descriptionA": "shaggy brown",
"entityB": "cat",
"poseB": "lying alert",
"descriptionB": "grey",
"style": "cinematic",
"renderstyle": "cinematic",
"camera": "high-angle",
"seed": "",
"updated": "2025-10-15T16:02:36.626Z",
"private": false
},
{
"scene": "D",
"weather": "fogy",
"location": "old town",
"entityA": "dog",
"poseA": "standing",
"descriptionA": "shaggy brown",
"entityB": "cat",
"poseB": "lying alert",
"descriptionB": "grey",
"style": "cinematic",
"renderstyle": "cinematic",
"camera": "high-angle",
"seed": "(seed:::283719138)",
"updated": "2025-10-15T16:07:10.756Z",
"private": false
}
]
} : prompt build example : misty, mountain, one wolf, standing, shaggy grey, other wolf, lying, shaggy brown, cinematic, cinematic, high-angle

Yes, it is possible, and it can be done with a single self‑contained HTML file plus your storyboard JSON and a `/sb` folder containing thumbnails like `B.jpg`, `C.jpg`, etc.[^1_1]

Below is a minimal proof‑of‑concept HTML page that does what you describe:

- A “Load storyboard” button that opens a JSON file from disk.
- Iterates through `scenes` and shows a list of items labeled by `scene`.
- For each scene, if `/sb/<scene>.jpg` exists, it shows a thumbnail (simple optimistic load).
- Clicking a list item opens a fullscreen modal.
- The modal builds a prompt from the scene fields and puts it in an editable `<textarea>`.

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Storyboard Viewer</title>
  <style>
    body { font-family: sans-serif; margin: 0; padding: 1rem; background:#111; color:#eee; }
    header { margin-bottom: 1rem; }
    button { padding: 0.4rem 0.8rem; cursor: pointer; }
    #scenesList { display: flex; flex-wrap: wrap; gap: 0.75rem; margin-top: 1rem; }
    .scene-card {
      background: #222;
      border-radius: 4px;
      padding: 0.5rem;
      width: 180px;
      cursor: pointer;
      border: 1px solid #333;
    }
    .scene-card:hover { border-color: #5af; }
    .scene-thumb {
      width: 100%;
      height: 100px;
      object-fit: cover;
      border-radius: 3px;
      background:#000;
      display:block;
      margin-bottom:0.4rem;
    }
    .scene-id { font-weight: bold; margin-bottom: 0.25rem; }
    .scene-meta { font-size: 0.8rem; color: #ccc; }

    /* Fullscreen modal */
    #modal {
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.85);
      display: none;
      align-items: center;
      justify-content: center;
      z-index: 9999;
    }
    #modalContent {
      background: #181818;
      max-width: 800px;
      width: 90%;
      max-height: 90vh;
      border-radius: 6px;
      padding: 1rem;
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
    }
    #modalHeader {
      display:flex;
      justify-content: space-between;
      align-items:center;
      border-bottom: 1px solid #333;
      padding-bottom: 0.3rem;
      margin-bottom: 0.3rem;
    }
    #modalTitle { font-weight: bold; }
    #modalClose {
      cursor:pointer;
      border:none;
      background:#333;
      color:#eee;
      padding:0.2rem 0.6rem;
      border-radius: 3px;
    }
    #promptBox {
      width: 100%;
      height: 200px;
      resize: vertical;
      background:#111;
      color:#eee;
      border:1px solid #444;
      padding:0.5rem;
      box-sizing:border-box;
      font-family: monospace;
      font-size: 0.9rem;
    }
    #sceneJson {
      width: 100%;
      height: 150px;
      resize: vertical;
      background:#090909;
      color:#eee;
      border:1px solid #444;
      padding:0.5rem;
      box-sizing:border-box;
      font-family: monospace;
      font-size: 0.8rem;
    }
  </style>
</head>
<body>
  <header>
    <h1>Storyboard Viewer</h1>
    <input type="file" id="fileInput" accept="application/json" style="display:none" />
    <button id="loadBtn">Load storyboard</button>
    <span id="storyTitle" style="margin-left:1rem; opacity:0.8;"></span>
  </header>

  <main>
    <div id="scenesList"></div>
  </main>

  <!-- Fullscreen modal -->
  <div id="modal">
    <div id="modalContent">
      <div id="modalHeader">
        <div id="modalTitle"></div>
        <button id="modalClose">Close</button>
      </div>
      <label for="promptBox">Prompt</label>
      <textarea id="promptBox"></textarea>

      <label for="sceneJson">Scene JSON</label>
      <textarea id="sceneJson" readonly></textarea>
    </div>
  </div>

  <script>
    const loadBtn     = document.getElementById('loadBtn');
    const fileInput   = document.getElementById('fileInput');
    const scenesList  = document.getElementById('scenesList');
    const storyTitle  = document.getElementById('storyTitle');

    const modal       = document.getElementById('modal');
    const modalTitle  = document.getElementById('modalTitle');
    const modalClose  = document.getElementById('modalClose');
    const promptBox   = document.getElementById('promptBox');
    const sceneJson   = document.getElementById('sceneJson');

    let storyboardData = null;

    loadBtn.addEventListener('click', () => fileInput.click());

    fileInput.addEventListener('change', (evt) => {
      const file = evt.target.files[^1_0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target.result);
          storyboardData = data;
          renderStoryboard(data);
        } catch (err) {
          alert('Invalid JSON: ' + err.message);
        }
      };
      reader.readAsText(file);
    });

    function renderStoryboard(data) {
      storyTitle.textContent = data.title ? `Title: ${data.title}` : '';
      scenesList.innerHTML = '';

      if (!Array.isArray(data.scenes)) return;

      data.scenes.forEach(scene => {
        const card = document.createElement('div');
        card.className = 'scene-card';

        // naive thumbnail: /sb/<scene>.jpg
        const img = document.createElement('img');
        img.className = 'scene-thumb';
        img.alt = scene.scene || '';
        img.src = `/sb/${scene.scene}.jpg`;

        // If image fails, hide it
        img.onerror = () => { img.style.display = 'none'; };

        const id = document.createElement('div');
        id.className = 'scene-id';
        id.textContent = `Scene ${scene.scene || ''}`;

        const meta = document.createElement('div');
        meta.className = 'scene-meta';
        meta.textContent = [
          scene.weather,
          scene.location,
          scene.entityA,
          scene.entityB
        ].filter(Boolean).join(', ');

        card.appendChild(img);
        card.appendChild(id);
        card.appendChild(meta);

        card.addEventListener('click', () => openModal(scene));

        scenesList.appendChild(card);
      });
    }

    function openModal(scene) {
      modal.style.display = 'flex';
      modalTitle.textContent = `Scene ${scene.scene || ''}`;

      // Build prompt string in your desired order
      const parts = [
        scene.weather,
        scene.location,
        scene.entityA,
        scene.poseA,
        scene.descriptionA,
        scene.entityB,
        scene.poseB,
        scene.descriptionB,
        scene.style,
        scene.renderstyle,
        scene.camera
      ].filter(Boolean);

      const prompt = parts.join(', ');
      promptBox.value = prompt;
      sceneJson.value = JSON.stringify(scene, null, 2);
    }

    modalClose.addEventListener('click', () => {
      modal.style.display = 'none';
    });

    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.style.display = 'none';
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modal.style.display === 'flex') {
        modal.style.display = 'none';
      }
    });
  </script>
</body>
</html>
```


### How to adapt this to your setup

- Place this HTML in a file like `storyboard.html` and open it in a browser (for local file loading, using the `<input type="file">` approach avoids CORS issues).[^1_5][^1_1]
- Put your `.json` storyboard files anywhere; the user chooses them via the “Load storyboard” button.
- Put thumbnails in `/sb` using the naming scheme `<scene>.jpg` (e.g. `B.jpg`, `C.jpg`) or adjust the `img.src` line if you prefer a different pattern.
- If you want the prompt builder to include or exclude fields, just edit the `parts` array in `openModal(scene)` to change the order or selection.
<span style="display:none">[^1_10][^1_2][^1_3][^1_4][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://stackoverflow.com/questions/66252240/loading-json-data-with-button-click-and-textbox

[^1_2]: https://www.reddit.com/r/webdev/comments/t8di0n/static_website_pulling_from_json_data_file_and/

[^1_3]: https://forum.freecodecamp.org/t/loading-json-data-with-button-click-and-textbox/446944

[^1_4]: https://www.reddit.com/r/webdev/comments/r9wjz8/how_would_i_go_about_using_json_data_to_make/

[^1_5]: https://stackoverflow.com/questions/18637418/trying-to-load-local-json-file-to-show-data-in-a-html-page-using-jquery

[^1_6]: https://stackoverflow.com/questions/51738504/adding-image-files-into-json-object-and-displaying-it-in-html

[^1_7]: https://webdeveloper.com/community/392817-loading-json-data-with-button-click-and-textbox/

[^1_8]: https://www.youtube.com/watch?v=lmcXjFY8dFc

[^1_9]: https://docs.dhtmlx.com/toolbar__from_script.html

[^1_10]: https://www.reddit.com/r/javascript/comments/5blh60/displaying_json_content_in_html/


---

```
# Very nice gracias. Is it possible to have the flex switch between a tile / card and a list view  so in the css there is .scene-card maybe add a .scene-list and a switch button next to <span id="storyTitle" style="margin-left:1rem; opacity:0.8;"></span> ?
```

Yes, you can add a toggle button that switches a CSS class on the container, and style cards differently in “tile” vs “list” mode.

Below is a minimal modification of the previous example showing:

- A “View: Tiles/List” toggle button.
- A `tiles` / `list` class on `#scenesList`.
- A `.scene-list` style that makes items appear as a list row.


### HTML changes (header and scenes list)

Add the toggle button next to the title, and a default view class on `#scenesList`:

```html
<header>
  <h1>Storyboard Viewer</h1>
  <input type="file" id="fileInput" accept="application/json" style="display:none" />
  <button id="loadBtn">Load storyboard</button>
  <span id="storyTitle" style="margin-left:1rem; opacity:0.8;"></span>

  <!-- View toggle -->
  <button id="viewToggle" style="margin-left:1rem;">View: Tiles</button>
</header>

<main>
  <div id="scenesList" class="tiles"></div>
</main>
```


### CSS changes (tile vs list)

Add two layout modes and a `.scene-list` variant:

```css
/* Container modes */
#scenesList.tiles {
  display: flex;
  flex-wrap: wrap;
  gap: 0.75rem;
}

#scenesList.list {
  display: flex;
  flex-direction: column;
  gap: 0.4rem;
}

/* Base card */
.scene-card {
  background: #222;
  border-radius: 4px;
  padding: 0.5rem;
  cursor: pointer;
  border: 1px solid #333;
}

/* Tile appearance (default card) */
#scenesList.tiles .scene-card {
  width: 180px;
}

#scenesList.tiles .scene-thumb {
  width: 100%;
  height: 100px;
  object-fit: cover;
  border-radius: 3px;
  background:#000;
  display:block;
  margin-bottom:0.4rem;
}

/* List appearance */
#scenesList.list .scene-card {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  width: 100%;
}

#scenesList.list .scene-thumb {
  width: 80px;
  height: 50px;
  object-fit: cover;
  border-radius: 3px;
  background:#000;
  display:block;
}

#scenesList.list .scene-id {
  min-width: 80px;
}

#scenesList.list .scene-meta {
  flex: 1;
}
```

The existing `.scene-id`, `.scene-meta`, hover, etc. can stay as they are; they will be reused in both modes.

### JavaScript changes (toggle behavior)

Add a small toggle to switch the class on `#scenesList` and update the button label:

```html
<script>
  const loadBtn     = document.getElementById('loadBtn');
  const fileInput   = document.getElementById('fileInput');
  const scenesList  = document.getElementById('scenesList');
  const storyTitle  = document.getElementById('storyTitle');
  const viewToggle  = document.getElementById('viewToggle');

  // ... rest of your variables and code ...

  viewToggle.addEventListener('click', () => {
    if (scenesList.classList.contains('tiles')) {
      scenesList.classList.remove('tiles');
      scenesList.classList.add('list');
      viewToggle.textContent = 'View: List';
    } else {
      scenesList.classList.remove('list');
      scenesList.classList.add('tiles');
      viewToggle.textContent = 'View: Tiles';
    }
  });

  // renderStoryboard and other functions remain the same
</script>
```

The rendering function does not need to know about tile vs list; it still creates `.scene-card` elements with `.scene-thumb`, `.scene-id`, and `.scene-meta`. The container’s class (`tiles` or `list`) determines whether they appear as cards or as a list.

---

# Hmm could you do a full page please?

Yes, here is a full, self‑contained page that includes:

- Load storyboard button.
- Tile/List view toggle.
- Scene cards with optional `/sb/<scene>.jpg` thumbnail.
- Click to open fullscreen modal with editable prompt and scene JSON.

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Storyboard Viewer</title>
  <style>
    body { font-family: sans-serif; margin: 0; padding: 1rem; background:#111; color:#eee; }
    header { margin-bottom: 1rem; display:flex; flex-wrap:wrap; align-items:center; gap:0.5rem; }
    h1 { margin:0; margin-right:1rem; font-size:1.3rem; }
    button { padding: 0.4rem 0.8rem; cursor: pointer; background:#333; color:#eee; border:1px solid #444; border-radius:3px; }
    button:hover { border-color:#5af; }
    #storyTitle { opacity:0.8; }
    #viewToggle { margin-left:auto; }

    /* Container modes */
    #scenesList.tiles {
      display: flex;
      flex-wrap: wrap;
      gap: 0.75rem;
    }
    #scenesList.list {
      display: flex;
      flex-direction: column;
      gap: 0.4rem;
    }

    /* Base card */
    .scene-card {
      background: #222;
      border-radius: 4px;
      padding: 0.5rem;
      cursor: pointer;
      border: 1px solid #333;
      transition: border-color 0.15s ease, transform 0.1s ease;
    }
    .scene-card:hover {
      border-color: #5af;
      transform: translateY(-1px);
    }

    /* Tile appearance */
    #scenesList.tiles .scene-card {
      width: 180px;
    }
    #scenesList.tiles .scene-thumb {
      width: 100%;
      height: 100px;
      object-fit: cover;
      border-radius: 3px;
      background:#000;
      display:block;
      margin-bottom:0.4rem;
    }

    /* List appearance */
    #scenesList.list .scene-card {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      width: 100%;
    }
    #scenesList.list .scene-thumb {
      width: 80px;
      height: 50px;
      object-fit: cover;
      border-radius: 3px;
      background:#000;
      display:block;
    }
    #scenesList.list .scene-id {
      min-width: 80px;
    }
    #scenesList.list .scene-meta {
      flex: 1;
    }

    .scene-id { font-weight:bold; margin-bottom:0.25rem; }
    .scene-meta { font-size:0.8rem; color:#ccc; }

    main { margin-top:0.5rem; }

    /* Fullscreen modal */
    #modal {
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.85);
      display: none;
      align-items: center;
      justify-content: center;
      z-index: 9999;
    }
    #modalContent {
      background: #181818;
      max-width: 800px;
      width: 90%;
      max-height: 90vh;
      border-radius: 6px;
      padding: 1rem;
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
      box-sizing:border-box;
    }
    #modalHeader {
      display:flex;
      justify-content: space-between;
      align-items:center;
      border-bottom: 1px solid #333;
      padding-bottom: 0.3rem;
      margin-bottom: 0.3rem;
    }
    #modalTitle { font-weight:bold; }
    #modalClose {
      cursor:pointer;
      border:none;
      background:#333;
      color:#eee;
      padding:0.2rem 0.6rem;
      border-radius: 3px;
    }
    label { font-size:0.85rem; opacity:0.85; }
    #promptBox, #sceneJson {
      width: 100%;
      resize: vertical;
      background:#111;
      color:#eee;
      border:1px solid #444;
      padding:0.5rem;
      box-sizing:border-box;
      font-family: monospace;
      font-size: 0.9rem;
    }
    #promptBox { height: 200px; }
    #sceneJson { height: 150px; background:#090909; font-size:0.8rem; }
  </style>
</head>
<body>
  <header>
    <h1>Storyboard Viewer</h1>

    <input type="file" id="fileInput" accept="application/json" style="display:none" />
    <button id="loadBtn">Load storyboard</button>

    <span id="storyTitle"></span>

    <button id="viewToggle">View: Tiles</button>
  </header>

  <main>
    <div id="scenesList" class="tiles"></div>
  </main>

  <!-- Fullscreen modal -->
  <div id="modal">
    <div id="modalContent">
      <div id="modalHeader">
        <div id="modalTitle"></div>
        <button id="modalClose">Close</button>
      </div>

      <label for="promptBox">Prompt</label>
      <textarea id="promptBox"></textarea>

      <label for="sceneJson">Scene JSON</label>
      <textarea id="sceneJson" readonly></textarea>
    </div>
  </div>

  <script>
    const loadBtn     = document.getElementById('loadBtn');
    const fileInput   = document.getElementById('fileInput');
    const scenesList  = document.getElementById('scenesList');
    const storyTitle  = document.getElementById('storyTitle');
    const viewToggle  = document.getElementById('viewToggle');

    const modal       = document.getElementById('modal');
    const modalTitle  = document.getElementById('modalTitle');
    const modalClose  = document.getElementById('modalClose');
    const promptBox   = document.getElementById('promptBox');
    const sceneJson   = document.getElementById('sceneJson');

    let storyboardData = null;

    // Load storyboard JSON from file picker
    loadBtn.addEventListener('click', () => fileInput.click());

    fileInput.addEventListener('change', (evt) => {
      const file = evt.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target.result);
          storyboardData = data;
          renderStoryboard(data);
        } catch (err) {
          alert('Invalid JSON: ' + err.message);
        }
      };
      reader.readAsText(file);
    });

    // View toggle (tiles / list)
    viewToggle.addEventListener('click', () => {
      if (scenesList.classList.contains('tiles')) {
        scenesList.classList.remove('tiles');
        scenesList.classList.add('list');
        viewToggle.textContent = 'View: List';
      } else {
        scenesList.classList.remove('list');
        scenesList.classList.add('tiles');
        viewToggle.textContent = 'View: Tiles';
      }
    });

    // Render storyboard scenes
    function renderStoryboard(data) {
      storyTitle.textContent = data.title ? 'Title: ' + data.title : '';
      scenesList.innerHTML = '';

      if (!Array.isArray(data.scenes)) return;

      data.scenes.forEach(scene => {
        const card = document.createElement('div');
        card.className = 'scene-card';

        // Thumbnail: /sb/<scene>.jpg
        const img = document.createElement('img');
        img.className = 'scene-thumb';
        img.alt = scene.scene || '';
        img.src = '/sb/' + (scene.scene || '') + '.jpg';
        img.onerror = () => { img.style.display = 'none'; };

        const id = document.createElement('div');
        id.className = 'scene-id';
        id.textContent = 'Scene ' + (scene.scene || '');

        const meta = document.createElement('div');
        meta.className = 'scene-meta';
        meta.textContent = [
          scene.weather,
          scene.location,
          scene.entityA,
          scene.entityB
        ].filter(Boolean).join(', ');

        card.appendChild(img);
        card.appendChild(id);
        card.appendChild(meta);

        card.addEventListener('click', () => openModal(scene));

        scenesList.appendChild(card);
      });
    }

    // Open fullscreen modal for a scene
    function openModal(scene) {
      modal.style.display = 'flex';
      modalTitle.textContent = 'Scene ' + (scene.scene || '');

      // Build prompt string
      const parts = [
        scene.weather,
        scene.location,
        scene.entityA,
        scene.poseA,
        scene.descriptionA,
        scene.entityB,
        scene.poseB,
        scene.descriptionB,
        scene.style,
        scene.renderstyle,
        scene.camera
      ].filter(Boolean);

      promptBox.value = parts.join(', ');
      sceneJson.value = JSON.stringify(scene, null, 2);
    }

    // Close modal handlers
    modalClose.addEventListener('click', () => {
      modal.style.display = 'none';
    });

    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.style.display = 'none';
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modal.style.display === 'flex') {
        modal.style.display = 'none';
      }
    });
  </script>
</body>
</html>
```

To use it:

- Save as `storyboard.html`.
- Open it in a browser.
- Click “Load storyboard” and select a JSON like the one you posted.
- Put thumbnails in `/sb/<scene>.jpg` relative to where you host the HTML (or adjust the `img.src` line).

---

# Nice but a small issue the view toggle was inverted so init with     <button id="viewToggle">View: Tile</button>

</header>

  <main>
    <div id="scenesList" class="list"></div>
  </main>
then :     // View toggle (tiles / list)
viewToggle.addEventListener('click', () => {
if (scenesList.classList.contains('tiles')) {
scenesList.classList.remove('tiles');
scenesList.classList.add('list');
viewToggle.textContent = 'View: Tile';
} else {
scenesList.classList.remove('list');
scenesList.classList.add('tiles');
viewToggle.textContent = 'View: List';
}
});
is fixed ... is it possible to put a div around the main page that centers the content and keeps its width at around 75% of the browser window so a more portrait view ....

Yes, you can wrap everything in a centered container and limit its width to about 75% of the viewport, which will give a more portrait‑like layout on wide screens. This is a standard pattern in HTML/CSS.[^4_1]

Below is your page with a simple `.page-wrapper` div added and some CSS to center and size it:

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Storyboard Viewer</title>
  <style>
    body {
      font-family: sans-serif;
      margin: 0;
      padding: 1rem 0;
      background:#111;
      color:#eee;
    }

    /* Centered page wrapper, ~75% width */
    .page-wrapper {
      width: 75vw;          /* 75% of viewport width */
      max-width: 1000px;    /* optional hard cap */
      margin: 0 auto;       /* center horizontally */
      padding: 0 0 1rem 0;  /* bottom padding only */
    }

    header {
      margin-bottom: 1rem;
      display:flex;
      flex-wrap:wrap;
      align-items:center;
      gap:0.5rem;
    }
    h1 { margin:0; margin-right:1rem; font-size:1.3rem; }
    button {
      padding: 0.4rem 0.8rem;
      cursor: pointer;
      background:#333;
      color:#eee;
      border:1px solid #444;
      border-radius:3px;
    }
    button:hover { border-color:#5af; }
    #storyTitle { opacity:0.8; }
    #viewToggle { margin-left:auto; }

    /* Container modes */
    #scenesList.tiles {
      display: flex;
      flex-wrap: wrap;
      gap: 0.75rem;
    }
    #scenesList.list {
      display: flex;
      flex-direction: column;
      gap: 0.4rem;
    }

    /* Base card */
    .scene-card {
      background: #222;
      border-radius: 4px;
      padding: 0.5rem;
      cursor: pointer;
      border: 1px solid #333;
      transition: border-color 0.15s ease, transform 0.1s ease;
    }
    .scene-card:hover {
      border-color: #5af;
      transform: translateY(-1px);
    }

    /* Tile appearance */
    #scenesList.tiles .scene-card {
      width: 180px;
    }
    #scenesList.tiles .scene-thumb {
      width: 100%;
      height: 100px;
      object-fit: cover;
      border-radius: 3px;
      background:#000;
      display:block;
      margin-bottom:0.4rem;
    }

    /* List appearance */
    #scenesList.list .scene-card {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      width: 100%;
    }
    #scenesList.list .scene-thumb {
      width: 80px;
      height: 50px;
      object-fit: cover;
      border-radius: 3px;
      background:#000;
      display:block;
    }
    #scenesList.list .scene-id {
      min-width: 80px;
    }
    #scenesList.list .scene-meta {
      flex: 1;
    }

    .scene-id { font-weight:bold; margin-bottom:0.25rem; }
    .scene-meta { font-size:0.8rem; color:#ccc; }

    main { margin-top:0.5rem; }

    /* Fullscreen modal */
    #modal {
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.85);
      display: none;
      align-items: center;
      justify-content: center;
      z-index: 9999;
    }
    #modalContent {
      background: #181818;
      max-width: 800px;
      width: 90%;
      max-height: 90vh;
      border-radius: 6px;
      padding: 1rem;
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
      box-sizing:border-box;
    }
    #modalHeader {
      display:flex;
      justify-content: space-between;
      align-items:center;
      border-bottom: 1px solid #333;
      padding-bottom: 0.3rem;
      margin-bottom: 0.3rem;
    }
    #modalTitle { font-weight:bold; }
    #modalClose {
      cursor:pointer;
      border:none;
      background:#333;
      color:#eee;
      padding:0.2rem 0.6rem;
      border-radius: 3px;
    }
    label { font-size:0.85rem; opacity:0.85; }
    #promptBox, #sceneJson {
      width: 100%;
      resize: vertical;
      background:#111;
      color:#eee;
      border:1px solid #444;
      padding:0.5rem;
      box-sizing:border-box;
      font-family: monospace;
      font-size: 0.9rem;
    }
    #promptBox { height: 200px; }
    #sceneJson { height: 150px; background:#090909; font-size:0.8rem; }
  </style>
</head>
<body>
  <div class="page-wrapper">
    <header>
      <h1>Storyboard Viewer</h1>

      <input type="file" id="fileInput" accept="application/json" style="display:none" />
      <button id="loadBtn">Load storyboard</button>

      <span id="storyTitle"></span>

      <!-- Using your corrected initial state: list + "View: Tile" -->
      <button id="viewToggle">View: Tile</button>
    </header>

    <main>
      <!-- Start in list mode -->
      <div id="scenesList" class="list"></div>
    </main>
  </div>

  <!-- Fullscreen modal -->
  <div id="modal">
    <div id="modalContent">
      <div id="modalHeader">
        <div id="modalTitle"></div>
        <button id="modalClose">Close</button>
      </div>

      <label for="promptBox">Prompt</label>
      <textarea id="promptBox"></textarea>

      <label for="sceneJson">Scene JSON</label>
      <textarea id="sceneJson" readonly></textarea>
    </div>
  </div>

  <script>
    const loadBtn     = document.getElementById('loadBtn');
    const fileInput   = document.getElementById('fileInput');
    const scenesList  = document.getElementById('scenesList');
    const storyTitle  = document.getElementById('storyTitle');
    const viewToggle  = document.getElementById('viewToggle');

    const modal       = document.getElementById('modal');
    const modalTitle  = document.getElementById('modalTitle');
    const modalClose  = document.getElementById('modalClose');
    const promptBox   = document.getElementById('promptBox');
    const sceneJson   = document.getElementById('sceneJson');

    let storyboardData = null;

    // Load storyboard JSON from file picker
    loadBtn.addEventListener('click', () => fileInput.click());

    fileInput.addEventListener('change', (evt) => {
      const file = evt.target.files[^4_0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const data = JSON.parse(e.target.result);
          storyboardData = data;
          renderStoryboard(data);
        } catch (err) {
          alert('Invalid JSON: ' + err.message);
        }
      };
      reader.readAsText(file);
    });

    // View toggle (tiles / list), using your logic
    viewToggle.addEventListener('click', () => {
      if (scenesList.classList.contains('tiles')) {
        scenesList.classList.remove('tiles');
        scenesList.classList.add('list');
        viewToggle.textContent = 'View: Tile';
      } else {
        scenesList.classList.remove('list');
        scenesList.classList.add('tiles');
        viewToggle.textContent = 'View: List';
      }
    });

    // Render storyboard scenes
    function renderStoryboard(data) {
      storyTitle.textContent = data.title ? 'Title: ' + data.title : '';
      scenesList.innerHTML = '';

      if (!Array.isArray(data.scenes)) return;

      data.scenes.forEach(scene => {
        const card = document.createElement('div');
        card.className = 'scene-card';

        // Thumbnail: /sb/<scene>.jpg
        const img = document.createElement('img');
        img.className = 'scene-thumb';
        img.alt = scene.scene || '';
        img.src = '/sb/' + (scene.scene || '') + '.jpg';
        img.onerror = () => { img.style.display = 'none'; };

        const id = document.createElement('div');
        id.className = 'scene-id';
        id.textContent = 'Scene ' + (scene.scene || '');

        const meta = document.createElement('div');
        meta.className = 'scene-meta';
        meta.textContent = [
          scene.weather,
          scene.location,
          scene.entityA,
          scene.entityB
        ].filter(Boolean).join(', ');

        card.appendChild(img);
        card.appendChild(id);
        card.appendChild(meta);

        card.addEventListener('click', () => openModal(scene));

        scenesList.appendChild(card);
      });
    }

    // Open fullscreen modal for a scene
    function openModal(scene) {
      modal.style.display = 'flex';
      modalTitle.textContent = 'Scene ' + (scene.scene || '');

      const parts = [
        scene.weather,
        scene.location,
        scene.entityA,
        scene.poseA,
        scene.descriptionA,
        scene.entityB,
        scene.poseB,
        scene.descriptionB,
        scene.style,
        scene.renderstyle,
        scene.camera
      ].filter(Boolean);

      promptBox.value = parts.join(', ');
      sceneJson.value = JSON.stringify(scene, null, 2);
    }

    // Close modal handlers
    modalClose.addEventListener('click', () => {
      modal.style.display = 'none';
    });

    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.style.display = 'none';
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modal.style.display === 'flex') {
        modal.style.display = 'none';
      }
    });
  </script>
</body>
</html>
```

You can tweak the wrapper sizing easily by changing `width: 75vw` or the `max-width` value if you want it even more **portrait**. Modern layout guides recommend this kind of centered wrapper for readability on large screens.[^4_1]

<div align="center">⁂</div>

[^4_1]: https://stackoverflow.com/questions/66252240/loading-json-data-with-button-click-and-textbox


---

# Very nice works very well thank you for the assistance. I'll start a new session to work on the scene editor so that it becomes compatible with this storyboard.

That sounds like a great next step, and the current structure should make a scene editor integration straightforward.[^5_1]

For the editor session, keeping the same field names (`weather`, `location`, `entityA`, etc.) and the same `scenes` array shape will ensure full compatibility with this storyboard viewer.[^5_1]

<div align="center">⁂</div>

[^5_1]: https://stackoverflow.com/questions/66252240/loading-json-data-with-button-click-and-textbox

