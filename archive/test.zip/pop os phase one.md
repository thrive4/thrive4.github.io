<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Currently I'm looking into linux mint and pop os ... are there any pro's and cons I might zoom into?

Here are the main angles you can zoom into when comparing Linux Mint and Pop!_OS, plus where each one tends to shine.[^1_1][^1_6][^1_8]

## Desktop experience

- Linux Mint: Traditional, **Windows‑like** layout (taskbar at bottom, start‑menu style launcher), very friendly if you’re coming from Windows and want something familiar.[^1_6][^1_1]
- Pop!_OS: Modern GNOME/COSMIC style with a top bar, app grid, and strong keyboard‑driven workflow; feels more “macOS + tiling WM hybrid”.[^1_8][^1_6]

**Questions to ask:**
Do you want “it just feels like Windows but nicer” (Mint) or “I want a modern, keyboard‑centric, tiled workflow” (Pop)?

## Performance and hardware

- Linux Mint: Cinnamon is relatively light; Mint is known to run smoothly on older or low‑spec hardware and even has lighter editions like Xfce.[^1_7][^1_9]
- Pop!_OS: Slightly heavier desktop, but tuned for performance and multitasking; shines on more modern machines, especially with good CPU/GPU.[^1_6][^1_8]

**Questions to ask:**
Is this for an older laptop or modest machine (favor Mint), or a more powerful system where you’ll push CPU/GPU (favor Pop)?

## Drivers, gaming, and GPUs

- Linux Mint: General‑purpose, stable desktop; gaming works via Steam/Proton, but Mint doesn’t focus specifically on gaming or hybrid GPU workflows.[^1_2][^1_4]
- Pop!_OS: Strong focus on NVIDIA/AMD GPU support, with dedicated ISOs and good hybrid‑graphics handling; popular with gamers and creators using 3D tools or GPU‑heavy apps.[^1_4][^1_2][^1_8]

**Questions to ask:**
Do you game a lot, use Blender/DaVinci, or have NVIDIA/hybrid graphics? If yes, Pop!_OS usually gives you fewer driver headaches.

## Updates, stability, and philosophy

- Linux Mint pros: Very stable, conservative updates (based on Ubuntu LTS), no Snap by default, strong focus on a calm, predictable desktop.[^1_5][^1_1][^1_7]
- Linux Mint cons: Slower access to the newest kernels/desktops, which can be a downside if you like cutting‑edge features or need very new hardware support.[^1_1][^1_4]
- Pop!_OS pros: Newer kernels and graphics stacks, faster updates, recovery partition, more “rolling‑ish” feel within Ubuntu’s base.[^1_4][^1_8]
- Pop!_OS cons: More moving parts; new COSMIC developments can mean occasional rough edges compared to Mint’s “boring but reliable” vibe.[^1_8][^1_4]

**Questions to ask:**
Do you value “set it and forget it” stability (Mint) or “newer stuff and features sooner” (Pop)?

## Software and package approach

- Both: Ubuntu‑based, so .deb packages, Flatpak, and most mainstream Linux software are easy to install.[^1_1][^1_6]
- Mint: Polished Software Manager, ratings/reviews, webapp manager, and a strong focus on GUI tools for everyday tasks.[^1_3][^1_7][^1_1]
- Pop!_OS: Pop!_Shop store, very friendly to developers (toolchains, IDEs, etc.), and often nudges you toward Flatpaks and newer app versions.[^1_10][^1_2][^1_6]

**Questions to ask:**
Are you a general user wanting a curated, simple app store (Mint), or a dev/gamer who likes quick access to newer packages and dev tools (Pop)?

## When to pick which

If you tell me a bit more about your use case (old vs new hardware, gaming or not, dev work, tiling windows yes/no, comfort with change), I can help you zoom into the 2–3 factors that matter most for **your** setup and suggest one of them with concrete reasons.

<div align="center">⁂</div>

[^1_1]: https://abh.ai/blog/linux-mint-pros-and-cons

[^1_2]: https://www.reddit.com/r/linux_gaming/comments/1japsl4/comparing_pop_os_to_linux_mint_whats_the_pros_and/

[^1_3]: https://www.reddit.com/r/linuxmint/comments/1cmgwzz/i_switched_to_mint_here_are_my_pros_and_cons/

[^1_4]: https://www.reddit.com/r/linux4noobs/comments/199m5h2/distro_question_what_is_the_best_between_linux/

[^1_5]: https://www.reddit.com/r/linuxquestions/comments/u11otn/what_are_the_pros_and_cons_of_linux_mint_vs_ubuntu/

[^1_6]: https://operatingsystems.info/linux-mint-vs-pop_os-which-one-is-right-for-you/

[^1_7]: https://www.unixmen.com/switching-to-linux-mint-the-benefits-and-drawbacks/

[^1_8]: https://cyberpanel.net/blog/linux-mint-vs-pop-os

[^1_9]: https://windowsforum.com/threads/switching-to-linux-mint-in-2025-a-windows-users-deep-dive-and-honest-review.365732/

[^1_10]: https://www.youtube.com/watch?v=eXQ6YBb0Cz4


---

# Okidoki lets start with the browser / email combi what do both come bundled with?

Linux Mint and Pop!_OS are both Ubuntu‑based, so they use very similar core apps, but their default browser/email choices differ slightly in emphasis.[^2_4][^2_6]

## Linux Mint defaults

On a fresh Linux Mint install you typically get:

- Browser: Firefox as the default web browser.[^2_4]
- Email: Thunderbird as the default desktop mail client, integrated with Mint’s “Preferred Applications” so mailto: links open there unless you change it.[^2_3][^2_4]

Mint also ships a WebApp manager, which many people use to turn webmail (Gmail, Outlook, Proton Mail, etc.) into standalone “apps” instead of or alongside Thunderbird.[^2_2][^2_3]

## Pop!_OS defaults

On current Pop!_OS releases you typically get:

- Browser: Firefox as the default browser out of the box.[^2_6][^2_7]
- Email: No heavy desktop email client preinstalled in many recent ISOs; most users either install Thunderbird/Evolution themselves or just pin their webmail in the browser.[^2_6]

Because Pop!_OS targets developers and power users, the assumption is often “you’ll pick your own mail client,” while Mint gives you a ready‑to‑go Thunderbird setup.

## What to zoom into

If the browser/email combo matters a lot to you, consider:

- Do you like a classic desktop mail client (then Mint’s defaults are convenient)?
- Or are you happy living in webmail (then both are similar, and you might ignore desktop mail entirely)?

If you tell me which mail service you use (Gmail, Outlook, Proton, etc.) and whether you want offline mail, I can suggest a concrete setup that’ll feel smooth on both Mint and Pop.
<span style="display:none">[^2_1][^2_5]</span>

<div align="center">⁂</div>

[^2_1]: https://community.getmailspring.com/t/mailspring-sets-itself-as-default-browser-in-linux-mint/4995

[^2_2]: https://www.reddit.com/r/linuxmint/comments/x9q49o/making_a_webapp_a_default/

[^2_3]: https://www.reddit.com/r/linuxmint/comments/1ftvuyn/email_client/

[^2_4]: https://www.youtube.com/watch?v=7Xpo_z1f_VY

[^2_5]: https://community.linuxmint.com/software/view/gnome-gmail

[^2_6]: https://operatingsystems.info/linux-mint-vs-pop_os-which-one-is-right-for-you/

[^2_7]: https://cyberpanel.net/blog/linux-mint-vs-pop-os


---

# Well I'm using thuderbird now (windows 7) so that's one notch for mint. Ok moving onto ai stuff, comfy ui, and then the usual hugging faces models, any one of the two more suited (maybe with regard to nvidia driver support cause most the ai stuff relies quite heavily on the video card) ?

For local AI workloads and NVIDIA‑heavy stuff (ComfyUI, Hugging Face models), Pop!_OS generally has the edge, but Mint can still work well if you’re willing to tweak more.

## NVIDIA drivers and GPU stack

- Pop!_OS offers a dedicated “NVIDIA” ISO with proprietary drivers preconfigured and tuned for GPU workloads (gaming, CUDA, GPU compute), plus good hybrid‑graphics handling on laptops.[^3_2][^3_5][^3_8]
- Linux Mint uses Ubuntu’s NVIDIA drivers via its Driver Manager; it’s stable and fine for most users, but Pop!_OS tends to ship newer kernels and GPU drivers sooner, which helps with recent cards and performance quirks.[^3_1][^3_6][^3_7]

If your card is relatively new (RTX generation) or you’re on a hybrid‑GPU laptop, Pop!_OS will usually “just work” faster and with less manual fiddling.[^3_5][^3_8]

## Running ComfyUI and local models

Both can run ComfyUI and local Hugging Face models because under the hood you’ll be using the same toolchain: Python, CUDA/cuDNN, PyTorch, etc.

- On Pop!_OS, newer drivers and kernels plus System76’s GPU focus make it a bit smoother for: installing CUDA, using GPU‑accelerated Docker containers, and juggling multiple models.[^3_6][^3_8][^3_2]
- On Mint, everything is doable, but you may need to: ensure proprietary NVIDIA drivers are selected in Driver Manager, install the right CUDA toolkit manually, and occasionally pin or tweak driver versions for maximum stability.[^3_3][^3_7][^3_1]

If your main goal is “local AI workstation first, nice desktop second,” Pop!_OS is the more purpose‑built choice.

## Day‑to‑day feel vs AI focus

- Linux Mint: You already like Thunderbird, and Mint gives you that plus a very calm, Windows‑like desktop that’s great for email, browsing, and general use.[^3_2][^3_6]
- Pop!_OS: A bit less hand‑holding on classic desktop tools, but more thought put into developers, GPU users, and power‑workflows (tiling, workspaces, hybrid graphics).[^3_8][^3_6][^3_2]

Given your Thunderbird habit, one practical route is:

- If AI/GPU work is the priority: go Pop!_OS (NVIDIA ISO) and just install Thunderbird.
- If a comfy “daily driver” feel is more important and AI is more of a hobby: Mint will be nicer, and you can still set up ComfyUI and local models with some driver care.

If you tell me your exact GPU (e.g., “RTX 3060 laptop” or “GTX 1080 desktop”) and whether it’s a laptop or tower, I can give a more pointed “Mint vs Pop for your hardware” recommendation.
<span style="display:none">[^3_4]</span>

<div align="center">⁂</div>

[^3_1]: https://www.reddit.com/r/linux4noobs/comments/kwy4zo/linux_mint_vs_popos_for_heavy_gaming_with_an/

[^3_2]: https://www.youtube.com/watch?v=eXQ6YBb0Cz4

[^3_3]: https://www.facebook.com/groups/linuxmintdesktop/posts/1859288218359411/

[^3_4]: https://www.linux.org/threads/what-does-pop-_os-have-that-linux-mint-doesnt.35163/

[^3_5]: https://www.facebook.com/groups/GNUAndLinux/permalink/10162404747270019/

[^3_6]: https://www.youtube.com/watch?v=cWNv8awiwyc

[^3_7]: https://www.reddit.com/r/linux4noobs/comments/199m5h2/distro_question_what_is_the_best_between_linux/

[^3_8]: https://www.reddit.com/r/pop_os/comments/1cyyt5v/pop_os_is_better_or_worse_than_mint/


---

# Ok that's one notch for pop os in that regard. The card by the by is a rtx 5060 desktop. In terms of game benchmarks, as far as I can tell, it's a bit all over the place lots of bench marks on youtube comparing both but I get the impression that both are pretty much on equal footing, pending game, driver version, etc ...

Your impression is spot on: for gaming performance itself, Mint and Pop!_OS are effectively neck‑and‑neck, and the differences you see in YouTube benchmarks mostly come down to specific game, kernel, driver version, and background services.[^4_2][^4_7][^4_8]

## Gaming performance reality

- Both are Ubuntu‑based, so they use the same NVIDIA driver stack and Proton/Steam ecosystem; raw FPS differences are usually in the 0–5% noise range, sometimes favoring one, sometimes the other.[^4_1][^4_2]
- With a desktop RTX 5060, once the correct proprietary driver is installed and you’re on a reasonably recent kernel, you’ll get very similar results in most titles across both distros.[^4_4][^4_9]


## Where Pop!_OS still has a slight edge

- Pop!_OS’s NVIDIA variant gives you a “ready to roll” setup for new GPUs with preinstalled drivers and often slightly newer kernels, so you hit that good state faster with less tinkering.[^4_6][^4_1]
- That convenience can matter more than the tiny FPS differences: fewer install hoops, quicker path to getting Steam, Lutris, and Proton games using your RTX properly.


## How that fits your use case

Given:

- You like Thunderbird (Mint wins on defaults).
- You care about local AI (Pop wins on NVIDIA focus).
- Gaming benchmarks are basically a wash (tie, leaning Pop for ease/recency rather than sheer FPS).

A sane strategy with an RTX 5060 desktop is:

- If you want the smoothest path for AI + games: go Pop!_OS NVIDIA image, install Thunderbird, and you’re golden.
- If you value Mint’s more traditional desktop more, you can still game and run AI just fine; you’ll just spend a bit more time making sure the latest NVIDIA driver is selected and working.

If you like, next we can zoom into: how you’d actually set up your AI stack (ComfyUI + a couple of Hugging Face models) on either Mint or Pop, step‑by‑step, so you know what you’re signing up for with each.
<span style="display:none">[^4_10][^4_3][^4_5]</span>

<div align="center">⁂</div>

[^4_1]: https://www.reddit.com/r/linux4noobs/comments/1e1l5rk/linux_mint_or_pop_os_on_a_gaming_laptop/

[^4_2]: https://www.reddit.com/r/linux4noobs/comments/kwy4zo/linux_mint_vs_popos_for_heavy_gaming_with_an/

[^4_3]: https://www.reddit.com/r/linux_gaming/comments/1qi9xyi/mint_vs_popos_for_gaming_and_daily_use/

[^4_4]: https://www.youtube.com/watch?v=FMA4Id6gTEE

[^4_5]: https://www.reddit.com/r/linux4noobs/comments/199m5h2/distro_question_what_is_the_best_between_linux/

[^4_6]: https://www.youtube.com/watch?v=cWNv8awiwyc

[^4_7]: https://www.youtube.com/watch?v=vsElW3-ulfs

[^4_8]: https://www.youtube.com/watch?v=4pXPkT7RdmA

[^4_9]: https://www.youtube.com/watch?v=WcFZW7vaw7c

[^4_10]: https://www.facebook.com/groups/linuxmintdesktop/posts/1859288218359411/


---

# Right a tie there. So lets look into some more 'dev' orientated stuff. How do they compare in bundling python, C, sdl libs, sqlite libs and for example if I download freebasic form here : https://github.com/freebasic/fbc/releases: (freebasic is a bit dated but let that be for now) would it prove 'challenges' to get it up and running on either distro's?

For dev tooling, Mint and Pop!_OS are almost the same under the hood, and FreeBASIC should be equally doable on both. The bigger differences are comfort and defaults, not capabilities.

## Built‑in dev stack (Python, C, libs)

Both are Ubuntu‑based, so they share the same package universe and compiler toolchains.

- C toolchain: You’ll install **build‑essential** (gcc, g++, make, etc.) via the package manager on both; neither is “worse” here.
- Python: Both ship a system Python and let you install python3, venv, pip, etc.; typical workflow (virtualenvs, conda, poetry) is identical.
- SDL, SQLite and friends: All the usual dev libraries (sdl2, sdl2‑image, sdl2‑mixer, libsqlite3‑dev, etc.) are in the standard repos on both.
- Extra tooling: Docker, git, CMake, Node, Rust, etc. are equally available; Pop!_OS markets itself more at devs, but from a package perspective Mint can do all the same things.

A nice side‑effect: Mint is often rated as having slightly better “out of the box” software support and repos, while Pop!_OS keeps the base a bit leaner, but for dev packages you just install what you want either way.[^5_1][^5_2][^5_3]

## FreeBASIC on Mint vs Pop!_OS

FreeBASIC’s Linux builds target glibc‑based distributions like Ubuntu/Debian, so both Mint and Pop!_OS are within its comfort zone.

Typical steps you’d hit on either distro:

1. Install dev essentials: gcc, make, binutils, and 32‑bit compatibility libs if the FreeBASIC build expects them.
2. Install needed libs: SDL, X11, ncurses, etc., depending on what you compile.
3. Download the FreeBASIC release tarball, extract it, run the installer script or manually place the binaries and add them to PATH.

Possible “challenges” you might see:

- 32‑bit dependencies: some older FreeBASIC binaries assume 32‑bit libs; you may need to enable multi‑arch and install a few `:i386` packages.
- Library names/paths: on modern Ubuntu‑ish systems library package names may differ slightly from what older docs say; you just translate them (e.g. libX11.so comes from a `libx11-dev` package).
- Wayland vs X11: if you use any ancient examples that assume pure X11, you might prefer an X11 session (both Mint Cinnamon and Pop’s COSMIC/ GNOME can run X.org sessions).

None of this is uniquely painful on Mint or Pop; if FreeBASIC works on Ubuntu, it will work on both with the same tweaks.

## Which is nicer for your dev use

Given your usage:

- Local AI + NVIDIA: slight practical win for **Pop!_OS**.
- Classic desktop apps (Thunderbird, general “Windows‑like” workflow): win for **Mint**.
- C/Python/SDL/SQLite/FreeBASIC: essentially a **draw**; both are equally capable with the same commands and packages.

So you can safely choose based on how you want the system to *feel*:

- Prefer a more “IDE‑workstation, tiling, GPU‑centric” vibe → Pop!_OS.
- Prefer a “traditional, everything visible in menus, very chill” vibe → Linux Mint.

If you like, I can sketch concrete install commands and folder layout for FreeBASIC on an Ubuntu‑based system so you know exactly what you’d do after first boot.
<span style="display:none">[^5_4][^5_5][^5_6][^5_7][^5_8][^5_9]</span>

<div align="center">⁂</div>

[^5_1]: https://embeddedinventor.com/linux-mint-vs-pop_os-similarities-differences/

[^5_2]: https://www.youtube.com/watch?v=eXQ6YBb0Cz4

[^5_3]: https://www.reddit.com/r/linux4noobs/comments/1djqqub/linux_mint_vs_pop_os/

[^5_4]: https://www.reddit.com/r/linux4noobs/comments/199m5h2/distro_question_what_is_the_best_between_linux/

[^5_5]: https://www.youtube.com/watch?v=Kb2qT9G5znc

[^5_6]: https://www.facebook.com/groups/poposlinux/posts/23951885677830462/

[^5_7]: https://www.youtube.com/watch?v=cWNv8awiwyc

[^5_8]: https://www.youtube.com/watch?v=PcxFfuxBiPg

[^5_9]: https://www.youtube.com/watch?v=7vIqH_kpaws


---

# All right a tie again ... So I guess more the logistics due either bombard the user with update? If so can system updates be disabled ...? And always a bit tricky but do either of them have a spotty behavior regarding privacy?

Linux Mint and Pop!_OS both notify users of updates via graphical tools (Update Manager for Mint, Pop!_Shop for Pop), but neither aggressively "bombards" you—updates are optional and non-intrusive compared to Windows.[^6_1][^6_2]

## Update frequency and behavior

- Linux Mint: Conservative approach based on Ubuntu LTS releases; daily/weekly security patches and minor app updates arrive steadily but infrequently for big changes. Update Manager lets you review, select, and apply them on your schedule—no forced reboots or popups.[^6_2]
- Pop!_OS: Slightly more frequent due to newer kernels/drivers (every 6 months for point releases), with daily security/app updates possible depending on installed software. Still chill—Pop!_Shop notifies quietly, and updates rarely require reboots.[^6_1]

Both respect your pace; Mint feels more "set and forget," while Pop has a tad more activity if you're on bleeding-edge NVIDIA stuff.

## Disabling updates

Yes, fully possible and straightforward on both:

**Linux Mint:**

```
sudo apt-mark hold package-name  # Hold specific packages
```

Or edit `/etc/apt/apt.conf.d/20auto-upgrades` to disable auto-checks entirely. Update Manager has checkboxes to skip levels (e.g., ignore "untrusted" 3rd-party updates).[^6_2]

**Pop!_OS:**

```
sudo systemctl disable --now pop-updated  # Stop auto-update service
sudo apt-mark hold package-name  # Same hold command
```

Pop!_Shop respects manual control; you can even uninstall it if paranoid.

## Privacy track record

Neither has "spotty" privacy issues—both are fully FOSS, telemetry-free by default, and don't phone home like Ubuntu sometimes does.

- Linux Mint: Gold standard for privacy-focused users; no phoning home, no user tracking, opt-in for everything. Past Popcorn Time fork drama is ancient history (pre-2016) and irrelevant today.[^6_2]
- Pop!_OS: Equally clean—no telemetry, System76 (makers) emphasize privacy. Optional hardware enablement (if you buy their gear) is transparent and disableable; no scandals or data leaks reported.[^6_3][^6_1]

**Short version:** Privacy is a non-issue for both. Updates won't harass you, and disabling is trivial.

## Scorecard so far

| Aspect | Winner | Notes |
| :-- | :-- | :-- |
| Thunderbird defaults | Mint | Ready out of box |
| NVIDIA/AI/RTX 5060 | Pop!_OS | Faster setup |
| Gaming FPS | Tie | Driver-dependent |
| Dev tools (Python/C/SDL/FreeBASIC) | Tie | Identical packages |
| Updates/privacy | Tie | Both respectful |

**Pop!_OS slight lead** for your GPU-heavy AI+gaming needs, but Mint if desktop familiarity trumps. Ready to pick hardware specs or test via live USB? I can guide first-boot setup for your winner.
<span style="display:none">[^6_4][^6_5][^6_6][^6_7]</span>

<div align="center">⁂</div>

[^6_1]: https://www.reddit.com/r/pop_os/comments/hrfjjc/how_frequent_are_system_updates/

[^6_2]: https://forum.zorin.com/t/frequency-of-updates-using-linux-mint-as-an-example/39572

[^6_3]: https://www.reddit.com/r/linux4noobs/comments/1djqqub/linux_mint_vs_pop_os/

[^6_4]: https://www.youtube.com/watch?v=eXQ6YBb0Cz4

[^6_5]: https://www.reddit.com/r/linux4noobs/comments/1byvj6b/linux_mint_vs_pop_os/

[^6_6]: https://www.youtube.com/watch?v=Kb2qT9G5znc

[^6_7]: https://www.reddit.com/r/linux4noobs/comments/199m5h2/distro_question_what_is_the_best_between_linux/


---

# Nice good info thank you. So started with a pop os install to an .... usb stick ... always fun. Tried earlier with linux mint both of them have this curious habit of allowing the install to take place on the usb stick which actually is used for the live setup (ventoy with a bunch of images) yes the image is loaded to ram so the os is running from there but still ... gets even more confusing when you happen to have two identical usb sticks and can's discern which has the ventoy with iso's on it ... so pulled that one out and started the install to the remaining usb stick ... will that work or does the install need the iso anyway ...

Yes, your Pop!_OS install to the second USB stick should work fine and boot afterward—the live environment runs entirely from RAM once loaded, so the installer doesn't need the original ISO USB present during or after installation.[^7_1][^7_3][^7_4]

## Why it works (and your Ventoy confusion is common)

Pop!_OS (and Mint) installers are smart enough to let you target *any* block device, including USB sticks—even the one you're booted from (though that's risky and often fails mid-process due to partition locks). By pulling the Ventoy stick and targeting the spare one, you're golden:

- The live session stays in RAM.
- The installer copies files, sets up GRUB bootloader on the target USB, and formats its partitions independently.
- Post-install, that second USB becomes a full, bootable Pop!_OS drive—no ISO dependency.

Users do this routinely for "portable Linux on USB" setups, as confirmed in guides and forums.[^7_3][^7_4]

## Next steps to test it

1. Finish the install if it's still running (user/password setup, etc.).
2. **Shut down completely** (don't just reboot with USBs plugged in).
3. Remove the Ventoy/live USB.
4. Plug in only the new Pop!_OS USB.
5. Boot from it (F12 boot menu or BIOS boot order).

It should GRUB-boot straight into your installed Pop!_OS. Expect some slowness on USB (especially writes), but it'll be functional for testing AI/gaming/dev stuff.[^7_4]

## Identical USB tip

Label them physically (sharpie + tape) or use distinct sizes/colors next time. For Ventoy, you can also add a unique partition label via its config.

## If it doesn't boot

- Check BIOS boot mode matches (UEFI for modern Pop!_OS; disable Secure Boot if issues).
- Verify target USB in installer was correct (`lsblk` during install shows devices clearly).
- Worst case: redo on the spare USB, double-checking device names.

Let me know how first boot goes or if you hit errors—can walk you through NVIDIA setup, Thunderbird install, or ComfyUI next!
<span style="display:none">[^7_10][^7_2][^7_5][^7_6][^7_7][^7_8][^7_9]</span>

<div align="center">⁂</div>

[^7_1]: https://itsfoss.com/install-pop-os/

[^7_2]: https://pop-os.github.io/docs/getting-started/create-bootable-media/create-bootable-usb.html

[^7_3]: https://www.youtube.com/watch?v=42zUASJ7tR8

[^7_4]: https://www.reddit.com/r/pop_os/comments/bog0q6/can_i_have_a_full_install_on_of_pop_os_on_a_usb/

[^7_5]: https://www.fosslinux.com/112708/the-ultimate-guide-to-creating-a-pop_os-bootable-usb-drive.htm

[^7_6]: https://www.youtube.com/watch?v=eol5O1qfWNs

[^7_7]: https://support.system76.com/articles/install-pop/

[^7_8]: https://support.system76.com/articles/live-disk/

[^7_9]: https://pop-os.github.io/docs/getting-started/installation/installation.html

[^7_10]: https://www.youtube.com/watch?v=1ekoWV4Li4k


---

# Good to know hopeful there. Would have been nice though that the user can not select the drive where the iso resides ... don't really see the merit of overwriting the 'install' / 'live' usb ...

You're right—it's a design quirk in most Linux installers (Pop!_OS, Mint, Ubuntu, etc.) that they don't automatically block the live USB as a target. The logic is flexibility: some users intentionally install *to* the live USB for portable setups, and the installer trusts you to know your `lsblk` output.[^8_1]

## Why they allow it (and why it's risky)

- **Portability use case:** People create "full persistent installs" on USBs to carry their OS+data everywhere; the installer supports that workflow.
- **No auto‑detection:** Live USBs use squashfs overlays that *look* like regular block devices to the installer; distinguishing "live source" vs "targetable drive" reliably is tricky without heuristics that could false‑positive.
- **User responsibility:** `lsblk` shows sizes, labels, mountpoints—installer assumes you'll double‑check before nuking the wrong stick.

In practice, selecting the live USB often fails anyway (partition locks, read‑only squashfs), but it *lets you try*, which is frustrating when juggling identical drives.

## Workarounds people use

- **Physical labels:** Sharpie+tape on USBs ("Ventoy LIVES", "Target TEST").
- **Size/layout clues:** During install, `lsblk -f` shows filesystems—live USB has `squashfs`, target is blank/unallocated.
- **Third USB:** Boot from one, install to second, keep Ventoy safe on third.
- **Virtualization first:** Test ISOs in VirtualBox/VMware before committing to USB.


## Mint vs Pop!_OS here

Both behave the same—no edge either way. Future Mint 22 or Pop!_COSMIC might add "live USB protection" if enough users complain, but for now it's universal.

Good call pulling the Ventoy stick mid‑install—your Pop!_OS USB should boot cleanly once done. Let me know how first boot goes!

<div align="center">⁂</div>

[^8_1]: https://itsfoss.com/install-pop-os/


---

# lsblk hmm I see that's a tall order specially when just starting out in linux land but I guess once people start habitually installing os's this sort of stuff becomes second nature ...  thanks for the tips though... regarding the progress odd so everything is loaded in to RAM but the install inches along with 'extracting files' it's that squashfs thing again ...

Yes, exactly—`lsblk` feels like a foreign language at first, but after a few installs it becomes muscle memory (like checking "This PC" sizes in Windows). You'll spot the live USB by its squashfs partition and odd size vs your blank target drive in seconds.

## The "extracting files" slowness

Spot on: even though the live environment runs from RAM, the installer still extracts the ~3-4GB squashfs root filesystem from the ISO image, decompresses it, and copies files to your target USB. That's the bottleneck—USB write speeds (often 10-30MB/s) make it crawl, especially on cheaper sticks.

**Normal behavior:**

```
[█████░░░░░░░░░░░] 35% Extracting files...
```

Can take 10-40 minutes depending on USB quality. It's not frozen—just USB-limited I/O.

## When it's done

Expect these final steps after extraction:

1. **Partition setup** (quick)
2. **GRUB bootloader** install to USB (1-2 min)
3. **First user config** screen (username/password)
4. Reboot prompt

**Then:** Power off fully, unplug Ventoy USB, plug only Pop!_OS USB, boot it. GRUB menu → Pop!_OS should load your fresh install.

## If it hangs forever

- **>1hr on extraction:** USB too slow/broken → cancel, try better stick
- **Stuck post-extraction:** Rare, but `Ctrl+Alt+F2` → `sudo systemctl status anaconda` (or installer logs) can show what's up

Let me know when you hit desktop or if it stalls—ready to guide NVIDIA drivers, Thunderbird setup, or ComfyUI once you're in! The slow extract is totally normal for USB targets.

---

# Ehhr 'the installer still extracts the ~3-4GB squashfs root filesystem from the ISO image, decompresses it, and copies files to your target USB' as I said I removed the 'install' stick maybe you mean the iso is now mounted virtually ... in RAM ?

Yes, exactly right—the ISO image (with its squashfs filesystem) was unpacked and mounted **entirely into RAM** when you booted the live session. Removing the physical USB stick doesn't stop the installer because all the needed files are already extracted and cached there.[^10_1][^10_2]

## How it works

1. **Boot phase:** Ventoy loads Pop!_OS ISO → kernel/initrd decompresses squashfs root to RAM overlay
2. **Live session:** Everything runs from RAM (that's why USB removal is safe)
3. **Install phase:** Installer reads from RAM-cached squashfs → writes fresh files directly to target USB

No dependency on the physical ISO USB after boot. Your "extracting files" progress is the installer:

```
RAM-cached files → decompress → copy → new ext4 filesystem on target USB
```


## Current status check

If it's still chugging at "extracting files," you're good—just USB write speed. Should finish soon. When it hits **"Configuring system"** or **user setup**, you're golden.

**Post-install flow:**

```
1. Set username/password  
2. "Installation complete" → reboot  
3. Shut down fully  
4. Pop!_OS USB only → boot → desktop!
```

Let me know when you see the desktop (or if it stalls). Then we tackle NVIDIA RTX 5060 drivers with one command!

<div align="center">⁂</div>

[^10_1]: https://itsfoss.com/install-pop-os/

[^10_2]: https://pop-os.github.io/docs/getting-started/installation/installation.html


---

# Will do ... good news the drivers are bundled so that should pan out ok. Well pop os comes with  six partitions ... what's recovery (4 gig) doing??

Great to hear you reached the Pop!_OS desktop and the NVIDIA RTX 5060 drivers were auto-detected—System76 bundles them smartly in the NVIDIA ISO.

## The 6 partitions layout

Pop!_OS uses a thoughtful default partitioning scheme, especially on USB/desktop installs. Here's the typical breakdown:

```
EFI (512MB)      - Bootloader (GRUB/ESP)  
Boot (1GB)       - Kernel + initrd  
Root (15-30GB+)  - Main / filesystem  
Recovery (4GB)   - **Recovery partition**  
Home (rest)      - /home (user files)  
Swap (4-8GB)     - Swap space  
```


## Recovery partition purpose

The **4GB recovery partition** contains a minimal Pop!_OS live environment + tools for:

- **Factory reset** from GRUB recovery menu (wipes + reinstalls Pop!_OS)
- **Driver reinstall** if NVIDIA/graphics break
- **Filesystem repair** (fsck, boot repair)
- **Internet recovery** (download updates during repair)

**Access it:**

1. Hold **Shift** during GRUB boot → Advanced → Recovery Mode
2. Or boot with `e` key → edit kernel line → add `systemd.unit=recovery.target`

**Very handy for:**

- GPU driver crashes (common with NVIDIA experimentation)
- USB corruption (your use case)
- "Something broke, get me back fast" scenarios

You can resize/move it later if needed, but 4GB is a nice safety net, especially since you're testing AI/gaming stacks that might push drivers hard.

## First things next?

1. **Verify NVIDIA:** `nvidia-smi` in terminal (should show RTX 5060, CUDA version)
2. **Thunderbird:** `sudo apt install thunderbird`
3. **Test Steam/gaming** or **ComfyUI setup**

What do you want to tackle first on this fresh install?

---

# Nvidia is a-ok went good with the bundled drivers install ... the partitons I have 2.1 MB unallocated (no idea why) then 1Gig Efi, then 4Gig recovery, x gig remainder I assume the os, then 4 Gig swap and finally 2.1 MB unallocated again ...

Perfect—bundled NVIDIA drivers working out of the box on Pop!_OS is exactly why it gets the nod for RTX 5060 users.

## Your partition layout decoded

That's Pop!_OS's standard scheme, just with ~2MB unallocated slivers at each end (normal, harmless—installer alignment padding):

```
2.1MB unallocated  
1GB   EFI          - GRUB/ESP boot  
4GB   Recovery     - Reset/tools (as explained)  
~XGB  Root         - Main OS (/ filesystem)  
4GB   Swap         - Hibernation/RAM overflow  
2.1MB unallocated  
```

**Clean and purposeful.** The recovery partition up front lets GRUB chainload it easily. Swap at end is conventional. No worries about the tiny unallocated gaps.

## Next practical steps

Since NVIDIA is ✅ and partitions are sensible:

**Quick wins to make it "your" system:**

```
# Thunderbird (your Windows 7 fave)
sudo apt update && sudo apt install thunderbird

# Verify NVIDIA + CUDA ready for AI
nvidia-smi   # Should show RTX 5060, ~16GB VRAM, driver version

# Steam for gaming test
sudo apt install steam
```

**For ComfyUI/HuggingFace later:**

```
sudo apt install python3-pip python3-venv git
```


## USB performance note

Since this is USB-based, expect:

- **Reads:** Fine (~100-300MB/s)
- **Writes:** Noticeable lag (compiling, model downloads, game saves)
- **Perfect for testing**, but internal SSD would feel snappier long-term.

What do you want to fire up first—Thunderbird import, Steam benchmark to validate gaming, or ComfyUI skeleton? Or just poke around the COSMIC desktop feel?

---

# nvidia is 580+ seems ok. By the by the install to usb failed I'm running on an ssd now, not happy with that but at least it's working. Thanks for the install lines will pick that up later ... but first resizing the main partition is allowed to 44GB I take it that is the minimum for the rest of pop os to function ? It's already gobbling up 8GB with the recovery and swap

NVIDIA 580+ driver series is excellent for RTX 5060—great CUDA 12.x support for your AI workloads ahead.

Glad the SSD install worked (USB persistence can be finicky long-term anyway). On resizing:

## Pop!_OS partition minimums

**44GB showing as resizable** means your **root (/) partition** can shrink/grow. That's **not** a hard minimum for "OS function"—it's just the *current used space*. Pop!_OS absolute minimums are much smaller:

```
EFI:      1GB   (fixed, don't touch)  
Recovery: 4GB   (fixed, safety net)  
Root (/): ~10GB (absolute min, grows with apps)  
Swap:     4GB   (can shrink to 2GB or zram)  
```

**Fresh install reality:** ~8GB total used (your observation). After Steam + ComfyUI + models, root will hit 20-30GB easily.

## Safe resizing now

**Yes, shrink root to 44GB** if you want space for /home or other partitions:

```
# Boot live USB → GParted (pre-installed on Pop!_OS live)  
1. Right-click root partition → Resize/Move  
2. Shrink to 44GB (or whatever) → Apply  
3. Expand /home or add data partition in freed space  
4. Reboot → good to go
```

**Future-proof tip:** Leave root at 60-80GB, put games/models on separate /home or data partition.

## Your next moves

```
# Thunderbird
sudo apt update && sudo apt install thunderbird

# Verify space
df -h /
lsblk -f

# NVIDIA + CUDA check (AI-ready)
nvidia-smi
nvcc --version  # If CUDA toolkit present
```

SSD + NVIDIA 580 + Pop!_OS = perfect testbed. Hit me when you're resized and want ComfyUI install steps!
<span style="display:none">[^13_1][^13_2][^13_3][^13_4][^13_5][^13_6][^13_7][^13_8][^13_9]</span>

<div align="center">⁂</div>

[^13_1]: https://www.reddit.com/r/pop_os/comments/lp4bjq/comment/go9bb5m/

[^13_2]: https://www.reddit.com/r/pop_os/comments/lp4bjq/how_much_space_is_required_for_pop_os_to_run/

[^13_3]: https://www.reddit.com/r/pop_os/comments/q8lksd/is_8gb_ram_and_500gb_of_storage_enough_for_pop_os/

[^13_4]: https://www.reddit.com/r/linux4noobs/comments/jjkrtq/what_sizes_should_the_popos_partitions_be/

[^13_5]: https://www.reddit.com/r/pop_os/comments/p77u74/how_much_storage_does_a_fresh_install_of_pop_os/

[^13_6]: https://www.reddit.com/r/pop_os/comments/1osu172/how_much_space_do_i_need/

[^13_7]: https://support.system76.com/articles/install-in-vm/

[^13_8]: https://pop-os.github.io/docs/getting-started/installation/installation.html

[^13_9]: https://www.facebook.com/groups/poposlinux/posts/7885381271574159/


---

# What is the effect of resizing this : 'Swap:     4GB   (can shrink to 2GB or zram)' to 2GB?

Shrinking Pop!_OS's 4GB swap partition to 2GB is safe and has minimal downsides for most use cases, especially with your RTX 5060 desktop setup.

## Effects of 4GB → 2GB swap

**What changes:**

- **RAM overflow buffer:** Halves from 4GB to 2GB. With modern desktops (likely 16-32GB+ RAM), swap rarely gets touched anyway unless running massive AI models that exceed VRAM+RAM.
- **Hibernation:** Breaks full-system hibernation (needs swap ≥ RAM size). But you probably don't hibernate a desktop gaming/AI rig.
- **ZRAM fallback:** Pop!_OS uses compressed RAM-based swap (zram) alongside partition swap. Shrinking partition swap just leans more on zram, which is faster anyway.

**No impact on:**

- Boot time, daily desktop use, gaming, ComfyUI (GPU-bound), NVIDIA drivers
- System stability—Linux handles low swap gracefully


## Your situation specifically

**RTX 5060 AI/gaming desktop → 2GB swap is fine:**

```
Gaming:     Steam/Proton → GPU+16GB RAM → rarely hits swap
ComfyUI:    Models load to 16GB VRAM → minimal system RAM use
Daily:      Browser+Thunderbird → <4GB RAM total
```


## How to do it safely

**From live USB (required—can't resize mounted swap):**

```
1. Boot Pop!_OS live USB 
2. GParted → right-click swap → Resize → 2GB
3. Apply → update /etc/fstab + GRUB (GParted usually handles)
4. Reboot to SSD
```

**Or easier: disable partition swap, rely on zram**

```
sudo swapoff /dev/sdX  # X = your swap partition
sudo systemctl disable --now systemd-swapfile
```

(2GB zram auto-configured, no partitioning needed)

## Recommendation

**Leave at 4GB for now.** Your AI models/games might surprise you with RAM spikes, and 4GB costs almost nothing. Revisit after you've stress-tested ComfyUI + Steam.

**Priority order now:**

1. `sudo apt update && sudo apt install thunderbird`
2. Test `nvidia-smi` + CUDA sample
3. Steam benchmark (confirms gaming perf)
4. ComfyUI setup

SSD + NVIDIA 580 + Pop!_OS = you're in prime position. Partition tweaking can wait!
<span style="display:none">[^14_1][^14_10][^14_2][^14_3][^14_4][^14_5][^14_6][^14_7][^14_8][^14_9]</span>

<div align="center">⁂</div>

[^14_1]: https://www.reddit.com/r/pop_os/comments/qioaip/how_to_increase_swap_filepartition_in_popos_2004/

[^14_2]: https://www.reddit.com/r/pop_os/comments/j0jrvm/need_help_understanding_resizing_partitions_for/

[^14_3]: https://www.reddit.com/r/linuxquestions/comments/133ak8k/resizing_swap_partition_in_pop_os_is_it_safe/

[^14_4]: https://github.com/pop-os/pop/issues/2758

[^14_5]: https://dev.to/fabiosleal/how-to-create-separate-partitions-for-boot-home-and-swap-on-popos-10lg

[^14_6]: https://www.reddit.com/r/pop_os/comments/z8nyzr/increase_swap_partition_on_encrypted_installation/

[^14_7]: https://www.reddit.com/r/pop_os/comments/boif6q/swap_size_recommendation/

[^14_8]: https://www.reddit.com/r/pop_os/comments/ibwk8x/how_to_resizemove_partition_in_pop_os/

[^14_9]: https://www.reddit.com/r/pop_os/comments/d1a72g/unable_to_resize_efi_partition_for_pop_os/

[^14_10]: https://www.facebook.com/groups/poposlinux/posts/3039116726200662/?locale=zh_CN


---

# And the recovery of 4GB what is it there fore and can it be shrunk?

Shrinking the 4GB recovery partition is **possible but not recommended**—it's tightly optimized and serves critical safety functions.

## Recovery partition purpose (detailed)

The 4GB FAT32 recovery partition contains a **complete Pop!_OS live environment**—essentially a full installer image baked onto your SSD. Key uses:[^15_9]

- **Reinstall/repair without USB:** Boot into recovery → refresh OS, fix GRUB, repair filesystems, reinstall NVIDIA drivers
- **Factory reset:** Clean install option (wipes root but keeps /home if separate)
- **Driver recovery:** Critical for NVIDIA experimentation gone wrong (your RTX 5060 AI/gaming use case)
- **Offline updates:** Can download patches even if main OS won't boot

**Access:** GRUB boot menu → Advanced → Recovery, or `recovery.target` kernel parameter.

## Shrinking effects (2GB or less)

**Works technically** (minimum ~3.5-4GB for full live image), but:

```
✅ Still boots recovery mode
✅ Refresh/repair functions
❌ Clean install may fail (installer image truncated)
❌ Future pop-upgrade recovery updates break
❌ Less buffer for driver snapshots
```

**Real-world:** Users report 3.5GB works, but System76 sizes it 4GB for safety + breathing room.

## Recommendation for your setup

**Leave 4GB untouched.** With your AI/RTX 5060/gaming stack, this is your "oh shit" button when:

- CUDA experiments brick display
- Steam/Proton breaks kernel modules
- ComfyUI model loads corrupt VRAM

**Better space strategy:**

```
Root (/):   60GB  (OS + apps + ComfyUI)
Home:      100GB+ (models, games, Thunderbird data)  
Swap:        4GB  (or zram)
Recovery:   4GB  (safety)
```


## Current action plan

```
# You're SSD + NVIDIA 580 ready. Next:
sudo apt update && sudo apt install thunderbird steam

# Space check
df -h /home
```

**Skip partition surgery.** Test your workflows first—4GB recovery could save your bacon during ComfyUI tuning. Ready for Thunderbird setup or Steam benchmark?
<span style="display:none">[^15_1][^15_10][^15_2][^15_3][^15_4][^15_5][^15_6][^15_7][^15_8]</span>

<div align="center">⁂</div>

[^15_1]: https://www.zaccariotto.net/post/pop_os-recovery-partition/

[^15_2]: https://www.reddit.com/r/pop_os/comments/174xw4u/what_is_this_4gb_fat32_partition_created_on/

[^15_3]: https://www.reddit.com/r/pop_os/comments/191uu5s/can_you_and_or_should_you_create_recovery/

[^15_4]: https://www.youtube.com/watch?v=gNvPX_O5IJY

[^15_5]: https://www.reddit.com/r/pop_os/comments/z5cefo/i_did_a_fresh_install_of_pop_os_and_there_is_no/

[^15_6]: https://www.reddit.com/r/linux/comments/10v2rld/a_recovery_partition_would_be_a_godsend_for_most/

[^15_7]: https://www.reddit.com/r/pop_os/comments/m6ljkq/i_have_no_recovery_partition/

[^15_8]: https://discussion.fedoraproject.org/t/ideas-from-other-projects-recovery-partition-pop-os/118208

[^15_9]: https://support.system76.com/articles/pop-recovery/

[^15_10]: https://www.facebook.com/groups/poposlinux/posts/4059806254131699/


---

# Ok will leave the 4GB partitons for what they are now. The  main partition can not be resized something about disk busy ah of course start up live session and then resize ok ... done main partition now 64GB rest of drive nfts ... ehrrr changing the password and if possible auto login at startup doable?

Smart move resizing from live session—mounted filesystems can't shrink. 64GB root + NTFS data partition looks solid.

## Changing password

**Terminal method (fastest):**

```
passwd
```

Enter current password → new password twice. Done instantly, syncs across login/sudo.[^16_1][^16_2]

**GUI method:** Settings → Users → unlock → Password field.

## Auto-login at startup

Pop!_OS (COSMIC/GNOME) enables this easily:

**GUI (easiest):**

1. Log out → login screen
2. Gear icon (bottom right) → "Turn on Auto Login"
3. Enter password once → next boots skip it

**Or terminal:**

```
sudo nano /etc/gdm3/custom.conf
```

Uncomment/add under `[daemon]`:

```
AutomaticLoginEnable=true
AutomaticLogin=username
```

Save → `sudo systemctl restart gdm3`

**Security note:** Auto-login fine for desktop/personal rig. Disable before sharing/giving away.

## Your setup now rocking:

```
✅ SSD install success  
✅ NVIDIA 580 drivers (RTX 5060)  
✅ 64GB root partition  
✅ 4GB recovery/swap safety nets  
✅ NTFS data partition ready
```

**Next up:**

```
sudo apt update && sudo apt install thunderbird
```

Then `nvidia-smi` to confirm CUDA-ready for ComfyUI.

Password/auto-login done → what workflow test first?
<span style="display:none">[^16_3][^16_4][^16_5][^16_6][^16_7][^16_8]</span>

<div align="center">⁂</div>

[^16_1]: https://www.reddit.com/r/pop_os/comments/12wpegq/how_do_i_change_my_disk_encryption_password_pop/

[^16_2]: https://nordpass.com/blog/how-to-change-password-linux/

[^16_3]: https://www.reddit.com/r/pop_os/comments/evih54/how_do_i_reset_my_root_password/

[^16_4]: https://support.system76.com/articles/password/

[^16_5]: https://www.reddit.com/r/pop_os/comments/lfkc0o/i_have_forgotten_my_user_password/

[^16_6]: https://www.reddit.com/r/pop_os/comments/zkdlea/admin_password_reset/

[^16_7]: https://forum.proxmox.com/threads/reset-root-password-systemd.99468/

[^16_8]: https://www.facebook.com/groups/poposlinux/posts/4559908514121468/


---

# gear icon > 'cosmic' no auto login ... /gdm3/ not there ... by the by surprisingly thunderbird is already installed seems to be bundled with pop-os_24.04_amd64_nvidia_23 ... why oh why is filemanager not showing os files or folders?

Nice, partition resize success and Thunderbird pre-bundled in Pop!_OS 24.04 NVIDIA ISO (handy dev/gaming focus). COSMIC desktop explains the quirks.

## File manager not showing OS files/folders

**Quick fixes:**

```
# Show all files (including system ones)
Super (Win key) → Files → hamburger menu (⋮⋮⋮) → Preferences → Views → Show Hidden Files ✓

# Or terminal jump straight there
cd /  
nautilus /
```

If still empty/weird: `sudo apt install --reinstall gvfs` (file indexer).

## COSMIC auto-login (Pop!_OS 24.04 specific)

No gear icon/gdm3—COSMIC uses **greetd + cosmic-greeter**. Edit this file:

```
sudo nano /etc/greetd/cosmic-greeter.toml
```

**Add/replace at bottom:**

```toml
[terminal]
vt = "1"

[general]
service = "login"

[default_session]
command = "cosmic-comp -t-greeter cosmic-greeter"
user = "cosmic-greeter"

[initial_session]
command = "cosmic-session"
user = "YOUR_USERNAME_HERE"
```

**Replace `YOUR_USERNAME_HERE`** with your actual username (`whoami` to check).

**Save + reboot:**

```
Ctrl+O → Enter → Ctrl+X
sudo reboot
```


## Password change (still works)

```
passwd
```

Current → new → new.

## Your golden setup now:

```
✅ SSD 64GB root + NTFS data  
✅ NVIDIA 580 RTX 5060  
✅ Thunderbird ready  
✅ Partitions solid
```

COSMIC auto-login tweak + file manager fix → test Steam/`nvidia-smi` next? Hit me with results!
<span style="display:none">[^17_1][^17_10][^17_2][^17_3][^17_4][^17_5][^17_6][^17_7][^17_8][^17_9]</span>

<div align="center">⁂</div>

[^17_1]: https://ubuntuhandbook.org/index.php/2024/05/enable-automatic-login-in-ubuntu-24-04-flavors/

[^17_2]: https://www.reddit.com/r/pop_os/comments/1q5vf57/auto_login_on_2404/

[^17_3]: https://github.com/pop-os/cosmic-greeter/issues/80

[^17_4]: https://www.reddit.com/r/pop_os/comments/1pk82cz/restoring_xfce_autologin_after_the_pop_os_version/

[^17_5]: https://techpiezo.com/ubuntu/ubuntu-24-04-login-a-guide-to-enabling-and-disabling-automatic-login/

[^17_6]: https://help.gnome.org/system-admin-guide/login-automatic.html

[^17_7]: https://www.reddit.com/r/pop_os/comments/1hfe6kh/auto_profile_login_on_2404lts/

[^17_8]: https://support.system76.com/articles/pop-basics/

[^17_9]: https://www.reddit.com/r/pop_os/comments/vsz5or/how_do_i_automatically_login/

[^17_10]: https://www.reddit.com/r/pop_os/comments/1pli881/how_do_i_auto_login/nttfrzq/


---

# Hmm the last two are bit tougher to crack but no worries I'll pick that up tomorrow. For now many thanks for shepherding me through the first baby steps in linux land much appreciated.

You're welcome! Glad I could help you navigate those first Linux steps—Pop!_OS 24.04 NVIDIA on SSD with RTX 5060 is a solid foundation for your AI/gaming/dev workflow.

## Quick wins for tomorrow

**File manager fix (99% chance):**

```
Super → Files → ⋮⋮⋮ menu → Preferences → Views → "Show Hidden Files" ✓
```

Or `nautilus /` jumps to root instantly.

**COSMIC auto-login (bookmark this):**

```
sudo nano /etc/greetd/cosmic-greeter.toml
```

Add `user = "yourusername"` under `[initial_session]` → `sudo reboot`.

## Your setup is prime:

```
✅ SSD + NVIDIA 580 + 64GB root  
✅ Thunderbird ready, partitions solid  
✅ Ready for Steam, ComfyUI, FreeBASIC  
```

**Next day priorities:**

1. File manager tweak
2. Auto-login config
3. `sudo apt install steam` → gaming benchmark
4. `nvidia-smi` → CUDA check for ComfyUI

Sleep well—you've conquered the hard part! Ping me tomorrow for ComfyUI setup or any COSMIC quirks. 🚀

