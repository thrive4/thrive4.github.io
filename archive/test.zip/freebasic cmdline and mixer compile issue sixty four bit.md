The short version: **your warnings come from 64‑bit pointer size differences in the WinMM mixer API declarations shipped with FreeBASIC**, not from `hMixer` itself. In 32‑bit the WinMM headers match the Windows API exactly; in 64‑bit some structures and parameters are declared with the wrong pointer types, so FB warns when you pass them.

## 🧩 What the warning actually means

The warning:

> Passing different pointer types, at parameter 1 of MIXERGETLINECONTROLS()

means that the FB declaration of:

```
mixerGetLineControls( hmx As HMIXEROBJ, pmxlc As LPMIXERLINECONTROLS, fdwControls As DWORD )
```

expects **HMIXEROBJ**, but you are passing **HMIXER**.

On 32‑bit Windows:

-   `HMIXER` = `HANDLE` = 32‑bit
    
-   `HMIXEROBJ` = `HANDLE` = 32‑bit → They are identical, so no warning.
    

On 64‑bit Windows:

-   `HMIXER` = 64‑bit pointer
    
-   `HMIXEROBJ` = 64‑bit pointer → They _should_ still be identical, **but FreeBASIC’s winmm.bi declares them differently**, so FB thinks you are passing the wrong pointer type.
    

This is a **header mismatch**, not a bug in your code.

## 🔍 The real culprit: FreeBASIC’s winmm.bi

In current FB versions, the mixer API declarations are not fully 64‑bit‑clean. Specifically:

-   `HMIXER` is declared as one type
    
-   `HMIXEROBJ` is declared as another
    
-   Some structures use `Integer` instead of `Long` or `LongPtr`
    
-   Some pointers inside `MIXERCONTROLDETAILS` and `MIXERLINECONTROLS` are declared incorrectly for 64‑bit
    

So when you do:

```
mixerGetLineControls(hMixer, @mxlc, MIXER_GETLINECONTROLSF_ONEBYTYPE)
```

FB sees:

-   parameter 1 expects `HMIXEROBJ`
    
-   you pass `HMIXER`
    

→ Warning.

Same for `mixerGetControlDetails()` and `mixerSetControlDetails()`.

## ✔️ How to fix it cleanly

### Option 1 — Cast the handle (safe)

```
mixerGetLineControls( cast(HMIXEROBJ, hMixer), @mxlc, MIXER_GETLINECONTROLSF_ONEBYTYPE )
mixerGetControlDetails( cast(HMIXEROBJ, hMixer), @mxcd, MIXER_GETCONTROLDETAILSF_VALUE )
mixerSetControlDetails( cast(HMIXEROBJ, hMixer), @mxcd, MIXER_SETCONTROLDETAILSF_VALUE )
```

This removes the warnings and is safe because `HMIXEROBJ` **is just a typedef of HANDLE** in the real Windows API.

### Option 2 — Patch winmm.bi (best long‑term fix)

Change the declarations so both types match:

```
type HMIXEROBJ as HANDLE
type HMIXER as HANDLE
```

And ensure all mixer structures use `LongPtr` for pointers.

This makes the FB headers match the real WinAPI.

### Option 3 — Use the modern Core Audio API

The WinMM mixer API is **deprecated**. If you want to avoid these issues entirely, switch to WASAPI / IAudioEndpointVolume.

You can ask me to generate a FreeBASIC example via **WASAPI volume example** or **IAudioEndpointVolume**.

## 🧠 Why hMixer is not the problem

Your `hMixer` variable is fine:

The issue is simply that FB thinks `HMIXER` ≠ `HMIXEROBJ` in 64‑bit, even though Windows treats them identically.

## If you want, I can inspect your winmm.bi

If you paste the relevant part of your **winmm.bi**, I can tell you exactly which declarations are wrong and provide corrected ones:

-   **Inspect winmm.bi**
    

Or if you want a fully corrected mixer header:

-   **Provide fixed mixer declarations**