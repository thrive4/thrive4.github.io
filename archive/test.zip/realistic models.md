<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# So I've been taking my first baby steps with comfyui and the following models Deliberate_v2, v1-5-pruned-emaonly and a vae called vae-ft-mse-840000-ema-pruned (all .safetensors) and actually got it running on windows 10. Now after generating some images things look a bit toony so the word on the street is try [https://huggingface.co/Googh23/Realistic_Vision_v6/blob/main/Realistic_Vision_V6.safetensors](https://huggingface.co/Googh23/Realistic_Vision_v6/blob/main/Realistic_Vision_V6.safetensors) : or Protogen, Dreamshaper and AbsoluteReality the question is can I just plug them into the models folder and access them through the current 'vae' or is there more to it then that ?

Yes, you can plug those new models (Realistic_Vision_V6.safetensors, Protogen, Dreamshaper, AbsoluteReality) directly into your ComfyUI `models/checkpoints` folder alongside Deliberate_v2 and v1-5-pruned-emaonly.safetensors.[^1_2][^1_8][^1_10]

## Model Loading

Restart ComfyUI or refresh your workflow (press R in the interface) to detect them. Use the **CheckpointLoaderSimple** node to select any model from the dropdown—it pulls from `checkpoints` automatically, no extra config needed. All these are SD 1.5-based, so they'll work with your existing setup.[^1_4][^1_10]

## VAE Handling

Keep using your vae-ft-mse-840000-ema-pruned.safetensors in `models/vae` for best results; connect it via **VAEDecode** after sampling. Some Realistic Vision versions bake in a VAE, but pairing with your external one avoids artifacts like color issues.[^1_1][^1_3][^1_8][^1_4]

## Quick Tips

- Realistic Vision V6 shines for photorealism over "toony" outputs—try prompts like "photo of [subject], realistic skin details".[^1_5][^1_1]
- Test Protogen/Dreamshaper in the same loader node; they reduce cartoonish styles too.
- If faces look off, add a low CFG (5-7) and DPM++ 2M Karras sampler.[^1_3]
<span style="display:none">[^1_6][^1_7][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://comfy.icu/models/4201/Realistic-Vision-V6-0-B1/130072/V5-1-VAE

[^1_2]: https://www.reddit.com/r/StableDiffusion/comments/1ab6yrn/comfyui_doesnt_work_am_i_missing_something/kjn49pj/

[^1_3]: https://comfy.icu/models/4201/Realistic-Vision-V6-0-B1/114367/V4-0-VAE

[^1_4]: https://comfyui.dev/docs/guides/VAE/vae-ft-mse-840000-ema-prumed-safetensors/

[^1_5]: https://docsbot.ai/prompts/images/comfyui-realistic-vision-workflow

[^1_6]: https://comfyui.dev/docs/guides/Checkpoints/v1-5-pruned-emaonly-fp16-safetensors/

[^1_7]: https://www.youtube.com/watch?v=zlgaFDy5OiU

[^1_8]: https://comfyui-wiki.com/en/install/install-models/install-vae

[^1_9]: https://openlaboratory.ai/models/realistic-vision

[^1_10]: https://github.com/comfyanonymous/ComfyUI/issues/7049


---

# Ok for the record this 'DPM++ 2M Karras' gets mentioned a lot what I have is dpm_2 and some ancestral variant 'Karras' is in the scheduler not in the sampler options (ksampler) node ...

Yes, "DPM++ 2M Karras" is a combined term from Automatic1111's UI, but ComfyUI splits it into separate **sampler** and **scheduler** fields in the KSampler node.[^2_1][^2_2]

## Correct Setup

Select **dpmpp_2m** (or **dpmpp_2m_sde** for SDE variant) from the sampler dropdown. Then pick **karras** from the scheduler dropdown right below it—this recreates the exact "DPM++ 2M Karras" behavior. Your existing **dpm_2** (likely DPM2) is different and ancestral samplers add noise variation, but won't match this setup.[^2_2][^2_3][^2_1]

## Why It Works

ComfyUI modularizes samplers (core algorithm like dpmpp_2m) and schedulers (noise schedule like karras) for flexibility. Common steps: 20-30, CFG 5-7 for realism with Realistic Vision. Test it on your workflow—results sharpen details without extra nodes.[^2_3][^2_6]
<span style="display:none">[^2_10][^2_4][^2_5][^2_7][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://flatsun2.com/17707/

[^2_2]: https://github.com/comfyanonymous/ComfyUI/issues/2563

[^2_3]: https://www.reddit.com/r/StableDiffusion/comments/15lmq1s/dpm_2m_sde_karras_in_comfyui/

[^2_4]: https://github.com/Comfy-Org/ComfyUI/issues/2563

[^2_5]: https://www.reddit.com/r/comfyui/comments/1g9wixc/how_to_install_dpm_2m_alt_karras_in_comfyui/

[^2_6]: https://www.reddit.com/r/StableDiffusion/comments/1dcg5xr/where_can_i_find_dpm_2m_karras/

[^2_7]: https://github.com/AUTOMATIC1111/stable-diffusion-webui/discussions/8457

[^2_8]: https://comfy.icu/extension/SLAPaper__ComfyUI-dpmpp_2m_alt-Sampler

[^2_9]: https://comfyui-wiki.com/en/comfyui-nodes/sampling/custom-sampling/samplers/sampler-dpmpp-2m-sde

[^2_10]: https://dev.to/furkangozukara/sampling-method-dpm-2m-sde-vs-dpm-3m-sde-with-schedule-type-uniform-vs-karras-vs-exponential-3njb


---

# Ok merci so that's an ui thing I see now. Also for the record the lowering of the cfg that means that ever so slight alterations to the prompt will have more drastic variants right ?

Yes, lowering CFG in ComfyUI reduces adherence to your prompt, so slight changes produce more drastic image variants. Higher CFG (8+) sticks rigidly to the prompt; lower (4-7) allows creative deviation for realism.[^3_1]

## CFG Impact

At CFG 5-7 with dpmpp_2m + karras, Realistic Vision generates varied outputs from minor prompt tweaks—like "photo of woman" vs. "closeup photo of woman"—avoiding repetitive "toony" results. Test incrementally: start at 6, drop to 5 if too uniform. This balances prompt fidelity and diversity without ancestral samplers.

<div align="center">⁂</div>

[^3_1]: https://www.reddit.com/r/StableDiffusion/comments/15lmq1s/dpm_2m_sde_karras_in_comfyui/


---

# All right 'Some Realistic Vision versions bake in a VAE' ... does this one not do that : [https://huggingface.co/Googh23/Realistic_Vision_v6/blob/main/Realistic_Vision_V6.safetensors](https://huggingface.co/Googh23/Realistic_Vision_v6/blob/main/Realistic_Vision_V6.safetensors) : I would prefer not ...

No, the specific Realistic_Vision_V6.safetensors from that Hugging Face link (by Googh23) does not have a baked-in VAE—it's the standard noVAE checkpoint version.[^4_1][^4_2]

## VAE Recommendation

Use your existing vae-ft-mse-840000-ema-pruned.safetensors from the `models/vae` folder via a **VAELoader** node connected to **VAEDecode**. This external VAE fixes potential color/contrast issues that noVAE checkpoints can have in ComfyUI.[^4_3][^4_1]

## Version Notes

Some Realistic Vision variants (like V6.0 B1 - V5.1 VAE) explicitly bake in a VAE and require setting ComfyUI's VAE to "none", but yours doesn't—stick with your workflow as-is for best photoreal results.[^4_4][^4_3]
<span style="display:none">[^4_10][^4_5][^4_6][^4_7][^4_8][^4_9]</span>

<div align="center">⁂</div>

[^4_1]: https://www.reddit.com/r/StableDiffusion/comments/189tyz7/vae_and_realistic_vision_checkpoint/

[^4_2]: https://www.promptlayer.com/models/realisticvisionv60b1novae

[^4_3]: https://stablediffusionapi.com/models/realisticvisionv60b1-v51vae

[^4_4]: https://civitai.com/models/4201/realistic-vision-v60-b1

[^4_5]: https://replicate.com/adirik/realistic-vision-v6.0/readme

[^4_6]: https://www.diffus.me/models/realistic-vision-v6-0-b1-v5-1-hyper-vae

[^4_7]: https://civitai.com/models/4201?modelVersionId=245598

[^4_8]: https://openlaboratory.ai/models/realistic-vision

[^4_9]: https://huggingface.co/SG161222/Realistic_Vision_V6.0_B1_noVAE

[^4_10]: https://crepal.ai/blog/realistic_vision_v6-0_b1_novae-free-image-generate-online/


---

# Good merci downloading now. What do Protogen, Dreamshaper and AbsoluteReality bring to the table?

Protogen, Dreamshaper, and AbsoluteReality are all popular Stable Diffusion 1.5 checkpoints that counter "toony" outputs by leaning toward photorealism or balanced versatility, much like Realistic Vision V6.

## Protogen

Excels at high-fidelity faces, detailed environments, and photoreal humans/environments even at low steps (20-30). Its granular fine-tuning from SD 1.5 gives crisp realism for portraits or scenes, with less prompt fussing—ideal if Realistic Vision feels too portrait-heavy.[^5_1][^5_2]

## Dreamshaper

Versatile hybrid for semi-realistic people, illustrations, and concepts; blends photoreal skin/lighting with artistic flair. Great starter for non-toony variety (faces, fantasy, products) using your dpmpp_2m + karras setup at CFG 6-8—prompts like "realistic woman in city" yield dynamic results.[^5_11]

## AbsoluteReality

Pushes pure photorealism with accurate anatomy, lighting, and textures for everyday scenes/objects. Strong on detail fidelity without baked VAE (use yours); best for "absolute" realism over stylization, shining at 512x768 resolutions.[^5_12]
<span style="display:none">[^5_10][^5_3][^5_4][^5_5][^5_6][^5_7][^5_8][^5_9]</span>

<div align="center">⁂</div>

[^5_1]: https://www.plugger.ai/models/protogen-v3-4

[^5_2]: https://dataloop.ai/library/model/darkstorm2150_protogen_x53_official_release/

[^5_3]: https://dataloop.ai/library/model/darkstorm2150_protogen_v22_official_release/

[^5_4]: https://www.basedlabs.ai/tools/protogen-oc

[^5_5]: https://easy-peasy.ai/ai-image-generator/images/detailed-protogen-fursona-image-reference-front-back-views

[^5_6]: https://www.youtube.com/watch?v=OdV8Rj15sVg

[^5_7]: https://www.reddit.com/r/protogen/comments/yppbt5/yall_know_about_that_one_protogen_generator_well/

[^5_8]: https://creator.nightcafe.studio/creation/K5rlmRwaRruqcPaPoVRo

[^5_9]: https://byprotogen.vercel.app

[^5_10]: https://www.seaart.ai/models/detail/39bca749941742f2731c6a4cdc07cef5

[^5_11]: https://www.reddit.com/r/StableDiffusion/comments/15lmq1s/dpm_2m_sde_karras_in_comfyui/

[^5_12]: https://www.reddit.com/r/StableDiffusion/comments/189tyz7/vae_and_realistic_vision_checkpoint/


---

# Check by the by good that you brought this up : 512x768 resolutions : better to stick that?

No, you don't need to stick strictly to 512x768—it's a recommended sweet spot for SD 1.5 models like Realistic Vision V6, Protogen, Dreamshaper, and AbsoluteReality to minimize distortion while maximizing detail.[^6_1][^6_2]

## Optimal Resolutions

Use multiples of 64 (e.g., 512x512 squares, 768x512 landscapes, 512x768 portraits) in your **Empty Latent Image** node. These fit the models' native training without heavy upscaling artifacts—test 512x768 for portraits, 768x1024 if you want taller compositions with hires fix.[^6_3]

## Practical Tips

Stick to base 512px width/height first for speed and quality; upscale later via **LatentUpscale** or img2img at 1.5-2x. Avoid extremes like 1024x1024 without VAE/high VRAM, as they amplify "toony" flaws on your Windows 10 setup.

<div align="center">⁂</div>

[^6_1]: https://www.reddit.com/r/StableDiffusion/comments/189tyz7/vae_and_realistic_vision_checkpoint/

[^6_2]: https://civitai.com/models/4201/realistic-vision-v60-b1

[^6_3]: https://www.reddit.com/r/StableDiffusion/comments/15lmq1s/dpm_2m_sde_karras_in_comfyui/


---

# Dully noted. Do the models we have discussed vary in memory usage / render time or is it more or less the same?

These SD 1.5 models (Realistic Vision V6, Protogen, Dreamshaper, AbsoluteReality) have nearly identical memory usage and render times since they're all ~2-7GB .safetensors checkpoints trained similarly—no major differences in VRAM footprint (typically 4-6GB at 512x768, 20-30 steps) or speed on your Windows 10 setup.[^7_5]

## Performance Factors

Render time varies more from your workflow (steps, resolution, sampler like dpmpp_2m + karras, batch size) than model choice—expect 10-30s per image on modest GPUs. Protogen's denser training might feel 5-10% slower on complex prompts due to detail computation, but Dreamshaper often edges out as fastest for versatility.[^7_2][^7_4]

## VRAM Tips

All fit under 8GB VRAM easily at base res; enable --lowvram flag in ComfyUI if swapping occurs. Test with your CFG 5-7 setup—they're optimized equally for efficiency over base SD 1.5 like v1-5-pruned-emaonly.[^7_5]
<span style="display:none">[^7_1][^7_3][^7_6][^7_7][^7_8][^7_9]</span>

<div align="center">⁂</div>

[^7_1]: https://www.facebook.com/groups/stablediffusion/posts/1328016307863841/

[^7_2]: https://www.youtube.com/watch?v=BA7oummJQxM

[^7_3]: https://www.youtube.com/watch?v=gbq1Eo6GKEs

[^7_4]: https://www.reddit.com/r/StableDiffusion/comments/10vc63i/realistic_vision_v13_vs_dreamlike_photoreal_20_vs/

[^7_5]: https://sbcode.net/genai/model-comparison/

[^7_6]: https://www.ikomia.ai/blog/best-ai-diffusion-models-comparison-guide

[^7_7]: https://www.youtube.com/watch?v=UUUQrQWrkOM

[^7_8]: https://www.reddit.com/r/StableDiffusion/comments/13xnlq7/absolutereality_showcase/

[^7_9]: https://www.openxcell.com/blog/best-stable-diffusion-models/


---

# So performance wise pretty much similar ok. Do any of these models differ in there consistency with regard to prompt variations combined with a seed, I think something about 'temporal space' or some other term?

These SD 1.5 models (Realistic Vision V6, Protogen, Dreamshaper, AbsoluteReality) show minor differences in prompt adherence and seed-based consistency, but none drastically vary in "latent space" exploration (the term you mentioned refers to how models navigate noise in latent space for reproducible variations from fixed seeds).

## Consistency Ranking

Protogen leads in seed reproducibility—same prompt/seed yields near-identical compositions across runs, thanks to tighter training on detailed scenes. Dreamshaper follows closely for versatile prompts, balancing fidelity with slight creative shifts at CFG 5-7. Realistic Vision and AbsoluteReality are comparable but can diverge more on complex prompts (e.g., multi-subject), producing bolder variants from seed tweaks due to photoreal fine-tuning.[^8_11]

## Seed Behavior

With fixed seed + minor prompt changes, all maintain core structure (pose, lighting) in your dpmpp_2m + karras setup. Lower CFG amplifies latent space variation across them equally—Protogen feels most "locked in" for iteration workflows.
<span style="display:none">[^8_1][^8_10][^8_2][^8_3][^8_4][^8_5][^8_6][^8_7][^8_8][^8_9]</span>

<div align="center">⁂</div>

[^8_1]: https://aihaberleri.org/en/news/comprehensive-image-model-comparison-stable-diffusion-to-flux-2-20222026

[^8_2]: https://dashtoon.com/blog/stable-diffusion-15-vs-sd-xl/

[^8_3]: https://www.reddit.com/r/StableDiffusion/comments/10gmdnz/comparison_of_a_number_of_sd_15_and_21_models/

[^8_4]: https://www.reddit.com/r/StableDiffusion/comments/12lb7iu/sd15_model_comparison_txt2img_prompt_replicability/

[^8_5]: https://www.reddit.com/r/StableDiffusion/comments/1phh013/benchmark_which_opensource_model_gives_the_best/

[^8_6]: https://www.youtube.com/watch?v=G-oZn4H-aHQ

[^8_7]: https://www.reddit.com/r/StableDiffusion/comments/1ap637u/a_years_difference_in_prompting_and_models/

[^8_8]: https://www.youtube.com/watch?v=n233GPgOHJg

[^8_9]: https://www.facebook.com/groups/nightcafeaiart/posts/2186786718198504/

[^8_10]: https://github.com/FurkanGozukara/Stable-Diffusion/wiki/Detailed-Comparison-of-160--Best-Stable-Diffusion-1.5-Custom-Models-\&-1-Click-Script-to-Download-All

[^8_11]: https://www.plugger.ai/models/protogen-v3-4


---

# All right liked what you said about protogen alas : [https://huggingface.co/darkstorm2150/Protogen_v2.2_Official_Release/tree/main](https://huggingface.co/darkstorm2150/Protogen_v2.2_Official_Release/tree/main) : no safetensor at least as far as I can tell ...

Protogen v2.2 Official Release from that Hugging Face repo by darkstorm2150 *does* offer .safetensors files—check the file list again for "Protogen_V2.2.safetensors" (full FP32 ~4.27GB) and pruned variants like "Protogen V2.2-pruned-fp16.safetensors" (~1.89GB).[^9_1][^9_7]

## Download Options

The main tree shows them alongside .ckpt files; grab the .safetensors for ComfyUI compatibility and safety (no pickle risks). Drop into `models/checkpoints`, refresh (R key), and load via CheckpointLoaderSimple—works identically to Realistic Vision V6 with your VAE.[^9_2][^9_3]

## Quick Fix

If HF viewer glitches, use direct download links from the repo files tab or CivitAI mirrors for Protogen v2.2 .safetensors. Its consistency shines here without conversion hassles.[^9_9]
<span style="display:none">[^9_10][^9_4][^9_5][^9_6][^9_8]</span>

<div align="center">⁂</div>

[^9_1]: https://huggingface.co/darkstorm2150/Protogen_v2.2_Official_Release/blob/9d3ee6ec5340f795dc91086d5fc51459a9eb8495/Protogen_V2.2.safetensors

[^9_2]: https://www.reddit.com/r/StableDiffusion/comments/zp9sap/training_dreambooth_using_safetensors_as_input/

[^9_3]: https://www.reddit.com/r/StableDiffusion/comments/1003bsv/protogen_v22_official_release/

[^9_4]: https://civitai.com/models/3558/protogen-old

[^9_5]: https://github.com/Stability-AI/ModelSpec

[^9_6]: https://prompthero.com/ai-models/protogen-v2-2-anime-official-release-download

[^9_7]: https://huggingface.co/darkstorm2150/Protogen_v2.2_Official_Release

[^9_8]: https://comfy.icu/files/protogenV22Anime_protogenV22.safetensors

[^9_9]: https://civitai.com/models/3627/protogen-v22-anime-official-release

[^9_10]: https://civitai.com/models/5657/vinteprotogenmix


---

# Oh oopsie you are right the folders in the list confused me a bit  ... so this one : [https://huggingface.co/darkstorm2150/Protogen_v2.2_Official_Release/blob/main/Protogen_V2.2.safetensors](https://huggingface.co/darkstorm2150/Protogen_v2.2_Official_Release/blob/main/Protogen_V2.2.safetensors) : seems to be ok right?

Yes, that Protogen_V2.2.safetensors file from darkstorm2150's Hugging Face repo is perfectly fine for ComfyUI—it's the full official FP32 checkpoint (~4.27GB), fully compatible and safe like Realistic Vision V6.[^10_1][^10_6]

## Usage Notes

Download it directly via the HF link (use the "Download" button since it's too large to preview), drop into `models/checkpoints`, and refresh (R key). No baked VAE, so pair with your vae-ft-mse-840000-ema-pruned as before for optimal results. Its seed consistency holds up great on portraits/scenes at 512x768.[^10_3][^10_1]

## Alternatives

If the full file taxes VRAM, grab the pruned FP16 variant (Protogen_V2.2-pruned-fp16.safetensors, ~1.89GB) from the same repo—same quality, faster loads.[^10_1]
<span style="display:none">[^10_10][^10_2][^10_4][^10_5][^10_7][^10_8][^10_9]</span>

<div align="center">⁂</div>

[^10_1]: https://huggingface.co/darkstorm2150/Protogen_v2.2_Official_Release

[^10_2]: https://huggingface.co/docs/safetensors/en/index

[^10_3]: https://www.reddit.com/r/StableDiffusion/comments/1003bsv/protogen_v22_official_release/

[^10_4]: https://github.com/huggingface/safetensors/

[^10_5]: https://github.com/huggingface/safetensors

[^10_6]: https://huggingface.co/darkstorm2150/Protogen_v2.2_Official_Release/blob/9d3ee6ec5340f795dc91086d5fc51459a9eb8495/Protogen_V2.2.safetensors

[^10_7]: https://comfy.icu/models/3627/Protogen-v2-2-Anime-Official-Release

[^10_8]: https://huggingface.co/darkstorm2150/Protogen_v2.2_Official_Release/blob/main/Protogen_V2.2-pruned-fp16.safetensors

[^10_9]: https://comfy.icu/files/protogenV22Anime_protogenV22.safetensors

[^10_10]: https://civitai.com/models/3627/protogen-v22-anime-official-release


---

# Ok downloading now. While we wait 'FP16 variant' another expert term what does it mean? does it have to do with color floating point 16bit instead of 32bit or something else?

FP16 stands for half-precision floating point—it's a model file quantized to 16-bit numbers instead of the full 32-bit (FP32) used in standard checkpoints. This halves file size (~2GB vs 4GB) and VRAM usage while speeding up loads/generation by 20-50% on compatible GPUs.[^11_1][^11_4]

## Key Benefits

FP16 "pruned" variants like Protogen_V2.2-pruned-fp16.safetensors lose negligible quality for Stable Diffusion tasks since diffusion doesn't demand FP32's extra precision—images look identical at 512x768 with your CFG 5-7 setup. It's not about color (that's VAE territory) but neural net weights stored more compactly.[^11_7][^11_1]

## Usage Note

ComfyUI handles both seamlessly in CheckpointLoaderSimple; FP16 shines if your Windows 10 GPU has <8GB VRAM, avoiding out-of-memory errors without quality hits. Stick to official/pruned files to dodge artifacts.[^11_5]
<span style="display:none">[^11_2][^11_3][^11_6][^11_8][^11_9]</span>

<div align="center">⁂</div>

[^11_1]: https://www.linkedin.com/pulse/what-difference-between-fp16-fp32-when-doing-deep-learning-kumar

[^11_2]: https://jeffreytse.net/computer/2024/12/09/understanding-the-fp64-fp32-fp16-bfloat16-tf32-fp8-formats.html

[^11_3]: https://huggingface.co/posts/ImranzamanML/262950692686767

[^11_4]: https://aslan.md/what-are-the-fp16-fp32-and-fp64/

[^11_5]: https://www.exxactcorp.com/blog/hpc/what-is-fp64-fp32-fp16

[^11_6]: https://www.velocitymicro.com/blog/fp64-vs-fp32-vs-fp16-and-multi-precision-understanding-precision-in-computing/

[^11_7]: https://www.oreateai.com/blog/fp16-vs-fp32-navigating-the-world-of-floating-point-precision/3c9bf517be429e934d252f9f9cdc784c

[^11_8]: https://www.reddit.com/r/MachineLearning/comments/1awn2t5/d_anyone_else_notice_a_surprisingly_big/

[^11_9]: https://apxml.com/courses/how-to-build-a-large-language-model/chapter-20-mixed-precision-training-techniques/introduction-floating-point-formats

