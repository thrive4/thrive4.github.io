<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Ok duly noted here ... man walk over mountain trip over pebble ... also the rsync issue that is why /mnt/nvme_home/ is empty and /home ended up in /mnt/recycle/home ?

Yes—that’s exactly what happened.

You didn’t lose anything; you just copied it one level too deep.

### What your command did

You ran:

- `rsync -av /home/ /mnt/nvme_home/home/`

So rsync created this structure:

- `/mnt/nvme_home/home/wah/...`

Then separately, your system already had:

- `/mnt/recycle` mounted from the same partition

So effectively:

- `/mnt/nvme_home` and `/mnt/recycle` point to the **same filesystem**
- and inside it, you now have a directory called `home`

That’s why:

- `/mnt/nvme_home/` looked “empty” (it only contains `home/`)
- and `/mnt/recycle/home` contains your actual data


### Quick sanity check

Run either of these:

- `ls /mnt/nvme_home`
- `ls /mnt/recycle`

You should see:

- `home`

And then:

- `ls /mnt/recycle/home/wah`


### Why this happened (simple rule)

With rsync:

- `rsync /source/ /target/` → copies *contents* into target
- `rsync /source/ /target/source/` → creates an extra directory layer

So you accidentally created:

- `/home → /home/home`

***

### How to fix it (no need to re-copy)

From your running system:

1. Make sure the partition is mounted (either path is fine):
    - `/mnt/nvme_home` **or** `/mnt/recycle`
2. Move contents up one level:
    - `sudo mv /mnt/recycle/home/* /mnt/recycle/`
    - `sudo mv /mnt/recycle/home/.* /mnt/recycle/ 2>/dev/null`
3. Remove the now-empty directory:
    - `sudo rmdir /mnt/recycle/home`

Now your structure is correct:

- `/mnt/recycle/wah/...` ✅

***

### Small caution

That `mv .../.*` line can complain about `.` and `..`, which is why we silence errors with `2>/dev/null`.

***

### Where you are now

- Your data is safe ✅
- It’s just one directory too deep ✅
- Easy fix, no re-copy needed ✅

***

If you want, next we can:

- clean up your fstab so you’re not double-mounting the same partition
- and make the final switch to `/home` smooth and predictable without surprises

---

# No need gracias. All though you have listed the steps could you do it one more time from 'though shall boot from usb and only from usb though shall boot" to the final step of the workflow 'moving /home'?

Got it—here’s the clean, no-surprises version from “boot external” to finished `/home` migration.

### Boot into a safe environment

- Boot from a Linux live USB (same distro if possible).
- Open a terminal.
- You want your installed system **not running**, so `/home` is inactive.


### Identify and mount your disks

From your earlier output:

- Root = `/dev/sdb2`
- New home partition = `/dev/nvme0n1p1`

Mount them:

- `sudo mount /dev/sdb2 /mnt`
- `sudo mkdir -p /mnt/newhome`
- `sudo mount /dev/nvme0n1p1 /mnt/newhome`

Verify:

- `ls /mnt` → should show your system (`etc`, `home`, etc.)
- `ls /mnt/newhome` → should be empty (or contain your corrected data)

***

### Copy `/home` to the new partition

(only if you haven’t already done it correctly)

- `sudo rsync -aAXv /mnt/home/ /mnt/newhome/`

Key detail:

- trailing slash on `/mnt/home/` ✅
- NO extra `/home` on destination ✅

Optional quick check:

- `sudo du -sh /mnt/home`
- `sudo du -sh /mnt/newhome`

***

### Prepare the switch

Rename old home and create a clean mountpoint:

- `sudo mv /mnt/home /mnt/home.old`
- `sudo mkdir /mnt/home`

***

### Configure fstab

Get UUID:

- `sudo blkid /dev/nvme0n1p1`

Edit:

- `sudo nano /mnt/etc/fstab`

Add this line:

- `UUID=31c512db-de02-46fb-a793-7cf730695fb4 /home ext4 defaults 0 2`

Important:

- Do NOT mount the same UUID twice unless you really intend to.
- Remove or comment `/mnt/recycle` entry if it uses the same partition.

***

### Test before reboot (important)

Mount using the edited fstab:

- `sudo mount -a -T /mnt/etc/fstab`

Then verify:

- `ls /mnt/home` → should show your user folders
- `df -h | grep home` (optional)

***

### Reboot into your system

- `sudo umount -R /mnt`
- `sudo reboot`

Remove the USB when prompted.

***

### After boot: verify everything

- `mount | grep /home`
- `df -h /home`
- `ls /home`

You should see:

- `/home` mounted from `/dev/nvme0n1p1`
- Your user directory intact

***

### Cleanup (after a safety window)

After you’re confident everything works:

- `sudo rm -rf /home.old`

***

### One example of “correct end state”

If everything worked:

- `/home/wah` → your files
- `/home` → mounted from NVMe
- old system disk → no longer storing active home data

***

If you hit anything weird during the live USB phase (mount fails, UUID confusion, empty `/mnt/home`, etc.), paste the output and I’ll help you debug it step-by-step.

---

# Many thanks. Ehrmm meant 'thou' not 'though' need a cup joe ... anyway got it saving this and updating my guide need to pluck the courage to do the whole thing again because if it goes wrong and in my case it did things can get very funky.

You’re not wrong to be cautious—this is exactly the kind of change where one small mismatch can make a system feel “haunted” afterward. The good news is your setup is already close, and the risky parts are now very well understood.

If you want to reduce the “funky” factor to near zero, here are a few practical safeguards before you try again:

### Pre-flight checks (worth 2 minutes)

- Make sure the new partition actually contains your full `/home`:
    - `ls /mnt/newhome/wah`
- Double-check UUID:
    - `blkid /dev/nvme0n1p1`
- Keep your current `/etc/fstab` backed up:
    - `cp /mnt/etc/fstab /mnt/etc/fstab.bak`


### One very useful safety net

Instead of deleting immediately, you already do the right thing:

- `/home` → `/home.old`

That gives you a full rollback by just:

- booting again from USB
- reverting fstab
- renaming back

That alone makes this operation safe.

### The biggest “gotcha” to avoid (your earlier one)

Just keep this rule in your head:

- Target must look like:
    - `/mnt/newhome/wah/...`
- Not:
    - `/mnt/newhome/home/wah/...`

If that’s correct, the rest is mostly mechanical.

### If something goes wrong

Typical failure modes are predictable:

- Boots but login fails → `/home` not mounted
- Empty home → wrong mount or wrong copy path
- Permission issues → rsync flags missing

All of these are fixable from a live USB because:

- your data is still either on `/home.old` or the new partition

Nothing gets destroyed unless you explicitly delete it.

***

Honestly, the fact you:

- checked with `lsof`
- verified mounts
- caught the rsync path issue

…means you’re doing this the *careful* way, which is exactly how to avoid disasters.

When you do attempt it again, take it slow and verify after each step—especially:

- after rsync
- after `mount -a -T`

If you want, when you’re about to actually execute it, you can paste:

- your `lsblk`
- your intended fstab line

…and I’ll sanity-check it in seconds before you pull the trigger.

