<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Would it be possible to add the table markup to the following freebasic code? The code is a markdown viewer utilizing sdl2 and sdl_ttf : \#include once "SDL2/SDL.bi"

\#include once "SDL2/SDL_ttf.bi"
\#include once "utilfile.bas"

' setup viewer
const win_w 		= 1100
const win_h 		= 1100
const margin 		= 16
const normal_size 	= 16
const heading_size 	= 18
const code_size 	= 15
const line_spacing 	= 6
const max_lines 	= 4096
const max_runs 		= 16384

const kind_text = 0
const kind_h1 	= 1
const kind_h2 	= 2
const kind_code = 3
const kind_hr 	= 4

dim shared as string lines(0 to max_lines - 1)
dim shared as integer kinds(0 to max_lines - 1)
dim shared as integer line_heights(0 to max_lines - 1)
dim shared as integer line_count = 0

' setup fle reading
dim locale          as string = "en"
dim dummy           as string = ""
dim appversion		as string = "1.0"
dim filetypes    	as string = ".txt, .md"
dim fileext         as string = ""
dim file_text		as string = ""
dim shared as string filename
filename            = ""

' colors and theme
type colorrgba
as ubyte r, g, b, a
end type

\#define sdl_rgba(r, g, b, a) type<sdl_color>(r, g, b, a)
Dim As colorrgba highlightcolor         = (45, 125, 195, 225)
Dim As colorrgba backgroundcolor        = (245, 245, 245, 255)
Dim As colorrgba backgroundplatecolor   = (25, 26, 27, 175)
Dim As colorrgba backgroundtextcolor    = (240, 241, 235, 235)
Dim As colorrgba headercolorb           = (80, 0, 0, 255)
Dim As colorrgba ttffontcolor           = (255, 255, 255, 0)
Dim As colorrgba ttffontgrey            = (185, 195, 205, 0)
Dim As colorrgba ttffontwhite           = (255, 255, 255, 0)
Dim As colorrgba ttffontblack           = (0, 0, 0, 0)
Dim As colorrgba ttffontgreen           = (35, 255, 125, 0)
Dim As colorrgba ttffontblue            = (35, 145, 225, 0)

sub setrenderdrawcolor(byval ren as SDL_Renderer ptr, byref c as colorrgba)
SDL_SetRenderDrawColor(ren, c.r, c.g, c.b, c.a)
end sub

function setsdlcolor(byref c as colorrgba) as SDL_Color
dim as SDL_Color cv
cv.r = c.r
cv.g = c.g
cv.b = c.b
cv.a = c.a
return cv
end function

type style_state
as integer bold
as integer italic
end type

type text_run
as string txt
as integer bold
as integer italic
end type

type run_list
as text_run runs(0 to max_runs - 1)
as integer count
end type

function load_file(byval filename as string) as string
dim as integer h = freefile()
dim as string txt

    if open(filename for binary access read as #h) <> 0 then return ""
    
    if lof(h) > 0 then
        txt = string(lof(h), 0)
        get #h, , txt
    end if
    
    close #h
    return txt
    end function

' parse commandline
select case command(1)
case "/?", "-h", "-help", "--help", "-man"
displayhelp(locale)
logentry("terminate", "normal termination " + appname)
case "-v", "-ver"
print appname + " version " \& exeversion
logentry("terminate", "normal termination " + appname)
case "-i", "-info"
'bassinfo()
logentry("terminate", "normal termination " + appname)
case else
dummy = resolvepath(command(1))
if instr(dummy, ".") <> 0 and instr(dummy, "..") = 0 then
if fileexists(dummy) = 0 then
logentry("fatal", "error: file not found " \& dummy)
end if		
fileext = lcase(mid(dummy, instrrev(dummy, ".")))
if instr(1, filetypes, fileext) = 0 then
logentry("fatal", dummy + " file type not supported")
end if
end if
file_text = load_file(dummy)	
end select

if SDL_Init(SDL_INIT_VIDEO) <> 0 then
logentry("fatal", "SDL_Init failed: " \& *SDL_GetError())
end if

if TTF_Init() <> 0 then
SDL_Quit()
logentry("fatal", "TTF_Init failed: " \& *TTF_GetError())
end if

dim as TTF_Font ptr font_normal  = TTF_OpenFont(strptr("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"), 			normal_size)
dim as TTF_Font ptr font_heading = TTF_OpenFont(strptr("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"), 				heading_size)
dim as TTF_Font ptr font_code 	 = TTF_OpenFont(strptr("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"), 			code_size)
dim as TTF_Font ptr font_bold 	 = TTF_OpenFont(strptr("/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"), 	normal_size)
dim as TTF_Font ptr font_italic  = TTF_OpenFont(strptr("/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Oblique.ttf"), 	normal_size)

if font_normal = 0 or font_heading = 0 or font_code = 0 or font_bold = 0 or font_italic = 0 then
logentry("fatal", "TTF_OpenFont failed: " \& *TTF_GetError())
if font_normal <> 0 then TTF_CloseFont(font_normal)
if font_heading <> 0 then TTF_CloseFont(font_heading)
if font_code <> 0 then TTF_CloseFont(font_code)
if font_bold <> 0 then TTF_CloseFont(font_bold)
if font_italic <> 0 then TTF_CloseFont(font_italic)
TTF_Quit()
SDL_Quit()
end 1
end if

dummy = "markdown viewer " + dummy
dim as SDL_Window ptr win = SDL_CreateWindow(strptr(dummy), SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, win_w, win_h, SDL_WINDOW_SHOWN or SDL_WINDOW_ALLOW_HIGHDPI)
if win = 0 then
TTF_Quit()
SDL_Quit()
logentry("fatal", "SDL_CreateWindow failed: " \& *SDL_GetError())
end if

dim as SDL_Renderer ptr ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED or SDL_RENDERER_PRESENTVSYNC)
if ren = 0 then
SDL_DestroyWindow(win)
TTF_Quit()
SDL_Quit()
logentry("fatal", "SDL_CreateRenderer failed: " \& *SDL_GetError())
end if

sub add_line(byval txt as string, byval kind as integer)
if line_count <= ubound(lines) then
lines(line_count) = txt
kinds(line_count) = kind
line_count += 1
end if
end sub

function strip_cr(byval s as string) as string
if len(s) > 0 then
if right(s, 1) = chr(13) then return left(s, len(s) - 1)
end if
return s
end function

function trim_text(byval s as string) as string
return trim(s)
end function

function is_heading(byval s as string) as integer
select case left(s, 4)
case "\#\#\# "
return 3
end select

    select case left(s, 3)
    case "## "
        return 2
    end select
    
    select case left(s, 2)
    case "# "
        return 1
    end select
    
    return 0
    end function

function remove_heading(byval s as string) as string
select case left(s, 4)
case "\#\#\# "
return mid(s, 5)
end select

    select case left(s, 3)
    case "## "
        return mid(s, 4)
    end select
    
    select case left(s, 2)
    case "# "
        return mid(s, 3)
    end select
    
    return s
    end function

function is_hr(byval s as string) as integer
select case trim_text(s)
case "---", "***", "___"
return 1
end select
select case true
case instr(trim_text(s), "---") > 0
return 1
end select
return 0
end function

sub add_run(byref rl as run_list, byval txt as string, byval bold as integer, byval italic as integer)
if len(txt) = 0 then exit sub
if rl.count > ubound(rl.runs) then exit sub
rl.runs(rl.count).txt = txt
rl.runs(rl.count).bold = bold
rl.runs(rl.count).italic = italic
rl.count += 1
end sub

sub parse_inline_styled_text(byval txt as string, byref rl as run_list)
dim as integer i = 1
dim as integer start_at = 1
dim as style_state st
rl.count = 0

    do while i <= len(txt)
        select case mid(txt, i, 2)
        case "**", "__"
            add_run(rl, mid(txt, start_at, i - start_at), st.bold, st.italic)
            st.bold = 1 - st.bold
            i += 2
            start_at = i
        case else
            select case mid(txt, i, 1)
            case "*", "_"
                add_run(rl, mid(txt, start_at, i - start_at), st.bold, st.italic)
                st.italic = 1 - st.italic
                i += 1
                start_at = i
            case else
                i += 1
            end select
        end select
    loop
    
    add_run(rl, mid(txt, start_at), st.bold, st.italic)
    end sub

sub parse_markdown(byval src as string)
dim as integer scan_at = 1, eol_at, in_code = 0
dim as string tmp
line_count = 0

    do while scan_at <= len(src) and line_count < max_lines
        eol_at = instr(scan_at, src, chr(10))
        if eol_at = 0 then
            tmp = mid(src, scan_at)
            scan_at = len(src) + 1
        else
            tmp = mid(src, scan_at, eol_at - scan_at)
            scan_at = eol_at + 1
        end if
    
        tmp = strip_cr(tmp)
    
        select case true
        case left(tmp, 3) = "```"
            if in_code = 0 then
                add_line("", kind_code)
                in_code = 1
            else
                add_line("", kind_code)
                in_code = 0
            end if
    
        case in_code = 1
            add_line(tmp, kind_code)
    
        case len(trim_text(tmp)) = 0
            add_line("", kind_text)
    
        case is_hr(tmp) <> 0
            add_line("", kind_hr)
    
        case else
            select case is_heading(tmp)
            case 1
                add_line(remove_heading(tmp), kind_h1)
            case 2, 3
                add_line(remove_heading(tmp), kind_h2)
            case else
                add_line(tmp, kind_text)
            end select
        end select
    loop
    
    if line_count = 0 then add_line("", kind_text)
    end sub

function draw_text_single(byval ren as SDL_Renderer ptr, byval font as TTF_Font ptr, _
byval txt as string, byval x as integer, byval y as integer, _
byval c as colorrgba) as integer

    dim as SDL_Color col = setsdlcolor(c)
    
    ' todo wrap hardcoded needs to be dynamic
    dim as SDL_Surface ptr surf = TTF_RenderUTF8_Blended_Wrapped(font, strptr(txt), col, 1000)
    if surf = 0 then return 0
    
    dim as SDL_Texture ptr tex = SDL_CreateTextureFromSurface(ren, surf)
    if tex <> 0 then
        dim as SDL_Rect dst
        dst.x = x
        dst.y = y
        dst.w = surf->w
        dst.h = surf->h
        SDL_RenderCopy(ren, tex, 0, @dst)
        SDL_DestroyTexture(tex)
    end if
    
    dim as integer used_h = surf->h
    SDL_FreeSurface(surf)
    return used_h
    end function

function measure_wrapped_height(byval font as TTF_Font ptr, byval txt as string, byval wrap_w as integer) as integer
dim as SDL_Color col
col.r = 255 : col.g = 255 : col.b = 255 : col.a = 255

    dim as SDL_Surface ptr surf
    if wrap_w > 0 then
        surf = TTF_RenderUTF8_Blended_Wrapped(font, strptr(txt), col, wrap_w)
    else
        surf = TTF_RenderUTF8_Blended(font, strptr(txt), col)
    end if
    
    if surf = 0 then return 0
    
    dim as integer h = surf->h
    SDL_FreeSurface(surf)
    return h
    end function

function draw_styled_line(byval ren as SDL_Renderer ptr, _
byval font_normal as TTF_Font ptr, _
byval font_bold as TTF_Font ptr, _
byval font_italic as TTF_Font ptr, _
byval txt as string, byval x as integer, byval y as integer, _
byval c as colorrgba, _
byval wrap_w as integer) as integer

    dim as run_list rl
    dim as integer i, p, word_len
    dim as integer cur_x = x
    dim as integer cur_y = y
    dim as integer line_h = 0
    dim as integer used_h = 0
    dim as string token, word
    dim as SDL_Color col
    dim as SDL_Surface ptr surf
    dim as SDL_Texture ptr tex
    dim as SDL_Rect dst
    dim as TTF_Font ptr fnt
    dim as integer tw, th
    
    col.r = c.r : col.g = c.g : col.b = c.b : col.a = c.a
    
    if instr(txt, "**") = 0 and instr(txt, "__") = 0 and instr(txt, "*") = 0 and instr(txt, "_") = 0 then
        if wrap_w > 0 then
            surf = TTF_RenderUTF8_Blended_Wrapped(font_normal, strptr(txt), col, wrap_w)
            if surf = 0 then return 0
    
            tex = SDL_CreateTextureFromSurface(ren, surf)
            if tex <> 0 then
                dst.x = x
                dst.y = y
                dst.w = surf->w
                dst.h = surf->h
                SDL_RenderCopy(ren, tex, 0, @dst)
                SDL_DestroyTexture(tex)
            end if
    
            used_h = surf->h
            SDL_FreeSurface(surf)
            return used_h
        else
            return draw_text_single(ren, font_normal, txt, x, y, c)
        end if
    end if
    
    parse_inline_styled_text(txt, rl)
    
    for i = 0 to rl.count - 1
        select case true
        case rl.runs(i).bold <> 0
            fnt = font_bold
        case rl.runs(i).italic <> 0
            fnt = font_italic
        case else
            fnt = font_normal
        end select
    
        token = rl.runs(i).txt
        p = 1
    
        do while p <= len(token)
            if mid(token, p, 1) = " " then
                word = " "
                surf = TTF_RenderUTF8_Blended(fnt, strptr(word), col)
                if surf <> 0 then
                    if TTF_SizeUTF8(fnt, strptr(word), @tw, @th) = 0 then
                        if wrap_w > 0 and cur_x > x and cur_x + tw > x + wrap_w then
                            cur_x = x
                            cur_y += line_h
                            line_h = 0
                        end if
                    end if
    
                    tex = SDL_CreateTextureFromSurface(ren, surf)
                    if tex <> 0 then
                        dst.x = cur_x
                        dst.y = cur_y
                        dst.w = surf->w
                        dst.h = surf->h
                        SDL_RenderCopy(ren, tex, 0, @dst)
                        SDL_DestroyTexture(tex)
                    end if
    
                    if surf->h > line_h then line_h = surf->h
                    cur_x += surf->w
                    SDL_FreeSurface(surf)
                end if
                p += 1
            else
                word_len = 0
                do while p + word_len <= len(token)
                    if mid(token, p + word_len, 1) = " " then exit do
                    word_len += 1
                loop
    
                word = mid(token, p, word_len)
                surf = TTF_RenderUTF8_Blended(fnt, strptr(word), col)
                if surf <> 0 then
                    if TTF_SizeUTF8(fnt, strptr(word), @tw, @th) = 0 then
                        if wrap_w > 0 and cur_x > x and cur_x + tw > x + wrap_w then
                            cur_x = x
                            cur_y += line_h
                            line_h = 0
                        end if
                    end if
    
                    tex = SDL_CreateTextureFromSurface(ren, surf)
                    if tex <> 0 then
                        dst.x = cur_x
                        dst.y = cur_y
                        dst.w = surf->w
                        dst.h = surf->h
                        SDL_RenderCopy(ren, tex, 0, @dst)
                        SDL_DestroyTexture(tex)
                    end if
    
                    if surf->h > line_h then line_h = surf->h
                    cur_x += surf->w
                    SDL_FreeSurface(surf)
                end if
    
                p += word_len
            end if
        loop
    next
    
    if line_h = 0 then line_h = normal_size
    used_h = cur_y - y + line_h
    return used_h
    end function

sub precompute_layout(byval wrap_w as integer, _
byval font_normal as TTF_Font ptr, _
byval font_heading as TTF_Font ptr, _
byval font_code as TTF_Font ptr)

    dim as integer i, h
    
    for i = 0 to line_count - 1
        select case kinds(i)
        case kind_code
            h = measure_wrapped_height(font_code, lines(i), wrap_w)
            if h <= 0 then h = code_size
            h += 4
    
        case kind_h1, kind_h2
            h = measure_wrapped_height(font_heading, lines(i), wrap_w)
            if h <= 0 then h = heading_size
            h += line_spacing
    
        case kind_hr
            h = 18
    
        case else
            h = measure_wrapped_height(font_normal, lines(i), wrap_w)
            if h <= 0 then h = normal_size
            h += line_spacing
        end select
    
        line_heights(i) = h
    next
    end sub

function total_content_height() as integer
dim as integer i, t = margin * 2
for i = 0 to line_count - 1
t += line_heights(i)
next
return t
end function

' main
parse_markdown(file_text)

dim as integer running = -1
dim as integer scrollY = 0
dim as integer maxScroll
dim as integer y, i
dim as integer wrapW = win_w - (margin * 2)
dim as SDL_Event e

precompute_layout(wrapW, font_normal, font_heading, font_code)
maxScroll = total_content_height() - win_h
if maxScroll < 0 then maxScroll = 0

do while running
while SDL_PollEvent(@e) <> 0
select case as const e.type
case SDL_QUIT_
running = 0

        case SDL_KEYDOWN
            select case e.key.keysym.sym
            case SDLK_ESCAPE
                running = 0
            case SDLK_DOWN
                scrollY += normal_size
            case SDLK_UP
                scrollY -= normal_size
            case SDLK_PAGEDOWN
                scrollY += win_h \ 2
            case SDLK_PAGEUP
                scrollY -= win_h \ 2
            case SDLK_HOME
                scrollY = 0
            case SDLK_END
                scrollY = maxScroll
            end select
    
        case SDL_MOUSEWHEEL
            scrollY -= e.wheel.y * normal_size * 3
        end select
    wend
    
    if scrollY < 0 then scrollY = 0
    if scrollY > maxScroll then scrollY = maxScroll
    
    setrenderdrawcolor(ren, backgroundcolor) 
    SDL_RenderClear(ren)
    
    y = margin - scrollY
    
    for i = 0 to line_count - 1
        dim as string txt = lines(i)
        dim as integer kind = kinds(i)
        dim as integer usedH
    
        select case kind
        case kind_code
            dim as SDL_Rect bg
            bg.x = 10
            bg.y = y - 2
            bg.w = win_w - 20
            bg.h = line_heights(i)
    		setrenderdrawcolor(ren, ttffontgrey) 
            SDL_RenderFillRect(ren, @bg)
            usedH = draw_text_single(ren, font_code, txt, margin, y, ttffontblack)
            if usedH <= 0 then usedH = code_size
    
        case kind_h1
            usedH = draw_text_single(ren, font_heading, txt, margin, y, ttffontblue)
            if usedH <= 0 then usedH = heading_size
    
        case kind_h2
            usedH = draw_text_single(ren, font_heading, txt, margin, y, ttffontblue)
            if usedH <= 0 then usedH = heading_size
    
        case kind_hr
            dim as SDL_Rect hr
            hr.x = margin
            hr.y = y + 8
            hr.w = win_w - (margin * 2)
            hr.h = 2
    		setrenderdrawcolor(ren, ttffontgrey) 
            SDL_RenderFillRect(ren, @hr)
    
        case else
            usedH = draw_styled_line(ren, font_normal, font_bold, font_italic, txt, margin, y, ttffontblack, wrapW)
            if usedH <= 0 then usedH = normal_size
        end select
    
        y += line_heights(i)
    next
    
    SDL_RenderPresent(ren)
    SDL_Delay(25)
    loop

TTF_CloseFont(font_normal)
TTF_CloseFont(font_heading)
TTF_CloseFont(font_code)
TTF_CloseFont(font_bold)
TTF_CloseFont(font_italic)
SDL_DestroyRenderer(ren)
SDL_DestroyWindow(win)
TTF_Quit()
SDL_Quit()
close
logentry("terminate", "normal termination " + appname)

I can help add table markup support to your FreeBASIC Markdown viewer. I’ll break this into a concise plan and provide code snippets you can drop in.

What you asked for

- Extend the parser to recognize Markdown tables and emit a new kind for table rows or cells.
- Render tables using existing text rendering, aligning columns, and optionally drawing header separators.

Approach

- Step 1: Extend the data model
    - Add a new kind: kind_table, and a new structure to hold per-row cell texts or a simple tokenization approach.
- Step 2: Table detection
    - In parse_markdown, detect lines that begin with pipe-delimited content (e.g., | a | b |) and, if followed by a separator row like |---|---|, treat as a table.
- Step 3: Table layout
    - Collect all table rows, compute max column count, and determine column widths by wrapping constraints.
- Step 4: Rendering
    - Render a table header row with bold/blue styling.
    - Render a separator line (hr-like) after the header.
    - Render subsequent rows with regular text, aligning cells within computed column widths.
    - Optionally render grid lines using SDL_RenderDrawLine for a table-like appearance.

Minimal viable implementation

- Add a new kind_table that represents a table row as an array of cell strings.
- In parsing, when a pipe-delimited line is found, collect as a table row; when a separator line (---) is found after a header, switch to table mode.
- Store tableRows as an array of strings arrays and compute column widths on the fly during precompute_layout or render pass.

Code excerpts (drop-in modifications)

- Extend constants and types
    - Add:
        - const kind_table = 5
    - Extend run_list or add a new struct if you prefer per-table data storage. For simplicity, store table rows in a new dynamic array:
        - dim shared as string table_rows(0 to max_lines - 1)
        - dim shared as integer table_cols(0 to max_lines - 1)
        - dim shared as integer table_count = 0
- In parse_markdown, detect tables
    - Pseudo logic to insert into table_rows when a line contains '|' and not code block:
        - If line begins with '|' and ends with '|' or contains '||', treat as table row.
        - After a header row, if next line matches a separator like |---|---|, set a flag is_in_table and store a header row as kind_table with a header styling.
    - When leaving a table (empty line or non-table line), reset the is_in_table flag.
- Rendering tables
    - In the main render loop, add a case for kind_table:
        - Compute y position per row using an additional table_row_heights array or reuse line_heights for each row in the table.
        - For each cell, render text with a fixed width equal to column_widths[col].
        - Optionally draw vertical grid lines using SDL_RenderDrawLine between columns.
    - Example drawing code (high level):
        - cell_x = margin
        - for col = 0 to table_cols-1
render cell text at (cell_x, y)
cell_x += col_widths[col]
        - draw vertical separators at cell_x positions
    - For header cells (row 0), use header styling (bold, blue).
- Memory and bounds
    - Ensure you bound writes to max_lines and max_runs, and reset per-table state after rendering.

Illustrative snippet (conceptual; adapt to your exact data structures)

- Add kind_table and a simple table structure:
    - type table_row
as string cells(0 to 8) ' adjust 8 for example
    - dim shared as integer table_row_count
    - dim shared as table_row table_rows(0 to max_lines - 1)
- Parsing logic outline inside parse_markdown:
    - If line contains '|' and not in_code:
        - parse cells = split(tmp, "|")
        - trim each cell
        - add_line("", kind_table)  ' placeholder header for readability
        - store cells into table_rows[table_row_count] and update table_row_count
    - If a line like |---|---| appears after a header row, set a flag is_table_header = true
- Rendering outline inside main loop:
    - case kind_table
        - for each cell in table_rows[current_table_row]
render with a fixed width
        - advance y by a computed row height (table_row_heights)

Notes and caveats

- This is a minimal, incremental addition. If you prefer a drop-in, you can implement a simpler variant:
    - Treat any pipe-delimited line as a table row and render each line as a single row without per-cell wrapping, using simple horizontal alignment.
- Consider a two-pass approach: first collect table data, then render with a dedicated layout pass in precompute_layout, computing column widths from the longest cell in each column.
- If you need a more complete, production-ready feature, you’ll want to add:
    - Proper escaping, handling of pipes within code blocks, and nested tables.
    - Proper wrapping per cell with rendering height per row.

Would you like me to generate a concrete, ready-to-paste patch for your codebase? If you share a small sample Markdown that includes a table, I can tailor the parsing and rendering logic to match your style and compute precise column widths and render behavior. I will include inline citations for any external references if I consult them.

---

# Lets start small with : \#\#\# Table

| Syntax | Description |
| :-- | :-- |
| Header | Title |
| Paragraph | Text |

| Syntax | Description | Center | Right |
| :-- | :-- | :--: | --: |
| Alpha | Left aligned | Centered | Right aligned |
| Beta | Another | Example | Row |

: ...

Yes — starting small is the right move. For these examples, the easiest path is to treat table blocks as a special block type: detect a header row, a separator row, then one or more data rows, and render them as aligned columns.

## What to add

You’ll want three things:

- A new line kind for tables.
- A small table parser that groups consecutive pipe-delimited lines.
- A renderer that computes column widths and draws each cell with alignment.


## Markdown cases you showed

Your examples include two common table forms:

- Simple table:
    - `| Syntax | Description |`
    - `| ----------- | ----------- |`
    - `| Header | Title |`
- Aligned table:
    - `| Syntax | Description | Center | Right |`
    - `| :------ | :------ | :---: | ---: |`
    - `| Alpha | Left aligned | Centered | Right aligned |`

The separator row tells you:

- `---` = left aligned.
- `:---` = left aligned with explicit left marker.
- `:---:` = centered.
- `---:` = right aligned.


## Minimal data model

Add a small table structure instead of trying to store tables as plain lines:

```freebasic
const kind_table = 5

type table_cell
    as string txt
    as integer align   ' 0 = left, 1 = center, 2 = right
end type

type table_row
    as table_cell cells(0 to 15)
    as integer count
    as integer is_header
end type

type table_block
    as table_row rows(0 to 255)
    as integer row_count
    as integer col_count
end type
```

If you want to keep it very simple, you can support one table at a time first.

## Parsing strategy

Inside `parse_markdown`, detect a table block like this:

1. A line contains `|`.
2. The next line is a separator row made of `-`, `:`, and `|`.
3. Then collect following rows until a non-table line appears.

That means this should be parsed as one block:

- header row
- separator row
- data rows


## Separator detection

A helper like this is enough for a first pass:

```freebasic
function is_table_separator(byval s as string) as integer
    dim as string t = trim(s)
    if left(t, 1) = "|" then t = mid(t, 2)
    if right(t, 1) = "|" then t = left(t, len(t) - 1)
    t = replace(t, " ", "")
    if len(t) = 0 then return 0

    dim as integer i
    for i = 1 to len(t)
        select case mid(t, i, 1)
        case "-", ":", "|"
        case else
            return 0
        end select
    next

    return instr(t, "-") > 0
end function
```


## Column parsing

Split by `|`, trim each cell, and ignore the outer empty cells if the row starts and ends with `|`.

```freebasic
sub parse_table_row(byval s as string, byref row as table_row)
    dim as string t = trim(s)
    dim as string parts()
    dim as integer i, n, p, startp, c

    row.count = 0
    if left(t, 1) = "|" then t = mid(t, 2)
    if right(t, 1) = "|" then t = left(t, len(t) - 1)

    n = 0
    startp = 1

    do
        p = instr(startp, t, "|")
        if p = 0 then
            n += 1
            redim preserve parts(1 to n)
            parts(n) = trim(mid(t, startp))
            exit do
        else
            n += 1
            redim preserve parts(1 to n)
            parts(n) = trim(mid(t, startp, p - startp))
            startp = p + 1
        end if
    loop

    row.count = n
    for i = 1 to n
        row.cells(i - 1).txt = parts(i)
        row.cells(i - 1).align = 0
    next
end sub
```


## Alignment parsing

Use the separator row to set per-column alignment:

```freebasic
sub parse_table_alignments(byval s as string, byref row as table_row)
    dim as string t = trim(s)
    dim as string parts()
    dim as integer i, n, p, startp

    if left(t, 1) = "|" then t = mid(t, 2)
    if right(t, 1) = "|" then t = left(t, len(t) - 1)

    n = 0
    startp = 1

    do
        p = instr(startp, t, "|")
        if p = 0 then
            n += 1
            redim preserve parts(1 to n)
            parts(n) = trim(mid(t, startp))
            exit do
        else
            n += 1
            redim preserve parts(1 to n)
            parts(n) = trim(mid(t, startp, p - startp))
            startp = p + 1
        end if
    loop

    row.count = n
    for i = 1 to n
        select case parts(i)
        case ":---:"
            row.cells(i - 1).align = 1
        case "---:"
            row.cells(i - 1).align = 2
        case ":---"
            row.cells(i - 1).align = 0
        case else
            row.cells(i - 1).align = 0
        end select
    next
end sub
```


## How to integrate it

In `parse_markdown`, when you hit a potential table header row:

- Look at current line and next line.
- If next line is a separator row, start a table block.
- Store the header row.
- Store the separator alignment row.
- Store following rows until a blank line or non-table line.

For a first version, you can simply store each row as a separate `kind_table` line and render with a shared table state.

## Rendering idea

For each table block:

- Compute the widest cell in each column.
- Add padding to each column.
- Use the alignment from the separator row.
- Render each row cell by cell.

A simple width helper:

```freebasic
function cell_width(byval font as TTF_Font ptr, byval s as string) as integer
    dim as integer w, h
    if TTF_SizeUTF8(font, strptr(s), @w, @h) <> 0 then return 0
    return w
end function
```

Then for each column:

- `col_w(col) = max(col_w(col), cell_width(font, cell_text)) + padding`

And for each row:

- draw a background rectangle if you want
- render each cell within its column box
- move `x` by the column width
- move `y` by the row height


## Best first step

For your exact sample, the smallest useful implementation is:

- detect the table block,
- parse into cells,
- compute column widths,
- draw each row as a grid of text with light borders.

That will already handle both of your examples.

## Recommended next patch

The most practical next step is to add:

- `kind_table`
- a `table_block` type
- `is_table_separator()`
- `parse_table_row()`
- a table rendering branch in the main loop

That keeps the rest of your markdown viewer intact and avoids rewriting the whole parser.

