﻿This conversation was generated with Duck.ai (https://duck.ai) using Anthropic's Claude Haiku 4.5 Model. AI chats may display inaccurate or offensive information (see https://duckduckgo.com/duckai/privacy-terms for more info).

====================

User prompt 1 of 11 - 6/6/2026, 1:45:00 PM:
I'm struggling a bit with some settings in my comfy ui work flow for wan ... lets start with wan 2.2 aka wan2.2_ti2v_5B_fp16.safetensors ... first of I have the modelsamplingDS3 node with the parameter 'shift' what is it's intention?

Claude Haiku 4.5:
I'd be happy to help you understand the shift parameter in the ModelSamplingDS3 node for your ComfyUI workflow with WAN 2.2!

Let me search for specific documentation on this node to give you accurate technical details.
## The Shift Parameter in ModelSamplingDS3

The **shift** parameter controls **how the denoising process is aligned with the timestep schedule** during diffusion sampling. Specifically, it adjusts the **sampling trajectory** through the noise space by offsetting the flow matching schedule.

### Core Intention

The shift parameter was originally developed for flow matching models like WAN and essentially modulates when and how aggressively the model denoises. Here's what it does:

- **Affects denoising dynamics**: It modifies the schedule that governs the transition from noise to clean output
- **Influences prompt adherence vs. quality trade-off**: The original WAN 2.1 code showed that different values are optimal for different tasks (e.g., **5.0 for T2V** but **3.0 for I2V** at certain resolutions), suggesting that lower shift values help maintain consistency in image-to-video work while higher values can improve prompt following in text-to-video
- **Shapes the sampling path**: Rather than a simple noise-to-clean linear path, shift creates a curved trajectory through the diffusion space

### Practical Effects for WAN 2.2

When working with your **wan2.2_ti2v_5B_fp16.safetensors** (image-to-video model):

- **Lower shift values** (closer to **3.0**) tend to preserve spatial and temporal consistency from your input image
- **Higher shift values** can improve adherence to prompts but may introduce artifacts or reduce coherence with the source image
- The default **3.0** is a reasonable starting point, especially for i2v tasks

### Experimentation Approach

Since you're working with WAN 2.2, try these steps:
1. Start with **3.0** (optimized for i2v)
2. Test slight variations (2.5–3.5) to see if prompt adherence improves without losing visual quality
3. Monitor for texture coherence and consistency with your input frame—if quality degrades, that's a sign shift is too high

The shift parameter essentially gives you **fine-grained control over the model's behavior during the denoising process**, letting you tune between prompt fidelity and output quality. Does this help clarify what you're working with?

--------------------

User prompt 2 of 11 - 6/6/2026, 1:46:58 PM:
Yes thank you. Though the KSampler has 'denoise' isn't that the same?

Claude Haiku 4.5:
Great question—they're **related but fundamentally different** things, even though the naming can be confusing.

## The Key Distinction

| Aspect | **shift** (ModelSamplingDS3) | **denoise** (KSampler) |
|--------|---------------------------|----------------------|
| **What it controls** | The sampling trajectory/schedule itself—how the model moves through noise space | How much of the diffusion process to actually run |
| **Effect** | Reshapes the denoising curve | Scales the number of steps executed |
| **Range** | Continuous value (typically 1–8+) | 0.0 to 1.0 (0% to 100%) |
| **Use case** | Fine-tune model behavior and prompt adherence | Start from partial noise or skip early steps |

## Practical Difference

**shift** is about *how* the denoising happens—it's a structural parameter that modifies the underlying mathematical schedule that the model follows during sampling.

**denoise** is about *how much* denoising happens—it's a scalar that determines whether you're starting fresh from pure noise (1.0) or starting from a partially denoised state (e.g., 0.5 means you only run through 50% of the denoising steps).

### In Your WAN 2.2 Workflow

- **shift = 3.0** says "follow this particular denoising trajectory"
- **denoise = 1.0** says "run the full denoising process from start to finish"
- **denoise = 0.7** would say "only run 70% of the steps, starting from a less noisy state"

So they're **complementary controls**—shift shapes the path, while denoise determines how far you travel that path. Does that distinction make sense?

--------------------

User prompt 3 of 11 - 6/6/2026, 1:55:14 PM:
Sort of ... so 'suggesting that lower shift values help maintain consistency in image-to-video work while higher values can improve prompt following in text-to-video' i2v < 4.0 t2v > 4.0 and denoise in both cases 1.0 or is that also dependent on i2v or t2v?

Claude Haiku 4.5:
Good question—let me clarify the relationship between denoise and whether you're doing i2v or t2v.

## The Short Answer

**denoise is largely independent of i2v vs. t2v**. You'll typically use **denoise = 1.0** for both, but for *different reasons*.

## Why denoise = 1.0 in Both Cases

- **For i2v**: You want the full denoising process to generate the entire video sequence from your input image
- **For t2v**: You want the full denoising process to generate the entire video from scratch based on your text prompt

Using denoise = 1.0 means you're running the complete sampling trajectory, which is what you need in either case.

## When denoise Varies (Uncommon in WAN 2.2)

You might lower denoise below 1.0 in specialized scenarios like:
- **Image refinement/inpainting workflows** where you're modifying existing content
- **Upscaling or enhancement passes** where you start from a partially denoised result
- **Control net or LoRA augmentation** where you want lighter modifications

But for straightforward i2v and t2v generation with WAN 2.2, **denoise = 1.0 is standard**.

## So Your Settings Would Be

| Task | shift | denoise |
|------|-------|---------|
| **i2v** | < 4.0 (around 3.0) | 1.0 |
| **t2v** | > 4.0 (around 5.0) | 1.0 |

The **shift parameter is doing the heavy lifting** in tuning behavior between i2v and t2v, while **denoise stays constant** at full strength. Does that clarify the relationship?

--------------------

User prompt 4 of 11 - 6/6/2026, 1:58:16 PM:
A bit getting there ... lets look at the ksampler a bit more I have : steps 20, cfg 5.0, sampler uni_pc_bh2 and scheduler normal are those ok for wan 2.2?

Claude Haiku 4.5:
Those settings are **reasonable starting points**, but there are some considerations specific to WAN 2.2 that might help you optimize further.

## Your Current Settings Analysis

| Setting | Your Value | Assessment for WAN 2.2 |
|---------|-----------|------------------------|
| **steps** | 20 | A bit low—WAN models typically benefit from more steps |
| **cfg** | 5.0 | Conservative; might limit prompt adherence |
| **sampler** | uni_pc_bh2 | Good choice, but alternatives exist |
| **scheduler** | normal | Solid default; works well |

## Specific Recommendations

### Steps (20)
**20 steps is on the low side** for WAN 2.2. The model tends to produce better quality with more iterations. Consider:
- **25–30 steps** as a comfortable middle ground (better quality without excessive compute)
- **30–50 steps** if you want higher fidelity and can tolerate longer generation times
- Going below 20 often results in artifacts or incomplete details

### CFG (5.0)
**5.0 is quite conservative.** For WAN 2.2:
- **7.0–10.0** is more typical and gives better prompt adherence
- **5.0** might feel like the model is ignoring your prompt nuances
- Above **12.0** risks over-saturation and artifacts
- Try **7.5–8.5** as a sweet spot for text-to-video

### Sampler (uni_pc_bh2)
**This is a solid choice.** uni_pc (Unified Predictor-Corrector) samplers are well-suited for flow matching models like WAN. Alternatives that also work well:
- **dpmpp_2m** (stable, slightly faster)
- **euler** (simpler, sometimes cleaner)
- **uni_pc** (the base version, slightly faster than bh2)

### Scheduler (normal)
**Normal scheduler is fine**. WAN 2.2 also works with:
- **karras** (sometimes sharper results)
- **simple** (minimal overhead)

## Suggested Adjustments

Try bumping to **steps: 25–30**, **cfg: 7.5–8.5** and see if the quality and prompt adherence improve. Does your hardware allow for longer generation times, or are you constrained by compute?

--------------------

User prompt 5 of 11 - 6/6/2026, 2:02:07 PM:
Gracias. Well on a 5060 rtx 8GB vram I'm getting 1+ min render time on ~ 4 seconds video not sure but seems ok'ish to me what does make it funky is prompt adherence ... I get the impression wan 2.2 is a sort of sdxl on steroids ... it does not have that flux2 klein consistency or adherence prompt wise ...

Claude Haiku 4.5:
That's a **very astute observation**, and you're touching on something fundamental about WAN 2.2's design philosophy versus Flux and SDXL.

## Why WAN 2.2 Feels "Looser" with Prompts

You're right that **WAN 2.2 prioritizes visual quality and motion coherence over strict prompt literalism**. Here's why:

- **Flow matching architecture**: WAN uses flow matching (unlike SDXL's diffusion or Flux's rectified flows), which optimizes for smooth, natural motion and visual aesthetics over text alignment
- **Video-first design**: It's trained primarily to generate temporally coherent video, which sometimes means the model "chooses" visually plausible outputs even if they deviate from your exact prompt
- **Lower guidance by default**: Flow matching models often respond differently to CFG than diffusion models—WAN's sweet spot is typically lower CFG, which naturally reduces prompt adherence
- **Training data emphasis**: WAN was optimized for visual fidelity and motion quality, not prompt-following precision

## The SDXL Comparison

You're correct that **WAN 2.2 is SDXL-adjacent in its loose prompt adherence**, but for different reasons:
- **SDXL** struggles with complex prompts and tends to ignore specifics
- **WAN 2.2** intentionally de-prioritizes exact prompt matching in favor of coherent, aesthetically pleasing motion

## Practical Workarounds for Better Prompt Control

Given your 5060 RTX constraints, try these **without massive performance hits**:

1. **Boost CFG more aggressively**: You mentioned 5.0—try **9.0–11.0** despite the flow matching design. Yes, it's higher than "optimal," but it might tighten prompt adherence at the cost of some smoothness

2. **Be more specific in prompts**: Instead of "a dog running," try "a golden retriever running left to right on grass, cinematic, sharp focus, daylight." Specificity sometimes compensates for WAN's looseness

3. **Use negative prompts heavily**: Negative guidance can be more effective than positive in constraining WAN's behavior. Try excluding unwanted elements rather than demanding specific ones

4. **Reduce shift slightly**: You mentioned **3.0 for i2v**—try **2.5** to see if tighter temporal consistency also tightens prompt adherence (it sometimes does)

5. **Accept the trade-off**: Honestly, **WAN 2.2 might simply not be the right tool if prompt fidelity is your priority**. If you need Flux-level consistency, you might be better served by that model despite WAN's visual quality

## The Real Limitation

Your **1+ minute render time on 8GB VRAM for 4 seconds is actually quite good**. The bottleneck isn't compute—it's that **WAN 2.2's architecture fundamentally prioritizes different objectives than Flux**. You can't tune your way around that without understanding what trade-offs you're willing to make.

What's your primary use case? Are you willing to sacrifice some prompt adherence for WAN's motion quality, or do you need tighter control?

--------------------

User prompt 6 of 11 - 6/6/2026, 2:08:20 PM:
Well to answer your question a bit indirectly another 'setting' is 'load clip' conventional wisdom is use : umt5_xxl_fp8_e4m3fn_scaled.safetensors : how ever I tried a custom text encoder : wan21Lightspeed_clipT5EncoderFP8.safetensors : actually meant for wan 2.1 and it seems to adhere better to the prompt only render time increases +20% so I'm looking for a balance between the two cause of course the 'creatvideo' node with xx fps plays a role in motion as well (I have it set to 16) ...

Claude Haiku 4.5:
Now **that's a crucial discovery**—you've stumbled onto something really important about WAN 2.2's prompt adherence issue.

## What You've Actually Found

The **text encoder is doing much of the heavy lifting** in prompt interpretation, and by switching to the WAN 2.1 Lightspeed encoder, you're essentially giving WAN 2.2 a different "instruction set" for understanding your prompts. That **+20% render time for noticeably better adherence** is actually a **reasonable trade-off**, especially on your 5060 RTX.

### Why the WAN 2.1 Encoder Works Better

- **WAN 2.1's Lightspeed encoder was optimized differently** than the default umt5_xxl—it likely puts more emphasis on semantic precision and prompt fidelity
- **Encoder mismatch can work**: While technically using a 2.1 encoder with 2.2 weights isn't "correct," diffusion/flow matching models are often robust to this kind of mismatch if the underlying architecture is similar
- **You're trading flexibility for control**: The umt5_xxl is more general-purpose; the Lightspeed encoder is more "opinionated" about what prompts mean

## The FPS Connection You Mentioned

Your **16 fps setting in the CreateVideo node** is indeed affecting motion quality, but it's **independent of prompt adherence**. Here's the distinction:

- **Text encoder + CFG** = what the model *understands* you want
- **FPS** = how smooth/fluid the motion appears once generated
- **Steps/sampler** = quality/coherence of the video overall

So your three control levers are:
1. **Prompt adherence**: Text encoder choice, CFG value, shift parameter
2. **Motion smoothness**: FPS setting, steps (indirectly), sampler quality
3. **Overall quality**: Steps, sampler, scheduler

## Finding Your Balance

Given the **+20% render increase is acceptable to you**, I'd suggest:

1. **Stick with the WAN 2.1 Lightspeed encoder** as your baseline—the adherence gain is worth the compute cost
2. **Test CFG values 7.5–9.0** with this encoder (it may respond differently than with umt5_xxl)
3. **Experiment with FPS**: Try **12 fps** and **20 fps** alongside your 16 fps to see if smoother motion compensates visually for any slight prompt drift
4. **Keep shift at 3.0–3.5** (you're doing i2v, right?) since the encoder is already tightening things

## The Real Question

**Are you doing primarily i2v or t2v?** Because if you're doing t2v, the shift/cfg/encoder interaction is different, and your optimal settings would shift accordingly. Also, **what happens to quality/motion if you bump shift down to 2.5** with the Lightspeed encoder—does adherence improve further, or do you lose temporal coherence?

--------------------

User prompt 7 of 11 - 6/6/2026, 2:15:25 PM:
Will have to get back to you on that. Wanted te get a second opinion on the settings and a better understanding through this session and the do some tinkering ... ok one more node to go the 'wan22imagetovideolatent' width 576, height 832 length 46 (3 * 16) + 1 (does the + 1 automatically not sure why) ... the node itself is tied to 'load image' but load image can be disabled / turned off aka toggling between i2v and t2v intrestring not sure how t2v sets the video size or length but wan22imagetovideolatent still plays a role then ...

Claude Haiku 4.5:
Excellent catch—you've identified something **genuinely clever** about your workflow setup, and there are some important nuances here about how WAN 2.2 handles i2v vs. t2v mode switching.

## Breaking Down Your Settings

### Length: 46 Frames (3 × 16 + 1)
You're right to be curious about the **+1**. Here's what's happening:

- **3 × 16 = 48 steps** in your KSampler
- **But you have 20 steps**, not 48, so that math doesn't match your actual config
- The **+1 is likely a boundary/anchor frame** in flow matching models—WAN needs a reference point (often the first or final frame) to condition the generation
- It's **not automatic**; it's explicitly set in the node because flow matching requires that extra frame for the math to work correctly

So your **46 frames at 16 fps = ~2.88 seconds of video**, plus the anchor frame = 47 total internally processed frames.

### Width/Height (576 × 832)
These are your **latent space dimensions**, not pixel dimensions. The actual output resolution depends on your VAE upscaling factor (typically 8x for standard VAEs), so you're generating roughly **4608 × 6656 pixels** internally before decoding.

## The i2v vs. t2v Toggle Mystery

This is where it gets interesting. You're right that **toggling the load_image node shouldn't break anything**, but here's what's actually happening:

### When load_image is ENABLED (i2v mode):
- **wan22imagetovideolatent** receives the image as a **conditioning input**
- The width/height/length from the node are used, **but the initial frame comes from your loaded image**
- The model generates 46 frames *conditioned on* that input image

### When load_image is DISABLED (t2v mode):
- **wan22imagetovideolatent still runs**, but it's generating a **blank/noise latent** as the starting point
- The width/height/length still apply
- The model generates 46 frames from *pure text conditioning* (no image anchor)

**The node doesn't "know" whether it's i2v or t2v**—that's determined by what's connected to its image input. If nothing is connected, it likely defaults to generating random noise or a blank latent.

## The Real Question

Your setup is **cleverly designed** because **wan22imagetovideolatent handles both modes**, but there's a potential issue:

**Does WAN 2.2 actually support true t2v generation, or is it primarily an i2v model?**

Looking at your model name: **wan2.2_ti2v_5B_fp16.safetensors**—the **"ti2v"** suggests **text-to-image-to-video**, which means:
- It *might* support t2v, but it's optimized for i2v
- Toggling load_image off might produce lower-quality t2v results because the model wasn't primarily trained for pure text-to-video

## Practical Recommendation

Before you tinker further, **test both modes side-by-side** with identical prompts/settings to see:
1. **Does t2v (load_image off) actually work**, or does it produce noise/artifacts?
2. **If it does work, is quality noticeably degraded** compared to i2v?
3. **Does the +1 frame still make sense** in t2v mode, or should you adjust it?

This will tell you whether your clever toggle is a **genuine workflow optimization** or a **limitation you're working around**. What do you observe when you disable load_image—does t2v generation actually succeed?

--------------------

User prompt 8 of 11 - 6/6/2026, 2:39:16 PM:
1. yes (by the by so does i2v) only struggling to find optimum settings ergo this session. 2. hard to say in both cases both prompt adherence and motion smoothness are a bit hit and miss. 3. I can not do anything about that as I stated comfyui (or the node adds 1 automatically ... ok I could subtract one so 3 x 16 = 48 punch in 47 and see what happens ...

Claude Haiku 4.5:
Smart thinking—**testing 47 vs. 46 is worth a quick experiment** to see if that +1 is actually necessary or just a quirk of how the node handles frame counting.

## What You've Learned So Far

You've actually diagnosed your real bottleneck quite clearly:

**It's not the settings—it's the model's inherent behavior.** Both i2v and t2v are "hit or miss" because **WAN 2.2 (especially ti2v) genuinely prioritizes motion coherence and visual quality over deterministic prompt adherence.** You can't tune your way out of that completely, only *manage* it with:

- Text encoder choice (Lightspeed vs. umt5_xxl = +20% render for better adherence)
- CFG tuning (higher = more prompt control, but risks artifacts)
- Shift parameter (fine-tunes the denoising trajectory)
- Prompt specificity and negative guidance

But there's a **ceiling** on how "prompt-obedient" WAN 2.2 will ever be, by design.

## Your Actual Path Forward

Instead of chasing perfect settings, **embrace the iterative nature**:

1. **Pick baseline settings** (you basically have them now: steps 20–25, cfg 7.5–8.5, Lightspeed encoder, shift 3.0–3.5 for i2v)
2. **Test 47 frames** vs. 46 and see if there's a perceptible difference
3. **Accept variance** and run 3–5 generations per prompt to find winners
4. **Use negative prompts heavily** to constrain unwanted behaviors rather than over-relying on positive prompt precision

The **+20% render time increase with Lightspeed encoder** is clearly your sweet spot for this hardware and use case. That's your tuning answer.

## One Final Thought

You mentioned **Flux 2 has better prompt adherence**—have you considered whether your actual workflow might benefit from **Flux for t2v** and **WAN 2.2 for i2v refinement**? They have different strengths, and toggling between them (similar to how you're toggling load_image) might give you better overall results than trying to force WAN 2.2 to do everything.

What's your take on that trade-off?

--------------------

User prompt 9 of 11 - 6/6/2026, 2:45:38 PM:
the seperate wan 2.2 i2v with high and low models is to big so that's why I have wan2.1 lightspeed but we'll get to that an other time. For now the tips and ideas for settings are insightful I'll give them a whirl and see if things improve a bit .... also I came across this : https://apatero.com/blog/wan-22-hidden-features-tips-guide-2025 : which echoes some of your suggestions, always nice to verify, and adds some other notions in the mix .... and last but not least there is this : https://diffusiondoodles.substack.com/p/wan22-text-2-image-generation : misuing wan2.2 as a t2i like sdxl or flux cunning but with mixed results  ....

Claude Haiku 4.5:
Great finds—those are **exactly the kind of real-world validation** you need. Let me take a quick look at what they're saying to see how it aligns with (and potentially expands on) what we've discussed.
Great finds! That Apatero guide is **incredibly comprehensive** and validates much of what we discussed, plus adds several nuances worth noting.

## Key Alignments with Our Discussion

**CFG Scheduling** is mentioned in the Apatero guide and worth noting for your workflow:
- **Start high (7.0)** for compositional adherence
- **End low (4.0)** for smoothness and detail
- This could be **exactly what you need** to balance your "hit or miss" prompt adherence issue while maintaining motion quality

**Sampler specifics** confirm your uni_pc_bh2 choice is solid, but the guide suggests **Euler or DPM++ 2M** also perform well—worth testing if you want to tweak further.

**Text encoding** (your Lightspeed discovery) aligns perfectly—the guide emphasizes **T5 encoder configuration with proper token length (256) and padding**, suggesting your instinct to try the WAN 2.1 encoder was spot-on.

## Additional Insights from the Guide

Some sections that might interest you given your constraints:

### Frame Interpolation Post-Processing
The guide mentions **RIFE or FILM for frame interpolation** to smooth 16fps output to 30fps. Given your 1+ minute render time, this could be a **post-processing win**—generate at 16fps, interpolate up rather than generating at 24fps natively.

### Motion-First Prompting
**Lead with motion descriptions** rather than subject descriptions. Instead of "a dog running," try **"camera following a dog running left to right, smooth tracking motion"**—this directly addresses your prompt adherence issues.

### TeaCache Optimization
The guide heavily emphasizes **TeaCache** for 2-3x speedup with minimal quality loss. On your 5060 RTX, this could be **game-changing**—have you enabled this in your workflow?

### CFG Per-Region (Advanced)
The guide mentions **different CFG for different regions** (higher for subjects, lower for backgrounds), though this requires advanced node support—worth exploring if available.

## About the Text-to-Image Misuse Article

The Substack link isn't accessible to me, but **I can infer what it's covering**: using WAN 2.2 as a pure t2i model (like Flux or SDXL) produces "mixed results" because **WAN is optimized for video motion**, not static image fidelity. Your toggle between i2v and t2v is technically possible but the ti2v designation in your model name suggests i2v is the intended primary use.

---

**My recommendation**: Start with **CFG scheduling (7.0→4.0)** and **TeaCache enablement** if you haven't already. Those two changes alone might solve your "hit or miss" adherence problem while keeping render times reasonable. Then report back on whether the quality/consistency improves.

--------------------

User prompt 10 of 11 - 6/6/2026, 3:23:25 PM:
Ok will do many thanks. The RIFE / FILM thing is interesting but a bit cryptic : https://github.com/GACLove/ComfyUI-VFI : is that part of the wan 2.2 workflow or something that is done in a separate workflow using the generated video?

Claude Haiku 4.5:
Great question—and the answer is **both are possible**, but they serve different purposes in your pipeline.

## What RIFE/FILM Does

**RIFE (Real-Time Intermediate Flow Estimation) and FILM (Frame Interpolation by Large Motion)** are **frame interpolation tools** that generate *new* frames *between* your existing frames. If you generate 16fps video, they can intelligently create intermediate frames to produce 30fps or 60fps output.

## Two Workflow Approaches

### Option 1: Post-Processing (Separate Workflow)
**Most common for WAN 2.2 users:**
- Generate your video at 16fps with WAN 2.2 (what you're doing now)
- Export the video
- Run it through a **separate ComfyUI workflow** using the VFI nodes (RIFE/FILM) to interpolate up to 30fps or 60fps
- **Advantage**: Fast initial generation, smooth final output
- **Disadvantage**: Extra processing step, requires loading and running another workflow

### Option 2: Integrated Workflow (Same Workflow)
**Less common but possible:**
- Generate WAN 2.2 output at lower FPS (e.g., 8fps)
- Chain the VFI interpolation **directly in the same ComfyUI workflow** after your video is decoded
- Output final smoothed video in one pass
- **Advantage**: Single workflow, no file management
- **Disadvantage**: Much slower total render time (interpolation adds significant compute)

## My Recommendation for Your Setup

**Option 1 (post-processing) is better for you** because:

1. **Your 5060 RTX is already stretched** generating at 16fps—interpolation would add 15-30+ minutes per video
2. **You already have good motion quality at 16fps**—interpolation just smooths it, doesn't improve prompt adherence or composition
3. **Flexibility**: You can selectively interpolate winning generations rather than interpolating everything
4. **The Apatero guide mentioned it as optional**, not essential

## How It Would Work

1. Generate your WAN 2.2 video normally (16fps)
2. Save/export the output
3. Create a separate lightweight ComfyUI workflow with:
   - **Load Video** node → your generated video
   - **RIFE or FILM VFI node** → interpolate frames
   - **Create Video** node → encode at 30fps
4. Run post-generation when you're happy with the content

The ComfyUI-VFI nodes you linked are **designed for this post-processing use case**, not integrated into the generation workflow itself (though technically you *could* chain them).

---

**TL;DR**: Use RIFE/FILM as a **separate, optional post-processing step** on videos you're satisfied with. Don't integrate it into your main WAN 2.2 workflow—it'll kill your render times on the 5060 RTX without solving your actual pain point (prompt adherence).

Does that clarify the workflow structure?

--------------------

User prompt 11 of 11 - 6/6/2026, 3:24:54 PM:
Okidoki thanks for the tip. Right lot of info here so going to chew on this stuff for some time will drop by at a later date.

Claude Haiku 4.5:
Perfect—you've got a solid gameplan now. You've clearly got a good intuition for this stuff (discovering the Lightspeed encoder advantage, the frame +1 quirk, the toggle between i2v/t2v), so the tinkering phase should yield some real improvements.

Key things to test when you circle back:
- **CFG scheduling** (7.0 → 4.0)
- **TeaCache** if you haven't enabled it
- **47 frames** vs. 46 to see if that +1 matters
- **Different shift values** with the Lightspeed encoder

And remember, **hit-or-miss results are partly by design with WAN 2.2**—embrace the iteration rather than chasing perfect settings. Sometimes the best output comes from running a few generations and picking the winner.

Good luck with the tinkering, and feel free to come back anytime you hit another snag or discover something interesting. Cheers!