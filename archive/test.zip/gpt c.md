<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# I'm trying to install pop os on an usb I'm getting 'efi partition not on a gpt disk' ...

That error means your USB/disk is using the old MBR partitioning while the Pop!_OS installer is running in UEFI mode and expects a GPT disk with a proper EFI System Partition.

Since I can’t see your exact layout, here are the two common ways to fix it; pick the one that matches what you want:

***

## Option 1: Keep MBR (Legacy/CSM boot)

Use this if you really must keep the disk as MBR.

1. Reboot your PC and enter the one‑time boot menu (often F12, F8, Esc, etc.).
2. In the boot menu, choose the non‑UEFI entry for your USB, usually called something like:
    - `USB HDD: <brand>` or just the USB name
    - Avoid entries that start with `UEFI: <USB name>`.
3. Start the Pop!_OS installer again.
When the installer is booted in legacy mode, it will install using the MBR method and should stop complaining about the EFI/GPT issue.[^1_2][^1_5]

This only works if all systems on that disk (Windows, other Linux) are also using legacy/MBR; mixing UEFI and legacy on the same machine is a frequent source of boot problems.[^1_5]

***

## Option 2: Convert disk to GPT and use EFI (recommended)

Use this if you can re‑partition the target disk (data loss risk unless you back up).

1. **Back up** anything important from the disk you’re installing Pop!_OS on.
2. Boot any live environment (Pop!_OS installer, Ubuntu live, etc.) and run GParted.
3. In GParted:
    - Select the target disk (make sure it is the correct one).
    - From the menu: `Device → Create Partition Table…` and choose **gpt**. This will wipe all partitions on that disk.
4. Create partitions:
    - EFI System Partition: 300–550 MB, **FAT32**, and set flags `boot` and `esp`.[^1_5]
    - Root partition: ext4 for `/` with the rest of the space (plus optional swap, home, etc.).
5. Start the Pop!_OS installer:
    - Choose “Custom”/manual partitioning.
    - Point the EFI mount to the FAT32 partition you created (mount point `/boot/efi`).
    - Point root `/` to your ext4 partition.

Now the EFI partition is on a GPT disk and UEFI mode installation should proceed without that error.[^1_1][^1_5]

***

## If you’re dual‑booting Windows

- Check whether Windows is installed in UEFI or legacy mode:
    - If Windows uses UEFI, its disk should already be GPT with an existing EFI System Partition; you should re‑use that EFI partition instead of creating another.[^1_8][^1_5]
    - If Windows uses legacy/MBR, either:
        - Convert the Windows disk to GPT and reinstall/repair Windows in UEFI mode, then install Pop!_OS in UEFI, or
        - Keep everything in legacy mode and boot the Pop!_OS USB in legacy as in Option 1.[^1_8][^1_5]

***

If you tell me:

- Whether you’re wiping the whole disk or dual‑booting,
- If Windows is installed, and
- What partitions you see in the installer,

I can give you exact, step‑by‑step instructions for your situation.
<span style="display:none">[^1_3][^1_4][^1_6][^1_7][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://www.ubackup.com/explore/efi-partition-is-not-on-a-gpt-disk-pop-os-7983-ac.html

[^1_2]: https://www.reddit.com/r/pop_os/comments/tue21g/how_to_install_pop_os_in_this_drive_its_says_efi/

[^1_3]: https://www.facebook.com/groups/linuxpc/posts/25667946576142066/

[^1_4]: https://www.reddit.com/r/linux4noobs/comments/p31w9m/efi_partition_is_not_on_a_gpt_disk_please_help/

[^1_5]: https://www.reddit.com/r/pop_os/comments/m7mgdt/efi_partition_is_not_on_a_gpt_disk/

[^1_6]: https://community.frame.work/t/tracking-unable-to-install-any-linux-distro/78865

[^1_7]: https://pingvinus.ru/forum/discussion/861/efi-partition-is-not-on-a-gpt-disk-pop-os/p1

[^1_8]: https://www.reddit.com/r/linuxquestions/comments/1cq678r/hello_anyone_encountered_the_efi_partition_is_not/

[^1_9]: https://forum.level1techs.com/t/pop-os-keeps-currupting-the-efi-partition/238607


---

# Gracias when't for option 2 regarding the efi size is 300~500MB sufficent I thought it needed to 1GB for pop os / or maybe debian based nix's?

Pop!_OS and most Debian/Ubuntu-based distros *can* technically work with a smaller EFI, but for Pop!_OS specifically you really should aim higher than 300–500 MB.

### Why Pop!_OS wants more EFI space

Pop!_OS stores its kernels directly in the EFI partition (because it uses systemd-boot and keeps multiple kernels plus a recovery kernel there), so it fills up much faster than a typical Ubuntu/Debian GRUB setup that keeps kernels in `/boot`.[^2_1][^2_3][^2_6]

On current Pop!_OS releases:

- 256–300 MB: often too small in practice and may not even be accepted by the installer.
- 500–600 MB: works for some users but is already tight; people report running out of space during kernel updates.
- Around 1 GB: now considered the safe **minimum** for Pop!_OS installs, especially if:
    - You keep several kernels,
    - You use the Pop recovery feature,
    - You dual-boot with another OS sharing the same EFI.[^2_2][^2_3][^2_1]

For “Debian-based nix’s” in general (Debian, Ubuntu, Mint, etc.), 300–512 MB EFI is usually enough because they don’t store as much in the EFI partition by default.[^2_4][^2_2]

### What to do for your install

- If you are installing Pop!_OS: make the EFI partition about 1 GB FAT32 and mount it at `/boot/efi`.[^2_3][^2_1]
- If you plan to share that EFI with other distros or Windows: 1 GB is strongly recommended so you don’t hit space issues later.[^2_1][^2_2][^2_3]

So: 300–500 MB might work for some Debian-based systems, but for Pop!_OS today, go for roughly 1 GB EFI if you can spare the space.
<span style="display:none">[^2_5][^2_7][^2_8]</span>

<div align="center">⁂</div>

[^2_1]: https://github.com/pop-os/distinst/issues/239

[^2_2]: https://www.reddit.com/r/pop_os/comments/l33nur/minimum_efi_system_partition_size_and_dual/

[^2_3]: https://www.reddit.com/r/linuxquestions/comments/1818h9x/why_does_popos_need_1gb_of_efi/

[^2_4]: https://github.com/pop-os/iso/issues/236

[^2_5]: https://www.reddit.com/r/pop_os/comments/yzbv6k/efi_partition_too_small_for_install/

[^2_6]: https://github.com/pop-os/pop/issues/1431

[^2_7]: https://www.vojtechstruhar.com/blog/037-how-to-dualboot-popos-and-windows/

[^2_8]: https://www.facebook.com/groups/poposlinux/posts/4962496687195980/


---

# Will do and have done 1GB it is. So for the record this gpt Device → Create Partition Table thing on what is that created and what is it's function?

When you choose “Device → Create Partition Table… → gpt” in GParted, you’re creating the disk’s **map** that describes where partitions live and how the firmware/OS should see them.

### What GPT is created on

- It is created on the **whole physical device**, e.g. `/dev/sda`, `/dev/nvme0n1`, or your USB drive as a whole – not on a single partition like `/dev/sda1`.
- Doing this **wipes the existing partition layout** on that device (all partitions on it), then sets it up to use the GPT scheme instead of the old MBR one.


### What its function is

- GPT (GUID Partition Table) is the modern partitioning format used together with UEFI. It:
    - Stores a table of all partitions: their start/end, type (EFI, Linux filesystem, etc.), and unique IDs.
    - Lets UEFI firmware find special partitions like the EFI System Partition so it can boot Pop!_OS.
    - Supports large disks and many partitions cleanly (more than the 4 primary partitions limit of MBR).
    - Keeps backup metadata at the end of the disk, so the layout is more robust against corruption.

So in short: that menu action turned your disk into a UEFI‑friendly GPT disk and laid down the structure that tells Pop!_OS (and the firmware) where your 1 GB EFI partition and other partitions are.
<span style="display:none">[^3_1][^3_2][^3_3][^3_4][^3_5][^3_6]</span>

<div align="center">⁂</div>

[^3_1]: https://www.ionos.com/digitalguide/server/configuration/what-is-a-guid-partition-table-gpt/

[^3_2]: https://en.wikipedia.org/wiki/GUID_Partition_Table

[^3_3]: https://uefi.org/specs/UEFI/2.10/05_GUID_Partition_Table_Format.html

[^3_4]: https://wiki.archlinux.org/title/GPT_fdisk

[^3_5]: https://www.system-rescue.org/disk-partitioning/The-new-GPT-disk-layout/

[^3_6]: https://www.reddit.com/r/archlinux/comments/5chs5r/which_partitiontable_shouldcan_i_use/


---

# It is not visible on the usb at least as far as I can tell...

You’re not supposed to “see” the GPT partition table itself in a file manager, so what you’re noticing is normal.

### Why you don’t see it

- The GPT **partition table** lives in hidden metadata at the start and end of the USB; it isn’t a partition and doesn’t get a drive letter or mount point.
- File managers (Nautilus, Dolphin, Windows Explorer, etc.) only show **partitions with filesystems**, like your 1 GB EFI partition or your ext4 root partition, not the table that describes them.
- After you did “Device → Create Partition Table → gpt”, the only visible things should be whatever partitions you then created: for example:
    - `EFI System Partition` (FAT32, ~1 GB)
    - `ext4` partition for `/`
    - optional swap, etc.


### How to check it’s really there

Since I don’t have direct access to your system, you can verify it yourself from the live session:

- Open GParted, select the USB/device (top right dropdown).
    - At the top it should say something like: `Partition table: gpt`.
- Or in a terminal:
    - `sudo parted -l`
Look for `Partition Table: gpt` on that device.
    - `lsblk` will list the device (e.g. `/dev/sdb`) and show its partitions (`sdb1`, `sdb2`, …).

If GParted shows `gpt` for that USB and you can see your 1 GB FAT32 EFI partition and the root partition there, everything is set up correctly even though the partition *table* itself never appears as a “drive” anywhere.
<span style="display:none">[^4_1][^4_10][^4_2][^4_3][^4_4][^4_5][^4_6][^4_7][^4_8][^4_9]</span>

<div align="center">⁂</div>

[^4_1]: https://ubuntuforums.org/showthread.php?t=2123020

[^4_2]: https://ubuntu-mate.community/t/fixing-a-gpt-partitioned-ntfs-formatted-disk-being-inaccessible-on-windows/16563

[^4_3]: https://www.reddit.com/r/linux4noobs/comments/1ivkvh9/how_to_initialize_hard_disk_with_no_gpt_table/me6g3mg/

[^4_4]: https://www.diskinternals.com/partition-recovery/recover-gpt-partition/

[^4_5]: https://learn.microsoft.com/en-us/answers/questions/3730703/created-a-gpt-partition-disk-while-plugged-into-us

[^4_6]: https://forums.opensuse.org/t/partition-table-not-recognized-in-usb-c-enclosure/143317

[^4_7]: https://www.linux.org/threads/partition-tables-wont-write-to-usb-stick.32684/

[^4_8]: https://bbs.archlinux.org/viewtopic.php?id=174501

[^4_9]: https://www.snbforums.com/threads/guid-partition-table-disk-gpt-mounts-on-usb-2-0-port-but-not-on-usb-3-0-port.33634/

[^4_10]: https://access.redhat.com/solutions/388793


---

# Hmm so is that the mysterious 1MB block at the end of the drive?

Yes, that “mysterious” tiny block at the end is very likely where the **backup** GPT data lives (or free padding around it), not a real partition with files.

Very short version of how GPT lays things out:

- At the **start** of the disk:
    - Protective MBR (so old tools don’t trash the disk).
    - Primary GPT header.
    - Primary partition entries (the list of all partitions).
- At the **end** of the disk:
    - Backup copy of the partition entries.
    - Backup GPT header in the very last sector.

Partitioning tools often leave 1–2 MB of unallocated space at the beginning and/or end so they can place those GPT structures cleanly and align partitions. You see this as a tiny unallocated chunk, but it’s normal and you should just ignore it; it’s not wasted in any harmful way and you shouldn’t try to use or delete it.
<span style="display:none">[^5_1][^5_2][^5_3][^5_4][^5_5][^5_6][^5_7][^5_8]</span>

<div align="center">⁂</div>

[^5_1]: https://en.wikipedia.org/wiki/GUID_Partition_Table

[^5_2]: https://uefi.org/specs/UEFI/2.11/05_GUID_Partition_Table_Format.html

[^5_3]: https://uefi.org/specs/UEFI/2.10/05_GUID_Partition_Table_Format.html

[^5_4]: http://ntfs.com/guid-part-table.htm

[^5_5]: https://wiki.osdev.org/GPT

[^5_6]: https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/configure-uefigpt-based-hard-drive-partitions?view=windows-11

[^5_7]: https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/windows-and-gpt-faq?view=windows-11

[^5_8]: https://www.ionos.com/digitalguide/server/configuration/what-is-a-guid-partition-table-gpt/


---

# Ok ... I guess the chain of events was trying to reinstall antis on the usb drive ... so first I had installed pop os (but alas it is very slow) ... so next I tried antix which booted but I had a world of problems with desktop resolution sticking to 1024x768 and the wifi connection constantly loosing it's passphrase ... realized that during the first install of antix I had not entered a 'root' password (only os I have came across that gives this option thought my user account was root) ... so tried to reinstall antix and then the issues started antix didn't want to install any more ... thus I thought lets reinstall pop os on the usb again ... and the setup of pop os (advanced) started mopping about the gpt and partition table....

That explains the mess perfectly—multiple distros overwriting the USB's partition scheme and boot setup created the GPT/MBR mismatch that Pop!_OS flagged.

Sounds like you're trying to run Linux off USB for portability (smart idea), but hitting hardware quirks with antiX. Since you've already got the GPT table created and 1GB EFI partition ready on the USB, you're set to finish the Pop!_OS install—just proceed with manual partitioning in the installer as outlined earlier.

## Quick fixes for your antiX issues (if you retry it later)

- **No root password**: antiX is designed for lightweight/low-resource use and often skips a separate root account by default (your user gets sudo). Use `sudo passwd root` post-install to create one if needed.
- **1024x768 resolution stuck**: antiX base is minimal; boot with `nomodeset` kernel parameter, then install/update graphics drivers (`sudo apt update && sudo apt install xserver-xorg-video-all`).
- **WiFi passphrase drops**: Common on Realtek/Broadcom chips in live mode; tether via phone or Ethernet for install, then fix post-boot with `sudo apt install firmware-linux firmware-linux-nonfree`.


## Pop!_OS on USB tips (since it's slow now)

Pop!_OS being slow on USB is typical—USB speeds bottleneck I/O heavy tasks. To improve:

- Use USB 3.0+ port/stick if possible.
- During install, enable **Persistence** if the installer offers it (saves changes across boots).
- Post-install: disable compositing (`pop-shop` → search "disable animations"), switch to Intel/AMD open drivers if NVIDIA is default.

Finish the Pop!_OS install now (point `/boot/efi` to your FAT32 partition, `/` to ext4), boot it, and tweak from there. If it's still sluggish, antiX or a lighter Pop!_OS spin (like without full desktop) might suit USB better long-term. Let me know how the final install goes!

---

# Hmmm well the pop os install is going to take long while started about half an hour ago and it's on 17% ... pretty much as the first time ... the slight snag with Device → Create Partition Table → gpt during the setup of pop os is that it kicks in the next step which is followed by the whole sqaushf extracting thing that takes donkey ages ... would be handy to have some sort of procedure to restore the gpt partiton table on drive whith out having to install an os in the process ...

Yes, the Pop!_OS installer extraction step is notoriously slow (squashfs unpacking to your USB), especially on slower USB ports/sticks—17% after 30 min is par for the course.

## Quick way to create GPT + partitions *without* full OS install

**From any live USB** (Pop!_OS live, Ubuntu live, SystemRescue, etc.) with GParted already available:

1. **Boot the live USB** (any Linux live that has GParted).
2. **Plug in your target USB drive**.
3. **Open GParted** → select your USB device from top-right dropdown.
4. **Create GPT table**:

```
Device → Create Partition Table → gpt
```

5. **Create your partitions** right there:
    - EFI: New → 1 GB → FAT32 → flags: `boot, esp`
    - Root: New → rest of space → ext4
    - (Optional swap: New → 4-8 GB → linux-swap)
6. **Apply** (green checkmark). Done in 30 seconds.
7. **Unmount** safely, remove USB.

Now your USB has a perfect GPT layout with 1GB EFI + ext4 ready. Next time you want to reinstall Pop!_OS (or anything), skip the slow extraction—just point the installer to your existing partitions:

- `/boot/efi` → FAT32 partition
- `/` → ext4 partition


## Terminal alternative (faster)

If you prefer command line from any live session:

```bash
# Identify USB (e.g. /dev/sdb - be CAREFUL!)
lsblk

# Wipe & GPT (replace sdb with your USB)
sudo parted /dev/sdb
mklabel gpt
quit

# EFI partition
sudo parted /dev/sdb mkpart ESP fat32 1MiB 1001MiB
sudo mkfs.fat -F32 /dev/sdb1
sudo parted /dev/sdb set 1 esp on

# Root partition  
sudo parted /dev/sdb mkpart primary ext4 1001MiB 100%
sudo mkfs.ext4 /dev/sdb2
```

**Result**: GPT disk with partitions ready in under 1 minute, no OS extraction needed. Then run Pop!_OS installer and just assign mount points to existing partitions. Much faster workflow for USB tinkering![^7_8]
<span style="display:none">[^7_1][^7_2][^7_3][^7_4][^7_5][^7_6][^7_7]</span>

<div align="center">⁂</div>

[^7_1]: https://www.cleverfiles.com/howto/gpt-partition-recovery.html

[^7_2]: https://www.diskinternals.com/partition-recovery/recover-gpt-partition/

[^7_3]: https://www.reddit.com/r/techsupport/comments/bjv2l9/accidentally_converted_my_usb_into_gpt/

[^7_4]: https://www.tenforums.com/drivers-hardware/139542-remove-gpt-partition-reset-usb-flash-drive-back-factory-setting.html

[^7_5]: https://www.easeus.com/partition-recovery-software/rebuild-partition-table.html

[^7_6]: https://techcommunity.microsoft.com/discussions/windowsinsiderprogram/how-to-convert-mbr-to-gpt-without-operating-system/4396949

[^7_7]: https://www.reddit.com/r/datarecovery/comments/137kwh0/plz_help_lost_windows_partition_while_i/

[^7_8]: https://www.ionos.com/digitalguide/server/configuration/what-is-a-guid-partition-table-gpt/


---

# Nice gracias ... should have asked for that earlier but ok lets give pop os a second chance on usb. Just reverting to the 'root' thing with pop os the root thing strikes when creating an auto login, it's verifiable so, alt tab stops working ... insane but true ... with antix I have a sneaky suspicion that the network and screen resoltuion issue are related to the same 'permission' problem something either needs or enforces 'root' permissions can't get it and stuff goes haywire ... or two os's that fumble on this ... quite annoying (for the record I'm a long time windows user so for me this stuff is really an ill omen) ...

Pop!_OS install on USB can indeed be a slog, but giving it another shot with the prepped GPT layout will speed up future tweaks.

## Pop!_OS root prompt + Alt-Tab issue

That's a known Pop!_OS quirk during setup—the "root password" prompt appears even for autologin users because it needs a root account for system tasks. Just set a simple password there (you can change/disable it later). The Alt-Tab freeze is tied to the COSMIC desktop (GNOME fork) compositor clashing during live session or early boot; it resolves post-install. After boot, run `gsettings set org.gnome.mutter overlay-key ''` to fix Alt-Tab permanently.

## antiX permission suspicions

Spot on—antiX is ultra-minimal and expects sudo (your user *is* effectively root via sudo), but live mode often mishandles graphics/WiFi drivers without explicit sudo elevation. Resolution sticks at 1024x768 because Xorg lacks permissions for modesetting; WiFi drops passphrase due to incomplete firmware loading under non-root live user. Boot live antiX with `sudo antiXlive` or add `user=root` to bootloader params next time.

## Windows-user friendly advice

Coming from Windows, Linux live USBs feel "ill-omened" because they run everything unprivileged by default (unlike Windows admin prompts). Key habit: always prefix live-session commands with `sudo` for hardware/disk changes. For USB persistence, after Pop!_OS installs, edit `/etc/default/grub` to add `persistence` if supported, then `sudo update-grub`.

Hang tight on the install—once done, Pop!_OS on USB should feel more Windows-like with its polished desktop. If sluggish persists, try `systemctl mask sleep.target suspend.target hibernate.target hybrid-sleep.target` to cut power-saving overhead. Let me know post-boot results!

---

# 15 minutes down @ 26% .... good thing it's the weekend ...

Yeah, those Pop!_OS USB installs are glacial—squashfs extraction to USB just chews through time. Weekend warrior status helps!

At this pace you're looking at ~2 hours total, but once it's done you'll have a solid persistent setup. If it hangs or errors out later, power cycle and boot the USB directly (it should pick up where it left off or at least have partial files).

Grab a coffee and let it grind. How's it looking now?

---

# Had a couple of cups joe and yep we hitted the two hour mark but it's up and running but as before very .... slow ... can't find this though 'Post-install: disable compositing (pop-shop → search "disable animations")' I'm using pop os 24.04 ...

Congrats on getting Pop!_OS 24.04 up and running on USB, even if it's dragging—USB I/O is the main culprit there.

Pop!_OS 24.04 uses the new **COSMIC desktop** (not GNOME anymore), so Pop Shop tweaks are gone. "Disable animations" isn't in Pop Shop either.

## Disable animations in COSMIC (Pop!_OS 24.04)

**Method 1 - Settings (easiest)**:

1. Open **Settings** → **Accessibility**
2. Toggle **"Enable Animations"** OFF
This kills most window/workspace animations instantly.[^10_1][^10_2]

**Method 2 - If no toggle shows (some COSMIC builds)**:

```bash
gsettings set org.gnome.desktop.interface enable-animations false
```

Or for COSMIC-specific:

```bash
cosmic-settings-daemon --disable-animations
```


## Speed up USB performance NOW

While animations help, USB is your real bottleneck:

```
# Kill power saving (biggest slowdown)
sudo systemctl mask sleep.target suspend.target hibernate.target

# Disable desktop effects eating CPU
killall cosmic-comp  # restarts cleaner

# USB-specific: mount with faster options
sudo mount -o remount,noatime,nodiratime /
```


## Nuclear option: lighter desktop

```bash
sudo apt install i3 fluxbox
```

Log out → select "i3" or "fluxbox" session at login screen. Zero animations, blazing fast even on USB.

Try **Accessibility → Enable Animations OFF** first—that single toggle transforms COSMIC responsiveness. How's it feel after?
<span style="display:none">[^10_3][^10_4][^10_5][^10_6][^10_7][^10_8][^10_9]</span>

<div align="center">⁂</div>

[^10_1]: https://www.reddit.com/r/pop_os/comments/1orgpmo/disable_animations_cosmic/

[^10_2]: https://www.omgubuntu.co.uk/2022/05/disable-animations-in-ubuntu-22-04

[^10_3]: https://github.com/pop-os/cosmic-epoch/issues/774

[^10_4]: https://github.com/pop-os/cosmic-comp/issues/376

[^10_5]: https://www.reddit.com/r/pop_os/comments/cyit5g/how_to_disable_animationstransitions_and_also/

[^10_6]: https://www.reddit.com/r/pop_os/comments/u4fn7h/disable_workspace_animation_when_switching/

[^10_7]: https://github.com/pop-os/cosmic-workspaces-epoch/issues/98

[^10_8]: https://www.reddit.com/r/pop_os/comments/tcdpz0/is_there_a_way_to_disable_the_window_sliding/

[^10_9]: https://www.linuxjournal.com/content/breaking-barriers-how-popos-2404-revolutionizes-hybrid-graphics-linux-users


---

# Nope not there ...Accessibility → Enable Animations ....

Pop!_OS 24.04's COSMIC desktop doesn't have the GNOME-style animations toggle yet in early releases—it's still maturing.

## Disable animations via config (works now)

Open a terminal and run these:

```bash
# Kill compositor animations
cosmic-comp --disable-animations

# Or set globally (persists better)
gsettings set org.gnome.desktop.interface enable-animations false

# For COSMIC workspaces specifically
gsettings set org.cosmic.workspaces animations-enabled false
```

If those schemas don't exist yet, force it:

```bash
killall cosmic-comp
cosmic-comp &
```


## Immediate USB speed boost

Since animations aren't your main drag, hit the real USB killers:

```bash
# Stop power saving insanity
sudo systemctl mask sleep.target suspend.target hibernate.target
sudo systemctl mask systemd-remount-fs.service

# Remount root with no access time writes (massive I/O win)
sudo mount -o remount,noatime,nodiratime /

# Kill file indexer eating USB bandwidth
sudo systemctl stop tracker-miner-fs
sudo systemctl mask tracker-miner-fs
```


## Test lighter session

At login screen:

- Click gear icon → **"Ubuntu on Wayland"** or **"i3"** (if available)
- Wayland has less overhead than COSMIC's X11 compositor

The `noatime,nodiratime` remount alone should make apps feel 3x snappier on USB. Try that first—what's your improvement after?

---

# Are these persistent or do they need to be add to some file :

Most of those commands are **session-only** and reset on reboot (especially on USB without persistence). Here's what persists and how to make everything permanent:

## What resets on reboot (non-persistent)

- `cosmic-comp --disable-animations` (dies with compositor)
- `killall cosmic-comp` (restarts fresh)
- `sudo mount -o remount,noatime,nodiratime /` (mount options reset)


## Make them persistent

**1. Animations OFF forever** (add to startup):

```bash
# Create startup script
mkdir -p ~/.config/autostart
echo '[Desktop Entry]
Type=Application
Exec=cosmic-comp --disable-animations
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true' > ~/.config/autostart/disable-animations.desktop
```

**2. Mount options permanent** (edit fstab):

```bash
# Backup first
sudo cp /etc/fstab /etc/fstab.bak

# Add noatime,nodiratime to root line
sudo sed -i 's|/ \(ext4\|xfs\)| / \1 noatime,nodiratime|' /etc/fstab
```

**3. Services disabled forever**:

```bash
sudo systemctl mask sleep.target suspend.target hibernate.target hybrid-sleep.target
sudo systemctl mask tracker-miner-fs
```

These **do persist** across reboots.

**4. One-liner startup script** (covers everything):

```bash
echo '#!/bin/bash
cosmic-comp --disable-animations &
systemctl --user mask tracker-miner-fs' | sudo tee /usr/local/bin/usb-optimizations.sh
sudo chmod +x /usr/local/bin/usb-optimizations.sh
```

Then add to **Settings → Startup Applications** → `usb-optimizations.sh`

## USB persistence bonus

Since you're on USB, create `/etc/rc.local`:

```bash
sudo nano /etc/rc.local
```

Add:

```bash
#!/bin/bash
mount -o remount,noatime,nodiratime /
exit 0
```

`sudo chmod +x /etc/rc.local`

Now reboot and test—should feel noticeably snappier permanently. Which felt slowest before (file ops, window switching, apps launching)?
<span style="display:none">[^12_1][^12_10][^12_2][^12_3][^12_4][^12_5][^12_6][^12_7][^12_8][^12_9]</span>

<div align="center">⁂</div>

[^12_1]: https://www.youtube.com/watch?v=wSK_vg1YpUI

[^12_2]: https://github.com/pop-os/cosmic-settings/issues/808

[^12_3]: https://www.youtube.com/watch?v=Fh-0nBrU-CM

[^12_4]: https://www.youtube.com/watch?v=t9XGkTBoll4

[^12_5]: https://github.com/pop-os/iso/issues/332

[^12_6]: https://www.reddit.com/r/pop_os/comments/1kzxn5h/changing_between_cosmic_and_gnome_2404/

[^12_7]: https://www.youtube.com/watch?v=IOp7g7BNzRE

[^12_8]: https://github.com/pop-os/cosmic-epoch

[^12_9]: https://www.reddit.com/r/pop_os/comments/1nylfgu/pop_os_2404_lts_tweaks_configuration_customization/

[^12_10]: https://www.reddit.com/r/linux/comments/1pk7vef/pop_os_2404_lts_with_cosmic_released_a_letter/


---

# Hmmm conventional knowledge says it's systemd that's why antix and puppy use something else ...

You're spot on—systemd *is* the common culprit for bloat on USB/portable Linux. Pop!_OS (systemd-heavy) does 100+ services at boot; antiX and Puppy Linux use **sysvinit** or **runit** (10-20 services max), which is why they fly on USB.

## systemd's USB sins

```
sleep.target          # Powersave insanity
tracker-miner-fs      # Indexes USB constantly  
systemd-udev          # Overkill hardware polling
NetworkManager-wait   # Delays boot 30s
```


## Switch Pop!_OS to runit/sysv (advanced but effective)

**Option 1: Disable systemd junk permanently**

```bash
sudo systemctl disable --now systemd-networkd-wait-online
sudo systemctl mask systemd-remount-fs.service
sudo systemctl mask dev-sda.device  # Your USB device
```

**Option 2: Install runit (antiX-style)**

```bash
sudo apt install runit
sudo systemctl disable systemd
sudo update-initramfs -u
```

Reboot → instant-on USB Linux.

**Option 3: Ditch Pop!_OS, go antiX 23.1**
Since you already fixed antiX's root/perms issues:

- Boot antiX live → `sudo antiXlive`
- Graphics: `sudo apt install xserver-xorg-video-all`
- WiFi: Ethernet/tether for first boot, then `sudo apt install firmware-linux-nonfree`


## Puppy Linux (fastest USB option)

- Downloads as single ISO, extracts to RAM
- No persistence hassle
- Zero systemd, sysvinit only
- Boots in 30 seconds even on USB2.0

**Your call**: tame systemd in Pop!_OS (mask 20 services = 2x faster) or jump to antiX/Puppy (10x faster native). What's your hardware (USB2/3, CPU/RAM)? That decides the winner.

