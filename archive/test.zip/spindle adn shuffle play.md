<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# I'm having a bit of an issues with the following freeabsic code. The idea is to be able to navigate back to the previous picked number (when playing in shuffle mode) but for that I need to keep tab of the sequence of the specific media item in a specific list type ... I tried using listseqh but it does not quite cut it logic wise ... : \#include "vbcompat.bi"

' setup playlist
type lrec
as string  listfile(any)
as string  listtype(any)
as integer listhist(any)
as integer listseqh(any)
end type
dim shared    listrec as lrec
common shared listnr  as integer
common shared listsq  as integer
listnr = 0
listsq = 0

' generate list of files recursive
' based on recursive dir code of coderjeff [https://www.freebasic.net/forum/viewtopic.php?t=5758](https://www.freebasic.net/forum/viewtopic.php?t=5758)
function createlist(folder as string, filterext as string, listname as string) as integer
' setup filelist
dim chk            as boolean
redim path(1 to 1) As string
dim as integer i = 1, n = 1, attrib
dim file           as string
dim fileext        as string
dim maxfiles       as integer

    #ifdef __FB_LINUX__
      const pathchar = "/"
    #else
      const pathchar = "\"
    #endif
    
    if chdir(folder) <> 0 then
        'logentry("warning", "path " + chkpath + " not found")
        'chdir(dummy)
        print folder + " " + "not found"
        return 0
    end if
    
    ' read dir recursive starting directory
    path(1) = folder 
    if( right(path(1), 1) <> pathchar) then
        file = dir(path(1), fbNormal or fbDirectory, @attrib)
        if( attrib and fbDirectory ) then
            path(1) += pathchar
        end if
    end if
    
    while i <= n
    file = dir(path(i) + "*" , fbNormal or fbDirectory, @attrib)
        while file > ""
            if (attrib and fbDirectory) then
                if file <> "." and file <> ".." then
                    ' todo evaluate limit recursive if starting folder is root
                    if len(path(1)) > 3 then
                        n += 1
                        redim preserve path(1 to n)
                        path(n) = path(i) + file + pathchar
                    else
                        'logentry("terminate", "scanning from root dir not supported! " + path(i))
                    end if
                end if
            else
                fileext = lcase(mid(file, instrrev(file, ".")))
                if instr(1, filterext, fileext) > 0 and len(fileext) > 3 then 
                    listnr += 1
                    redim preserve listrec.listfile(0 to listnr)
                    redim preserve listrec.listtype(0 to listnr)
                    redim preserve listrec.listhist(0 to listnr)
                    redim preserve listrec.listseqh(0 to listnr)
                    listrec.listfile(listnr)  = path(i) & file
                    listrec.listtype(listnr) = listname
                    listrec.listhist(listnr) = 0
                    listrec.listseqh(listnr) = 0
                    maxfiles += 1
                else
    '                    logentry("warning", "file format not supported - " + path(i) \& file)
end if
end if
file = dir(@attrib)
wend
i += 1
wend

    ' chk if filelist is created
    '    if FileExists(filelist) = false then
'        logentry("warning", "could not create filelist: " + filelist)
'    end if

    return maxfiles
    end function

' used for listplay passes selected item to current
function getcurrentlistitem(listtype as string, filename as string) as integer
dim itemnr as integer = -1

    for i as integer = 0 to listnr
        with listrec
            itemnr += 1
            if listrec.listtype(i) = listtype and listrec.listfile(i) = filename then
                'print listrec.listfile(i)
                'print listrec.listtype(i)
                'print listrec.listhist(i)
                exit for
            end if
        end with
    next i
    
    return itemnr
    end function

dim media as string
dim currentitem as integer

print "music "; createlist("g:\data\mp3", ".mp3", "music")
print "image "; createlist("g:\data\images\classical paintings", ".jpg", "image")
print "slide "; createlist("g:\data\images\flickr\winter mixed", ".jpg", "slide")
print "video "; createlist("g:\data\aerialtv", ".mp4", "video")
print "shade "; createlist("f:\osd\media\glsl", ".gls", "shade")
print
print "total "; listnr
print

media = "g:\data\mp3\beatless\the beatles - pennylane.mp3"
currentitem = getcurrentlistitem("music", media)
print "music selected " \& listrec.listfile(currentitem) \& " " \& currentitem
listrec.listhist(currentitem) = currentitem
print "history itemnr " \& listrec.listhist(currentitem)
listrec.listseqh(currentitem) += 1
print "sequence       " \& listrec.listseqh(currentitem)
print

media = "g:\data\mp3\beatless\the beatles - fixing a hole.mp3"
currentitem = getcurrentlistitem("music", media)
print "music selected " \& listrec.listfile(currentitem) \& " " \& currentitem
listrec.listhist(currentitem) = currentitem
print "history itemnr " \& listrec.listhist(currentitem)
listrec.listseqh(currentitem) += 1
print "sequence       " \& listrec.listseqh(currentitem)
print

media       = "g:\data\images\classical paintings\102.jpg"
currentitem = getcurrentlistitem("image", media)
print "image selected " \& listrec.listfile(currentitem) \& " " \& currentitem
listrec.listhist(currentitem) = currentitem
print "history itemnr " \& listrec.listhist(currentitem)
print

media       = "g:\data\images\flickr\winter mixed\crystal chains.jpg"
currentitem = getcurrentlistitem("slide", media)
print "slide selected " \& listrec.listfile(currentitem) \& " " \& currentitem
listrec.listhist(currentitem) = currentitem
print "history itemnr " \& listrec.listhist(currentitem)
print

media       = "g:\data\aerialtv\sao paulo brazil.mp4"
currentitem = getcurrentlistitem("video", media)
print "video selected " \& listrec.listfile(currentitem) \& " " \& currentitem
listrec.listhist(currentitem) = currentitem
print "history itemnr " \& listrec.listhist(currentitem)
print

media       = "f:\osd\media\glsl\singularity.gls"
currentitem = getcurrentlistitem("shade", media)
print "shade selected " \& listrec.listfile(currentitem) \& " " \& currentitem
listrec.listhist(currentitem) = currentitem
print "history itemnr " \& listrec.listhist(currentitem)
print

/' debug
dim needle as string = "images"
for i as integer = 0 to listnr
with listrec
if listrec.listtype(i) = needle then
print listrec.listfile(i)
print listrec.listtype(i)
print listrec.listhist(i)
end if
end with
next i
'/
sleep

The core of the problem is that `listseqh()` as used in your code cannot by itself represent a *play history* across multiple list types and shuffle order. You need a separate history structure that records “which list type, which index, in which order it was played”, and you also have a small logic issue in `getcurrentlistitem`.

## Issues in the current code

1. `getcurrentlistitem` logic
You initialize `itemnr` to `-1` and then increment it on *every* loop iteration, regardless of whether you found a match or not.
In effect, the returned value is always equal to the last loop index (`listnr`), whether a match was found early or not. Better is to use the loop index directly or set `itemnr = -1` and assign when matched.
2. Per–item `listseqh` is not a global play sequence
`listseqh(currentitem) += 1` counts how many times that particular item has been selected, not its position in the *overall* shuffled play order.
If you want “previous” to go back through the *sequence* of played items, you must store that sequence somewhere else (e.g. as a stack or list of indices).
3. Mixing list type and history
To go “previous” you must know *both* the index in `listrec.listfile()` and, if needed, which `listtype` it belonged to. Right now `listhist()` is just set to `currentitem`, so it does not help with a multi‑step history.

## Fixing `getcurrentlistitem`

A more straightforward and correct version:

```freebasic
function getcurrentlistitem(listtype as string, filename as string) as integer
    for i as integer = 0 to listnr
        if listrec.listtype(i) = listtype and listrec.listfile(i) = filename then
            return i
        end if
    next i
    return -1   ' not found
end function
```

This returns the actual array index directly and `-1` if not found.

## Adding a real play history

You need an array that records the order in which items were played (regardless of list type), for example:

```freebasic
dim shared playHist()  as integer   ' indices into listrec.*
dim shared playPos     as integer   ' current position in playHist
dim shared playCount   as integer   ' number of entries in playHist
```

Each time you “select” or play an item (in shuffle mode):

```freebasic
sub add_to_history(idx as integer)
    ' optionally cut off forward history if user moved back and then chose a new item
    if playPos < playCount - 1 then
        playCount = playPos + 1
        redim preserve playHist(0 to playCount - 1)
    end if

    playCount += 1
    redim preserve playHist(0 to playCount - 1)
    playHist(playCount - 1) = idx
    playPos = playCount - 1
end sub
```

When you select an item:

```freebasic
currentitem = getcurrentlistitem("music", media)
if currentitem >= 0 then
    add_to_history(currentitem)
end if
```

Now “previous” and “next” become trivial:

```freebasic
function prev_item() as integer
    if playPos > 0 then
        playPos -= 1
        return playHist(playPos)
    else
        return -1  ' already at first
    end if
end function

function next_item() as integer
    if playPos < playCount - 1 then
        playPos += 1
        return playHist(playPos)
    else
        return -1  ' already at last
    end if
end function
```

Use `prev_item` to implement your “back to previous picked number”.

## How `listhist` and `listseqh` can still be used

If you still want per–item counters:

- `listhist(i)` can store “has this item ever been played” or “last play position in the global history”.
- `listseqh(i)` can count how many times item `i` was played.

Example:

```freebasic
sub add_to_history(idx as integer)
    playCount += 1
    redim preserve playHist(0 to playCount - 1)
    playHist(playCount - 1) = idx
    playPos = playCount - 1

    listrec.listhist(idx) = playCount      ' last position in history
    listrec.listseqh(idx) += 1             ' times played
end sub
```

This separation—global `playHist()` for navigation, per‑item `listseqh()`/`listhist()` for statistics—gives you reliable “previous/next” in shuffle mode without relying on `listseqh` as a sequence index.
<span style="display:none">[^1_1][^1_10][^1_2][^1_3][^1_4][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://www.freebasic.net/wiki/wikka.php?wakka=CatPgFunctIndex

[^1_2]: https://www.vbforums.com/showthread.php?796717-Shuffling-a-list

[^1_3]: https://www.freebasic.net/wiki/wikka.php?wakka=KeyPgFunction

[^1_4]: https://ps.allbasic.info/index6402.html?topic=4130.0

[^1_5]: https://documentation.help/FreeBASIC/KeyPgFunction.html

[^1_6]: https://www.reddit.com/r/vba/comments/9vluwr/for_loop_through_a_listbox_is_unexpectedly/

[^1_7]: https://www.auditsi.eu/?wpfb_dl=26

[^1_8]: https://stackoverflow.com/questions/23576469/how-to-shuffle-array-in-vb

[^1_9]: https://www.freebasic.net/wiki/wikka.php?wakka=CatPgFullIndex

[^1_10]: https://freebasic.net/forum/viewtopic.php?t=7627


---

# Hmm that's quite a refactor ... could you do a re-write of the code with the alterations and fix you suggested so I can compare it to what I have now?

The changes can be done with minimal disruption: fix `getcurrentlistitem`, add a small play-history structure, and update the “selected” blocks to use it. Below is a full rewrite of your code with only those alterations, clearly marked with comments.

## Updated full code

```freebasic
#include "vbcompat.bi"

' setup playlist
type lrec
    as string  listfile(any)
    as string  listtype(any)
    as integer listhist(any)   ' last position in global history
    as integer listseqh(any)   ' times played
end type
dim shared    listrec as lrec
common shared listnr  as integer
common shared listsq  as integer
listnr = 0
listsq = 0

' ---- NEW: global play history for shuffle navigation ----
dim shared playHist() as integer   ' indices into listrec.*
dim shared playPos    as integer   ' current position in history
dim shared playCount  as integer   ' number of valid entries in playHist

' add played item to history
sub add_to_history(idx as integer)
    ' if user went back and now picks a new item, cut off forward history
    if playPos < playCount - 1 then
        playCount = playPos + 1
        redim preserve playHist(0 to playCount - 1)
    end if

    playCount += 1
    redim preserve playHist(0 to playCount - 1)
    playHist(playCount - 1) = idx
    playPos = playCount - 1

    ' per-item statistics (reuse your existing arrays)
    listrec.listhist(idx) = playCount        ' last position in global history
    listrec.listseqh(idx) += 1               ' times this item has been played
end sub

function prev_item() as integer
    if playPos > 0 then
        playPos -= 1
        return playHist(playPos)
    else
        return -1   ' already at first item in history
    end if
end function

function next_item() as integer
    if playPos < playCount - 1 then
        playPos += 1
        return playHist(playPos)
    else
        return -1   ' already at last item in history
    end if
end function
' ---- END NEW HISTORY CODE ----

' generate list of files recursive
' based on recursive dir code of coderjeff
function createlist(folder as string, filterext as string, listname as string) as integer
    ' setup filelist
    dim chk            as boolean
    redim path(1 to 1) As string
    dim as integer i = 1, n = 1, attrib
    dim file           as string
    dim fileext        as string
    dim maxfiles       as integer

    #ifdef __FB_LINUX__
      const pathchar = "/"
    #else
      const pathchar = "\"
    #endif

    if chdir(folder) <> 0 then
        print folder + " " + "not found"
        return 0
    end if
 
    ' read dir recursive starting directory
    path(1) = folder 
    if( right(path(1), 1) <> pathchar) then
        file = dir(path(1), fbNormal or fbDirectory, @attrib)
        if( attrib and fbDirectory ) then
            path(1) += pathchar
        end if
    end if

    while i <= n
        file = dir(path(i) + "*" , fbNormal or fbDirectory, @attrib)
        while file > ""
            if (attrib and fbDirectory) then
                if file <> "." and file <> ".." then
                    ' todo evaluate limit recursive if starting folder is root
                    if len(path(1)) > 3 then
                        n += 1
                        redim preserve path(1 to n)
                        path(n) = path(i) + file + pathchar
                    else
                        ' scanning from root dir not supported
                    end if
                end if
            else
                fileext = lcase(mid(file, instrrev(file, ".")))
                if instr(1, filterext, fileext) > 0 and len(fileext) > 3 then 
                    listnr += 1
                    redim preserve listrec.listfile(0 to listnr)
                    redim preserve listrec.listtype(0 to listnr)
                    redim preserve listrec.listhist(0 to listnr)
                    redim preserve listrec.listseqh(0 to listnr)
                    listrec.listfile(listnr)  = path(i) & file
                    listrec.listtype(listnr)  = listname
                    listrec.listhist(listnr)  = 0
                    listrec.listseqh(listnr)  = 0
                    maxfiles += 1
                else
                    ' file format not supported
                end if    
            end if
            file = dir(@attrib)
        wend
        i += 1
    wend
    
    return maxfiles
end function

' used for listplay passes selected item to current
' ---- FIXED: simpler and correct getcurrentlistitem ----
function getcurrentlistitem(listtype as string, filename as string) as integer
    for i as integer = 0 to listnr
        if listrec.listtype(i) = listtype and listrec.listfile(i) = filename then
            return i
        end if
    next i
    return -1   ' not found
end function
' ---- END FIX ----

dim media as string
dim currentitem as integer

print "music "; createlist("g:\data\mp3", ".mp3", "music")
print "image "; createlist("g:\data\images\classical paintings", ".jpg", "image")
print "slide "; createlist("g:\data\images\flickr\winter mixed", ".jpg", "slide")
print "video "; createlist("g:\data\aerialtv", ".mp4", "video")
print "shade "; createlist("f:\osd\media\glsl", ".gls", "shade")
print
print "total "; listnr
print

' ---- EXAMPLE: selecting / playing items and recording history ----

media = "g:\data\mp3\beatless\the beatles - pennylane.mp3"
currentitem = getcurrentlistitem("music", media)
if currentitem >= 0 then
    add_to_history(currentitem)
    print "music selected " & listrec.listfile(currentitem) & " " & currentitem
    print "history pos    " & listrec.listhist(currentitem)
    print "times played   " & listrec.listseqh(currentitem)
    print
else
    print "music not found: " & media
end if

media = "g:\data\mp3\beatless\the beatles - fixing a hole.mp3"
currentitem = getcurrentlistitem("music", media)
if currentitem >= 0 then
    add_to_history(currentitem)
    print "music selected " & listrec.listfile(currentitem) & " " & currentitem
    print "history pos    " & listrec.listhist(currentitem)
    print "times played   " & listrec.listseqh(currentitem)
    print
else
    print "music not found: " & media
end if

media       = "g:\data\images\classical paintings\102.jpg"
currentitem = getcurrentlistitem("image", media)
if currentitem >= 0 then
    add_to_history(currentitem)
    print "image selected " & listrec.listfile(currentitem) & " " & currentitem
    print "history pos    " & listrec.listhist(currentitem)
    print "times played   " & listrec.listseqh(currentitem)
    print
else
    print "image not found: " & media
end if

media       = "g:\data\images\flickr\winter mixed\crystal chains.jpg"
currentitem = getcurrentlistitem("slide", media)
if currentitem >= 0 then
    add_to_history(currentitem)
    print "slide selected " & listrec.listfile(currentitem) & " " & currentitem
    print "history pos    " & listrec.listhist(currentitem)
    print "times played   " & listrec.listseqh(currentitem)
    print
else
    print "slide not found: " & media
end if

media       = "g:\data\aerialtv\sao paulo brazil.mp4"
currentitem = getcurrentlistitem("video", media)
if currentitem >= 0 then
    add_to_history(currentitem)
    print "video selected " & listrec.listfile(currentitem) & " " & currentitem
    print "history pos    " & listrec.listhist(currentitem)
    print "times played   " & listrec.listseqh(currentitem)
    print
else
    print "video not found: " & media
end if

media       = "f:\osd\media\glsl\singularity.gls"
currentitem = getcurrentlistitem("shade", media)
if currentitem >= 0 then
    add_to_history(currentitem)
    print "shade selected " & listrec.listfile(currentitem) & " " & currentitem
    print "history pos    " & listrec.listhist(currentitem)
    print "times played   " & listrec.listseqh(currentitem)
    print
else
    print "shade not found: " & media
end if

' ---- DEMO: go back to previous picked numbers ----
dim prevIdx as integer
prevIdx = prev_item()
if prevIdx >= 0 then
    print "PREVIOUS from history:"
    print "file  : " & listrec.listfile(prevIdx)
    print "type  : " & listrec.listtype(prevIdx)
    print "index : " & prevIdx
    print
end if

' debug: dump all "image" items
/' dim needle as string = "image"
for i as integer = 0 to listnr
    if listrec.listtype(i) = needle then
        print listrec.listfile(i)
        print listrec.listtype(i)
        print listrec.listhist(i)
    end if
next i '/

sleep
```

Key comparison points with your original:

- `getcurrentlistitem` now returns the loop index directly and `-1` if not found.
- `listseqh` and `listhist` are now used purely for per-item stats, not for navigation.
- The new `playHist()`, `playPos`, and `playCount` implement the actual back/forward play history you can use in shuffle mode.

---

# I see ... the snag, and I should have been a bit more clear on this is, that each listtype (music, image, slide, etc) should have an independent play sequence ... so by example for the music list we first have : media = "g:\data\mp3\beatless\the beatles - pennylane.mp3"

: that has a listrec.listhist(currentitem) = currentitem assigned to it and is the first number played then, either linear or via shuffle, media = "g:\data\mp3\beatless\the beatles - fixing a hole.mp3" is selected which again has  listrec.listhist(currentitem) = currentitem assigned and is the second number played this should not affect image, slide, video etc whom have their own sequence ... hope this clarifies..

Each list type needs its own history structure instead of one global history. The idea is: you still keep your shared `listrec` with all files, but you add one independent play-history array per list type (music/image/slide/video/shade) that stores indices into `listrec`.

## Core idea

For each logical list type, keep:

- A history array of indices into `listrec`
- A “current position” inside that history
- A “count” of history entries

You then add to the appropriate history depending on the `listtype` of the selected item, and “previous/next” operates **within that list’s own history**.

### Per-list history fields

Add this on top, near `listrec`:

```freebasic
' independent histories for each list type
dim shared hist_music() as integer
dim shared pos_music    as integer
dim shared cnt_music    as integer

dim shared hist_image() as integer
dim shared pos_image    as integer
dim shared cnt_image    as integer

dim shared hist_slide() as integer
dim shared pos_slide    as integer
dim shared cnt_slide    as integer

dim shared hist_video() as integer
dim shared pos_video    as integer
dim shared cnt_video    as integer

dim shared hist_shade() as integer
dim shared pos_shade    as integer
dim shared cnt_shade    as integer
```


### Helper: add to history for a specific list type

```freebasic
sub add_to_list_history(listtype as string, idx as integer)
    select case listtype
    case "music"
        if pos_music < cnt_music - 1 then
            cnt_music = pos_music + 1
            redim preserve hist_music(0 to cnt_music - 1)
        end if
        cnt_music += 1
        redim preserve hist_music(0 to cnt_music - 1)
        hist_music(cnt_music - 1) = idx
        pos_music = cnt_music - 1

    case "image"
        if pos_image < cnt_image - 1 then
            cnt_image = pos_image + 1
            redim preserve hist_image(0 to cnt_image - 1)
        end if
        cnt_image += 1
        redim preserve hist_image(0 to cnt_image - 1)
        hist_image(cnt_image - 1) = idx
        pos_image = cnt_image - 1

    case "slide"
        if pos_slide < cnt_slide - 1 then
            cnt_slide = pos_slide + 1
            redim preserve hist_slide(0 to cnt_slide - 1)
        end if
        cnt_slide += 1
        redim preserve hist_slide(0 to cnt_slide - 1)
        hist_slide(cnt_slide - 1) = idx
        pos_slide = cnt_slide - 1

    case "video"
        if pos_video < cnt_video - 1 then
            cnt_video = pos_video + 1
            redim preserve hist_video(0 to cnt_video - 1)
        end if
        cnt_video += 1
        redim preserve hist_video(0 to cnt_video - 1)
        hist_video(cnt_video - 1) = idx
        pos_video = cnt_video - 1

    case "shade"
        if pos_shade < cnt_shade - 1 then
            cnt_shade = pos_shade + 1
            redim preserve hist_shade(0 to cnt_shade - 1)
        end if
        cnt_shade += 1
        redim preserve hist_shade(0 to cnt_shade - 1)
        hist_shade(cnt_shade - 1) = idx
        pos_shade = cnt_shade - 1
    end select

    ' per-item stats remain local to item
    listrec.listhist(idx) = idx      ' store its own index, as you did
    listrec.listseqh(idx) += 1       ' how many times *this item* played
end sub
```


### Helper: previous/next per list type

```freebasic
function prev_in_list(listtype as string) as integer
    select case listtype
    case "music"
        if pos_music > 0 then
            pos_music -= 1
            return hist_music(pos_music)
        end if

    case "image"
        if pos_image > 0 then
            pos_image -= 1
            return hist_image(pos_image)
        end if

    case "slide"
        if pos_slide > 0 then
            pos_slide -= 1
            return hist_slide(pos_slide)
        end if

    case "video"
        if pos_video > 0 then
            pos_video -= 1
            return hist_video(pos_video)
        end if

    case "shade"
        if pos_shade > 0 then
            pos_shade -= 1
            return hist_shade(pos_shade)
        end if
    end select

    return -1    ' no previous
end function

function next_in_list(listtype as string) as integer
    select case listtype
    case "music"
        if pos_music < cnt_music - 1 then
            pos_music += 1
            return hist_music(pos_music)
        end if

    case "image"
        if pos_image < cnt_image - 1 then
            pos_image += 1
            return hist_image(pos_image)
        end if

    case "slide"
        if pos_slide < cnt_slide - 1 then
            pos_slide += 1
            return hist_slide(pos_slide)
        end if

    case "video"
        if pos_video < cnt_video - 1 then
            pos_video += 1
            return hist_video(pos_video)
        end if

    case "shade"
        if pos_shade < cnt_shade - 1 then
            pos_shade += 1
            return hist_shade(pos_shade)
        end if
    end select

    return -1    ' no next
end function
```


### Using it where you select media

Take one of your existing select blocks and minimally change it. For example, music:

```freebasic
media = "g:\data\mp3\beatless\the beatles - pennylane.mp3"
currentitem = getcurrentlistitem("music", media)
if currentitem >= 0 then
    add_to_list_history("music", currentitem)
    print "music selected " & listrec.listfile(currentitem) & " " & currentitem
    print "listhist (index) " & listrec.listhist(currentitem)
    print "times played     " & listrec.listseqh(currentitem)
    print
end if
```

Image, slide, video, shade all use the same pattern but with their own `listtype` string. When you want to go back one step in the **music** sequence, you do:

```freebasic
dim prevMusicIdx as integer
prevMusicIdx = prev_in_list("music")
if prevMusicIdx >= 0 then
    print "Music previous: " & listrec.listfile(prevMusicIdx)
end if
```

This way:

- `listhist(currentitem) = currentitem` keeps the item’s own index (as you wanted).
- `listseqh(currentitem)` keeps a per-item play count.
- Each list type maintains its own independent play sequence, so “previous” in music does not affect or get affected by image/slide/video/shade.

---

# Hmm that's very close to something already I have .. I was hoping that since listtype distinguishes the media set in the array listrec and listhist contains the media item nr via getcurrentlistitem the only missing info would be to get the played sequence number via listseqh ...

You can absolutely keep it close to what you have; you just need to adjust what `listseqh` means and how it is updated so it really is a “played sequence number” per list type, not just a plain counter.

## What your current data already gives

- `listtype(i)` tells you which logical list (music/image/slide/…) item `i` belongs to.
- `listhist(i) = i` (your original idea) just stores the item’s own index; this is fine if you want quick access to “its position in the master array”.
- `listseqh(i)` is the natural place to store “for this listtype, this item was the N‑th played” – but that only works if you maintain a separate sequence counter per list type.

Right now, if you call `listseqh(currentitem) += 1` directly, the value becomes “how many times this item was played”, not “the global order in which it first appeared in the play sequence of that list type”.

## Minimal change: per‑list sequence counters

Introduce one integer counter per listtype and use those to assign a sequence number into `listseqh` when an item is played the first time. The rest of your structure (`listrec`, `listhist`, `listtype`) stays as is.

Add globals:

```freebasic
dim shared seq_music as integer
dim shared seq_image as integer
dim shared seq_slide as integer
dim shared seq_video as integer
dim shared seq_shade as integer
```

Then, when you play/select an item (linear or shuffle), do something like:

```freebasic
sub mark_played(idx as integer)
    dim lt as string = listrec.listtype(idx)

    select case lt
    case "music"
        if listrec.listseqh(idx) = 0 then
            seq_music += 1
            listrec.listseqh(idx) = seq_music   ' N-th music track played
        end if
    case "image"
        if listrec.listseqh(idx) = 0 then
            seq_image += 1
            listrec.listseqh(idx) = seq_image   ' N-th image played
        end if
    case "slide"
        if listrec.listseqh(idx) = 0 then
            seq_slide += 1
            listrec.listseqh(idx) = seq_slide
        end if
    case "video"
        if listrec.listseqh(idx) = 0 then
            seq_video += 1
            listrec.listseqh(idx) = seq_video
        end if
    case "shade"
        if listrec.listseqh(idx) = 0 then
            seq_shade += 1
            listrec.listseqh(idx) = seq_shade
        end if
    end select

    ' keep your original idea of storing the item index, if you still want it
    listrec.listhist(idx) = idx
end sub
```

Usage in your current code becomes:

```freebasic
currentitem = getcurrentlistitem("music", media)
if currentitem >= 0 then
    mark_played(currentitem)
    print "music selected " & listrec.listfile(currentitem) & " " & currentitem
    print "item index (listhist) " & listrec.listhist(currentitem)
    print "music play sequence   " & listrec.listseqh(currentitem)
end if
```

Now, for each listtype:

- `listseqh(i) = 1` means: this item was the first played in that list’s sequence.
- `listseqh(i) = 2` means: second, etc.
- Items that have not been played yet still have `listseqh(i) = 0`.

To navigate “previous” or “next” inside a listtype using only `listrec` and `listseqh`, you can scan for the item with `listtype = "music"` and `listseqh = currentSeq - 1` (for previous) or `currentSeq + 1` (for next). That lets you keep everything in your existing arrays and avoid a separate history array per list.

---

# Hmmm in a way  listrec.listseqh is already (idx)'d because it is an element in the array which distinguishes sets by media image, music, etc  ... ok how about something like getseqnr(currentitem, media) > sort listrec.listseqh by listtype get highest number > return highest number plus one > set listrec.listseqh(currentitem) ?

That approach can work, but it’s important to be precise about what is being sorted and how you search “per listtype”.

## How to compute the next sequence number

You do not even need a `getseqnr` function if all you want is “highest sequence for this listtype, plus one”. You can scan the array once:

- Filter by `listtype` matching the current one.
- Track the maximum `listseqh` for those items.
- Assign `max + 1` to the current item’s `listseqh`.


### Example: assign sequence when playing

```freebasic
sub assign_sequence(idx as integer)
    dim as string lt = listrec.listtype(idx)
    dim as integer maxSeq = 0

    ' find highest sequence number for this listtype
    for i as integer = 0 to listnr
        if listrec.listtype(i) = lt then
            if listrec.listseqh(i) > maxSeq then
                maxSeq = listrec.listseqh(i)
            end if
        end if
    next i

    ' assign next sequence number to the current item
    listrec.listseqh(idx) = maxSeq + 1

    ' optional: keep your index in listhist
    listrec.listhist(idx) = idx
end sub
```

Usage in your existing flow:

```freebasic
currentitem = getcurrentlistitem("music", media)
if currentitem >= 0 then
    assign_sequence(currentitem)
    print "music selected " & listrec.listfile(currentitem) & " " & currentitem
    print "sequence nr     " & listrec.listseqh(currentitem)
end if
```

This gives you exactly what you described:

- `listtype` is the “set” (music/image/slide/…)
- `listseqh(i)` becomes “N‑th played within that set”
- You never mix sequences between sets, because the scan is filtered by `listtype`.


## Getting previous/next using `listseqh`

Once every played item in a set has a unique `listseqh` for that set:

- For “previous” in the same set: look for the item with `listtype = current listtype` and `listseqh = currentSeq - 1`.
- For “next”: same but `currentSeq + 1`.

So yes, your idea of “get highest number for this list type and use +1 for the new play” is sound; the key is to always filter by `listtype` when scanning `listrec.listseqh`.

---

# Nice gracias. Knew that there would be a more elegant solution very nice plus it scales a bit more easier without having to add a bunch of arrays for every media type added if needed.

You're welcome! That scan-based approach keeps everything compact in your existing `listrec` structure and scales perfectly—adding a new media type just means a new `listname` in `createlist`, no extra arrays needed.

## Quick navigation helpers

To complete the picture, here are the "previous/next" functions using the same scan logic:

```freebasic
function get_prev_in_list(lt as string, currentSeq as integer) as integer
    dim targetSeq as integer = currentSeq - 1
    if targetSeq < 1 then return -1
    
    for i as integer = 0 to listnr
        if listrec.listtype(i) = lt and listrec.listseqh(i) = targetSeq then
            return i
        end if
    next
    return -1
end function

function get_next_in_list(lt as string, currentSeq as integer) as integer
    dim targetSeq as integer = currentSeq + 1
    
    for i as integer = 0 to listnr
        if listrec.listtype(i) = lt and listrec.listseqh(i) = targetSeq then
            return i
        end if
    next
    return -1
end function
```

Usage after playing something:

```freebasic
dim prevIdx as integer = get_prev_in_list("music", listrec.listseqh(currentitem))
if prevIdx >= 0 then
    print "Previous music: " & listrec.listfile(prevIdx)
end if
```

Clean, elegant, and uses exactly what you already have. Happy coding!

---

# Nice thank you handy to have some navigation options on the pocket. However I am wondering would it be prudent / handy to merge assign_sequence with getcurrentlistitem?

No, merging them would hurt clarity and flexibility. Keep them separate.

## Why separate is better

**Different purposes:**

- `getcurrentlistitem(listtype, filename)` = **lookup** (find index by file+type). Used anywhere you need to locate an item.
- `assign_sequence(idx)` = **mutation** (update sequence when *playing*). Only called after lookup succeeds.

**Current flow stays clean:**

```freebasic
currentitem = getcurrentlistitem("music", media)  ' lookup
if currentitem >= 0 then
    assign_sequence(currentitem)                   ' mutate
    ' now use listrec.listseqh(currentitem)
end if
```

**You need lookup independently:**

- Check if file exists before playing
- Get index for display/debug
- Navigation functions like `get_prev_in_list` need indices too


## If you really want one function

Only if you *always* assign sequence immediately after lookup (which seems unlikely):

```freebasic
function getcurrentlistitem_and_seq(listtype as string, filename as string, byref seqnr as integer) as integer
    dim idx as integer = -1
    for i as integer = 0 to listnr
        if listrec.listtype(i) = listtype and listrec.listfile(i) = filename then
            idx = i
            ' assign sequence if not yet set
            if listrec.listseqh(idx) = 0 then
                dim maxSeq as integer = 0
                for j as integer = 0 to listnr
                    if listrec.listtype(j) = listtype and listrec.listseqh(j) > maxSeq then
                        maxSeq = listrec.listseqh(j)
                    end if
                next j
                listrec.listseqh(idx) = maxSeq + 1
            end if
            seqnr = listrec.listseqh(idx)
            exit for
        end if
    next
    return idx
end function
```

Usage: `currentitem = getcurrentlistitem_and_seq("music", media, seqnr)`

But this is less readable, does double work on every lookup, and breaks if you want to lookup without assigning sequence.

**Recommendation:** Keep them separate. The two-step `lookup → assign` is the most flexible and readable pattern here.

---

# Ok convincing arguments I'll keep it that way. So I need to setup up and link a menu navigation system I'll drop by at a later date if needed for some more tips and examples. For now many thanks for aiding and resolving the issue listseqh.

You're welcome! Glad the `listseqh` sequence assignment clicked into place—it's now a clean, scalable solution that fits perfectly with your existing structure.

The lookup → assign pattern will serve you well for the menu navigation too. When you're ready to build that system (current position display, prev/next buttons, listtype switching), just drop by—happy to help with examples or tweaks.

Enjoy coding your media player! 🚀

