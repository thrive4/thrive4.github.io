<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Could you take a look at this freebasic issue: Ok indeed a lot of pathchars aka slash - backslash needed to be fixed good one thanks is fixed now. Back to that function output with debug : wah@:/mnt/recycle/dev/audioplayer-bass\$ ./audioplayer.sh /media/wah/games/data/mp3/10am/ genre pop /media/wah/games/data/mp3/10am genre : print dummy print dir(dummy) print command(2) sleep if dir(dummy) <> "" and len(command(2)) <> 0 then select case command(2) case "artist" case "title" case "album" case "year" case "genre" case else logentry("fatal", "unknown tag '" \& command(2) \& "' valid tags artist, title, album, genre and year") end select ' scan and search nr results overwritten by getmp3playlist listnr = exportm3u(dummy, "*.mp3", "m3u", "exif", command(2), command(3)) if listnr < 2 then logentry("fatal", "no matches found for " + command(3) + " in " + command(2)) else listnr = getmp3playlist(exepath + pathchar + command(3) + ".m3u", listtype) end if end if dummy = "" : dummy = /media/wah/games/data/mp3/10am but print dir(dummy) is empty so if dir(dummy) <> "" and len(command(2)) <> 0 prevents further parsing ...

The problem is that `Dir(dummy)` is not being used the way you expect on Linux, and your guard `if dir(dummy) <> "" and len(command(2)) <> 0 then` is likely blocking the rest of the logic because `Dir()` returns an empty string when the path doesn’t match an existing entry or when it’s being called in a context it doesn’t interpret as a search pattern.[^1_1][^1_2]

## What’s going wrong

`Dir` in FreeBASIC is mainly a directory-entry search function, and on Linux path separators are forward slashes `/`. If you pass a full directory path into `Dir(dummy)` expecting “does this directory exist?”, it can fail or return empty depending on how the string is formed and whether the target is treated as a search pattern or a directory name.[^1_2][^1_1]

Your debug output suggests `dummy = /media/wah/games/data/mp3/10am`, but `dir(dummy)` is empty, so the `if` condition short-circuits and `exportm3u(...)` never runs. In other words, the issue is probably not the `command(2)` value itself, but the existence test logic around `Dir()`.[^1_1][^1_2]

## Likely fixes

- Use `CurDir()` / `ExePath()` only when building relative paths, but for an already absolute path like `/media/wah/games/data/mp3/10am`, don’t rely on `Dir(dummy)` as an existence check.[^1_3]
- If you want to test whether a folder exists, use a function designed for filesystem checks rather than `Dir()` as a gate for the whole block.[^1_2][^1_1]
- Keep your path separator handling consistent with Linux: use `/` in the runtime path values, and only convert separators if you truly need cross-platform compatibility.[^1_1][^1_2]


## Code-level issue

This line is the immediate blocker:

```basic
if dir(dummy) <> "" and len(command(2)) <> 0 then
```

A safer structure is to validate the command first, then separately validate the directory/path using a proper existence check. That prevents a failed `Dir()` lookup from stopping the rest of the argument parsing and logging path.

## Practical rewrite

A more robust flow would be:

```basic
if len(command(2)) <> 0 then
    select case command(2)
    case "artist", "title", "album", "year", "genre"
    case else
        logentry("fatal", "unknown tag '" & command(2) & "' valid tags artist, title, album, genre and year")
    end select

    ' check the folder with an actual path test, not Dir(dummy)
    listnr = exportm3u(dummy, "*.mp3", "m3u", "exif", command(2), command(3))
    if listnr < 2 then
        logentry("fatal", "no matches found for " + command(3) + " in " + command(2))
    else
        listnr = getmp3playlist(exepath + pathchar + command(3) + ".m3u", listtype)
    end if
end if
```


## Main takeaway

`Dir(dummy)` is the wrong guard here; it’s causing your parsing to stop before `exportm3u()` runs. The fix is to separate “is the tag valid?” from “does the directory exist?”, and to use Linux-style `/` paths consistently.[^1_2][^1_1]
<span style="display:none">[^1_10][^1_4][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://freebasic.net/wiki/KeyPgdir

[^1_2]: https://documentation.help/FreeBASIC/KeyPgDir.html

[^1_3]: https://www.freebasic.net/forum/viewtopic.php?t=10670

[^1_4]: https://freebasic.net/forum/viewtopic.php?t=4369

[^1_5]: https://man7.org/linux/man-pages/man3/realpath.3.html

[^1_6]: https://github.com/freebasic/fbc/blob/master/src/compiler/fbc.bas

[^1_7]: https://manpages.opensuse.org/Leap-15.6/perl-Path-Class/Path::Class::Dir.3pm.en.html

[^1_8]: https://www.tempel.org/RB/FilePaths

[^1_9]: https://help.libreoffice.org/latest/eo/text/sbasic/shared/03020404.html

[^1_10]: https://documentation.help/FreeBASIC/KeyPgRmdir.html


---

# Hmm the original guard was : ' search with query and export .m3u

'if instr(dummy, ":") <> 0 and len(command(2)) <> 0  then
: which works fine on windows not so much on unix ...

Yes — that guard is the portability problem.

On Windows, `instr(dummy, ":") <> 0` works as a quick “looks like a drive/path” test because absolute paths often contain a drive letter like `C:`. On Unix-like systems, absolute paths usually start with `/`, so there is no colon, and the condition fails even for valid paths.[^2_4][^2_8]

## Why it breaks

Your old test:

```basic
if instr(dummy, ":") <> 0 and len(command(2)) <> 0 then
```

implicitly assumes a Windows-style path format. On Unix, `/media/wah/games/data/mp3/10am` is a valid absolute path, but it contains no `:`, so the whole block is skipped.[^2_8][^2_4]

## Better check

Instead of checking for `:`, check whether the path is non-empty and, if needed, whether it is absolute in a platform-neutral way:

```basic
if len(dummy) <> 0 and len(command(2)) <> 0 then
```

If you specifically want to accept only absolute paths on both platforms, use logic like:

```basic
if (left(dummy, 1) = "/" or instr(dummy, ":") <> 0) and len(command(2)) <> 0 then
```

That covers Unix-style `/...` and Windows-style `C:...` paths.[^2_4][^2_8]

## Even cleaner

If `dummy` is already coming from the command line and you only need to know whether it was supplied, then `len(dummy) <> 0` is usually enough. Let the later file or directory operations decide whether the path is valid, instead of trying to infer validity from a separator character.[^2_3][^2_5]

## Suggested fix

A practical replacement would be:

```basic
if len(dummy) <> 0 and len(command(2)) <> 0 then
    select case command(2)
    case "artist", "title", "album", "year", "genre"
    case else
        logentry("fatal", "unknown tag '" & command(2) & "' valid tags artist, title, album, genre and year")
    end select

    listnr = exportm3u(dummy, "*.mp3", "m3u", "exif", command(2), command(3))
    if listnr < 2 then
        logentry("fatal", "no matches found for " + command(3) + " in " + command(2))
    else
        listnr = getmp3playlist(exepath + pathchar + command(3) + ".m3u", listtype)
    end if
end if
```

That removes the Windows-only assumption and should behave correctly on Unix too.[^2_8][^2_4]
<span style="display:none">[^2_1][^2_10][^2_2][^2_6][^2_7][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://www.freebasic.net/forum/viewtopic.php?t=29674\&start=30

[^2_2]: https://www.reddit.com/r/PowerShell/comments/z2fqgg/why_powershell_uses_the_back_slash_for_file_paths/

[^2_3]: https://documentation.help/FreeBASIC/KeyPgDir.html

[^2_4]: https://www.freebasic.net/forum/viewtopic.php?t=25121

[^2_5]: https://freebasic.net/wiki/KeyPgdir

[^2_6]: https://github.com/BurntSushi/ripgrep/issues/275

[^2_7]: https://www.freebasic.net/wiki/wikka.php?wakka=CompilerOpttarget

[^2_8]: https://stackoverflow.com/questions/38428561/difference-between-forward-slash-and-backslash-in-file-path

[^2_9]: https://freebasic.net/forum/viewtopic.php?t=11572

[^2_10]: https://jasonroell.com/2015/03/11/how-to-once-and-for-all-remember-when-to-use-or/


---

# if len(dummy) <> 0 and len(command(2)) <> 0 then

nice elegant but I'm not quite sure if something down the road might break ... so went for if (left(dummy, 1) = "/" or instr(dummy, ":") <> 0) and len(command(2)) <> 0 then
for now just to be on the safe side .... thanks both solutions deal with the windows / unix issue so that's nice. Oh ... wah@:/mnt/recycle/dev/audioplayer-bass\$ ./audioplayer.sh /media/wah/games/data/mp3/10am/ conf/pop.m3u
/media/wah/games/data/mp3/10am
/
conf/pop.m3u
unknown tag 'conf/pop.m3u' valid tags artist, title, album, genre and year ... yeah it still breaks the commandline parsing is ehhrr special ....

Yes — the next bug is that your command line is being split into **more arguments than you expect** on Unix because the shell and FreeBASIC both preserve argument boundaries differently than your Windows case.[^3_1][^3_2]

## What your output shows

You ran:

```basic
./audioplayer.sh /media/wah/games/data/mp3/10am/ conf/pop.m3u
```

and your program sees:

- `dummy = /media/wah/games/data/mp3/10am`
- `command(2) = /`
- `command(3) = conf/pop.m3u`

So `conf/pop.m3u` is being interpreted as the tag argument, which then triggers:

```basic
unknown tag 'conf/pop.m3u'
```

That means the parser is not treating your second shell token as a playlist path argument the way you intended.[^3_2][^3_1]

## Why this happens

`COMMAND()` returns the arguments as the program received them, with shell quoting rules applied. If the shell splits or rewrites the arguments, FreeBASIC will faithfully see that result rather than reconstruct your intended meaning. On Unix, `/` is just a normal path separator, not something that belongs in a tag name, so your current positional parsing logic is too fragile for mixed inputs.[^3_3][^3_4][^3_1][^3_2]

## What to change

Your parser should not infer meaning from position alone if the inputs can be either:

- a directory path,
- a tag name,
- a playlist filename.

Instead, make the command line explicit, for example:

```text
audioplayer <folder> <tag> <value>
```

or better:

```text
audioplayer --dir /media/... --tag genre --value pop --out conf/pop.m3u
```

That avoids ambiguity completely.[^3_1][^3_2]

## Minimal fix

If you want to keep the current interface, add validation before using `command(2)` as a tag:

```basic
select case lcase(command(2))
case "artist", "title", "album", "year", "genre"
case else
    logentry("fatal", "unknown tag '" & command(2) & "' valid tags artist, title, album, genre and year")
end select
```

Then separately decide which argument is the output playlist path, instead of assuming `command(3)` is always the value you want.

## Safer parsing idea

A common approach is:

- `command(1)` = program name,
- `command(2)` = source folder,
- `command(3)` = tag,
- `command(4)` = tag value,
- `command(5)` = output playlist.

That way `conf/pop.m3u` cannot accidentally become the tag just because a slash appears in it. FreeBASIC’s `COMMAND` documentation makes clear that argument boundaries come from the shell and quoting rules, so your code should treat each argument as already split, not try to rediscover structure from the text.[^3_2][^3_1]

If you want, I can help rewrite the argument handling into a small robust parser for both Windows and Unix.
<span style="display:none">[^3_10][^3_11][^3_12][^3_5][^3_6][^3_7][^3_8][^3_9]</span>

<div align="center">⁂</div>

[^3_1]: https://documentation.help/FreeBASIC/KeyPgCommand.html

[^3_2]: https://www.freebasic.net/wiki/keypgcommand

[^3_3]: https://www.freebasic.net/forum/viewtopic.php?t=25121

[^3_4]: https://stackoverflow.com/questions/38428561/difference-between-forward-slash-and-backslash-in-file-path

[^3_5]: https://freebasic.net/forum/viewtopic.php?t=4369

[^3_6]: https://gist.github.com/jehiah/855086

[^3_7]: https://github.com/freebasic/fbc/blob/master/src/compiler/fbc.bas

[^3_8]: https://stackoverflow.com/questions/27368153/command-line-arguments-paths-with-spaces-parsing-incorrectly

[^3_9]: https://www.freebasic.net/forum/viewtopic.php?t=28783

[^3_10]: https://github.com/platise/m3u-tools

[^3_11]: https://www.freebasic.net/forum/viewtopic.php?t=20411

[^3_12]: https://gist.github.com/Quackward/655cc02e9366180d31872ce76e099cd9

