<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# I'm currently experimenting with comfy ui and the following models : 04-03-26  13:18     2.132.625.431 Deliberate_v2.safetensors

04-03-26  18:56     2.132.625.894 dreamshaper_8.safetensors
04-03-26  19:17     2.132.625.918 photon_v1.safetensors
04-03-26  18:51     4.265.096.902 Protogen_V2.2.safetensors
04-03-26  18:40     4.265.096.996 Realistic_Vision_V6.safetensors
04-03-26  13:00     4.265.146.304 v1-5-pruned-emaonly.safetensors
: do any if not all support image to image and if so how do I get that to work in comfyui?

All listed models—Deliberate_v2, DreamShaper_8, Photon_v1, Protogen_V2.2, Realistic_Vision_V6, and v1-5-pruned-emaonly—are Stable Diffusion 1.5-based checkpoints, so they all natively support image-to-image (img2img) workflows in ComfyUI.

## Basic Img2Img Setup

Load your checkpoint with a **CheckpointLoaderSimple** node, then build a workflow like this:

- **LoadImage** node: Drag your input image here (supports PNG/JPG).
- **VAEEncode** (for the image): Connect the image pixels to encode into latent space; use the VAE from your checkpoint.
- **CLIPTextEncode** nodes: One for positive prompt, one for negative (connect CLIP from checkpoint).
- **KSampler**: Wire MODEL and CLIP from checkpoint; connect the latent from VAEEncode to its latent_image input. Set denoising to 0.4-0.75 (lower keeps more of the original image).
- **VAEDecode**: Connect sampled latent output here, then **SaveImage** for results.

Start with 20-30 steps, CFG 7-8, and Euler a sampler. Examples using DreamShaper_8 confirm strong img2img results with ControlNet too.[^1_5]

## Tips for Your Models

- **Realistic_Vision_V6** and **Protogen_V2.2**: Excel at photoreal img2img; use denoising ~0.5 for subtle edits.
- **DreamShaper_8** and **Deliberate_v2**: Versatile for styles; pair with highres fix via upscaling nodes.
- **Photon_v1**: Good for quick, clean transformations; lower steps (15-20).
- **v1-5-pruned-emaonly**: Base model, works universally but needs strong prompts.

Right-click canvas > Add Node > Loaders for quick starts, or search ComfyUI examples for "img2img" JSON workflows to drag in.[^1_1][^1_3]
<span style="display:none">[^1_10][^1_2][^1_4][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://comfy.icu/files/dreamshaper_8.safetensors

[^1_2]: https://comfy.icu/files/dreamshaper_7.safetensors

[^1_3]: https://comfyui.dev/docs/guides/Checkpoints/dreamshaper-8-safetensors/

[^1_4]: https://www.reddit.com/r/comfyui/comments/1de6vlo/how_to_use_the_new_sd3_medium_safetensor_model_in/

[^1_5]: https://www.reddit.com/r/comfyui/comments/1k9srn4/img2img_output_using_dreamshaper_8_controlnet/

[^1_6]: https://www.comfyflow.app/docs/models/common-models

[^1_7]: https://www.reddit.com/r/StableDiffusion/comments/15d2uc2/dreamshaper_v8_maybe_the_end_of_the_journey/

[^1_8]: https://comfyanonymous.github.io/ComfyUI_examples/flux/

[^1_9]: https://huggingface.co/Lykon/dreamshaper-8-lcm/discussions/3

[^1_10]: https://docs.comfy.org/troubleshooting/model-issues


---

# Ok nice will give that a whirl. An other thing I was wondering about is the 'clip text encode' node can that be auto filled cq automated in some way or is there an other method of batching a number of diffrent prompts to a workflow?

Yes, ComfyUI offers ways to automate CLIP Text Encode nodes and batch multiple prompts without manual entry each time.

## Prompt Automation Options

Use dynamic text inputs via these built-in or common custom nodes:

- **Primitive Node** (right-click > utils > Primitive > String): Connect its `string` output directly to CLIPTextEncode's `text` input. Edit the value once, and it updates instantly—great for quick tests.
- **Note/Prompt Saver Nodes** (from ComfyUI-Manager custom nodes): Store reusable prompt templates; switch between them via dropdowns.

For true automation, install **ComfyUI-Prompt-Control** or **WAS Node Suite** via ComfyUI Manager—these add nodes like `PCTextEncode` for prompt scheduling (e.g., blending prompts over steps) or random wildcards.[ from prior]

## Batching Multiple Prompts

Build batch workflows with these nodes (search in Add Node menu):

- **CR Text List** (from Comfyroll Custom Nodes): Input a list of prompts (e.g., line-separated), outputs multiple CONDITIONING tensors for parallel generation.
- **Batch Prompt Schedule**: Connect to KSampler's `positive`/`negative`—cycles through prompts automatically across batch count.
- **Loop/Repeat Nodes** (e.g., **Logic > Batch to List** + **For Each** loops): Feed a text file or array of prompts; generates one image per prompt in sequence.


## Quick Workflow Example

1. Load checkpoint and CLIP.
2. Add **Text List** node: Enter prompts like:

```
a cat in space
a dog on beach
cyberpunk city
```

3. Connect to **CLIPTextEncode** via text input.
4. Set KSampler `batch_size` to match prompt count (e.g., 3).
5. Queue Prompt—outputs grid of batched results.

Load workflows from ComfyUI Examples (right-click > Examples > prompts) for batch img2img starters. This scales your experiments efficiently with those SD1.5 models.
<span style="display:none">[^2_1][^2_10][^2_2][^2_3][^2_4][^2_5][^2_6][^2_7][^2_8][^2_9]</span>

<div align="center">⁂</div>

[^2_1]: https://www.runcomfy.com/comfyui-nodes/ComfyUI_smZNodes/smZ-CLIPTextEncode

[^2_2]: https://comfyai.run/documentation/CLIPTextEncodeAndEnhance

[^2_3]: https://docs.comfy.org/built-in-nodes/ClipTextEncode

[^2_4]: https://www.runcomfy.com/comfyui-nodes/ComfyUI/CLIPTextEncode

[^2_5]: https://blenderneko.github.io/ComfyUI-docs/Core Nodes/Conditioning/CLIPTextEncode/

[^2_6]: https://docs.comfy.org/built-in-nodes/ClipTextEncodeFlux

[^2_7]: https://comfyui-wiki.com/en/comfyui-nodes/conditioning/clip-text-encode

[^2_8]: https://github.com/BlenderNeko/ComfyUI_ADV_CLIP_emb

[^2_9]: https://www.reddit.com/r/comfyui/comments/1lu0wi4/extract_prompt_from_clip_text_encode_conditioning/

[^2_10]: https://www.reddit.com/r/comfyui/comments/1dc86sv/how_to_pass_a_string_to_a_cliptextencode_node/


---

# Hmmm so something more command like based is not an an option ?

Yes, ComfyUI supports command-line options for launching and basic config, but full workflow execution (like batching prompts) via CLI requires external tools since core ComfyUI lacks native scripting.[^3_2]

## Native CLI Flags

Run ComfyUI from terminal with `python main.py [flags]`:

- `--input-directory /path/to/prompts` for batch images (auto-processes folders).
- `--output-directory /path/to/save` for results.
- `--frontent-pr /path/to/workflow.json` loads workflows on startup.

No direct prompt batching here—it's GUI-driven primarily.[^3_2]

## CLI Automation Tools

Install these for scriptable, command-like batching:

- **comfy-cli** (`pip install comfy-cli`): `comfy launch --workflow batch_prompts.json` runs JSON workflows with embedded prompt lists.[^3_1][^3_5]
- **ComfyUI-to-Prompt-Travel** or **API mode** (`--listen 0.0.0.0 --port 8188`): Script Python/CLI calls to `/prompt` endpoint, feeding JSON payloads with prompt arrays.[^3_3]

Example batch script (Python):

```python
import requests
prompts = ["cat in space", "dog on beach"]
for p in prompts:
    payload = {"prompt": workflow_json_with_prompt_replaced_by_p}
    requests.post("http://localhost:8188/prompt", json=payload)
```

Load your img2img workflow as JSON, replace CLIPTextEncode text dynamically. This beats manual node entry for your model experiments.
<span style="display:none">[^3_10][^3_4][^3_6][^3_7][^3_8][^3_9]</span>

<div align="center">⁂</div>

[^3_1]: https://github.com/Comfy-Org/comfy-cli

[^3_2]: https://www.reddit.com/r/comfyui/comments/15jxydu/comfyui_command_line_arguments_informational/

[^3_3]: https://github.com/richinsley/comfycli

[^3_4]: https://www.youtube.com/watch?v=tpW7Kl3C9L0

[^3_5]: https://docs.comfy.org/comfy-cli/getting-started

[^3_6]: https://comfyui-wiki.com/en/install/install-comfyui/comfy-cli

[^3_7]: https://www.reddit.com/r/StableDiffusion/comments/1cmaqej/a_command_line_interface_to_manage_comfyui_and/

[^3_8]: https://docs.comfy.org/comfy-cli/reference

[^3_9]: https://mixinglight.com/color-grading-tutorials/comfyui-command-line-101-part-3/

[^3_10]: https://github.com/comfyanonymous/ComfyUI/discussions/3158


---

# Hmm had hoped this would be a tad more straight forward ... seems this is the canonical way aka use api : [https://www.andreszsogon.com/comfyui-load-prompts-from-text-file-sample-workflow/](https://www.andreszsogon.com/comfyui-load-prompts-from-text-file-sample-workflow/) :

Yes, the workflow in that link (using ComfyUI's API with a text file of prompts) is one of the most straightforward CLI-like methods—no extra tools needed beyond basic Python/curl and your running ComfyUI server.

## How It Works

Save your img2img workflow as JSON in API format (menu > Save (API Format)). Edit it to replace the CLIPTextEncode `text` value with a placeholder like `_PROMPT_`. Then use a script like this to batch from `prompts.txt` (one prompt per line):

```bash
cat prompts.txt | while read prompt; do
  sed "s/_PROMPT_/$prompt/" workflow.json > temp.json
  curl -X POST -H "Content-Type: application/json" -d @temp.json http://127.0.0.0:8188/prompt
done
```

This queues each prompt sequentially via the API endpoint, perfect for your models—outputs land in ComfyUI's folder automatically.[^4_6]

## Simpler Alternatives

- **Custom Nodes (Easier GUI)**: Install **ComfyUI-Inspire-Pack** via Manager, add **BatchPromptFromFile** node. Drop prompts separated by `---` in a .txt file, connect to CLIPTextEncode, set batch size, and Queue Prompt once for all.[^4_4]
- **WAS Suite**: **Load Text File** node batches lines directly, no API hassle.

Both beat manual entry; API shines for headless/scripts. Test with 3-5 prompts from your models first.
<span style="display:none">[^4_1][^4_10][^4_2][^4_3][^4_5][^4_7][^4_8][^4_9]</span>

<div align="center">⁂</div>

[^4_1]: https://github.com/rbbrdckybk/comfy-batcher

[^4_2]: https://www.youtube.com/watch?v=Uk9mzFBle3g

[^4_3]: https://github.com/comfyanonymous/ComfyUI/issues/7880

[^4_4]: https://www.youtube.com/watch?v=xfelqTfnnO8

[^4_5]: https://comfyai.run/documentation/BatchPrompts

[^4_6]: https://blog.xentoo.info/2023/07/22/comfyui-batch-run-from-command-line-with-api/

[^4_7]: https://www.reddit.com/r/comfyui/comments/15e93n1/batch_up_prompts_and_execute_them_sequentially/

[^4_8]: https://www.youtube.com/watch?v=ZgcDoCcp6Qw

[^4_9]: https://www.youtube.com/watch?v=KU2VBZldN1U

[^4_10]: https://www.youtube.com/watch?v=KMlUakdbdnc


---

# Hmmm was suite so copy WAS_Node_Suite.py to /ComfyUI/custom_nodes/ done?

No, just copying `WAS_Node_Suite.py` to `/ComfyUI/custom_nodes/` is the legacy method and often fails—it's missing dependencies, resources, and auto-install logic.[^5_2][^5_5]

## Recommended Install (5 mins)

Use **ComfyUI Manager** (assuming you have it—most do):

1. Click **Manager** button (top menu).
2. Select **Install Custom Nodes**.
3. Search **WAS Node Suite** > **Install**.
4. Click **Restart** when prompted.

## Manual (If No Manager)

```bash
cd ComfyUI/custom_nodes
git clone https://github.com/WASasquatch/was-node-suite-comfyui
cd was-node-suite-comfyui
# Portable: python_embeded/python.exe -m pip install -r requirements.txt
# Or system: pip install -r requirements.txt
```

Restart ComfyUI. Nodes appear under **WAS Suite** menu (e.g., **WAS Load Text File** for batch prompts).[^5_1][^5_5]

Verify in startup log—no "import failed" errors. Then wire **WAS Text File** > **CLIPTextEncode** for your prompt batching needs.
<span style="display:none">[^5_10][^5_3][^5_4][^5_6][^5_7][^5_8][^5_9]</span>

<div align="center">⁂</div>

[^5_1]: https://www.runcomfy.com/comfyui-nodes/was-node-suite-comfyui

[^5_2]: https://www.instasd.com/comfyui/custom-nodes/was-node-suite-comfyui

[^5_3]: https://comfyui-info.com/custom_node/was-node-suite-comfyui

[^5_4]: https://docs.comfy.org/installation/install_custom_node

[^5_5]: https://github.com/WASasquatch/was-node-suite-comfyui

[^5_6]: https://comfyui-wiki.com/en/install/install-custom-nodes

[^5_7]: https://comfyui-wiki.com/en/install/install-comfyui/install-comfyui-on-windows

[^5_8]: https://comfyai.run/custom_node/was-node-suite-comfyui

[^5_9]: https://www.reddit.com/r/comfyui/comments/1bds38t/was_node_suite/

[^5_10]: https://www.reddit.com/r/comfyui/comments/1and6s9/installing_nodes_but_without_the_manager/


---

# So tiring .. this .. need to take x amount of steps only to find out that something might not work as expected have a horrific time removing it and the added bonus that it can ruin the comfyui install ...

I get it—custom node installs can feel like a minefield with dependency hell and breakage risks.

## Zero-Install Batch Prompts (Built-in Only)

Skip WAS Suite entirely. Use **this dead-simple API method** with your existing ComfyUI:

1. Save any workflow as **API Format JSON** (menu button).
2. Replace CLIPTextEncode `"text"` value with `"PROMPT_HERE"`.
3. Create `prompts.txt` (one prompt per line).
4. Run in terminal (ComfyUI must be running):
```bash
for p in $(cat prompts.txt); do
  curl -X POST -H "Content-Type: application/json" \
  -d "$(sed "s/PROMPT_HERE/$p/g" workflow.json)" \
  http://127.0.0.0:8188/prompt
done
```

**No new installs, no breakage.** Works today with your Deliberate_v2 etc. models. Outputs save automatically.

## Even Simpler: Workflow Copy-Paste

Duplicate your img2img workflow 5x on canvas, edit each CLIPTextEncode manually, select all nodes, **Ctrl+G** (group), **Queue Prompt**. Zero risk, instant results.

The API method scales better than manual without touching custom nodes.

---

# ehhr I'm on windows...

No problem—Windows PowerShell handles it easily, no Unix needed.

## Windows Batch Script (Save as `batch_prompts.bat`)

```batch
@echo off
for /f "tokens=*" %%i in (prompts.txt) do (
  powershell -Command "(Get-Content workflow.json) -replace 'PROMPT_HERE', '%%i' | Set-Content temp.json; curl.exe -X POST -H \"Content-Type: application/json\" -d @temp.json http://127.0.0.0:8188/prompt"
)
del temp.json
pause
```


## One-Liner PowerShell (Paste in PowerShell)

```powershell
Get-Content prompts.txt | ForEach { (Get-Content workflow.json) -replace 'PROMPT_HERE', $_ | Set-Content temp.json; curl.exe -X POST -H "Content-Type: application/json" -d @temp.json http://127.0.0.0:8188/prompt }; Remove-Item temp.json
```

**Setup**: `prompts.txt` with one prompt per line, `workflow.json` with `PROMPT_HERE` placeholder in CLIPTextEncode. Double-click `.bat` or run PowerShell command. ComfyUI processes each automatically.

Pure Windows-native, zero installs, zero risk. Works with your img2img setup immediately.

---

# Back up the img2img was tentative I don't have that now yet what I have is text to image workflow with two clip encode text node's one negative ... I'm looking at the batch you generated how does it start comfy ui or wait comfy ui is supposed to be running somehow the script is pumping the text line to a temp.json that gets picked up by comfyui?

**Yes, ComfyUI must already be running**—the script doesn't start it. Launch ComfyUI first (via `run_nvidia_gpu.bat` or similar), then run the batch script.

## How the Script Works (Text-to-Image)

Your txt2img workflow (Checkpoint → CLIPTextEncode positive/negative → EmptyLatent → KSampler → VAE Decode → SaveImage) is perfect:

1. **Save workflow**: Menu → **Save (API Format)** as `workflow.json`.
2. **Edit JSON** (Notepad++): Find the **positive** CLIPTextEncode node, replace `"text": "whatever"` with `"text": "PROMPT_HERE"`. Leave negative prompt unchanged.
3. **prompts.txt**: One positive prompt per line (e.g. `a cat in space`, `cyberpunk cityscape`).
4. **Run script** (PowerShell or .bat from before)—each line becomes a full API job queued to your running ComfyUI.

**ComfyUI processes them in queue** (watch Progress tab), outputs land in `ComfyUI/output/` automatically. No img2img needed yet.

## Windows Test (Copy-paste to PowerShell)

```powershell
# Test with 2 prompts
@"
a majestic dragon
futuristic city at night
"@ | Out-File prompts.txt -Encoding utf8

# Then run the batch script above
```

Start ComfyUI → load your txt2img → save API JSON → run script. Images appear while you watch. Zero risk, pure Windows.
<span style="display:none">[^8_1][^8_10][^8_2][^8_3][^8_4][^8_5][^8_6][^8_7][^8_8][^8_9]</span>

<div align="center">⁂</div>

[^8_1]: https://docs.comfy.org/tutorials/basic/text-to-image

[^8_2]: https://comfyui-wiki.com/en/tutorial/basic/creating-your-first-image-by-the-first-time

[^8_3]: https://docs.comfy.org/get_started/first_generation

[^8_4]: https://www.comflowy.com/basics/comfyui-foundation

[^8_5]: https://comfyui.org/en/flux-1-text-to-image-generation-guide

[^8_6]: https://www.youtube.com/watch?v=rw8TRf5gqyY

[^8_7]: https://www.reddit.com/r/comfyui/comments/1pg09qs/i_build_a_comfyui_workflow_image_to_decription/

[^8_8]: https://www.youtube.com/watch?v=sEF2oV7Ay_A

[^8_9]: https://www.youtube.com/watch?v=gaLHn_SSI2I

[^8_10]: https://www.reddit.com/r/comfyui/comments/1k8sbhf/a_workflow_for_total_beginners_simple_txt2img/


---

# 2. be specific ... edit workflow.json or something else?

Yes, edit the **workflow.json** file you saved in **API Format** from ComfyUI's menu.

## Exact Steps to Edit

1. In ComfyUI: Build your txt2img workflow → **Menu (top right)** → **Save (API Format)** → save as `workflow.json`.
2. Open `workflow.json` in **Notepad** or **Notepad++** (it's readable JSON).
3. **Search** (Ctrl+F) for `"CLIPTextEncode"`—find your **positive prompt** node (usually first one), looks like:

```json
{
  "inputs": {
    "text": "YOUR_CURRENT_PROMPT",
    ...
  },
  "type": "CLIPTextEncode",
  "id": 5
}
```

4. **Replace** `"text": "YOUR_CURRENT_PROMPT"` → `"text": "PROMPT_HERE"`. Leave negative prompt unchanged.
5. **Save file**.

Now the batch script replaces `PROMPT_HERE` with each line from `prompts.txt` and sends via API. Your two CLIPTextEncode nodes work perfectly—one gets batched, other stays fixed.[^9_1]
<span style="display:none">[^9_10][^9_2][^9_3][^9_4][^9_5][^9_6][^9_7][^9_8][^9_9]</span>

<div align="center">⁂</div>

[^9_1]: https://docs.comfy.org/specs/workflow_json

[^9_2]: https://comfyui-wiki.github.io/ComfyUI-Workflow-JSON-Editor/

[^9_3]: https://docs.runcomfy.com/serverless/workflow-files

[^9_4]: https://docs.comfy.org/development/core-concepts/workflow

[^9_5]: https://www.reddit.com/r/StableDiffusion/comments/15cnh44/how_to_get_json_files_into_comfyui/

[^9_6]: https://comfyui-wiki.com/en/interface/workflow

[^9_7]: https://www.reddit.com/r/comfyui/comments/14xeein/drag_and_drop_workflow_json_replaces_existing/

[^9_8]: https://www.youtube.com/watch?v=3ymiL2M9YRY

[^9_9]: https://docs.comfydeploy.com/docs/workflows/import

[^9_10]: https://docs.comfy.org/custom-nodes/workflow_templates


---

# Tentative getting there doesn't this through up a storm of tabs in the browser plus how does comfyui trigger 'run' in this scenario?

No, the API script **won't spawn browser tabs**—it sends requests directly to ComfyUI's backend server (localhost:8188), bypassing the web UI entirely.

## How ComfyUI Handles API Jobs

1. **ComfyUI stays running** in background (your browser tab open, idle).
2. Script POSTs JSON workflows → **Queue fills automatically** (watch Progress bar in UI).
3. ComfyUI **auto-executes** each job—no manual "Queue Prompt" needed. Progress shows in **Progress** tab; images save to `/output/` folder.
4. Browser shows real-time status but no new tabs/windows.

Your txt2img with dual CLIPTextEncode nodes works perfectly—positive gets swapped per prompt, negative stays fixed. Queue processes sequentially on your GPU with those models (Deliberate_v2 etc.). Clean, headless batching.
<span style="display:none">[^10_1][^10_10][^10_2][^10_3][^10_4][^10_5][^10_6][^10_7][^10_8][^10_9]</span>

<div align="center">⁂</div>

[^10_1]: https://comfyai.run/download/workflow/Basic Batch Workflow/d8a93c58-5f25-40df-877b-fc99dfa4a809

[^10_2]: https://github.com/rbbrdckybk/comfy-batcher

[^10_3]: https://www.reddit.com/r/StableDiffusion/comments/187b4dm/how_do_i_batch_process_images_on_comfyui/

[^10_4]: https://www.reddit.com/r/comfyui/comments/1dtsep0/batch_processing/

[^10_5]: https://www.comflowy.com/blog/comflowy-batch

[^10_6]: https://www.youtube.com/watch?v=xfelqTfnnO8

[^10_7]: https://blog.xentoo.info/2023/07/22/comfyui-batch-run-from-command-line-with-api/

[^10_8]: https://www.youtube.com/watch?v=DLFPuXFSnQE

[^10_9]: https://github.com/rsandagon/comfyui-batch-image-generation

[^10_10]: https://www.reddit.com/r/comfyui/comments/1jgy705/api_comfyui_and_batch_image_processing/

