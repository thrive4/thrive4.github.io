<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# I'm trying to install pop os on an usb I'm getting 'efi partition not on a gpt disk' ...

That error means your USB/disk is using the old MBR partitioning while the Pop!_OS installer is running in UEFI mode and expects a GPT disk with a proper EFI System Partition.

Since I can’t see your exact layout, here are the two common ways to fix it; pick the one that matches what you want:

***

## Option 1: Keep MBR (Legacy/CSM boot)

Use this if you really must keep the disk as MBR.

1. Reboot your PC and enter the one‑time boot menu (often F12, F8, Esc, etc.).
2. In the boot menu, choose the non‑UEFI entry for your USB, usually called something like:
    - `USB HDD: <brand>` or just the USB name
    - Avoid entries that start with `UEFI: <USB name>`.
3. Start the Pop!_OS installer again.
When the installer is booted in legacy mode, it will install using the MBR method and should stop complaining about the EFI/GPT issue.[^1_2][^1_5]

This only works if all systems on that disk (Windows, other Linux) are also using legacy/MBR; mixing UEFI and legacy on the same machine is a frequent source of boot problems.[^1_5]

***

## Option 2: Convert disk to GPT and use EFI (recommended)

Use this if you can re‑partition the target disk (data loss risk unless you back up).

1. **Back up** anything important from the disk you’re installing Pop!_OS on.
2. Boot any live environment (Pop!_OS installer, Ubuntu live, etc.) and run GParted.
3. In GParted:
    - Select the target disk (make sure it is the correct one).
    - From the menu: `Device → Create Partition Table…` and choose **gpt**. This will wipe all partitions on that disk.
4. Create partitions:
    - EFI System Partition: 300–550 MB, **FAT32**, and set flags `boot` and `esp`.[^1_5]
    - Root partition: ext4 for `/` with the rest of the space (plus optional swap, home, etc.).
5. Start the Pop!_OS installer:
    - Choose “Custom”/manual partitioning.
    - Point the EFI mount to the FAT32 partition you created (mount point `/boot/efi`).
    - Point root `/` to your ext4 partition.

Now the EFI partition is on a GPT disk and UEFI mode installation should proceed without that error.[^1_1][^1_5]

***

## If you’re dual‑booting Windows

- Check whether Windows is installed in UEFI or legacy mode:
    - If Windows uses UEFI, its disk should already be GPT with an existing EFI System Partition; you should re‑use that EFI partition instead of creating another.[^1_8][^1_5]
    - If Windows uses legacy/MBR, either:
        - Convert the Windows disk to GPT and reinstall/repair Windows in UEFI mode, then install Pop!_OS in UEFI, or
        - Keep everything in legacy mode and boot the Pop!_OS USB in legacy as in Option 1.[^1_8][^1_5]

***

If you tell me:

- Whether you’re wiping the whole disk or dual‑booting,
- If Windows is installed, and
- What partitions you see in the installer,

I can give you exact, step‑by‑step instructions for your situation.
<span style="display:none">[^1_3][^1_4][^1_6][^1_7][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://www.ubackup.com/explore/efi-partition-is-not-on-a-gpt-disk-pop-os-7983-ac.html

[^1_2]: https://www.reddit.com/r/pop_os/comments/tue21g/how_to_install_pop_os_in_this_drive_its_says_efi/

[^1_3]: https://www.facebook.com/groups/linuxpc/posts/25667946576142066/

[^1_4]: https://www.reddit.com/r/linux4noobs/comments/p31w9m/efi_partition_is_not_on_a_gpt_disk_please_help/

[^1_5]: https://www.reddit.com/r/pop_os/comments/m7mgdt/efi_partition_is_not_on_a_gpt_disk/

[^1_6]: https://community.frame.work/t/tracking-unable-to-install-any-linux-distro/78865

[^1_7]: https://pingvinus.ru/forum/discussion/861/efi-partition-is-not-on-a-gpt-disk-pop-os/p1

[^1_8]: https://www.reddit.com/r/linuxquestions/comments/1cq678r/hello_anyone_encountered_the_efi_partition_is_not/

[^1_9]: https://forum.level1techs.com/t/pop-os-keeps-currupting-the-efi-partition/238607


---

# Gracias when't for option 2 regarding the efi size is 300~500MB sufficent I thought it needed to 1GB for pop os / or maybe debian based nix's?

Pop!_OS and most Debian/Ubuntu-based distros *can* technically work with a smaller EFI, but for Pop!_OS specifically you really should aim higher than 300–500 MB.

### Why Pop!_OS wants more EFI space

Pop!_OS stores its kernels directly in the EFI partition (because it uses systemd-boot and keeps multiple kernels plus a recovery kernel there), so it fills up much faster than a typical Ubuntu/Debian GRUB setup that keeps kernels in `/boot`.[^2_1][^2_3][^2_6]

On current Pop!_OS releases:

- 256–300 MB: often too small in practice and may not even be accepted by the installer.
- 500–600 MB: works for some users but is already tight; people report running out of space during kernel updates.
- Around 1 GB: now considered the safe **minimum** for Pop!_OS installs, especially if:
    - You keep several kernels,
    - You use the Pop recovery feature,
    - You dual-boot with another OS sharing the same EFI.[^2_2][^2_3][^2_1]

For “Debian-based nix’s” in general (Debian, Ubuntu, Mint, etc.), 300–512 MB EFI is usually enough because they don’t store as much in the EFI partition by default.[^2_4][^2_2]

### What to do for your install

- If you are installing Pop!_OS: make the EFI partition about 1 GB FAT32 and mount it at `/boot/efi`.[^2_3][^2_1]
- If you plan to share that EFI with other distros or Windows: 1 GB is strongly recommended so you don’t hit space issues later.[^2_1][^2_2][^2_3]

So: 300–500 MB might work for some Debian-based systems, but for Pop!_OS today, go for roughly 1 GB EFI if you can spare the space.
<span style="display:none">[^2_5][^2_7][^2_8]</span>

<div align="center">⁂</div>

[^2_1]: https://github.com/pop-os/distinst/issues/239

[^2_2]: https://www.reddit.com/r/pop_os/comments/l33nur/minimum_efi_system_partition_size_and_dual/

[^2_3]: https://www.reddit.com/r/linuxquestions/comments/1818h9x/why_does_popos_need_1gb_of_efi/

[^2_4]: https://github.com/pop-os/iso/issues/236

[^2_5]: https://www.reddit.com/r/pop_os/comments/yzbv6k/efi_partition_too_small_for_install/

[^2_6]: https://github.com/pop-os/pop/issues/1431

[^2_7]: https://www.vojtechstruhar.com/blog/037-how-to-dualboot-popos-and-windows/

[^2_8]: https://www.facebook.com/groups/poposlinux/posts/4962496687195980/


---

# Will do and have done 1GB it is. So for the record this gpt Device → Create Partition Table thing on what is that created and what is it's function?

When you choose “Device → Create Partition Table… → gpt” in GParted, you’re creating the disk’s **map** that describes where partitions live and how the firmware/OS should see them.

### What GPT is created on

- It is created on the **whole physical device**, e.g. `/dev/sda`, `/dev/nvme0n1`, or your USB drive as a whole – not on a single partition like `/dev/sda1`.
- Doing this **wipes the existing partition layout** on that device (all partitions on it), then sets it up to use the GPT scheme instead of the old MBR one.


### What its function is

- GPT (GUID Partition Table) is the modern partitioning format used together with UEFI. It:
    - Stores a table of all partitions: their start/end, type (EFI, Linux filesystem, etc.), and unique IDs.
    - Lets UEFI firmware find special partitions like the EFI System Partition so it can boot Pop!_OS.
    - Supports large disks and many partitions cleanly (more than the 4 primary partitions limit of MBR).
    - Keeps backup metadata at the end of the disk, so the layout is more robust against corruption.

So in short: that menu action turned your disk into a UEFI‑friendly GPT disk and laid down the structure that tells Pop!_OS (and the firmware) where your 1 GB EFI partition and other partitions are.
<span style="display:none">[^3_1][^3_2][^3_3][^3_4][^3_5][^3_6]</span>

<div align="center">⁂</div>

[^3_1]: https://www.ionos.com/digitalguide/server/configuration/what-is-a-guid-partition-table-gpt/

[^3_2]: https://en.wikipedia.org/wiki/GUID_Partition_Table

[^3_3]: https://uefi.org/specs/UEFI/2.10/05_GUID_Partition_Table_Format.html

[^3_4]: https://wiki.archlinux.org/title/GPT_fdisk

[^3_5]: https://www.system-rescue.org/disk-partitioning/The-new-GPT-disk-layout/

[^3_6]: https://www.reddit.com/r/archlinux/comments/5chs5r/which_partitiontable_shouldcan_i_use/


---

# It is not visible on the usb at least as far as I can tell...

You’re not supposed to “see” the GPT partition table itself in a file manager, so what you’re noticing is normal.

### Why you don’t see it

- The GPT **partition table** lives in hidden metadata at the start and end of the USB; it isn’t a partition and doesn’t get a drive letter or mount point.
- File managers (Nautilus, Dolphin, Windows Explorer, etc.) only show **partitions with filesystems**, like your 1 GB EFI partition or your ext4 root partition, not the table that describes them.
- After you did “Device → Create Partition Table → gpt”, the only visible things should be whatever partitions you then created: for example:
    - `EFI System Partition` (FAT32, ~1 GB)
    - `ext4` partition for `/`
    - optional swap, etc.


### How to check it’s really there

Since I don’t have direct access to your system, you can verify it yourself from the live session:

- Open GParted, select the USB/device (top right dropdown).
    - At the top it should say something like: `Partition table: gpt`.
- Or in a terminal:
    - `sudo parted -l`
Look for `Partition Table: gpt` on that device.
    - `lsblk` will list the device (e.g. `/dev/sdb`) and show its partitions (`sdb1`, `sdb2`, …).

If GParted shows `gpt` for that USB and you can see your 1 GB FAT32 EFI partition and the root partition there, everything is set up correctly even though the partition *table* itself never appears as a “drive” anywhere.
<span style="display:none">[^4_1][^4_10][^4_2][^4_3][^4_4][^4_5][^4_6][^4_7][^4_8][^4_9]</span>

<div align="center">⁂</div>

[^4_1]: https://ubuntuforums.org/showthread.php?t=2123020

[^4_2]: https://ubuntu-mate.community/t/fixing-a-gpt-partitioned-ntfs-formatted-disk-being-inaccessible-on-windows/16563

[^4_3]: https://www.reddit.com/r/linux4noobs/comments/1ivkvh9/how_to_initialize_hard_disk_with_no_gpt_table/me6g3mg/

[^4_4]: https://www.diskinternals.com/partition-recovery/recover-gpt-partition/

[^4_5]: https://learn.microsoft.com/en-us/answers/questions/3730703/created-a-gpt-partition-disk-while-plugged-into-us

[^4_6]: https://forums.opensuse.org/t/partition-table-not-recognized-in-usb-c-enclosure/143317

[^4_7]: https://www.linux.org/threads/partition-tables-wont-write-to-usb-stick.32684/

[^4_8]: https://bbs.archlinux.org/viewtopic.php?id=174501

[^4_9]: https://www.snbforums.com/threads/guid-partition-table-disk-gpt-mounts-on-usb-2-0-port-but-not-on-usb-3-0-port.33634/

[^4_10]: https://access.redhat.com/solutions/388793

