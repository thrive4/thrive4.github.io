<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# This is turning out to quite a thing ... so flow wise playmedia() sets up song track and init's BASS_ChannelGetInfo and Dim levels As Single Ptr = CAllocate(ci.chans * SizeOf(Single)) once ... first snag levels need to shared or passed some way ... next step a separate setdrc() called via the main program loop x amount of times per second ... could pass min / max level ... maybe .. then new track playmedia gets triggered again but Deallocate(levels) needs to take place could be done in main loop with BASS_ChannelIsActive used for end of track and / or manual key press next / previous track ...

Yes, that flow makes sense, and the cleanest approach is to treat `levels` as **track state** rather than loop state. `BASS_ChannelGetInfo` gives you the channel count for the current handle, and `BASS_ChannelGetLevelEx` can then fill one value per channel using an array sized from `ci.chans`.[^1_1][^1_2]

## Recommended flow

- `playmedia()` opens the new stream.
- Right after `fx1Handle` is valid, call `BASS_ChannelGetInfo(fx1Handle, @ci)` and allocate `levels` once for that track.
- Your periodic `setdrc()` loop only reads levels and updates volume.
- When track changes, free the old buffer before creating the next one.

That avoids repeated allocation in the hot loop and matches the fact that channel count is tied to the stream handle.[^1_3][^1_2]

## Where to store levels

You do need `levels` accessible outside `playmedia()`, so either:

- make it a shared/global pointer, or
- pass it into `setdrc()` by reference, or
- wrap both the handle and buffer in a small shared state structure.

For your current setup, a shared pointer plus a shared `levelChans` integer is probably the simplest. Since `BASS_ChannelGetLevelEx` expects a buffer with enough space for all channels, you should keep both the pointer and the count together.[^1_2]

## Track changes and cleanup

`playmedia()` is the right place to reinitialize because that is where the handle changes. Before replacing `fx1Handle`, free any old `levels` buffer, then create the new stream, call `BASS_ChannelGetInfo`, and allocate a new buffer sized to the new channel count.[^1_2]

If you want to do cleanup from the main loop instead, `BASS_ChannelIsActive` can tell you whether playback is still active or stopped, and it also reports stalled or paused states. For end-of-track handling, though, a `BASS_SYNC_END` sync is usually cleaner than polling `IsActive` every frame.[^1_4]

## Simple structure

```freebasic
dim shared as Single Ptr levels = 0
dim shared as Integer levelChans = 0

sub freeLevels()
    if levels <> 0 then
        Deallocate(levels)
        levels = 0
    end if
    levelChans = 0
end sub

sub initLevels(byval h as DWORD)
    dim as BASS_CHANNELINFO ci
    freeLevels()
    if BASS_ChannelGetInfo(h, @ci) = 0 then exit sub
    if ci.chans <= 0 then exit sub
    levelChans = ci.chans
    levels = CAllocate(levelChans * SizeOf(Single))
end sub
```

Then in `setdrc()`:

```freebasic
if levels = 0 Or levelChans <= 0 then exit sub
if BASS_ChannelGetLevelEx(fx1Handle, levels, 0.3, 0) = 0 then exit sub
```


## Practical note

If you are only handling mono/stereo most of the time, you could simplify further and keep a fixed 2-float buffer, but the channel-count-based version is safer for arbitrary streams.[^1_1][^1_2]

The main thing I’d avoid is allocating and freeing inside the loop. Reinitialize on track change, process in the periodic loop, and let `playmedia()` own the buffer lifecycle.
<span style="display:none">[^1_10][^1_5][^1_6][^1_7][^1_8][^1_9]</span>

<div align="center">⁂</div>

[^1_1]: https://documentation.help/BASS/BASS_ChannelGetLevel.html

[^1_2]: https://github.com/ManagedBass/ManagedBass.DocFX/blob/master/apidoc/Bass/Bass.ChannelGetLevel.md

[^1_3]: http://www.un4seen.com/forum/?topic=13627.0

[^1_4]: https://www.un4seen.com/doc/bass/BASS_ChannelIsActive.html

[^1_5]: https://documentation.help/BASS/documentation.pdf

[^1_6]: https://www.radio42.com/bass/help/html/c3034602-9916-2a02-f21a-63ec100a8959.htm

[^1_7]: http://www.un4seen.com/forum/?topic=16833.0

[^1_8]: https://documentation.help/BASSmix/documentation.pdf

[^1_9]: https://www.un4seen.com/forum/?topic=18134.0

[^1_10]: https://www.scribd.com/document/882149358/bass

