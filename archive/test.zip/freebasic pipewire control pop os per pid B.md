<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# That's good news getting the pid is going to complicated ... I think so : wah@:/media/wah/games/source/audioplayer-bass\$ wpctl status

PipeWire 'pipewire-0' [1.5.85, wah@pop-os, cookie:3804764287]
└─ Clients:
33. WirePlumber                         [1.5.85, wah@pop-os, pid:1483]
37. pipewire                            [1.5.85, wah@pop-os, pid:1485]
47. WirePlumber [export]                [1.5.85, wah@pop-os, pid:1483]
59. cosmic-osd                          [1.5.85, wah@pop-os, pid:1610]
60. cosmic-osd                          [1.5.85, wah@pop-os, pid:1637]
61. cosmic-applets                      [1.5.85, wah@pop-os, pid:1923]
62. xdg-desktop-portal                  [1.5.85, wah@pop-os, pid:1911]
63. system76-scheduler                  [1.5.85, root@pop-os, pid:1388]
73. speech-dispatcher-dummy             [1.5.85, wah@pop-os, pid:11395]
74. PipeWire ALSA [audioplayer]         [1.5.85, wah@pop-os, pid:35130]
79. wpctl                               [1.5.85, wah@pop-os, pid:35273]
84. PipeWire ALSA [audioplayer]         [1.5.85, wah@pop-os, pid:35130] : somehow my app 'audioplayer' is one of them ...

Yes — that output is actually encouraging. Your app is showing up as `PipeWire ALSA [audioplayer]` with `pid:35130`, so you already have the PID you need to target app-specific volume control.

## What to use

For that app, the relevant command should be along the lines of:

```bash
wpctl set-volume --pid 35130 0.8
```

or to mute/unmute just that app:

```bash
wpctl set-mute --pid 35130 1
wpctl set-mute --pid 35130 0
```

That is the PipeWire equivalent of controlling a per-app channel rather than the master sink.

## In your case

Since the app is listed directly in `wpctl status`, you may not need any extra discovery logic at all. You can:

- scan the status output for `PipeWire ALSA [audioplayer]`,
- extract the PID in brackets,
- use that PID for `set-volume --pid ...`.

That should be much simpler than trying to map mixer-style channels the old Windows way.

## Important detail

Your app appears twice in the list, with the same PID. That usually means there may be multiple PipeWire nodes or streams tied to the same process, so PID-based control is the right level to start with. If the volume command affects both entries, that is expected.

## For FreeBASIC

A practical route is:

- run `wpctl status`,
- parse the line containing your app name,
- grab the PID value,
- store it,
- call `wpctl set-volume --pid <pid> ...` for app volume changes.

That should get you very close to the Windows mixer behavior without needing deep PipeWire internals.

---

# Ouch '74. PipeWire ALSA [audioplayer]         [1.5.85, wah@pop-os, pid:35130]' indeed completely overlooked it ... ahhr I overlooked it twice ... got it yeah fortunately they both have the same pid but hey not a separate 'sink' with a volume percentage?

Correct: that entry is not a sink, it’s a **stream/client node** belonging to your app. In PipeWire terms, the sink is the output device, while your app shows up as a client or stream that feeds audio into that sink.

So yes:

- `@DEFAULT_AUDIO_SINK@` is the master output.
- `PipeWire ALSA [audioplayer]` is your app’s audio stream.
- Per-app volume is usually handled by targeting the stream/client, not by creating a separate sink.

If `wpctl status` shows a percentage next to the app entry, that’s the stream’s current volume. If it doesn’t, the value may still be available through the stream node, but not as a separate sink-level slider in the same sense as Windows’ per-app mixer channel.

## What this means for your code

For your FreeBASIC side, the logic is:

- use sink volume commands for global volume,
- use PID-based control for app-specific volume,
- do not expect a separate sink object for each app.

That makes PipeWire a bit different from the old Windows mixer model, but the behavior you want is still there.

---

# Good, good thank you that clarifies just need some mechanism to get the pid via freebasic possibly some open pipe voodoo ... I take it the pids volume is relative to master 'sink' right?

Yes — the per-app PID volume is still relative to the sink’s current gain stage, so it behaves like a stream volume feeding into the master output rather than an independent hardware mixer. In practice, that means the app can be turned up or down within its own range, but the final loudness still depends on the sink/master volume too.[^3_1][^3_2]

## What that means

If the sink is at 50% and the app stream is at 50%, the audible result is effectively lower than if the sink were at 100% with the same app setting. PipeWire separates those two layers: stream volume for the app, sink volume for the output device.[^3_2][^3_1]

## Getting the PID in FreeBASIC

`wpctl status` already prints the PID, so the simplest approach is to parse that text with `Open Pipe`, which FreeBASIC supports for reading a command’s stdout. You can scan for your app name, then extract the `pid:` value from the matching line.[^3_3]

A rough strategy is:

- run `wpctl status`,
- read line by line,
- find the line containing `PipeWire ALSA [audioplayer]`,
- locate `pid:`,
- parse the number after it,
- use `wpctl set-volume --pid <pid> ...`.


## Example parsing idea

```basic
dim as integer f = FreeFile
dim as string ln, pidText
dim as integer pidPos, pid

Open Pipe "wpctl status" For Input As #f
Do Until EOF(f)
    Line Input #f, ln
    if InStr(ln, "PipeWire ALSA [audioplayer]") > 0 then
        pidPos = InStr(ln, "pid:")
        if pidPos > 0 then
            pidText = Mid(ln, pidPos + 4)
            pid = Val(pidText)
            exit do
        end if
    end if
Loop
Close #f
```

Then you can call:

```basic
Shell "wpctl set-volume --pid " & Str(pid) & " 5%-"
```


## Practical note

If you already know your app name at startup, a PID lookup like this is usually enough. If the app restarts and gets a new PID, you’ll need to refresh it, but for a running player it should work fine.

A good fallback is to keep sink volume control as the master fallback and PID volume as the app-specific control path.
<span style="display:none">[^3_10][^3_4][^3_5][^3_6][^3_7][^3_8][^3_9]</span>

<div align="center">⁂</div>

[^3_1]: https://linuxcommandlibrary.com/man/wpctl

[^3_2]: https://github.com/MusicPlayerDaemon/MPD/issues/1588

[^3_3]: https://documentation.help/FreeBASIC/KeyPgOpenPipe.html

[^3_4]: https://gist.github.com/venam/bd453b4fd673ff8abb9323e69f182045

[^3_5]: https://stackoverflow.com/questions/74189415/how-to-change-volume-of-a-specific-application-using-pipewire

[^3_6]: https://www.freebasic.net/forum/viewtopic.php?t=28356

[^3_7]: https://forum.linuxconfig.org/t/volume-on-hyprland-always-100-after-rebooting-works-fine-on-kde/8645

[^3_8]: https://wiki.archlinux.org/title/PipeWire

[^3_9]: https://www.freebasic.net/wiki/wikka.php?wakka=KeyPgOpenCons

[^3_10]: https://pipewire.pages.freedesktop.org/wireplumber/daemon/configuration/configuration_option_types.html

